"""Build a small, shareable bundle of "what we fed the parser, and what came out".

One folder per vendor, each holding a couple of real source artifacts (the HTML
page, or an excerpt of the spreadsheet) next to exactly what our code extracted
from them. The point is that a parsing problem can be diagnosed from the bundle
alone, without needing your machine, your network or your whole dataset.

    python -m rfparts.parse_sample                       # all vendors, 2 each
    python -m rfparts.parse_sample --vendors qorvo marki
    python -m rfparts.parse_sample --per-vendor 3 --offline

GUI: "Create parse sample bundle…" in the Rebuild dataset dialog.

WHAT ENDS UP IN THE ZIP

    README.txt                     what each file is
    environment.txt                versions and resolved paths
    Qorvo/
        01_product-list_ca0021.html        the exact bytes we parsed
        01_parsed.txt                      readable parse report
        01_parsed.json                     the same report, machine-readable
        parts.json                         the part dicts the pipeline emits
    Marki-Microwave/
        01_connectorized_mixers.html       a listing page
        02_datasheet_MM1-0320LBH.html      one part's datasheet page
        ...
    Analog-Devices-parametric/
        01_ADIParametricSearchMixers_excerpt.csv
        ...

DELIBERATE CHOICES

  * Only a couple of part numbers per vendor. A full walk is neither necessary to
    show a parsing fault nor reasonable to send.
  * Cached pages are reused, so a bundle usually costs zero requests. --offline
    refuses to fetch at all and reports what was unavailable.
  * Spreadsheets are excerpted to a CSV of the header, the units row and a few
    data rows -- and the part-number column is written as its RAW FORMULA, since
    that column is =HYPERLINK(...) and reading it wrongly is a real failure mode
    worth being able to see.
  * parts.json holds the dicts as the pipeline would emit them, specs included,
    so extracted values can be compared against the source side by side.
"""
from __future__ import annotations

import argparse
import json
import platform
import re
import sys
import time
import zipfile
from pathlib import Path

try:
    from . import parse_debug, vendor_catalogs as vc
    from .paths import (ADI_PARAMETRICS, DATA_ROOT, EVERYTHING_RF, NEW_SOURCES,
                        PARSE_DEBUG_DIR)
except ImportError:                                     # loose-script fallback
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from rfparts import parse_debug, vendor_catalogs as vc   # type: ignore
    from rfparts.paths import (                              # type: ignore
        ADI_PARAMETRICS, DATA_ROOT, EVERYTHING_RF, NEW_SOURCES,
        PARSE_DEBUG_DIR)

SAMPLE_VENDORS = ["qorvo", "macom", "skyworks", "marki", "adi_parametric",
                  "adi_space", "everythingrf"]

_FOLDER = {
    "qorvo": "Qorvo", "macom": "MACOM", "skyworks": "Skyworks",
    "marki": "Marki-Microwave", "adi_parametric": "Analog-Devices-parametric",
    "adi_space": "Analog-Devices-space-portfolio",
    "everythingrf": "everythingRF",
}


def _safe(name, limit=70):
    return re.sub(r"[^A-Za-z0-9._+-]", "_", str(name))[:limit] or "item"


class Bundle:
    """Accumulates files in memory, then writes one zip."""

    def __init__(self, progress=None):
        self.files = {}                 # arcname -> bytes
        self.say = progress or print
        self.notes = []

    def add_bytes(self, arcname, data):
        if isinstance(data, str):
            data = data.encode("utf-8", "replace")
        self.files[arcname] = data
        return arcname

    def add_text(self, arcname, text):
        return self.add_bytes(arcname, text)

    def write(self, out_path):
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
            for arc in sorted(self.files):
                z.writestr(arc, self.files[arc])
        return out_path


# ------------------------------------------------------------ spreadsheets
def excerpt_workbook(path, rows_wanted=6):
    """Header + units + a few data rows as CSV.

    The part-number column is emitted as its RAW FORMULA (data_only=False),
    because it is =HYPERLINK("url","PN") and reading that column with
    data_only=True returns blanks -- a failure worth being able to see in the
    sample rather than having to describe."""
    import csv
    import io
    try:
        import openpyxl
    except ImportError:
        return None, "openpyxl not installed"
    try:
        wb = openpyxl.load_workbook(str(path), read_only=True, data_only=False)
    except Exception as e:
        return None, f"{type(e).__name__}: {e}"
    sheet = ("Web Display" if "Web Display" in wb.sheetnames
             else wb.sheetnames[0])
    ws = wb[sheet]
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow([f"# source: {Path(path).name}  sheet: {sheet}"])
    w.writerow([f"# NOTE: column values are RAW (formulas not evaluated)"])
    kept = 0
    header_seen = False
    for i, row in enumerate(ws.iter_rows(values_only=True)):
        cells = ["" if c is None else str(c) for c in row]
        if not any(cells):
            continue
        w.writerow(cells)
        kept += 1
        low = " ".join(cells).lower()
        if "part number" in low or "generic part number" in low:
            header_seen = True
            continue
        if header_seen and kept >= rows_wanted + 3:
            break
        if kept > 40:
            break
    wb.close()
    return out.getvalue(), None


def _sample_adi(bundle, kind, per_vendor):
    """Excerpt one workbook and record what our parser makes of it."""
    folder = _FOLDER[kind]
    roots = ([ADI_PARAMETRICS, NEW_SOURCES, DATA_ROOT.parent / "Sources"]
             if kind == "adi_parametric"
             else [NEW_SOURCES, DATA_ROOT.parent / "Sources", ADI_PARAMETRICS])
    pattern = ("ADIParametricSearch*.xlsx" if kind == "adi_parametric"
               else "*space*portfolio*.xlsx")
    found = []
    for r in roots:
        r = Path(r)
        if r.is_dir():
            found += [p for p in r.rglob(pattern) if not p.name.startswith("~$")]
    found = sorted(set(found))
    if not found:
        bundle.notes.append(f"{folder}: no workbook matching {pattern} found "
                            f"under {', '.join(str(x) for x in roots)}")
        return 0
    n = 0
    for i, wbpath in enumerate(found[:per_vendor], 1):
        csv_text, err = excerpt_workbook(wbpath)
        if err:
            bundle.notes.append(f"{folder}: {wbpath.name}: {err}")
            continue
        stem = f"{i:02d}_{_safe(wbpath.stem)}"
        bundle.add_text(f"{folder}/{stem}_excerpt.csv", csv_text)
        report = parse_debug.inspect_path(wbpath)
        # keep the report small: a couple of parts is the point
        parts = report.get("parts", [])[:per_vendor]
        trimmed = dict(report)
        trimmed["parts"] = parts
        trimmed["parts_total_in_source"] = len(report.get("parts", []))
        bundle.add_text(f"{folder}/{stem}_parsed.txt",
                        parse_debug.render(trimmed, max_parts=per_vendor,
                                           show_rejects=10))
        bundle.add_text(f"{folder}/{stem}_parsed.json",
                        json.dumps(trimmed, indent=2, default=str))
        n += 1
        bundle.say(f"      {folder}: {wbpath.name} "
                   f"({trimmed['parts_total_in_source']} parts in source, "
                   f"{len(parts)} sampled)")
    # what the pipeline would actually emit for a couple of parts
    emitted = []
    try:
        mod = (__import__("rfparts.adi_parametric_ingest", fromlist=["x"])
               if kind == "adi_parametric"
               else __import__("rfparts.adi_space_ingest", fromlist=["x"]))
        mod.ingest(found[0].parent if kind == "adi_parametric" else found[0],
                   dry_run=True, verbose=False, progress=lambda m: None,
                   part=lambda r: emitted.append(r) if len(emitted) < per_vendor
                   else None)
    except Exception as e:
        bundle.notes.append(f"{folder}: pipeline emit failed: "
                            f"{type(e).__name__}: {e}")
    if emitted:
        bundle.add_text(f"{folder}/parts.json",
                        json.dumps(emitted[:per_vendor], indent=2, default=str))
    return n


def _sample_everythingrf(bundle, per_vendor):
    folder = _FOLDER["everythingrf"]
    roots = [Path(EVERYTHING_RF), Path(NEW_SOURCES)]
    pages = []
    for r in roots:
        if r.is_dir():
            pages += sorted(r.rglob("*.html"))[:per_vendor]
            pages += sorted(r.rglob("*.htm"))[:per_vendor]
        if len(pages) >= per_vendor:
            break
    pages = pages[:per_vendor]
    if not pages:
        bundle.notes.append(f"{folder}: no local HTML found under "
                            f"{', '.join(str(r) for r in roots)}")
        return 0
    emitted = []
    for i, page in enumerate(pages, 1):
        raw = page.read_text(encoding="utf-8", errors="replace")
        stem = f"{i:02d}_{_safe(page.stem)}"
        bundle.add_text(f"{folder}/{stem}.html", raw)
        # what our own everythingRF parser makes of it
        try:
            from . import erf_space_ingest as erf
            rows = list(erf.parse_page(raw, page.parent.name))
            summary = []
            for part in rows[:per_vendor]:
                summary.append({
                    "mpn": part.get("mpn"), "vendor": part.get("vendor"),
                    "category": part.get("category"),
                    "subcategory": part.get("subcategory"),
                    "variant": part.get("variant"),
                    "reason": part.get("reason"),
                    "specs": erf.flat_specs(part),
                })
            bundle.add_text(
                f"{folder}/{stem}_parsed.json",
                json.dumps({"source": str(page),
                            "folder_name": page.parent.name,
                            "parts_found_on_page": len(rows),
                            "sampled": summary}, indent=2, default=str))
            lines = [f"everythingRF page: {page}",
                     f"folder name (decides qualified vs grade): {page.parent.name}",
                     f"parts found on this page: {len(rows)}", ""]
            for sm in summary:
                lines.append(f"  {sm['mpn']}  [{sm['variant']}]  "
                             f"{sm['category']}/{sm['subcategory']}")
                lines.append(f"    reason: {sm['reason']}")
                for k, v in sorted((sm["specs"] or {}).items()):
                    lines.append(f"    {k:<22} {v}")
                lines.append("")
            bundle.add_text(f"{folder}/{stem}_parsed.txt", "\n".join(lines))
            emitted.extend(summary)
            bundle.say(f"      {folder}: {page.name} "
                       f"({len(rows)} part(s) on the page)")
        except Exception as e:
            bundle.notes.append(f"{folder}: {page.name}: "
                                f"{type(e).__name__}: {e}")
    if emitted:
        bundle.add_text(f"{folder}/parts.json",
                        json.dumps(emitted[:per_vendor * 2], indent=2,
                                   default=str))
    return len(pages)


# ---------------------------------------------------------------- web vendors
_SEEDS = {
    "qorvo": ["https://www.qorvo.com/products/product-list?categoryID=ca0021",
              "https://www.qorvo.com/products/product-list?categoryID=ca0118"],
    "macom": ["https://www.macom.com/products"],
    "skyworks": ["https://www.skyworksinc.com/en/Products/Amplifiers",
                 "https://www.skyworksinc.com/en/Products"],
    "marki": ["https://markimicrowave.com/products/surface-mount/amplifiers/",
              "https://markimicrowave.com/products/connectorized/mixers/"],
}


def _sample_web(bundle, key, per_vendor, fetcher, offline):
    folder = _FOLDER[key]
    got = 0
    parts_seen = []
    for i, url in enumerate(_SEEDS.get(key, [])[:per_vendor], 1):
        html = None
        source = "cache"
        cache_path = fetcher._cache_path(url)
        if cache_path.exists():
            html = cache_path.read_text(encoding="utf-8", errors="replace")
        elif offline:
            bundle.notes.append(f"{folder}: {url} not cached and --offline set")
            continue
        else:
            try:
                html, source = fetcher.get(url)
            except Exception as e:
                bundle.notes.append(f"{folder}: {url}: "
                                    f"{type(e).__name__}: {e}")
                continue
        stem = f"{i:02d}_{_safe(url.split('//')[-1].replace('/', '_'))}"
        bundle.add_bytes(f"{folder}/{stem}.html", html)
        report = parse_debug.inspect_source(html, url, vendor=key)
        parts = report.get("parts", [])
        trimmed = dict(report)
        trimmed["parts_total_in_source"] = len(parts)
        trimmed["parts"] = parts[:per_vendor]
        bundle.add_text(f"{folder}/{stem}_parsed.txt",
                        parse_debug.render(trimmed, max_parts=per_vendor,
                                           show_rejects=10))
        bundle.add_text(f"{folder}/{stem}_parsed.json",
                        json.dumps(trimmed, indent=2, default=str))
        parts_seen.extend(parts[:per_vendor])
        got += 1
        bundle.say(f"      {folder}: {url[:56]} [{source}] "
                   f"({len(parts)} part(s) parsed, {len(parts[:per_vendor])} sampled)")

    # a per-part page for the vendors whose specs live there
    if key in ("marki", "skyworks") and parts_seen:
        for rec in parts_seen[:per_vendor]:
            purl = rec.get("product_url") or ""
            if key == "marki" and purl:
                purl = purl.rstrip("/") + "/datasheet/"
            if not purl:
                continue
            cache_path = fetcher._cache_path(purl)
            if cache_path.exists():
                html = cache_path.read_text(encoding="utf-8", errors="replace")
            elif offline:
                bundle.notes.append(f"{folder}: {purl} not cached, --offline")
                continue
            else:
                try:
                    html, _src = fetcher.get(purl)
                except Exception as e:
                    bundle.notes.append(f"{folder}: {purl}: "
                                        f"{type(e).__name__}: {e}")
                    continue
            pn = _safe(rec.get("mpn", "part"))
            bundle.add_bytes(f"{folder}/part_{pn}.html", html)
            rep = parse_debug.inspect_source(html, purl, vendor=key)
            bundle.add_text(f"{folder}/part_{pn}_parsed.txt",
                            parse_debug.render(rep, max_parts=3,
                                               show_rejects=6))
            bundle.add_text(f"{folder}/part_{pn}_parsed.json",
                            json.dumps(rep, indent=2, default=str))
            bundle.say(f"      {folder}: part page {pn}")
    if parts_seen:
        bundle.add_text(f"{folder}/parts.json",
                        json.dumps(parts_seen[:per_vendor * 2], indent=2,
                                   default=str))
    return got


# -------------------------------------------------------------------- driver
def build_bundle(vendors=None, per_vendor=2, out_path=None, progress=None,
                 offline=False, rate=1.0):
    say = progress or print
    vendors = [v for v in (vendors or SAMPLE_VENDORS) if v in SAMPLE_VENDORS]
    bundle = Bundle(progress=say)
    started = time.time()
    say("=" * 62)
    say(f"PARSE SAMPLE BUNDLE -- {len(vendors)} vendor(s), "
        f"{per_vendor} sample(s) each")
    say(f"  {'offline (cache only)' if offline else 'cache first, fetch if needed'}")
    say("=" * 62)
    fetcher = vc.Fetcher(rate=rate, progress=lambda m: None)
    counts = {}
    for key in vendors:
        say(f"\n  {_FOLDER[key]}")
        try:
            if key in ("adi_parametric", "adi_space"):
                counts[key] = _sample_adi(bundle, key, per_vendor)
            elif key == "everythingrf":
                counts[key] = _sample_everythingrf(bundle, per_vendor)
            else:
                counts[key] = _sample_web(bundle, key, per_vendor, fetcher,
                                          offline)
        except Exception as e:
            counts[key] = 0
            bundle.notes.append(f"{_FOLDER[key]}: FAILED "
                                f"{type(e).__name__}: {e}")
            say(f"      FAILED: {type(e).__name__}: {e}")

    # ---- environment + readme
    env = [
        "rfparts parse sample bundle",
        f"generated       {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"python          {sys.version.split()[0]}",
        f"platform        {platform.platform()}",
        f"samples/vendor  {per_vendor}",
        f"offline         {offline}",
        "",
        "resolved paths",
    ]
    try:
        from .paths import describe
        env.append(describe())
    except Exception:
        env.append("  (paths.describe unavailable)")
    for mod in ("openpyxl", "bs4", "pdfplumber", "pypdf"):
        try:
            m = __import__(mod)
            env.append(f"  {mod:<12} {getattr(m, '__version__', 'present')}")
        except ImportError:
            env.append(f"  {mod:<12} MISSING")
    env.append("")
    env.append("per-vendor sample counts")
    for k in vendors:
        env.append(f"  {_FOLDER[k]:<34} {counts.get(k, 0)}")
    if bundle.notes:
        env.append("")
        env.append("notes / things that could not be sampled")
        for n in bundle.notes:
            env.append(f"  - {n}")
    bundle.add_text("environment.txt", "\n".join(env))

    bundle.add_text("README.txt", f"""rfparts parse sample bundle
===========================
generated {time.strftime('%Y-%m-%d %H:%M:%S')}

One folder per vendor. In each folder:

  NN_<something>.html        the exact source bytes our parser was given
  NN_<something>_excerpt.csv for spreadsheets: header + units + a few data rows,
                             with the part-number column as its RAW FORMULA
                             (it is =HYPERLINK(...), and reading it wrongly
                             yields blank part numbers)
  NN_..._parsed.txt          readable parse report: tables found, header ->
                             spec-key mapping, columns that were IGNORED, each
                             parsed value beside the cell it came from, and every
                             rejected row with its reason
  NN_..._parsed.json         the same report, machine-readable
  part_<PN>.html             for Marki/Skyworks, one part's own page, where the
                             specs actually live
  parts.json                 the part dicts the pipeline emits, specs included

Only {per_vendor} sample(s) per vendor: enough to show a parsing fault, small
enough to send. Cached pages were reused where available, so this usually costs
no requests.

environment.txt records versions, resolved paths, per-vendor counts, and anything
that could not be sampled and why.
""")

    out_path = Path(out_path or (PARSE_DEBUG_DIR /
                                 f"rfparts_parse_samples_"
                                 f"{time.strftime('%Y%m%d_%H%M')}.zip"))
    written = bundle.write(out_path)
    total = sum(counts.values())
    say(f"\n  {len(bundle.files)} file(s) from {total} sample source(s)")
    if bundle.notes:
        say(f"  {len(bundle.notes)} note(s) recorded in environment.txt")
    say(f"  -> {written}")
    say(f"  ({written.stat().st_size / 1024:.0f} kB, "
        f"{time.time() - started:.1f}s)")
    return written


def main(argv=None):
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--vendors", nargs="*", metavar="V",
                    help="subset of: " + " ".join(SAMPLE_VENDORS))
    ap.add_argument("--per-vendor", type=int, default=2)
    ap.add_argument("--out", help="output .zip path")
    ap.add_argument("--offline", action="store_true",
                    help="use only already-cached pages; never fetch")
    ap.add_argument("--rate", type=float, default=1.0)
    args = ap.parse_args(argv)
    build_bundle(vendors=args.vendors, per_vendor=args.per_vendor,
                 out_path=args.out, offline=args.offline, rate=args.rate)
    return 0


if __name__ == "__main__":
    sys.exit(main())
