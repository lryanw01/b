"""Space-qualification evidence engine.

Classifies a part as qualified / hi_rel / qualifiable / None from WEIGHTED,
INDIVIDUALLY-RECORDED evidence, instead of one regex over a text blob. Every
returned classification carries its evidence rows so the GUI/report can show
*why* — and so "qualifiable" reads as "credible upscreen candidate, here's the
construction case," never as a certification.

The taxonomy encodes what actually makes a part space-qualifiable:

  QUALIFIED  — a hard program listing: MIL-PRF-38534 Class K, MIL-PRF-38535
               Class V / QML-V, MIL-PRF-19500 JANS, ESCC/ESA QPL, S-level SMD,
               or characterized rad-hardness (TID + SEE data). Vendor "space
               qualified" prose counts but at lower weight than a QML listing.

  HI_REL     — one screening step down: Class H / Class Q / JANTX(V) /
               MIL-STD-883 screening / hermetic + full mil temp.

  QUALIFIABLE — additive construction evidence that an upscreen flow (PIND,
               fine/gross leak, temp cycle, burn-in, DPA per EEE-INST-002 or a
               38534-K-like flow) has something to work with:
                 + hermetic / metal-ceramic cavity package   (screenable: leak,
                   PIND, internal water vapor all become meaningful)
                 + passive topology                          (no junctions ->
                   inherent TID/SEL tolerance; qual reduces to construction)
                 + thin-film / LTCC / core-&-wire build      (space-heritage
                   construction classes)
                 + -55/+125 C operating range                (already mil temp)
                 + no pure tin (Au or SnPb finish)           (whisker rule)
                 + vendor runs an in-house hi-rel flow
                 + outgassing data (ASTM E595 TML<1 CVCM<0.1)
                 - plastic overmold / pure tin / electrolytics / moving parts

Vendor-level facts from partdb.vendors (learned when the crawler passes a
vendor's Hi-Rel/Space program page) contribute reduced-weight evidence to every
part from that domain — the generalization of v1's hard-coded Mini-Circuits
AN00-018 assumption.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

# ---------------------------------------------------------------------------
# Evidence patterns. Each entry: (signal_name, weight, tier_hint, regex).
# tier_hint: 'qualified' | 'hi_rel' | None (None = feeds the qualifiable score)
# ---------------------------------------------------------------------------

_E = []


def _sig(name, weight, tier, pattern):
    _E.append((name, weight, tier, re.compile(pattern, re.I)))


# --- hard qualification listings -------------------------------------------
_sig("mil-prf-38534-class-k", 10, "qualified",
     r"mil[-\s]?prf[-\s]?38534[^.\n]{0,40}class\s*k\b|class\s*k\b[^.\n]{0,40}38534|\bclass\s*k\s+hybrid")

_sig("qml-v", 10, "qualified",
     r"\bqml[-\s]?v\b|mil[-\s]?prf[-\s]?38535[^.\n]{0,40}class\s*v\b")

_sig("qml-k", 10, "qualified", r"\bqml[-\s]?k\b")

_sig("jans", 9, "qualified", r"\bjans\b")

_sig("escc-esa", 9, "qualified",
     r"\bescc\b[^.\n]{0,30}(?:qualified|qpl|9000)|\besa\b[^.\n]{0,20}qualified")

_sig("s-level", 8, "qualified", r"\bs[-\s]?level\b|space\s*level\s*screen")

_sig("rad-hard-tested", 7, "qualified",
     r"(?:\btid\b|total\s*(?:ionizing\s*)?dose)[^.\n]{0,50}\d+\s*krad|rad[-\s]?hard(?:ened)?\s*(?:to|assurance)")

# Aggregator product pages (everythingRF and kin) render an explicit
# "Space Qualified: Yes" attribute — a structured field, not prose, so it
# earns a hard-signal weight of its own.
_sig("aggregator-space-field", 9, "qualified",
     r"space\s*qualified\s*[:\-–]?\s*(?:yes|true)\b")

# Explicit negative: "Space Qualified: No" is an aggregator saying this part
# is NOT space grade. When present, prose-level space-claim signals are
# suppressed in classify() — without this, everythingRF's COTS majority would
# all classify qualified off the field LABEL alone.
_SPACE_FIELD_NO = re.compile(r"space\s*qualified\s*[:\-–]?\s*no\b", re.I)

# Prose "space qualified"/"flight proven" wording is evidence, NOT a tier:
# vendors link their space product line from every page's footer (JFW's
# footer put the words "Space Qualified" on literally every switch page, so
# the whole catalog tiered qualified). Hard signals (QML/38534-K/ESCC/S-level,
# the aggregator Yes-field, a space-catalog or SATNow listing) set the tier;
# this only feeds the qualifiable score.
_sig("vendor-space-claim", 3, None,
     r"space[-\s]?(?:qualified|grade|flight)|flight[-\s]?(?:heritage|proven|qualified)")

# --- hi-rel listings --------------------------------------------------------
_sig("mil-prf-38534-class-h", 6, "hi_rel",
     r"38534[^.\n]{0,40}class\s*h\b|class\s*h\b[^.\n]{0,40}38534|\bclass\s*h\s+hybrid")

_sig("qml-q", 6, "hi_rel", r"\bqml[-\s]?q\b|38535[^.\n]{0,40}class\s*q\b")

_sig("jantx", 5, "hi_rel", r"\bjantxv?\b")

_sig("mil-std-883-screened", 4, "hi_rel",
     r"mil[-\s]?std[-\s]?883[^.\n]{0,40}(?:screen|method|compliant|tested)")

# Boilerplate "hi-rel"/"high reliability" wording is marketing on half the
# RF industry's pages — it feeds the qualifiable score, but a bare mention
# must NOT set the hi_rel tier by itself (it put 428 of ~640 stored parts,
# including plain Marki COTS, into hi_rel).
_sig("hirel-generic", 1.5, None, r"\bhi[-\s]?rel(?:iability)?\b")

# --- qualifiable construction evidence (positive) ---------------------------
_sig("hermetic-package", 3.0, None,
     r"hermetic(?:ally)?\s*(?:sealed)?|glass[-\s]?to[-\s]?metal\s*seal|seam[-\s]?(?:seal|weld)")

_sig("ceramic-thinfilm-ltcc", 2.0, None,
     r"\bltcc\b|thin[-\s]?film\s*(?:on\s*)?(?:alumina|ceramic|quartz)?|ceramic\s*(?:substrate|package|construction)|core\s*&?\s*wire")

_sig("mil-temp-range", 1.5, None,
     r"-\s*55\s*(?:°\s*C|C\b)[^.\n]{0,25}\+?\s*(?:125|150)\s*(?:°\s*C|C\b)")

_sig("no-pure-tin", 1.5, None,
     r"gold[-\s]?plated?\s*(?:leads?|pins?|contacts?)|\bAu\s*(?:plat|finish)|sn\s*pb\b|tin[-\s]?lead|whisker[-\s]?(?:free|mitigat)")

_sig("outgassing-data", 1.0, None,
     r"astm\s*e\s*595|outgassing[^.\n]{0,40}(?:tml|cvcm|data|tested)|low[-\s]?outgassing")

_sig("pind-compatible", 1.0, None,
     r"\bpind\b|particle\s*impact\s*noise")

_sig("dpa-available", 0.5, None,
     r"\bdpa\b|destructive\s*physical\s*analysis")

_sig("no-prohibited-materials", 0.5, None,
     r"cadmium[-\s]?free|zinc[-\s]?free|rohs[^.\n]{0,20}exempt")

# --- application/market targeting -------------------------------------------
# A datasheet listing Space (or satellite/satcom) among its APPLICATIONS is the
# manufacturer stating the part is intended for space use. That is not a
# qualification by itself, but it is a strong upscreen signal: weight is set
# just above QUALIFIABLE_THRESHOLD so this alone yields "upscreen?", and it
# tiers higher as soon as construction evidence (hermetic, GaAs, mil-temp)
# stacks on top.
_sig("application-space", 4.5, None,
     r"application[s]?\s*[:\-–][^.\n]{0,120}\bspace\b|"
     r"\bspace\b[^.\n]{0,30}application|"
     r"markets?\s*[:\-–][^.\n]{0,120}\bspace\b|"
     r"(?:designed|suitable|intended)\s+for[^.\n]{0,40}\bspace\b|"
     r"satellite\s*(?:communications?|payloads?|applications?|systems?)|"
     r"\bsatcom\b|\bnew\s*space\b|\bleo\b\s*(?:constellation|satellite)")

# --- semiconductor technology evidence -------------------------------------
# Radiation physics by process, encoded as construction evidence:
#   GaAs pHEMT/MESFET: no gate oxide -> negligible TID charge trapping; no
#     parasitic thyristor -> immune to SEL. The classic rad-tolerant RF process.
#   GaN HEMT: similar oxide-free story, wide bandgap; strong TID tolerance.
#   InP HBT/HEMT: comparable; common in space mmWave.
#   CMOS/SOI control or bias logic: gate oxides accumulate TID, bulk CMOS can
#     latch up (SEL) -- a CMOS driver inside an otherwise-passive part is often
#     THE component that fails first and the exact thing an upscreen can't fix
#     without a die swap.
_sig("gaas-process", 1.5, None,
     r"\bGaAs\b|gallium\s*arsenide|\bpHEMT\b|\bMESFET\b")

_sig("gan-process", 1.0, None,
     r"\bGaN\b|gallium\s*nitride")

_sig("inp-process", 1.0, None,
     r"\bInP\b|indium\s*phosphide")

_sig("no-active-bias", 0.5, None,
     r"self[-\s]?biased|no\s*(?:external\s*)?bias\s*(?:circuit|network|required)|"
     r"internally\s*matched")

_sig("cmos-control-logic", -1.5, None,
     r"\bCMOS\b[^.\n]{0,40}(?:driver|logic|control|decoder|interface)|"
     r"(?:driver|logic|control)[^.\n]{0,25}\bCMOS\b|\bTTL\b[^.\n]{0,20}(?:driver|compatible)")

_sig("soi-charge-pump", -1.0, None,
     r"\bSOI\b[^.\n]{0,30}(?:switch|driver)|charge\s*pump|negative\s*voltage\s*generator")

# --- qualifiable construction evidence (negative) ---------------------------
_sig("plastic-overmold", -2.0, None,
     r"plastic\s*(?:encapsulat|overmold|package)|epoxy\s*mold|\bpqfn\b|molded\s*plastic")

_sig("pure-tin-finish", -3.0, None,
     r"(?:matte|pure|bright)\s*tin\s*(?:finish|plat)|100\s*%\s*(?:matte\s*)?tin\b")

_sig("electrolytic-caps", -2.0, None, r"electrolytic\s*capacitor")

_sig("moving-parts", -10.0, None, r"\bfan[-\s]?cooled\b|mechanical\s*relay")

# Qualified-variant pointers: a COTS part advertising its space-grade sibling.
_VARIANT = re.compile(
    r"(?:space|class\s*k|qml|hi[-\s]?rel)\s*(?:version|variant|option|grade)"
    r"[^.\n]{0,60}?([A-Z0-9][A-Z0-9\-/+]{3,})", re.I)

_PASSIVE_CATEGORIES = {
    "attenuator", "filter", "coupler", "divider", "termination", "dc_block",
    "bias_tee", "equalizer", "balun", "connector", "cable", "waveguide",
    "phase_shifter", "limiter",
}

QUALIFIABLE_THRESHOLD = 4.0


@dataclass
class QualResult:
    tier: str | None                 # 'qualified' | 'hi_rel' | 'qualifiable' | None
    score: float
    evidence: list                   # [(signal, weight, snippet), ...]
    variant_hint: str | None = None

    def summary(self):
        if not self.tier:
            return "—"
        ev = ", ".join(f"{s} {'+' if w >= 0 else ''}{w:g}"
                       for s, w, _ in self.evidence[:5])
        label = {"qualified": "space-qual", "hi_rel": "hi-rel",
                 "qualifiable": "upscreen?"}[self.tier]
        return f"{label} ({ev} — score {self.score:g})"


def _snippet(text, match, span=60):
    a = max(0, match.start() - span)
    b = min(len(text), match.end() + span)
    return re.sub(r"\s+", " ", text[a:b]).strip()


def classify(text, *, category=None, vendor_facts=None,
             page_text="", source_url=""):
    """Classify one part from its datasheet text (+ optionally its product page).

    Returns a QualResult. Hard listings win outright; otherwise the additive
    construction score decides `qualifiable`. `vendor_facts` (partdb.vendor_facts)
    contributes reduced-weight domain-level evidence.
    """
    blob = f"{text}\n{page_text}"
    evidence = []
    best_tier = None
    tier_rank = {"qualified": 2, "hi_rel": 1}
    score = 0.0

    space_field_no = bool(_SPACE_FIELD_NO.search(blob))
    for name, weight, tier, pat in _E:
        if space_field_no and name in ("aggregator-space-field",
                                       "vendor-space-claim"):
            continue
        m = pat.search(blob)
        if not m:
            continue
        evidence.append((name, weight, _snippet(blob, m)))
        if tier:
            if tier_rank.get(tier, 0) > tier_rank.get(best_tier, 0):
                best_tier = tier
        else:
            score += weight

    # Category-level physics: passive topology is construction evidence even
    # when the datasheet never says the word "passive".
    if category in _PASSIVE_CATEGORIES:
        evidence.append(("passive-topology", 2.0,
                         f"category '{category}' has no active junctions"))
        score += 2.0

    # Vendor-level facts, at reduced weight.
    vf = vendor_facts or {}
    if vf.get("hirel_program"):
        evidence.append(("vendor-hirel-flow", 1.5,
                         f"vendor {vf.get('name', '')} operates a hi-rel/upscreen flow"))
        score += 1.5
    if vf.get("outgassing_published"):
        evidence.append(("vendor-outgassing-data", 0.5,
                         "vendor publishes outgassing data"))
        score += 0.5

    variant = None
    vm = _VARIANT.search(blob)
    if vm:
        variant = vm.group(1)
        evidence.append(("qualified-variant-pointer", 0.0, _snippet(blob, vm)))

    if best_tier:
        tier = best_tier
    elif score >= QUALIFIABLE_THRESHOLD:
        tier = "qualifiable"
    else:
        tier = None

    evidence.sort(key=lambda e: -abs(e[1]))
    return QualResult(tier=tier, score=round(score, 2), evidence=evidence,
                      variant_hint=variant)


# --- vendor program-page detector (drives partdb.put_vendor_fact) ----------

_PROGRAM_PAGE = re.compile(
    r"(?:hi[-\s]?rel|space)\s*(?:products?|program|screening|solutions)|"
    r"upscreen|environmental\s*screening\s*services|class\s*k\s*capabilit", re.I)


def looks_like_hirel_program_page(html_text):
    """True when a crawled page reads like a vendor hi-rel/space program page.
    The crawler calls this and records vendors.hirel_program=1 on a hit."""
    return bool(_PROGRAM_PAGE.search(html_text or ""))
