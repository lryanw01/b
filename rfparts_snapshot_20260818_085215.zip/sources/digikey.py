"""DigiKey Product Information V4 adapter (strategy: api).

Live, credentialed source for price / stock / lead / datasheet plus whatever RF
parameters DigiKey publishes. It is *opt-in by credentials*: with no client ID
/ secret in the environment it logs once and returns an empty list, so a default
install behaves exactly as before.

Auth is OAuth 2.0 two-legged (client-credentials) — no user login — which is the
flow DigiKey documents for Product Information V4. The bearer token is cached to
disk with its expiry and reused across runs (a token is an auth credential, not
DigiKey Data). Search *responses* are cached in memory for the life of the
process only and never written to disk: the API User Agreement (sec. 5.1) forbids
using the API to build your own database of DigiKey Data, so product records are
kept transiently just to avoid duplicate calls within a single run.

Results are restricted to DigiKey's "RF and Wireless" family: every product whose
category name does not start with "RF" is dropped, which removes the coax
connectors / logic-switch ICs that a bare keyword search otherwise returns.

Credentials / config (environment):
    DIGIKEY_CLIENT_ID        OAuth client id      (required)
    DIGIKEY_CLIENT_SECRET    OAuth client secret  (required)
    DIGIKEY_SANDBOX=1        use the sandbox host (default: production)
    DIGIKEY_LOCALE_SITE      X-DIGIKEY-Locale-Site header, e.g. US (optional)
    DIGIKEY_LOCALE_CURRENCY  currency, e.g. USD (optional)
    RFPARTS_DIGIKEY_LIMIT    products per call, max 50  (default 50)
    DIGIKEY_CATEGORY_ID      optional: restrict the search server-side to this
                             DigiKey category id (get it from the Categories
                             endpoint / debug_sources.py); off by default

Rate limits are roughly 120 requests/minute and 1000/day for standard products,
so the adapter makes at most one keyword call per search and asks for the maximum
50 records per call.

Product Information V4 field names are accessed defensively (several fallback
keys) so the adapter tolerates minor V3/V4 shape differences.
"""
import json
import os
import re
import threading
import time
from urllib.parse import quote

import requests

from .. import fetch
from ..registry import CATEGORY_SYNONYMS, DATA, synonyms

PROD_HOST = "https://api.digikey.com"
SANDBOX_HOST = "https://sandbox-api.digikey.com"

TOKEN_CACHE = DATA / "digikey_token.json"
# Legacy on-disk product cache; no longer written. Removed on import so stale
# DigiKey Data doesn't linger (see API User Agreement sec. 5.1).
_LEGACY_SEARCH_CACHE = DATA / "digikey_search_cache.json"

TIMEOUT = 20
MAX_RETRIES = 3
RETRY_STATUS = {429, 500, 502, 503, 504}

# In-memory, process-lifetime response cache: avoids duplicate identical calls
# within one run (e.g. GUI re-search) without persisting product data to disk.
_RESPONSE_CACHE = {}

_LOCK = threading.RLock()
_NO_CREDS_LOGGED = False

try:
    if _LEGACY_SEARCH_CACHE.exists():
        _LEGACY_SEARCH_CACHE.unlink()
except OSError:
    pass


def _host():
    return SANDBOX_HOST if os.environ.get("DIGIKEY_SANDBOX") else PROD_HOST


def _creds():
    return (os.environ.get("DIGIKEY_CLIENT_ID", "").strip(),
            os.environ.get("DIGIKEY_CLIENT_SECRET", "").strip())


def _limit():
    try:
        return max(1, min(50, int(os.environ.get("RFPARTS_DIGIKEY_LIMIT", "50"))))
    except ValueError:
        return 50


def _ttl():
    return 0  # deprecated: responses are cached in memory only, never on disk


# --- injectable transport (tests replace _request) -----------------------
def _request(method, url, headers=None, data=None, json_body=None):
    """Single HTTP call. Returns (status_code, parsed_json_or_None). Never raises
    for HTTP errors; only transport exceptions propagate to the retry loop."""
    r = requests.request(method, url, headers=headers, data=data, json=json_body,
                         timeout=TIMEOUT)
    body = None
    try:
        body = r.json()
    except ValueError:
        body = None
    return r.status_code, body, r.headers


def _retry_after(headers, fallback):
    ra = (headers or {}).get("Retry-After")
    if ra:
        try:
            return max(0.0, float(ra))
        except (TypeError, ValueError):
            pass
    return fallback


def _call(method, url, headers=None, data=None, json_body=None):
    """Retry wrapper honoring Retry-After on 429/5xx. Returns parsed json or None."""
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            status, body, hdrs = _request(method, url, headers=headers, data=data,
                                          json_body=json_body)
        except requests.RequestException as exc:
            fetch.log(f"digikey transport {type(exc).__name__} ({attempt})")
            if attempt >= MAX_RETRIES:
                return None
            time.sleep(0.5 * attempt)
            continue
        if status in RETRY_STATUS and attempt < MAX_RETRIES:
            wait = _retry_after(hdrs, 0.5 * attempt)
            fetch.log(f"digikey retry {status} ({attempt}) in {wait:g}s")
            time.sleep(wait)
            continue
        if status >= 400:
            fetch.log(f"digikey HTTP {status}")
            return None
        return body
    return None


# --- token cache ----------------------------------------------------------
def _load_token():
    try:
        raw = json.loads(TOKEN_CACHE.read_text(encoding="utf-8"))
        if isinstance(raw, dict) and raw.get("access_token") and raw.get("expires_at", 0) > time.time() + 30:
            return raw["access_token"]
    except (OSError, ValueError):
        pass
    return None


def _store_token(token, expires_in):
    try:
        TOKEN_CACHE.write_text(json.dumps(
            {"access_token": token, "expires_at": time.time() + float(expires_in or 0)}),
            encoding="utf-8")
    except OSError:
        pass


def _token():
    """Return a valid bearer token, fetching a fresh one if needed. None on failure."""
    cid, secret = _creds()
    if not cid or not secret:
        return None
    with _LOCK:
        tok = _load_token()
        if tok:
            return tok
        body = _call(
            "POST", f"{_host()}/v1/oauth2/token",
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data={"client_id": cid, "client_secret": secret,
                  "grant_type": "client_credentials"})
        if not isinstance(body, dict) or not body.get("access_token"):
            fetch.log("digikey token request failed")
            return None
        _store_token(body["access_token"], body.get("expires_in", 0))
        return body["access_token"]


# --- response cache (in-memory, process lifetime; never persisted) --------
def _cache_get(key):
    with _LOCK:
        return _RESPONSE_CACHE.get(key)


def _cache_put(key, products):
    with _LOCK:
        _RESPONSE_CACHE[key] = products


# --- query + response mapping ---------------------------------------------
def _first(d, *keys, default=None):
    if not isinstance(d, dict):
        return default
    for k in keys:
        if k in d and d[k] not in (None, "", []):
            return d[k]
    return default


def _num(value):
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if not isinstance(value, str):
        return None
    m = re.search(r"-?\d+(?:\.\d+)?", value.replace(",", ""))
    return float(m.group()) if m else None


def _to_ghz(value):
    """Parse a frequency string to GHz. Returns float or None."""
    if value is None:
        return None
    s = str(value).lower()
    m = re.search(r"(-?\d+(?:\.\d+)?)\s*(ghz|mhz|khz|hz)?", s)
    if not m:
        return None
    n = float(m.group(1))
    unit = m.group(2) or "ghz"
    return {"ghz": n, "mhz": n / 1e3, "khz": n / 1e6, "hz": n / 1e9}[unit]


def _freq_range_ghz(value):
    """Parse 'a - b <unit>' or 'DC-18GHz' to [lo, hi] GHz, else None."""
    if value is None:
        return None
    s = str(value)
    low = 0.0 if "dc" in s.lower() else None
    nums = re.findall(r"(-?\d+(?:\.\d+)?)\s*(ghz|mhz|khz|hz)?", s.lower())
    # keep only tokens that actually had a digit
    vals = []
    for n, u in nums:
        vals.append(_to_ghz(f"{n}{u or 'ghz'}"))
    vals = [v for v in vals if v is not None]
    if not vals:
        return None
    if low == 0.0 and len(vals) >= 1:
        return [0.0, max(vals)]
    if len(vals) >= 2:
        return [min(vals), max(vals)]
    return None


def _mount(value):
    s = str(value or "").lower()
    if "surface" in s or "smd" in s or "smt" in s:
        return "smt"
    if "die" in s or "bare" in s or "chip" in s:
        return "die"
    if "flange" in s:
        return "flange"
    if "connector" in s or "coax" in s or "sma" in s or "bnc" in s or "n-type" in s:
        return "connectorized"
    return None


def _ports(value):
    n = _num(value)
    if n is None or n <= 0:
        return None
    return int(n)


def _pt(ch):
    ch = ch.upper()
    if ch.isdigit():
        return int(ch)
    return {"S": 1, "D": 2, "T": 3}.get(ch)


def _ports_from_config(text):
    """RF port count from a switch configuration token (SPDT, SP4T, DPDT, ...).

    DigiKey's RF Switches category exposes the pole/throw configuration rather
    than a literal port count. An <poles>P<throws>T switch has, per pole, one
    common plus <throws> throw ports, i.e. poles*(throws+1) RF ports.
    """
    for m in re.finditer(r"\b([0-9SDT])P([0-9SDT])T\b", str(text or "").upper()):
        poles, throws = _pt(m.group(1)), _pt(m.group(2))
        if poles and throws:
            return poles * (throws + 1)
    return None


def _category_names(product):
    """All raw DigiKey category names attached to a product (parents + children)."""
    names = []

    def walk(c):
        if isinstance(c, dict):
            nm = _first(c, "Name", "Value", default="")
            if nm:
                names.append(str(nm))
            for ch in (c.get("ChildCategories") or c.get("Children") or []):
                walk(ch)
        elif isinstance(c, str):
            names.append(c)

    walk(product.get("Category"))
    for k in ("CategoryName", "Family"):
        v = product.get(k)
        if isinstance(v, dict):
            nm = _first(v, "Name", "Value", default="")
            if nm:
                names.append(str(nm))
        elif isinstance(v, str) and v:
            names.append(v)
    return names


def _is_rf_category(product):
    """True if the product belongs to DigiKey's RF/Wireless family.

    Those category names all start with "RF" (RF Amplifiers, RF Switches, ...).
    Fail open only when no category is readable at all, so a field-name change
    can't silently drop every result — it can't be used to keep a coax connector,
    whose category ("Coaxial Connectors") is present and does not start with RF.
    """
    names = _category_names(product)
    if not names:
        return True
    return any(n.strip().upper().startswith("RF") for n in names)


def _abs_url(url):
    """DigiKey datasheet/photo links are often protocol-relative ('//host/..')."""
    u = str(url or "").strip()
    if u.startswith("//"):
        return "https:" + u
    return u


def _digikey_category(product):
    """Best-effort canonical category from DigiKey's own taxonomy, else None.

    DigiKey classifies every part; using that (instead of blindly stamping the
    searched-for category) is what keeps a coax connector returned by a "switch"
    search from being scored as a switch.
    """
    cat = product.get("Category")
    names = []
    if isinstance(cat, dict):
        names.append(str(_first(cat, "Name", "Value", default="")))
        for ch in (cat.get("ChildCategories") or cat.get("Children") or []):
            if isinstance(ch, dict):
                names.append(str(_first(ch, "Name", "Value", default="")))
    elif isinstance(cat, str):
        names.append(cat)
    for key in ("CategoryName", "Family"):
        v = product.get(key)
        if isinstance(v, dict):
            names.append(str(_first(v, "Name", "Value", default="")))
        elif isinstance(v, str):
            names.append(v)
    blob = " ".join(n for n in names if n).lower()
    if not blob:
        return None
    # A DigiKey category name can contain several canonical synonyms (e.g.
    # "Coaxial Connectors" hits both 'coaxial'->cable and 'connector'->connector).
    # Pick the longest matching token so the most specific category wins.
    best, best_len = None, 0
    for canon, syns in CATEGORY_SYNONYMS.items():
        for token in [canon.replace("_", " ")] + [s.lower() for s in syns]:
            if token and token in blob and len(token) > best_len:
                best, best_len = canon, len(token)
    return best


def _dk_dims(value):
    """Parse a DigiKey 'Size / Dimension' value into {l, w, h?, unit, raw}.

    DigiKey interleaves axis labels (``0.750" L x 0.400" W``); strip the bare
    L/W/H/D letters, then reuse the extract-layer dimension regexes. Returns None
    when nothing usable is present (a bare diameter like ``0.5" Dia`` is skipped).
    """
    from .. import extract
    s = re.sub(r"\s+[LWHD]\b", " ", str(value or ""), flags=re.I)
    return extract._dimensions(s, "")


def _dk_space(value):
    """Map a DigiKey qualification/grade parameter to a space signal, or None."""
    s = str(value or "").lower()
    if any(k in s for k in ("space", "radiation", "rad-hard", "rad hard",
                            "class s", "class k", "flight")):
        return "qualified"
    if any(k in s for k in ("mil-", "mil ", "class h", "qml", "aec-q",
                            "automotive", "screen", "hermetic", "hi-rel",
                            "high reliability")):
        return "hi_rel"
    return None


# Parameter-name substring -> (schema key, parser). First match wins.
_PARAM_MAP = [
    ("impedance", ("impedance_ohm", _num)),
    ("gain", ("gain_db", _num)),
    ("attenuation", ("attenuation_db", _num)),
    ("frequency range", ("freq_ghz", _freq_range_ghz)),
    ("operating frequency", ("freq_ghz", _freq_range_ghz)),
    ("frequency", ("freq_ghz", _freq_range_ghz)),
    ("mounting type", ("mount_type", _mount)),
    ("package / case", ("mount_type", _mount)),
    ("size / dimension", ("dimensions", _dk_dims)),
    ("qualification", ("space", _dk_space)),
    ("connector type", ("connector", str)),
    ("number of ports", ("ports", _ports)),
    ("noise figure", ("nf_db", _num)),
    ("p1db", ("p1db_dbm", _num)),
    ("1db compression", ("p1db_dbm", _num)),
    ("oip3", ("oip3_dbm", _num)),
    ("third order intercept", ("oip3_dbm", _num)),
    ("isolation", ("isolation_db", _num)),
    ("conversion loss", ("conversion_loss_db", _num)),
    ("coupling", ("coupling_db", _num)),
]


def _param_text(par):
    return str(_first(par, "ParameterText", "Parameter", "ParameterType", default="")).lower()


def _param_value(par):
    return _first(par, "ValueText", "Value", "ParameterValue", default="")


def _map_specs(product):
    """Map a DigiKey product record to the pipeline's common specs schema."""
    specs = {}
    price = _num(_first(product, "UnitPrice", "unitPrice"))
    if price is not None:
        specs["price_usd"] = price
    qty = _first(product, "QuantityAvailable", "quantityAvailable")
    qn = _num(qty)
    if qn is not None:
        specs["stock_qty"] = int(qn)
        if qn > 0:
            specs["lead_weeks"] = 0
    ds = _first(product, "DatasheetUrl", "PrimaryDatasheet", "datasheetUrl")
    if ds:
        specs["datasheet"] = _abs_url(ds)
    mfr = _first(_first(product, "Manufacturer", default={}), "Name", "Value") \
        or _first(product, "ManufacturerName")
    if mfr:
        specs["manufacturer"] = mfr

    params = _first(product, "Parameters", "parameters", default=[]) or []
    pmap = {}
    for par in params:
        text = _param_text(par)
        if text:
            pmap[text] = _param_value(par)
        for needle, (key, parser) in _PARAM_MAP:
            if needle in text:
                val = parser(_param_value(par))
                if val not in (None, ""):
                    specs.setdefault(key, val)
                break

    # DigiKey commonly splits frequency into 'frequency - min' / 'frequency - max'
    # (each a single value), which the range parser above can't use alone. Merge
    # them into freq_ghz when a plain range parameter didn't already set it.
    if "freq_ghz" not in specs:
        fmin = _to_ghz(pmap.get("frequency - min"))
        fmax = _to_ghz(pmap.get("frequency - max"))
        if fmin is not None or fmax is not None:
            lo = fmin if fmin is not None else 0.0
            hi = fmax if fmax is not None else fmin
            if hi is not None:
                specs["freq_ghz"] = [min(lo, hi), max(lo, hi)]
    # A meaningful connector value implies a connectorized RF interface even when
    # DigiKey lists no mounting-type parameter. Ignore placeholder values ("-").
    conn = specs.get("connector")
    conn_ok = isinstance(conn, str) and conn.strip().lower() not in (
        "", "-", "--", "\u2013", "n/a", "na", "none")
    if not conn_ok:
        specs.pop("connector", None)
    if "mount_type" not in specs and conn_ok:
        specs["mount_type"] = "connectorized"
    # DigiKey rarely exposes impedance outside the datasheet; a connectorized RF
    # part is 50 Ω by near-universal convention unless it says otherwise.
    if "impedance_ohm" not in specs and (
            specs.get("mount_type") == "connectorized" or conn_ok):
        specs["impedance_ohm"] = 50.0
    return specs


def _product_url(product):
    url = _first(product, "ProductUrl", "productUrl")
    if url:
        return url
    pn = _first(product, "ManufacturerProductNumber", "ManufacturerPartNumber",
                "DigiKeyProductNumber", default="")
    return f"https://www.digikey.com/en/products/result?keywords={quote(str(pn))}"


def _to_candidate(product, requested_category):
    pn = _first(product, "ManufacturerProductNumber", "ManufacturerPartNumber",
                "DigiKeyProductNumber", default="")
    desc = _first(_first(product, "Description", default={}), "ProductDescription",
                  "DetailedDescription") \
        or _first(product, "ProductDescription", "DetailedDescription", "Description", default="")
    mfr = _first(_first(product, "Manufacturer", default={}), "Name", "Value") \
        or _first(product, "ManufacturerName", default="")
    base = " ".join(str(x) for x in (mfr, pn) if x).strip()
    short = str(desc)[:70]
    # Surface the DigiKey description in the title so rank's category check (which
    # reads title + url) can tell a real RF switch from a coax connector, and so
    # the GUI Part column is meaningful.
    title = f"{base} — {short}" if base and short else (base or short or "DigiKey product")
    specs = _map_specs(product)
    params = _first(product, "Parameters", "parameters", default=[]) or []
    param_text = " ".join(
        f"{_param_text(p)}: {_param_value(p)}" for p in params if _param_text(p))
    text = " ".join(str(x) for x in (desc, param_text) if x)
    # Use DigiKey's own classification, NOT the searched-for category, so
    # irrelevant hits are scored honestly (and de-ranked) rather than trusted.
    category = _digikey_category(product)
    if "ports" not in specs:
        p = _ports_from_config(f"{title} {text}")
        if p:
            specs["ports"] = p
    return {
        "url": _product_url(product),
        "title": title[:180],
        "category": category,   # may be None -> rank falls back to text match
        "_catalog": True,        # reuse the no-network extract path
        "_api": True,
        "_specs": specs,
        "text": text,
        "_api_record": product,
    }


def _build_keyword(spec):
    # DigiKey keyword search spans all of electronics, so lead with "RF <category>"
    # (or a more specific subcategory term when one is chosen) to bias toward
    # RF/microwave parts. Impedance is deliberately NOT a keyword term — "50 ohm"
    # pulls in coax connectors; it stays a ranking criterion.
    parts = []
    terms = spec.get("subcategory_terms") or []
    cat = spec.get("category")
    if terms:
        parts.append(f"RF {terms[0]}")
    elif cat:
        parts.append(f"RF {cat.replace('_', ' ')}")
    if spec.get("connector"):
        parts.append(str(spec["connector"]))
    for tok in spec.get("other", []) or []:
        parts.append(str(tok))
    return " ".join(parts).strip() or (cat or "")


def candidates(vendor, spec):
    """Return DigiKey candidates for a spec, or [] when unavailable/uncredentialed."""
    global _NO_CREDS_LOGGED
    cid, secret = _creds()
    if not cid or not secret:
        if not _NO_CREDS_LOGGED:
            fetch.log("digikey: no DIGIKEY_CLIENT_ID/SECRET set; skipping (opt-in source)")
            _NO_CREDS_LOGGED = True
        return []

    keyword = _build_keyword(spec)
    if not keyword:
        return []
    limit = _limit()
    cat_id = os.environ.get("DIGIKEY_CATEGORY_ID", "").strip()
    cache_key = f"{'sbx' if os.environ.get('DIGIKEY_SANDBOX') else 'prod'}|{limit}|{cat_id}|{keyword.lower()}"

    products = _cache_get(cache_key)
    if products is None:
        token = _token()
        if not token:
            return []
        headers = {
            "Authorization": f"Bearer {token}",
            "X-DIGIKEY-Client-Id": cid,
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": fetch.UA,
        }
        site = os.environ.get("DIGIKEY_LOCALE_SITE")
        cur = os.environ.get("DIGIKEY_LOCALE_CURRENCY")
        if site:
            headers["X-DIGIKEY-Locale-Site"] = site
        if cur:
            headers["X-DIGIKEY-Locale-Currency"] = cur
        json_body = {"Keywords": keyword, "Limit": limit, "Offset": 0}
        if cat_id:
            # Server-side restriction to a DigiKey category (opt-in). The V4
            # keyword endpoint accepts a category filter here; verify the id via
            # the Categories endpoint before relying on it.
            json_body["FilterOptionsRequest"] = {"CategoryFilter": [{"Id": cat_id}]}
        body = _call(
            "POST", f"{_host()}/products/v4/search/keyword", headers=headers,
            json_body=json_body)
        if not isinstance(body, dict):
            return []
        products = _first(body, "Products", "products", default=[]) or []
        _cache_put(cache_key, products)

    out = []
    dropped = 0
    for p in products:
        if not isinstance(p, dict):
            continue
        if not _is_rf_category(p):     # keep only DigiKey's RF/Wireless family
            dropped += 1
            continue
        out.append(_to_candidate(p, spec.get("category")))
    if dropped:
        fetch.log(f"digikey: dropped {dropped} non-RF result(s); kept {len(out)}")
    return out
