"""SATNow adapter — space-qualified RF/microwave parts.

SATNow (satnow.com) is a space/satellite component marketplace whose
``/search/<slug>`` listings are curated space-qualified product sets. This
adapter turns a requirement spec into the right listing URL(s), pages through
them, and returns candidates in the shape the rest of the pipeline expects.

Design notes
------------
* Fetching goes through ``rfparts.fetch`` — the honest-UA, robots-obeying,
  rate-limited, SQLite-cached path. This adapter deliberately does NOT carry
  the browser-spoofing fetcher from the standalone debug script; that would
  break the policy stated in fetch.py and the README.
* Listing pages are cheap and structured, so no product page is fetched here.
  ``_catalog: True`` + a prebuilt ``_specs`` lets extract.extract_specs work
  without a live page hit. Parametrics still come from the product page if the
  pipeline later chooses to fetch it.
* Every SATNow listing is a space-qualified set, so ``_specs["space"]`` is set
  to ``"qualified"`` and ``space_evidence`` records the provenance so a human
  reviewing the report can see the claim came from the marketplace's
  categorization rather than from a datasheet.
* Never raises. A blocked page, a robots disallow, or a markup change yields
  fewer (or zero) candidates plus a log line — one bad source cannot sink a run.
"""
import html
import re
from urllib.parse import quote_plus, urljoin

from .. import fetch

BASE = "https://www.satnow.com"
MAX_PAGES = 4            # listing pages per slug
MAX_PER_CATEGORY = 400
LISTING_TTL = 3 * 86400  # listings churn slowly; 3 days is plenty


# --- canonical category -> SATNow listing slugs --------------------------
# Keys are canonical registry categories (registry.CATEGORY_SYNONYMS), NOT the
# ad-hoc keys the debug script used ("lna", "power_amplifier", "multiplier").
# Each value is a list of (slug, facet_param, facet_value); they are tried in
# order and every slug that returns rows contributes.
#
# Slugs marked VERIFIED were confirmed live. The debug run's failures for
# divider/isolator/circulator/multiplier were wrong slug guesses, now fixed.
SLUGS = {
    "amplifier": [("microwave-rf-amplifiers", None, None)],                  # VERIFIED
    "attenuator": [("microwave-rf-fixed-attenuators", None, None),           # VERIFIED
                   ("microwave-rf-variable-attenuators", None, None)],
    "phase_shifter": [("analog-phase-shifters", None, None),                 # VERIFIED
                      ("digital-phase-shifters", None, None)],
    "switch": [("switches", None, None)],                                    # VERIFIED
    "filter": [("rf-filters", None, None)],                                  # VERIFIED
    "mixer": [("microwave-rf-mixers", None, None)],                          # VERIFIED
    "coupler": [("couplers", None, None)],                                   # VERIFIED
    "oscillator": [("oscillators", None, None)],                             # VERIFIED
    "divider": [("power-dividers", None, None)],                             # FIXED
    "isolator": [("rf-microwave-isolators", None, None)],                    # FIXED
    "circulator": [("rf-microwave-circulators", None, None)],                # FIXED
    "frequency_multiplier": [("multipliers", None, None)],                   # FIXED
    "synthesizer": [("frequency-synthesizers", None, None)],                 # NEW
    "connector": [("rf-connectors", None, None)],                            # NEW
    "termination": [("terminations", None, None)],                           # NEW
    # SATNow has no standalone limiter listing; limiting amplifiers live under
    # amplifiers. Facet is unconfirmed — if it returns nothing the bare
    # amplifier listing below still supplies candidates.
    "limiter": [("microwave-rf-amplifiers", "stype", "Limiting Amplifier"),
                ("microwave-rf-amplifiers", None, None)],
}

# Subcategory refinement: when the spec names an amplifier subtype, add the
# matching SATNow facet so the listing returns the right subset instead of all
# 700+ amplifiers.
AMP_FACETS = [
    (("low noise", "low-noise", "lna"), "Low Noise Amplifier"),
    (("high power", "hpa"), "High Power Amplifier"),
    (("power amplifier", "solid state power", "sspa"), "Power Amplifier"),
    (("driver",), "Driver Amplifier"),
    (("limiting",), "Limiting Amplifier"),
    (("variable gain", "vga", "dvga"), "Variable Gain Amplifier"),
    (("log", "logarithmic", "sdlva"), "Logarithmic Amplifier"),
]


def _facet(value):
    """SATNow encodes a facet value as ;Value; (URL-escaped)."""
    return "%3B" + quote_plus(str(value)) + "%3B"


def _listing_url(slug, page, fparam=None, fval=None):
    # SATNow's own pagination links always route through /filters?page=N&
    # country=global, facet or not. The bare /search/{slug}?page=N form
    # (used previously when there was no facet) silently ignores the page
    # param past page 1 -- it re-serves page 1 every time, which is why
    # non-faceted categories used to dead-end at ~15 results after dedup.
    url = f"{BASE}/search/{slug}/filters?page={page}&country=global"
    if fparam:
        url += f"&{fparam}={_facet(fval)}"
    return url


# --- device / non-device discrimination ----------------------------------
# Ported from the debug script, trimmed to what a SATNow listing actually
# needs. The manufacturer-crawler heuristics were dropped along with the
# crawler itself.
STANDARDS_RX = re.compile(
    r"\bMIL-?STD-?\d|\bMIL-?PRF-?\d|\bMIL-?DTL-?\d|\bMIL-?C-?\d|\bESCC\b|"
    r"\bECSS\b|\bSMD\s*5962\b|\b5962-?\d|\bDSCC\b|\bJESD\b|\bQML-?\d", re.I)
NON_DEVICE_RX = re.compile(
    r"\bcatalog\b|products?\s*\(\s*\d|\breport\b|brochure|white\s*paper|"
    r"\boverview\b|\bsupplier\b|\bdirectory\b|manufacturers?\b|\bnews\b|\bblog\b|"
    r"webinar|datasheet|application\s+note|\bresources?\b|\bprofile\b|\bcompany\b|"
    r"\babout\b|\bcontact\b|\blogin\b|\bquote\b|\bcompare\b|\bdownload\b|"
    r"\bterms\b|privacy|cookie|sitemap|careers|\bfaq\b|\bcart\b|subscribe", re.I)
COMPANY_RX = re.compile(
    r"\b(inc|llc|ltd|limited|corp|corporation|gmbh|co|company|technolog(?:y|ies)|"
    r"electronics|systems|industries|semiconductors?|microwave|microcircuits?|"
    r"labs?|monolithics?|solutions|group|ag)\.?\s*$", re.I)
MFR_PART_RX = re.compile(
    r"^(.{2,60}?)\s+[-\u2013\u2014]\s+([A-Za-z0-9][A-Za-z0-9\-\./\+\*_ ]{2,40})$")

_A_RX = re.compile(r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', re.I | re.S)
_TAG_RX = re.compile(r"<[^>]+>")
_NAV_WORDS = ("login", "sign in", "view all", "see all", "read more",
              "learn more", "add to", "back to", "next", "previous")


def _parse_mfr_part(title):
    """'Mini Circuits - CMA-162LN+' -> ('Mini Circuits', 'CMA-162LN+')."""
    m = MFR_PART_RX.match(title or "")
    if not m:
        return None
    mfr, part = m.group(1).strip(), m.group(2).strip()
    if STANDARDS_RX.search(part):
        return None
    # A digit is required, a letter is not: XMA (10618307), Frontgrade
    # (11000-00918), Qorvo (880273) and Wenzel (501-28039) all ship
    # all-numeric part numbers. The debug script's letter requirement silently
    # dropped the manufacturer attribution on those rows.
    if not re.search(r"\d", part):
        return None
    return mfr, part


def _looks_like_part(text):
    if not text or not (3 <= len(text) <= 80):
        return False
    low = text.lower()
    if any(w in low for w in _NAV_WORDS):
        return False
    return bool(re.search(r"[A-Za-z]", text) and re.search(r"\d", text))


def _is_device(title):
    t = (title or "").strip()
    if not t or STANDARDS_RX.search(t) or NON_DEVICE_RX.search(t):
        return False
    if _parse_mfr_part(t):
        return True
    if COMPANY_RX.search(t):
        return False            # bare manufacturer name, e.g. "…HiRel Electronics"
    return _looks_like_part(t)


def _is_product_url(url):
    u = (url or "").lower()
    if not u or u.startswith(("javascript", "mailto")) or u.endswith(".pdf"):
        return False
    return "/products/" in u


def _anchors(body, base_url):
    """(title, url) for every anchor with short visible text."""
    out, seen = [], set()
    for href, inner in _A_RX.findall(body or ""):
        text = html.unescape(re.sub(r"\s+", " ", _TAG_RX.sub(" ", inner)).strip())
        if not text or len(text) > 90:
            continue
        url = urljoin(base_url, href)
        key = (text.lower(), url)
        if key in seen:
            continue
        seen.add(key)
        out.append((text, url))
        if len(out) >= 800:
            break
    return out


# --- spec -> slug selection ----------------------------------------------
def _slugs_for(spec):
    """Listing specs for this requirement, refined by subcategory when given."""
    cat = spec.get("category")
    base = SLUGS.get(cat)
    if not base:
        return []
    terms = " ".join(spec.get("subcategory_terms") or []).lower()
    if not terms:
        terms = " ".join(spec.get("other") or []).lower()
    if cat == "amplifier" and terms:
        for keys, facet in AMP_FACETS:
            if any(k in terms for k in keys):
                # Facet first, bare listing second as a safety net.
                return [("microwave-rf-amplifiers", "stype", facet)] + base
    return base


def _candidate(title, url, category):
    mp = _parse_mfr_part(title)
    mfr = mp[0] if mp else None
    part = mp[1] if mp else title
    # Text the extract layer mines; the space wording is real (SATNow listings
    # are space-qualified sets) and keeps title-based signals consistent.
    text = f"{title}\nSpace qualified {category or 'RF'} listed on SATNow."
    return {
        "vendor": "SATNow",
        "url": url,
        "title": title[:180],
        "part": part,
        "manufacturer": mfr,
        "category": category,
        "_catalog": True,          # reuse the no-network extract path
        "_api": True,
        "_specs": {
            "space": "qualified",
            "space_evidence": "SATNow space-qualified listing (marketplace "
                              "categorization, not datasheet-verified)",
            "manufacturer": mfr,
            "part": part,
        },
        "text": text,
    }


def candidates(vendor, spec):
    """Return SATNow candidates for ``spec``. Never raises."""
    cat = spec.get("category")
    specs = _slugs_for(spec)
    if not specs:
        fetch.log(f"satnow: no listing slug for category {cat!r}")
        return []

    out, seen = [], set()
    for slug, fparam, fval in specs:
        rows_this_slug = 0
        for page in range(1, MAX_PAGES + 1):
            url = _listing_url(slug, page, fparam, fval)
            body = fetch.get(url, ttl=LISTING_TTL)
            if not body:
                if page == 1:
                    # fetch.get logs robots-disallow / HTTP failure itself; make
                    # the consequence explicit so this never fails silently.
                    fetch.log(f"satnow: no content for {slug} (page 1) — "
                              f"category {cat} gets no SATNow candidates")
                break
            page_rows = 0
            for title, link in _anchors(body, url):
                if not (_is_product_url(link) and _is_device(title)):
                    continue
                key = link.split("?")[0].lower()
                if key in seen:
                    continue
                seen.add(key)
                out.append(_candidate(title, link, cat))
                page_rows += 1
                rows_this_slug += 1
            if page_rows < 5 or len(out) >= MAX_PER_CATEGORY:
                break        # short page = last page
        if rows_this_slug:
            fetch.log(f"satnow: {slug} -> {rows_this_slug} candidates")
        if len(out) >= MAX_PER_CATEGORY:
            break
    return out[:MAX_PER_CATEGORY]
