"""Adapters for ``strategy: api`` vendors.

Discovery routes ``strategy: api`` vendors here (see discover.candidates). Each
vendor names an ``adapter`` (e.g. ``digikey``); this package looks it up and
calls its ``candidates(vendor, spec)``, which returns candidate dicts in the
same shape the rest of the pipeline expects. Adapters set ``_catalog: True`` and
prebuild ``_specs`` so extract.extract_specs uses the structured data without a
live page fetch.

Adapters must never raise: a missing dependency, missing credentials, or a
network error yields an empty list plus a log line, so one bad source can't sink
a run.
"""
from . import digikey

_ADAPTERS = {
    "digikey": digikey.candidates,
}


def candidates(vendor, spec):
    """Dispatch to the adapter named by ``vendor['adapter']``.

    Unknown or missing adapter -> empty list (never raises).
    """
    name = (vendor.get("adapter") or "").strip().lower()
    fn = _ADAPTERS.get(name)
    if fn is None:
        return []
    try:
        return fn(vendor, spec) or []
    except Exception:  # noqa: BLE001 - a broken source must not sink the run
        return []
