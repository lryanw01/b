"""Ingest the Analog Devices space-qualified parts portfolio (.xlsx) into partdb.

Reads the LOCAL spreadsheet ADI publishes (e.g. ``adi_space_portfolio_YYYY-MM-DD
.xlsx``) — no network. Every row is a space part; multiple orderable material
numbers of the same generic part collapse into one DB part, keeping the
strongest space grade and the richest radiation data.

Sheet layout (header on the 4th row):
    Generic Part Number | Description | Orderable Material Number | Category |
    Sub-Category | Space Qualification Level | Operating Temperature |
    Production RHA | TID Threshold (kRad) | TID Report | SEL Threshold
    (MeV*cm2/mg) | SEE Report | Displacement Damage (TNID) | ... | Package |
    Package Material | Lead Finish | ADI POD No. | Datasheet URL

What lands per part:
    parts row   mpn=generic PN / vendor="Analog Devices" / category / subcategory
                / product_url=datasheet / description
    specs       freq via description is NOT parsed (ADI sheet has no freq column);
                radiation + screening land as: tid_krad, sel_mev, temp_c (range),
                package, qual_level (text), orderable (text), space, space_variant
    evidence    adi-space-portfolio (+9 qualified / +7 grade)

Run:
    python -m rfparts.adi_ingest "C:\\path\\adi_space_portfolio_2026-07-28.xlsx"
    python -m rfparts.adi_ingest FILE --dry-run
"""
from __future__ import annotations

import argparse
import re
from collections import Counter
from pathlib import Path

from openpyxl import load_workbook

try:
    from .partdb import SpecRow, upsert_part, put_specs, put_evidence
except ImportError:                                    # loose-script fallback
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from rfparts.partdb import (                        # type: ignore
        SpecRow, upsert_part, put_specs, put_evidence)

VENDOR = "Analog Devices"

# ADI portfolio Category (and, where it disambiguates, Sub-Category) -> the
# pipeline's canonical category. RF families reuse the existing RF categories;
# space-semiconductor families use the categories added to the registry.
_CAT = {
    "PRECISION AMPLIFIERS": "amplifier",
    "RF AMPLIFIERS": "amplifier",
    "RF MIXERS": "mixer",
    "RF DETECTORS": "detector",
    "VOLTAGE CONTROLLED OSCILLATORS (VCO)": "oscillator",
    "PHASE LOCKED LOOP (PLL)": "synthesizer",
    "I/Q MOD/DEMOD": "modulator",
    "RF TRANSCEIVERS AND MxFE": "transceiver",
    "BEAMFORMERS, PHASE SHIFTERS & VECTOR MODULATORS": "beamformer",
    "SWITCH/MUX": "switch",
    "PRECISION D/A CONVERTERS": "data_converter",
    "HIGH SPEED D/A CONVERTERS": "data_converter",
    "PRECISION A/D CONVERTERS": "data_converter",
    "HIGH SPEED A/D CONVERTERS": "data_converter",
    "INTEGRATED A/D CONVERTERS": "data_converter",
    "POWER MANAGEMENT": "power",
    "CLOCK AND TIMING": "clock",
    "SENSORS": "sensor",
    "INTERFACE/ISOLATION": "interface",
    "ANALOG FUNCTIONS": "ic",
    "VIDEO PRODUCTS": "ic",
    "HIGH SPEED LOGIC": "ic",
}


def _canon_category(cat_text: str, sub_text: str) -> tuple[str, str]:
    cat = (cat_text or "").strip().upper()
    sub = (sub_text or "").strip()
    canon = _CAT.get(cat, "ic")
    # RF CONTROL PRODUCTS and FREQUENCY DIVIDERS/MULTIPLIERS are decided by their
    # sub-category text (the same ADI category holds switches, attenuators, etc.)
    if cat == "RF CONTROL PRODUCTS":
        s = sub.lower()
        if "switch" in s:
            canon = "switch"
        elif "atten" in s:
            canon = "attenuator"
        elif "phase" in s:
            canon = "phase_shifter"
        else:
            canon = "switch"
    elif cat == "FREQUENCY DIVIDERS/MULTIPLIERS":
        canon = "frequency_multiplier" if "multipl" in sub.lower() else "divider"
    # amplifier sub-typing lets an LNA search narrow correctly
    subcat = ""
    if canon == "amplifier" and re.search(r"low noise", sub, re.I):
        subcat = "lna"
    return canon, subcat


# Space Qualification Level -> ("space_qualified"|"space_grade").
def _variant(level: str) -> tuple[str, str]:
    t = (level or "").strip()
    low = t.lower()
    qualified = (
        "38535" in low or "class v" in low or "class level s" in low
        or "class s" in low or "asd model" in low or "38534 class k" in low
        or "class h" in low or "nasa" in low or "commercial space high" in low)
    grade_only = (
        "engineering model" in low or "not space qualified" in low
        or "class level b" in low or "commercial space low" in low)
    if qualified and not grade_only:
        return "space_qualified", t or "ADI space-qualified flow"
    return "space_grade", t or "ADI space portfolio (grade)"


_NUM = re.compile(r"[-+]?\d+(?:\.\d+)?")
_TEMP = re.compile(r"([-+]?\d+)\s*°?\s*C\s*(?:to|–|—|-)\s*([-+]?\d+)\s*°?\s*C", re.I)


def _leading_number(text) -> float | None:
    """First numeric token in a value like '100 (non-RHA)', or None for
    'Not performed'/'n/a'/blank."""
    if text is None:
        return None
    s = str(text).strip()
    if not s or s.lower() in ("not performed", "n/a", "na", "tbd", "-", "—"):
        return None
    m = _NUM.search(s)
    return float(m.group()) if m else None


def _temp_range(text):
    m = _TEMP.search(str(text or ""))
    if not m:
        return None
    lo, hi = float(m.group(1)), float(m.group(2))
    return {"value_min": min(lo, hi), "value_max": max(lo, hi), "unit": "C"}


def _header_row(rows):
    """Index of the row whose first cell is 'Generic Part Number'."""
    for i, r in enumerate(rows):
        if r and str(r[0]).strip().lower().startswith("generic part number"):
            return i
    return 0


def _cols(header):
    """Map a normalized header label -> column index (robust to \\n and spaces)."""
    out = {}
    for i, h in enumerate(header):
        key = re.sub(r"\s+", " ", str(h or "").strip().lower())
        out[key] = i
    def find(*needles):
        for label, i in out.items():
            if all(n in label for n in needles):
                return i
        return None
    return {
        "mpn": find("generic part number"),
        "desc": find("description"),
        "orderable": find("orderable material"),
        "cat": find("category") if find("sub-category") is None else _cat_main(out),
        "sub": find("sub-category") if find("sub-category") is not None else find("sub", "category"),
        "level": find("space qualification"),
        "temp": find("operating", "temperature"),
        "tid": find("tid threshold"),
        "sel": find("sel threshold"),
        "pkg": find("package") if find("package material") is None else _pkg_main(out),
        "url": find("datasheet"),
    }


def _cat_main(out):
    # the plain "category" column, not "sub-category"
    for label, i in out.items():
        if label == "category":
            return i
    return None


def _pkg_main(out):
    for label, i in out.items():
        if label == "package":
            return i
    return None


def parse_rows(path: Path):
    """Yield one aggregated dict per generic part number."""
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb[wb.sheetnames[0]]
    rows = list(ws.iter_rows(values_only=True))
    h = _header_row(rows)
    cols = _cols(rows[h])
    data = rows[h + 1:]

    def cell(row, key):
        i = cols.get(key)
        return row[i] if (i is not None and i < len(row)) else None

    agg: dict[str, dict] = {}
    for row in data:
        mpn = cell(row, "mpn")
        if not mpn or not str(mpn).strip():
            continue
        mpn = str(mpn).strip()
        level = str(cell(row, "level") or "")
        variant, reason = _variant(level)
        rec = agg.get(mpn)
        if rec is None:
            canon, subcat = _canon_category(
                str(cell(row, "cat") or ""), str(cell(row, "sub") or ""))
            rec = agg[mpn] = {
                "mpn": mpn,
                "description": str(cell(row, "desc") or "").strip(),
                "category": canon, "subcategory": subcat,
                "url": str(cell(row, "url") or "").strip(),
                "adi_category": str(cell(row, "cat") or "").strip(),
                "adi_subcategory": str(cell(row, "sub") or "").strip(),
                "variant": variant, "reason": reason,
                "level": level.strip(),
                "orderables": set(), "packages": set(),
                "tid": None, "sel": None, "temp": None,
            }
        # strongest variant wins for the part
        if rec["variant"] == "space_grade" and variant == "space_qualified":
            rec["variant"], rec["reason"], rec["level"] = variant, reason, level.strip()
        ordn = cell(row, "orderable")
        if ordn:
            rec["orderables"].add(str(ordn).strip())
        pkg = cell(row, "pkg")
        if pkg:
            rec["packages"].add(str(pkg).strip())
        tid = _leading_number(cell(row, "tid"))
        if tid is not None:
            rec["tid"] = tid if rec["tid"] is None else max(rec["tid"], tid)
        sel = _leading_number(cell(row, "sel"))
        if sel is not None:
            rec["sel"] = sel if rec["sel"] is None else max(rec["sel"], sel)
        if rec["temp"] is None:
            rec["temp"] = _temp_range(cell(row, "temp"))
    return list(agg.values())


def _write(rec: dict) -> int:
    url = rec["url"] or f"https://www.analog.com/{rec['mpn']}"
    pid = upsert_part(mpn=rec["mpn"], vendor=VENDOR, category=rec["category"],
                      subcategory=rec["subcategory"], product_url=url,
                      description=rec["description"])
    rows = []

    def add(key, snippet, **kw):
        rows.append(SpecRow(key=key, method="catalog", confidence=0.9,
                            source_url=url, snippet=snippet[:150], **kw))

    if rec["tid"] is not None:
        add("tid_krad", f"TID threshold {rec['tid']:g} kRad",
            value_typ=rec["tid"], unit="krad")
    if rec["sel"] is not None:
        add("sel_mev", f"SEL threshold {rec['sel']:g} MeV*cm2/mg",
            value_typ=rec["sel"], unit="MeV*cm2/mg")
    if rec["temp"]:
        add("temp_c", f"operating {rec['temp']['value_min']:g}..{rec['temp']['value_max']:g} C",
            **rec["temp"])
    if rec["packages"]:
        add("package", "ADI package", value_text="; ".join(sorted(rec["packages"]))[:200])
    if rec["orderables"]:
        add("orderable", "ADI orderable material numbers",
            value_text=", ".join(sorted(rec["orderables"]))[:200])
    if rec["adi_category"]:
        add("source_category", "ADI category",
            value_text=f"{rec['adi_category']} / {rec['adi_subcategory']}"[:200])
    if rec["level"]:
        add("qual_level", "ADI space qualification level", value_text=rec["level"][:200])
    # space readiness (both variants are space-ready; variant carries the pedigree)
    add("space", rec["reason"], value_text="qualified")
    add("space_variant", rec["reason"], value_text=rec["variant"])
    put_specs(pid, rows)

    if rec["variant"] == "space_qualified":
        put_evidence(pid, [("adi-space-portfolio-qualified", 9.0, url,
                            rec["reason"] or "ADI space-qualified portfolio")])
    else:
        put_evidence(pid, [("adi-space-portfolio-grade", 7.0, url,
                            rec["reason"] or "ADI space portfolio")])
    return pid


def ingest(path: Path, dry_run: bool = False, verbose: bool = False) -> dict:
    path = Path(path)
    if not path.is_file():
        raise SystemExit(f"file not found: {path}")
    records = parse_rows(path)
    counts = Counter()
    for rec in records:
        counts["parts"] += 1
        counts[rec["variant"]] += 1
        if verbose:
            print(f"  {rec['mpn']:<20} {rec['category']:<14} {rec['variant']}")
        if not dry_run:
            _write(rec)
    return dict(counts)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file", help="ADI space portfolio .xlsx")
    ap.add_argument("--dry-run", action="store_true", help="parse and report, write nothing")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args(argv)
    c = ingest(Path(args.file), args.dry_run, args.verbose)
    print("\n=== ADI space portfolio ingest "
          + ("(dry run) ===" if args.dry_run else "===")
          + f"\n  parts             {c.get('parts', 0)}"
          + f"\n    space_qualified {c.get('space_qualified', 0)}"
          + f"\n    space_grade     {c.get('space_grade', 0)}")
    if args.dry_run:
        print("  (nothing written -- drop --dry-run to commit)")


if __name__ == "__main__":
    main()
