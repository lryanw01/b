"""Sitemap-based part discovery — no search engine, no spoofing, pip-only.

Replaces web-search seeding on networks where search engines are unreachable
or where search-scraping dependencies are unacceptable (ddgs pulls in primp, a
browser-impersonation client — exactly the anti-bot evasion this project's
design rules out).

How it works: RF vendors publish sitemap.xml files listing every product page.
For each domain in VENDOR_DOMAINS (plus any the user adds), this module:

  1. reads robots.txt for `Sitemap:` lines (the standard discovery mechanism —
     using it IS respecting robots.txt), falling back to /sitemap.xml,
  2. parses the XML with stdlib ElementTree, following one level of sitemap
     index nesting,
  3. scores each URL against the requirement spec (category synonyms in the
     path, product-page shape) and pushes the best ones into the crawl
     frontier, where the normal same-domain recursion takes over.

Everything is plain `requests` through the project's polite fetch layer when
available: honest UA, robots-aware, rate-limited, cached. Sitemaps are cached
hard (they're big and change slowly).

Public API:
    seed_frontier(spec, domains=None, per_domain=40) -> int   (# URLs queued)
    sitemap_urls(domain) -> list[str]
"""
from __future__ import annotations

import gzip
import io
import os
import re
import xml.etree.ElementTree as ET
from urllib.parse import urlparse

from . import netfix  # noqa: F401  (process-global TLS fix, must import early)
from . import partdb

try:
    from . import fetch as _fetch
except ImportError:
    _fetch = None

import requests

try:
    from .registry import CATEGORY_SYNONYMS
except ImportError:
    CATEGORY_SYNONYMS = {}

UA = {"User-Agent": "rfparts/2.0 (component sourcing; contact: set-me)"}

SITEMAP_TTL = 7 * 86400

MAX_SITEMAP_BYTES = 20 * 1024 * 1024

MAX_CHILD_SITEMAPS = int(os.environ.get("RFPARTS_MAX_CHILD_SITEMAPS", 8))

# RF/microwave vendors with server-rendered catalogs and usable sitemaps.
# Extend freely — or pass your own list to seed_frontier(domains=[...]).
VENDOR_DOMAINS = [
    "markimicrowave.com",
    "pasternack.com",
    "fairviewmicrowave.com",
    "minicircuits.com",
    "macom.com",
    "qorvo.com",
    "analog.com",
    "psemi.com",
    "narda-miteq.com",
    "krytar.com",
    "ditom.com",
    "jfwindustries.com",
    "xma-corp.com",
    "rlcelectronics.com",
    "lownoisefactory.com",
    "apitech.com",
    "smithsinterconnect.com",
]

_PRODUCTY = re.compile(
    r"/(?:products?|parts?|models?|series|catalog|store|component)s?/|"
    r"datasheet|dashboard\.html", re.I)

_JUNKY = re.compile(
    r"/(?:news|blog|careers?|about|press|events?|privacy|legal|terms|"
    r"login|cart|account|contact|support|resources|videos?)(?:/|$)|"
    r"\.(?:jpg|png|gif|svg|css|js)$", re.I)

_XMLNS = re.compile(r"\{[^}]+\}")


def _get_text(url):
    """Fetch a (possibly gzipped) sitemap politely; '' on any failure."""
    body = None
    if _fetch is not None and hasattr(_fetch, "get_bytes"):
        try:
            body = _fetch.get_bytes(url, ttl=SITEMAP_TTL)
        except TypeError:
            body = _fetch.get_bytes(url)
        except Exception:
            body = None
    if body is None:
        try:
            r = requests.get(url, headers=UA, timeout=25)
            r.raise_for_status()
            body = r.content
        except requests.RequestException:
            return ""
    if not body or len(body) > MAX_SITEMAP_BYTES:
        return ""
    if body[:2] == b"\x1f\x8b" or url.endswith(".gz"):
        try:
            body = gzip.decompress(body)
        except OSError:
            return ""
    try:
        return body.decode("utf-8", "replace")
    except Exception:
        return ""


def _parse_sitemap(xml_text):
    """-> (page_urls, child_sitemap_urls). Namespace-agnostic."""
    pages, children = [], []
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return pages, children
    tag = _XMLNS.sub("", root.tag).lower()
    for el in root.iter():
        if _XMLNS.sub("", el.tag).lower() != "loc" or not (el.text or "").strip():
            continue
        loc = el.text.strip()
        if tag == "sitemapindex":
            children.append(loc)
        else:
            pages.append(loc)
    return pages, children


def _sitemap_starts(domain):
    """Sitemap URLs for a domain: robots.txt `Sitemap:` lines, else defaults."""
    starts = []
    robots = _get_text(f"https://www.{domain}/robots.txt") or \
        _get_text(f"https://{domain}/robots.txt")
    for line in robots.splitlines():
        if line.lower().startswith("sitemap:"):
            starts.append(line.split(":", 1)[1].strip())
    if not starts:
        starts = [f"https://www.{domain}/sitemap.xml",
                  f"https://{domain}/sitemap.xml"]
    return starts


def sitemap_urls(domain):
    """All page URLs from a domain's sitemap(s), one index level deep."""
    urls = []
    for start in _sitemap_starts(domain):
        text = _get_text(start)
        if not text:
            continue
        pages, children = _parse_sitemap(text)
        urls.extend(pages)
        # Prefer product-looking child sitemaps when the index is large.
        children.sort(key=lambda u: 0 if _PRODUCTY.search(u) else 1)
        for child in children[:MAX_CHILD_SITEMAPS]:
            cpages, _ = _parse_sitemap(_get_text(child))
            urls.extend(cpages)
        if urls:
            break
    return urls


# A part number in the last URL segment: letters+digits, often hyphenated,
# e.g. amm-7200uc-k, 567-13-apm-6848ch, grf2118, cl-1012.
_PN_IN_URL = re.compile(
    r"^(?:[a-z]{1,6}[-_]?\d{2,6}[a-z0-9\-+]*|"
    r"[a-z0-9]+(?:-[a-z0-9]+){1,5})$", re.I)

_PN_STRONG = re.compile(r"[a-z]{2,}[-_]?\d{2,}|\d{2,}[-_]?[a-z]{2,}", re.I)


# Quote / datasheet-request / login pages carry part numbers in their URLs and
# would otherwise score as products, but contain no specs.
_REQUEST_FORM = re.compile(
    r"request[-_/]?(?:a[-_]?)?(?:datasheet|quote|sample|info|pricing)|"
    r"/rfq|/quote|/inquir|/enquir|/contact|datasheet[-_]?request|"
    r"/download[-_]?request|lead[-_]?form|/register|/login|/cart", re.I)


def is_request_form(url):
    return bool(_REQUEST_FORM.search(url or ""))


def _score(url, tokens):
    low = url.lower()
    s = 0.0
    if _JUNKY.search(low) or is_request_form(low):
        return -10.0
    if _PRODUCTY.search(low):
        s += 3.0
    for t in tokens:
        if t and t in low:
            s += 4.0
    tail = urlparse(url).path.rstrip("/").rsplit("/", 1)[-1]
    # Part-number shape in the last segment is the single strongest signal
    # that a URL is a PRODUCT page rather than a category or article.
    if _PN_STRONG.search(tail):
        s += 4.0
    elif _PN_IN_URL.match(tail):
        s += 2.0
    elif re.search(r"\d", tail):
        s += 1.0
    depth = len([x for x in urlparse(url).path.split("/") if x])
    if depth >= 3:
        s += 1.0                         # deep paths are usually products
    return s


def _top_cluster(scored, min_keep=10, max_keep=400):
    """Take the top natural cluster of scores instead of a fixed top-N.

    Sorted descending, walk down and cut at the largest gap between adjacent
    scores in the upper region. A hard top-40 cap discarded thousands of
    equally-good product URLs on big sitemaps (Fairview: 40,000 URLs -> 40
    kept), and kept junk on small ones.
    """
    if not scored:
        return []
    vals = [sc for _u, sc in scored]
    positives = [i for i, v in enumerate(vals) if v > 0]
    if not positives:
        return []
    end = positives[-1] + 1
    if end <= min_keep:
        return scored[:end]
    best_i, best_gap = end, 0.0
    # only consider cuts after min_keep and before max_keep
    for i in range(min_keep, min(end, max_keep)):
        gap = vals[i - 1] - vals[i]
        if gap > best_gap:
            best_gap, best_i = gap, i
    # a meaningful cluster boundary needs a real gap; otherwise keep all
    # positives up to max_keep
    if best_gap < 1.0:
        best_i = min(end, max_keep)
    return scored[:best_i]


def url_template(url):
    """Structural signature of a URL path: (n_segments, static prefix).

    /products/microwave-rf-amplifiers/marki-microwave/567-13-apm-6848ch
      -> (4, '/products/microwave-rf-amplifiers')
    /products/connectorized/amplifiers/amm-7200uc-k/
      -> (4, '/products/connectorized/amplifiers')
    Everything but the final (part-number) segment is treated as the prefix,
    so sibling parts under the same catalog branch share a template.
    """
    segs = [x for x in urlparse(url).path.split("/") if x]
    if len(segs) < 2:
        return None
    return (len(segs), "/" + "/".join(segs[:-1]))


def urls_matching_templates(domain, templates, limit=2000):
    """Retroactively pull every sitemap URL of `domain` matching any learned
    product template. This is how one confirmed product page turns into its
    whole catalog branch without re-scoring heuristics."""
    if not templates:
        return []
    out = []
    for u in sitemap_urls(domain):
        t = url_template(u)
        if t and t in templates:
            out.append(u)
            if len(out) >= limit:
                break
    return out


def _tokens_for(spec):
    cat = spec.get("category", "")
    toks = set()
    for syn in CATEGORY_SYNONYMS.get(cat, [cat]) or [cat]:
        syn = str(syn).lower().strip()
        if syn:
            toks.add(syn.replace(" ", "-"))
            toks.add(syn.replace(" ", ""))
            toks.add(syn.replace(" ", "_"))
    return toks


# SATNow (space & satellite marketplace) facet URLs — slugs and URL scheme
# lifted verbatim from the user's working rfparts_space.py probe. Listing pages
# under these facets contain real /products/ part pages; parts discovered here
# carry a space-marketplace evidence signal (see crawler._ingest_product).
SATNOW = {
    "lna":             [("microwave-rf-amplifiers", "stype", "Low Noise Amplifier")],
    "amplifier":       [("microwave-rf-amplifiers", None, None)],
    "power_amplifier": [("microwave-rf-amplifiers", "stype", "Power Amplifier")],
    "phase_shifter":   [("analog-phase-shifters", None, None),
                        ("digital-phase-shifters", None, None)],
    "attenuator":      [("microwave-rf-fixed-attenuators", None, None),
                        ("microwave-rf-variable-attenuators", None, None)],
    "switch":          [("microwave-rf-switches", None, None)],
    "filter":          [("rf-filters", None, None)],
    "mixer":           [("microwave-rf-mixers", None, None)],
    "limiter":         [("microwave-rf-limiters", None, None)],
    "coupler":         [("couplers", None, None)],
    "divider":         [("power-dividers-combiners", None, None)],
    "isolator":        [("isolators-circulators", None, None)],
    "circulator":      [("isolators-circulators", None, None)],
    "oscillator":      [("oscillators", None, None)],
}

SATNOW_PAGES = int(os.environ.get("RFPARTS_SATNOW_PAGES", 3))

# everythingRF — SATNow's sibling site (same platform, same /search/<slug> and
# /products/<cat>/<mfr>/<part> shapes), which lists space-qualified parts as an
# explicit "Space Qualified: Yes" product field. NOT auto-qualified like
# SATNow (it's mostly COTS): qualification comes from that page field via the
# aggregator-space-field evidence signal.
# everythingRF — same platform as SATNow (identical /search/<slug>/filters and
# /products/<cat>/<mfr>/<part> shapes), confirmed against a real saved page.
# CRITICAL: the slug is the SATNow one ("microwave-rf-amplifiers"), not
# "rf-amplifiers" — the earlier guess 404'd and classified as junk.
# The space filter is a query param: sindustry_application=;Space;
EVERYTHINGRF = {
    "amplifier":       ["microwave-rf-amplifiers"],
    "lna":             ["microwave-rf-amplifiers"],
    "power_amplifier": ["microwave-rf-amplifiers"],
    "attenuator":      ["microwave-rf-fixed-attenuators",
                        "microwave-rf-variable-attenuators"],
    "filter":          ["rf-filters"],
    "mixer":           ["microwave-rf-mixers"],
    "switch":          ["microwave-rf-switches"],
    "coupler":         ["couplers"],
    "divider":         ["power-dividers-combiners"],
    "phase_shifter":   ["analog-phase-shifters", "digital-phase-shifters"],
    "limiter":         ["microwave-rf-limiters"],
    "oscillator":      ["oscillators"],
    "circulator":      ["isolators-circulators"],
    "isolator":        ["isolators-circulators"],
    "multiplier":      ["frequency-multipliers"],
    "detector":        ["rf-detectors"],
}

ERF_SPACE_FILTER = "sindustry_application=;Space;"

ERF_PAGES = int(os.environ.get("RFPARTS_ERF_PAGES", 8))

# Space-heavy RF vendors whose ENTIRE catalogs are hi-rel/space lines. Seeded
# through the normal sitemap path and pre-marked with a hi-rel vendor fact so
# their parts pick up the vendor-level qualifiable evidence immediately.
SPACE_VENDOR_DOMAINS = [
    "frontgrade.com",                   # CAES/Cobham rad-hard
    "teledynedefenseelectronics.com",   # Teledyne e2v HiRel
    "erzia.com",                        # space Ka/Ku amplifiers
    "micross.com",                      # hi-rel die/packaging + components
    "craneae.com",                      # Interpoint space power
]


def leash_slugs(domain, category):
    """Aggregator leash: on these domains, listing expansion may only follow
    links carrying the seeded category's slug(s). None = no leash (normal
    vendor domain)."""
    if domain == "satnow.com":
        return tuple(sl for sl, _f, _v in SATNOW.get(category, []))
    if domain == "everythingrf.com":
        return tuple(EVERYTHINGRF.get(category, ()))
    return None


def seed_everythingrf(spec):
    """Seed everythingRF listing pages. When space qualification is required,
    every URL carries the Space industry-application filter, so the listings
    contain ONLY space parts — the aggregator does the qualification filtering
    server-side and each product inherits qualified status from the facet."""
    queued = 0
    cats = [spec.get("category") or ""]
    if spec.get("subcategory"):
        cats.insert(0, spec["subcategory"])
    space = bool(spec.get("space"))
    for cat in cats:
        for slug in EVERYTHINGRF.get(cat, []):
            for page in range(1, ERF_PAGES + 1):
                if space:
                    url = (f"https://www.everythingrf.com/search/{slug}/filters"
                           f"?page={page}&country=global&{ERF_SPACE_FILTER}")
                else:
                    url = (f"https://www.everythingrf.com/search/{slug}"
                           f"?page={page}")
                if partdb.frontier_push(url, 21.0, 0, "everythingrf.com",
                                        requeue=True):
                    queued += 1
    return queued


def mark_space_vendors():
    """Record the hi-rel vendor fact for the dedicated space-vendor domains."""
    for d in SPACE_VENDOR_DOMAINS:
        partdb.put_vendor_fact(d, hirel_program=1)


def seed_satnow(spec):
    """Push SATNow facet listing pages for the spec's category (and its
    subcategory synonyms) into the frontier at high priority. The crawler's
    listing expansion turns them into /products/ part pages. Returns # queued."""
    from urllib.parse import quote_plus
    cats = [spec.get("category") or ""]
    if spec.get("subcategory"):
        cats.insert(0, spec["subcategory"])
    queued = 0
    for cat in cats:
        for slug, fparam, fval in SATNOW.get(cat, []):
            for page in range(1, SATNOW_PAGES + 1):
                if fparam:
                    url = (f"https://www.satnow.com/search/{slug}/filters"
                           f"?page={page}&country=global&{fparam}={quote_plus(fval)}")
                else:
                    url = f"https://www.satnow.com/search/{slug}?page={page}"
                if partdb.frontier_push(url, 20.0, 0, "satnow.com",
                                        requeue=True):
                    queued += 1
    return queued


def seed_frontier(spec, domains=None, per_domain=40, on_progress=None):
    """Seed the crawl frontier from vendor sitemaps. Returns # URLs queued.

    Listing pages score highest and enter at depth 0, so the crawler's normal
    same-domain recursion expands them into product pages exactly as it would
    for a search hit.
    """
    tokens = _tokens_for(spec)
    queued = 0
    if spec.get("space"):
        queued += seed_satnow(spec)
        queued += seed_everythingrf(spec)
        mark_space_vendors()
        domains = list(domains or VENDOR_DOMAINS) + SPACE_VENDOR_DOMAINS
    for domain in (domains or VENDOR_DOMAINS):
        urls = sitemap_urls(domain)
        scored = sorted(((u, _score(u, tokens)) for u in urls),
                        key=lambda x: -x[1])
        keep = _top_cluster(scored, min_keep=max(10, per_domain // 2),
                            max_keep=per_domain * 10)
        n = 0
        for url, sc in keep:
            if partdb.frontier_push(url, sc, 0, domain):
                queued += 1
                n += 1
        # Retroactive template expansion: any product templates already
        # learned for this domain pull in their whole catalog branch.
        for u in urls_matching_templates(domain,
                                         partdb.get_templates(domain)):
            if partdb.frontier_push(u, 8.0, 1, domain):
                queued += 1
                n += 1
        if on_progress:
            on_progress(domain, len(urls), n)
    return queued
