"""One-time migration of legacy RF Parts data into the top-level Data folder.

Run from the project root:
    python migrate_rfparts_data.py

The script copies rather than deletes legacy files. Existing destination files
are preserved unless --overwrite is supplied.
"""
from __future__ import annotations

import argparse
import shutil
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEST = PROJECT_ROOT / "Data"


def copy_item(src: Path, dst: Path, overwrite: bool) -> int:
    if not src.exists():
        return 0
    if src.is_dir():
        copied = 0
        for child in src.rglob("*"):
            if not child.is_file():
                continue
            rel = child.relative_to(src)
            target = dst / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists() and not overwrite:
                continue
            shutil.copy2(child, target)
            copied += 1
        return copied
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists() and not overwrite:
        return 0
    shutil.copy2(src, dst)
    return 1


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--overwrite", action="store_true")
    args = ap.parse_args()
    DEST.mkdir(parents=True, exist_ok=True)

    legacy_roots = [
        Path.home() / ".rfparts",
        PROJECT_ROOT / "rfparts" / "Data",
        PROJECT_ROOT / "rfparts" / ".rfparts",
    ]
    mappings = {
        "parts.db": Path("database/parts.db"),
        "parts.db-wal": Path("database/parts.db-wal"),
        "parts.db-shm": Path("database/parts.db-shm"),
        "vendor_cache": Path("cache/vendor_pages"),
        "vendor_pages": Path("cache/vendor_pages"),
        "scrape_state.json": Path("cache/scrape_state.json"),
        "datasheets": Path("datasheets"),
        "minicircuits_live_specs.json": Path("minicircuits_live_specs.json"),
        "cache.db": Path("cache.db"),
        "results.json": Path("results.json"),
        "results.md": Path("results.md"),
        "gui_prefs.json": Path("gui_prefs.json"),
    }

    total = 0
    for root in legacy_roots:
        if not root.exists() or root.resolve() == DEST.resolve():
            continue
        for old_name, relative_dest in mappings.items():
            count = copy_item(root / old_name, DEST / relative_dest,
                              args.overwrite)
            if count:
                print(f"copied {count:>5} item(s): {root / old_name} -> {DEST / relative_dest}")
                total += count
    print(f"Migration complete. {total} file(s) copied. Destination: {DEST}")


if __name__ == "__main__":
    main()
