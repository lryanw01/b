"""Verify the modules still agree with each other.

Two breakages shipped because nothing checked the seams between layers:

  * `space_dataset` called `partdb.reset_dataset(...)`, which did not exist, so
    the Reset option raised AttributeError the first time anyone used it.
  * `gui`, `space_dataset` and `erf_space_ingest` all imported `rfparts.paths`,
    which was never added, so a clean tree died on import.

Both are the same class of fault: a caller and a callee drifting apart between
patches. Both are caught in under a second by importing every module and
comparing each cross-module call against the target's real signature.

    python -m rfparts.selfcheck            # exits non-zero on any failure
    python -m rfparts.selfcheck --verbose

Run it before shipping a patch. It needs no database, no network and no Tk
display (the GUI module is import-checked, not instantiated).
"""
from __future__ import annotations

import argparse
import importlib
import inspect
import sys

# Every module that must import cleanly.
MODULES = [
    "paths", "partdb", "pedigree", "registry", "spec", "rank", "rfq",
    "marketplaces", "space_dataset", "vendor_catalogs",
    "adi_parametric_ingest", "adi_space_ingest", "erf_space_ingest",
    "adi_ingest", "qorvo_ingest",
    "ti_ingest", "parse_debug", "parse_sample", "nospec_audit", "cli",
]
GUI_MODULES = ["gui"]

# (module, attribute) pairs that other modules call. Checked for existence.
REQUIRED_ATTRS = [
    ("partdb", "upsert_part"), ("partdb", "put_specs"),
    ("partdb", "put_evidence"), ("partdb", "merge_duplicates"),
    ("partdb", "dataset_stats"), ("partdb", "dataset_health"),
    ("partdb", "reset_dataset"), ("partdb", "mark_scraped"),
    ("partdb", "already_scraped"), ("partdb", "scraped_keys"),
    ("partdb", "vendor_part_counts"), ("partdb", "vendor_counts"),
    ("partdb", "export_parts_json"), ("partdb", "family_key"),
    ("paths", "DATA_ROOT"), ("paths", "CACHE_DIR"), ("paths", "EVERYTHING_RF"),
    ("paths", "NEW_SOURCES"), ("paths", "ADI_PARAMETRICS"),
    ("paths", "EXPORT_DIR"), ("paths", "describe"),
    ("space_dataset", "rebuild"), ("space_dataset", "CATALOG_VENDORS"),
    ("vendor_catalogs", "ingest"), ("vendor_catalogs", "ALL_VENDORS"),
    ("vendor_catalogs", "VENDORS"), ("vendor_catalogs", "Reporter"),
    ("vendor_catalogs", "ResumeState"), ("vendor_catalogs", "parse_tables"),
    ("vendor_catalogs", "map_headers"), ("vendor_catalogs", "looks_like_pn"),
    ("vendor_catalogs", "is_orderable_part"),
    ("parse_debug", "inspect_source"), ("parse_debug", "render"),
    ("parse_debug", "cached_files"), ("parse_debug", "inspect_path"),
    ("parse_debug", "all_sources"), ("parse_debug", "vendors_available"),
    ("parse_sample", "build_bundle"), ("parse_sample", "SAMPLE_VENDORS"),
    ("nospec_audit", "build_audit"), ("nospec_audit", "parts_with_gaps"),
    ("nospec_audit", "verdict_for"), ("nospec_audit", "visible_text"),
    ("nospec_audit", "source_group_for"), ("nospec_audit", "SOURCE_GROUPS"),
    ("partdb", "effective_nf"), ("partdb", "PASSIVE_CATEGORIES"),
    ("adi_space_ingest", "parse_workbook"), ("adi_space_ingest", "find_workbooks"),
    ("erf_space_ingest", "flat_specs"),
    ("registry", "GUI_CATEGORIES"), ("registry", "category_label"),
]

# Keyword arguments one layer passes to another. A missing keyword here is
# exactly the failure mode that broke Reset.
REQUIRED_KWARGS = [
    ("space_dataset", "rebuild", [
        "erf_parent", "source_files", "source_dir", "dedupe", "progress",
        "vendors", "vendor_rate", "vendor_limits", "download_datasheets",
        "adi_dir", "use_cache", "categories", "reset", "resume",
        "reset_vendors_only", "part", "event", "cancel"]),
    ("vendor_catalogs", "ingest", [
        "vendors", "rate", "progress", "limits", "download", "download_limit",
        "adi_dir", "use_cache", "categories", "resume", "part", "event",
        "cancel"]),
    ("partdb", "dataset_health", ["vendor"]),
    ("partdb", "reset_dataset", ["vendors", "clear_cache", "progress"]),
    ("partdb", "mark_scraped", ["vendor", "key", "kind", "parts_found"]),
    ("erf_space_ingest", "ingest", [
        "parent", "glob", "dry_run", "verbose", "default_variant", "resume",
        "progress", "part", "cancel"]),
    ("adi_parametric_ingest", "ingest", [
        "path", "dry_run", "verbose", "progress", "categories", "part",
        "cancel"]),
    ("parse_sample", "build_bundle", [
        "vendors", "per_vendor", "out_path", "progress", "offline", "rate"]),
    ("nospec_audit", "build_audit", [
        "sources", "categories", "per_source", "out_path", "progress",
        "missing_only", "vendors", "per_vendor"]),
    ("nospec_audit", "parts_with_gaps", [
        "sources", "categories", "per_source", "require_missing"]),
    ("adi_space_ingest", "ingest", [
        "path", "dry_run", "verbose", "progress", "categories", "part",
        "cancel"]),
    ("erf_space_ingest", "flat_specs", ["part"]),
]


def undefined_names(path):
    """Names a function reads but nothing ever defines.

    This is the fault that produced "name 'part_cb' is not defined" on Reset: a
    patch anchored on `def emit(message):` while the file actually said
    `def emit(message: str) -> None:`, so the helper definitions were never
    inserted while their call sites were. The module still imports and still
    compiles -- it only fails when that branch runs, which may be days later.
    A scope walk finds it in milliseconds.
    """
    import ast
    import builtins
    from pathlib import Path
    try:
        tree = ast.parse(Path(path).read_text(encoding="utf-8"))
    except Exception as e:
        return [f"{Path(path).name}: does not parse: {e}"]

    module_names = set(dir(builtins))
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            module_names.add(node.name)
        elif isinstance(node, ast.Assign):
            for t in node.targets:
                module_names.update(n.id for n in ast.walk(t)
                                    if isinstance(n, ast.Name))
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            module_names.add(node.target.id)
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            for a in node.names:
                module_names.add((a.asname or a.name).split(".")[0])
        elif isinstance(node, (ast.Try, ast.If, ast.For, ast.While, ast.With)):
            # conditional imports and module-level try/except fallbacks
            for sub in ast.walk(node):
                if isinstance(sub, (ast.Import, ast.ImportFrom)):
                    for a in sub.names:
                        module_names.add((a.asname or a.name).split(".")[0])
                elif isinstance(sub, ast.Assign):
                    for t in sub.targets:
                        module_names.update(n.id for n in ast.walk(t)
                                            if isinstance(n, ast.Name))
                elif isinstance(sub, (ast.FunctionDef, ast.AsyncFunctionDef,
                                      ast.ClassDef)):
                    module_names.add(sub.name)

    problems = []

    def _args_of(argobj, names):
        for a in list(argobj.args) + list(argobj.kwonlyargs) + \
                list(getattr(argobj, "posonlyargs", [])):
            names.add(a.arg)
        if argobj.vararg:
            names.add(argobj.vararg.arg)
        if argobj.kwarg:
            names.add(argobj.kwarg.arg)

    def bound_in(fn):
        names = set()
        # arguments of this function AND of every function nested inside it, so a
        # closure's own parameters are not reported as undefined
        for node in ast.walk(fn):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef,
                                 ast.Lambda)):
                _args_of(node.args, names)
        for node in ast.walk(fn):
            if isinstance(node, ast.Assign):
                for t in node.targets:
                    names.update(n.id for n in ast.walk(t)
                                 if isinstance(n, ast.Name))
            elif isinstance(node, ast.AnnAssign) and \
                    isinstance(node.target, ast.Name):
                names.add(node.target.id)
            elif isinstance(node, ast.AugAssign) and \
                    isinstance(node.target, ast.Name):
                names.add(node.target.id)
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef,
                                   ast.ClassDef)):
                names.add(node.name)
            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                for a in node.names:
                    names.add((a.asname or a.name).split(".")[0])
            elif isinstance(node, (ast.For, ast.AsyncFor)):
                names.update(n.id for n in ast.walk(node.target)
                             if isinstance(n, ast.Name))
            elif isinstance(node, ast.comprehension):
                names.update(n.id for n in ast.walk(node.target)
                             if isinstance(n, ast.Name))
            elif isinstance(node, ast.withitem) and node.optional_vars:
                names.update(n.id for n in ast.walk(node.optional_vars)
                             if isinstance(n, ast.Name))
            elif isinstance(node, ast.ExceptHandler) and node.name:
                names.add(node.name)
            elif isinstance(node, (ast.Global, ast.Nonlocal)):
                names.update(node.names)
            elif isinstance(node, ast.NamedExpr) and \
                    isinstance(node.target, ast.Name):
                names.add(node.target.id)
        return names

    # walk top-level functions and methods, giving each nested function the
    # enclosing function's bindings as well
    def visit(fn):
        local = bound_in(fn)
        for node in ast.walk(fn):
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
                if node.id not in local and node.id not in module_names:
                    problems.append(
                        f"{Path(path).name}:{node.lineno} in {fn.name}(): "
                        f"'{node.id}' is used but never defined")

    # roots only: module-level functions and the methods of module-level classes.
    # ast.walk(root) already covers everything nested inside them.
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            visit(node)
        elif isinstance(node, ast.ClassDef):
            for m in node.body:
                if isinstance(m, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    visit(m)
    # de-duplicate, keep order
    seen, out = set(), []
    for pr in problems:
        if pr not in seen:
            seen.add(pr)
            out.append(pr)
    return out


def unassigned_attributes(path):
    """`self.X` read in a class where nothing ever assigns `self.X`.

    This is the failure that hid the bundle button: a patch anchored on
    `ttk.Frame(frm)` while the file said `ttk.Frame(self, padding=...)`, so the
    widgets -- including `self.sample_n` -- were never created, while the handler
    that reads them was. The module imports, compiles, and passes the
    dangling-NAME scan, because `self.sample_n` is an attribute, not a name. It
    only fails when the button is pressed.

    To stay quiet, this reports only the pattern that actually signals a missing
    widget or variable: `self.X` followed by a further attribute access, as in
    `self.sample_n.get()`. A bare `self.X` -- a method passed as a callback
    (`command=self.destroy`), a dataclass field in an f-string -- is skipped,
    since those are legitimately inherited or class-level.
    """
    import ast
    from pathlib import Path as _P
    try:
        tree = ast.parse(_P(path).read_text(encoding="utf-8"))
    except Exception:
        return []
    problems = []
    for cls in [n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)]:
        assigned = set()
        for node in ast.walk(cls):
            if isinstance(node, ast.Assign):
                for t in node.targets:
                    for a in ast.walk(t):
                        if isinstance(a, ast.Attribute) and \
                                isinstance(a.value, ast.Name) and \
                                a.value.id == "self":
                            assigned.add(a.attr)
            elif isinstance(node, (ast.AnnAssign, ast.AugAssign)):
                tgt = node.target
                if isinstance(tgt, ast.Attribute) and \
                        isinstance(tgt.value, ast.Name) and tgt.value.id == "self":
                    assigned.add(tgt.attr)
            elif isinstance(node, (ast.For, ast.AsyncFor)):
                for a in ast.walk(node.target):
                    if isinstance(a, ast.Attribute) and \
                            isinstance(a.value, ast.Name) and a.value.id == "self":
                        assigned.add(a.attr)
        # methods and class-level fields count as assigned
        for node in cls.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                assigned.add(node.name)
            elif isinstance(node, ast.AnnAssign) and \
                    isinstance(node.target, ast.Name):
                assigned.add(node.target.id)
            elif isinstance(node, ast.Assign):
                # class-level constants: _FILTER_RESPONSE = {...}
                for t in node.targets:
                    if isinstance(t, ast.Name):
                        assigned.add(t.id)
        # attributes that are the function of a call are method lookups
        called = set()
        for node in ast.walk(cls):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) \
                    and isinstance(node.func.value, ast.Name) \
                    and node.func.value.id == "self":
                called.add(node.func.attr)
        # only `self.X.<something>` -- we then use X as an object, which is what a
        # never-created widget or StringVar looks like
        used_as_object = set()
        for node in ast.walk(cls):
            inner = getattr(node, "value", None)
            if isinstance(node, (ast.Attribute, ast.Subscript)) and \
                    isinstance(inner, ast.Attribute) and \
                    isinstance(inner.ctx, ast.Load) and \
                    isinstance(inner.value, ast.Name) and \
                    inner.value.id == "self":
                used_as_object.add((inner.attr, inner.lineno))
        for attr, lineno in sorted(used_as_object):
            if attr in assigned or attr in called:
                continue
            problems.append(
                f"{_P(path).name}:{lineno} {cls.name}.self.{attr} is used as an "
                f"object but never assigned in the class")
    seen, out = set(), []
    for pr in problems:
        if pr not in seen:
            seen.add(pr)
            out.append(pr)
    return out


def check(verbose=False):
    failures, notes = [], []

    def say(msg):
        if verbose:
            print(msg)

    loaded = {}
    for name in MODULES:
        try:
            loaded[name] = importlib.import_module(f"rfparts.{name}")
            say(f"  import  OK    rfparts.{name}")
        except Exception as e:
            failures.append(f"import rfparts.{name}: {type(e).__name__}: {e}")
            say(f"  import  FAIL  rfparts.{name}: {e}")

    # Tk may be absent on a headless box; that is not a code fault.
    for name in GUI_MODULES:
        try:
            loaded[name] = importlib.import_module(f"rfparts.{name}")
            say(f"  import  OK    rfparts.{name}")
        except ImportError as e:
            if "tkinter" in str(e).lower() or "_tkinter" in str(e).lower():
                notes.append(f"rfparts.{name} skipped: no Tk available here")
                say(f"  import  SKIP  rfparts.{name} (no Tk)")
            else:
                failures.append(f"import rfparts.{name}: {e}")
        except Exception as e:
            failures.append(f"import rfparts.{name}: {type(e).__name__}: {e}")

    for mod, attr in REQUIRED_ATTRS:
        m = loaded.get(mod)
        if m is None:
            continue
        if not hasattr(m, attr):
            failures.append(f"{mod}.{attr} is missing but other modules use it")
            say(f"  attr    FAIL  {mod}.{attr}")
        else:
            say(f"  attr    OK    {mod}.{attr}")

    for mod, fn, kwargs in REQUIRED_KWARGS:
        m = loaded.get(mod)
        if m is None or not hasattr(m, fn):
            continue
        try:
            sig = inspect.signature(getattr(m, fn))
        except (TypeError, ValueError):
            continue
        params = sig.parameters
        takes_kwargs = any(p.kind is inspect.Parameter.VAR_KEYWORD
                           for p in params.values())
        for kw in kwargs:
            if kw not in params and not takes_kwargs:
                failures.append(
                    f"{mod}.{fn}() does not accept '{kw}', but a caller passes it")
                say(f"  kwarg   FAIL  {mod}.{fn}({kw}=)")
        say(f"  kwarg   OK    {mod}.{fn} accepts {len(kwargs)} checked arg(s)")

    # gui: if Tk is unavailable (headless build box, CI) fall back to parsing the
    # source, so the module most changed by a patch is never simply unchecked.
    gui = loaded.get("gui")
    if gui is None:
        import ast
        from pathlib import Path as _P
        gui_src = _P(__file__).with_name("gui.py")
        try:
            tree = ast.parse(gui_src.read_text(encoding="utf-8"))
        except Exception as e:
            failures.append(f"gui.py does not parse: {type(e).__name__}: {e}")
            tree = None
        if tree is not None:
            classes = {n.name: {m.name for m in n.body
                                if isinstance(m, (ast.FunctionDef,
                                                  ast.AsyncFunctionDef))}
                       for n in ast.walk(tree) if isinstance(n, ast.ClassDef)}
            for cls_name, methods in (
                    ("BuildProgressWindow",
                     ["add_message", "add_part", "handle_event", "finish",
                      "_upsert_part", "_refresh_vendor_rows", "_request_stop",
                      "_open_health", "_tick"]),
                    ("ParseInspectorWindow", ["_run", "_load_list"]),
                    ("RebuildDialog", ["_go", "_mode_changed",
                                       "_make_sample_bundle"]),
                    ("SampleBundleWindow", ["_copy", "_reveal"]),

                    ("App", ["run_rebuild", "_poll_rebuild", "_put_part",
                             "_put_event", "_put_status",
                             "audit_missing_specs"])):
                have = classes.get(cls_name)
                if have is None:
                    failures.append(f"gui.py: class {cls_name} is missing")
                    continue
                for meth in methods:
                    if meth not in have:
                        failures.append(f"gui.py: {cls_name}.{meth} is missing")
                    else:
                        say(f"  ast     OK    gui.{cls_name}.{meth}")
            src = gui_src.read_text(encoding="utf-8")
            if "from . import parse_bundle" in src or \
                    "import parse_bundle" in src.replace("from . import parse_sample", ""):
                failures.append(
                    "gui.py imports parse_bundle, which is not shipped; the "
                    "bundle feature lives in parse_sample")
            if "PART ROW" in src:
                failures.append(
                    "gui.py still parses the 'PART ROW |' string protocol; "
                    "parts should arrive via add_part()")
            for needed in ('("part", ', '("build_event", ', "queue.Queue(maxsize="):
                if needed not in src:
                    failures.append(f"gui.py is missing expected wiring: {needed}")
    if gui is not None:
        for cls_name, methods in (
                ("BuildProgressWindow",
                 ["add_message", "add_part", "handle_event", "finish"]),
                ("ParseInspectorWindow", ["_run"])):
            cls = getattr(gui, cls_name, None)
            if cls is None:
                failures.append(f"gui.{cls_name} is missing")
                continue
            for meth in methods:
                if not hasattr(cls, meth):
                    failures.append(f"gui.{cls_name}.{meth} is missing but the "
                                    f"queue dispatcher calls it")
                else:
                    say(f"  method  OK    gui.{cls_name}.{meth}")
    # dangling-name scan over every shipped module
    from pathlib import Path as _P
    pkg = _P(__file__).parent
    for src in sorted(pkg.glob("*.py")):
        if src.name.startswith("test") or src.name == "selfcheck.py":
            continue
        for problem in undefined_names(src):
            failures.append(problem)
            say(f"  name    FAIL  {problem}")
        for problem in unassigned_attributes(src):
            failures.append(problem)
            say(f"  attr    FAIL  {problem}")
    return failures, notes


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--verbose", "-v", action="store_true")
    args = ap.parse_args(argv)
    print("rfparts selfcheck — module imports and cross-layer signatures")
    failures, notes = check(args.verbose)
    for n in notes:
        print(f"  note: {n}")
    if failures:
        print(f"\n{len(failures)} PROBLEM(S):")
        for f in failures:
            print(f"  * {f}")
        return 1
    print("\nall checks passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
