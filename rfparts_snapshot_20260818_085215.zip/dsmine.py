
"""dsmine — mine specs out of the datasheets already sitting on disk.

WHY THIS EXISTS
---------------
The rebuild read vendor CATALOG LISTINGS only. `space_dataset.rebuild()` calls
the vendor ingests and the everythingRF page parser, and none of them open a
datasheet. `extract.py`'s pattern engine -- which knows how to read switching
speed, P1dB, OIP3, noise figure and the rest out of prose -- runs only in the
live-crawler path, which a local rebuild never touches.

The practical consequence was that thousands of downloaded datasheets sat in
the library contributing nothing, and any spec a listing did not happen to
tabulate was simply absent. Switching speed is the clearest case: it is on
essentially every switch datasheet, and everythingRF's switch listings do not
carry it as an attribute, so the field was empty across the entire dataset.

WHAT IT DOES
------------
Builds a part-number index of the local datasheet library once, then for each
part: reads the datasheet (PDF or HTML), mines the parametric patterns, and
returns SpecRows so a catalog value normally wins over a text-mined one.

READ THE TABLE AS A TABLE (v4)
------------------------------
Everything below the index is organised around one finding: nearly every wrong
value this module used to produce came from reading a spec TABLE as prose.
pypdf's `extract_text()` flattens columns, which fuses cells into strings no
regex can recover -- a real switch datasheet came out as

    Isolation1
    DC-8 GHz 75 90
    dB8-18 GHz 60 66
    18-26.5 GHz 55 65

and the old first-match-wins scan read that as a 66 dB part (it is a 55 dB
part), while

    RF Input Power
    Cold switching 30
    WHot switching3 0.1

produced a 0.1 W rating for a part rated 30 W cold. The unit had migrated onto
the next row's label.

So the primary path is now positional: `pdfplumber.extract_words()` clustered
into rows and split into cells on x-gaps, or for HTML the actual <tr>/<td>
structure. That recovers `Frequency Range | DC | 26.5 | GHz` and
`Isolation | 18-26.5 GHz | 55 | 65 | dB` as the rows they are, with real
min/typ/max columns. Regex-over-prose is kept, but demoted to a fallback that
only fills what no table row supplied, and only after a negative-context guard.

Three further changes follow from the same finding:

  * band-segmented rows aggregate conservatively. Isolation quoted as 75/66/55
    dB across three bands is a 55 dB part; insertion loss quoted as
    0.30/0.50/0.80 is a 0.80 dB part. Taking whichever row the label landed on
    is not a defensible answer.
  * every spec has a plausibility window, and a value outside it is refused
    rather than stored at low confidence. A 230914 W attenuator is not a low
    confidence measurement, it is a parse artifact.
  * family datasheets are detected. One MACOM sheet serves 23 couplers and the
    per-part frequency cell is VERTICALLY MERGED across groups of four rows, so
    it does not appear on the part's own row at all; a limiter sheet lists the
    requested MPN only as a cross-reference to a different part number. Mining
    either one part-blind gives every sharer the same wrong values. When the
    part's own row cannot be located on a family sheet, per-part specs are
    suppressed instead of guessed.

CONFIDENCE
----------
No longer a single number. A value read from a table cell with a matching unit
and an in-range magnitude is worth more than a regex hit in a paragraph, and
the difference is what lets datasheet precedence be decided per spec rather
than globally. See CONF_*.
"""
from __future__ import annotations

import html as _html
import os
import re
from pathlib import Path

from . import specmatch
from .partdb import SpecRow
from .registry import PARAM_SPECS

# ---------------------------------------------------------------- versioning
# BUMP THIS ON ANY CHANGE BELOW. The disk cache keys on it, so without a bump a
# pattern fix is invisible on every file already parsed -- exactly the bug the
# everythingRF ingest hit before it grew a parser stamp.
PARSER_VERSION = 4

# Confidence tiers. A table cell that carried its own unit is a different kind
# of evidence from a regex hit in a paragraph, and collapsing both to one number
# is what forced datasheet precedence to be an all-or-nothing decision.
CONF_TABLE = 0.72        # label + unit + min/typ/max columns, in range
CONF_TABLE_WEAK = 0.55   # table row, but unit absent or columns ambiguous
CONF_PROSE = 0.35        # regex over prose, negative-context guard passed
CONF_DERIVED = 0.50      # band from an explicit "Frequency Range" row
# Kept for callers that still reference it; equals the prose tier.
MINED_CONFIDENCE = CONF_PROSE

MAX_TEXT_CHARS = 60000
_HEAD_CHARS = 6000
# Stop paging once this many distinct HARD parametric specs have been found.
# It used to count every key in the mine, and freq_min, freq_max,
# space_score_pct, space_evidence and throw_config all come off page one -- so
# the threshold tripped before the electrical table was ever read, on every
# datasheet in the library.
EARLY_EXIT_SPECS = 4
_DS_EXT = {".pdf", ".htm", ".html", ".txt"}

# Positional row extraction costs a pdfplumber open (~0.4 s) where the old path
# cost a pypdf open (~0.1 s). It runs once per file ever, because the mined
# result is cached, but set RFPARTS_DSMINE_ROWS=0 to fall back to prose-only if
# a rebuild has to be fast.
ROWS_ENABLED = os.environ.get("RFPARTS_DSMINE_ROWS", "1").strip() != "0"
ROW_PAGES = 5


def default_roots():
    env = os.environ.get("RFPARTS_DATASHEETS", "").strip()
    roots = [Path(env)] if env else []
    home = Path.home()
    roots += [home / "Downloads" / "rfparts" / "data" / "datasheets",
              home / "Downloads" / "rfparts" / "Data" / "datasheets"]
    try:
        from .paths import DATASHEET_DIR
        roots.append(Path(DATASHEET_DIR))
    except Exception:
        pass
    return [r for r in roots if r.is_dir()]


def _loose(pn):
    return re.sub(r"[^A-Z0-9]", "", str(pn or "").upper())


def build_index(roots=None, say=None):
    """{loose part number: path} for every datasheet on disk.

    One walk, then O(1) lookups. Globbing per part across a 4000-file tree would
    dominate the rebuild."""
    roots = roots or default_roots()
    index = {}
    for root in roots:
        root = Path(root)
        if not root.is_dir():
            continue
        for f in root.rglob("*"):
            try:
                if not f.is_file() or f.suffix.lower() not in _DS_EXT:
                    continue
            except OSError:
                continue
            key = _loose(f.stem)
            if not key:
                continue
            # Prefer the larger file when two match: a stub redirect page loses
            # to the real datasheet.
            prev = index.get(key)
            if prev is None:
                index[key] = f
            else:
                try:
                    if f.stat().st_size > prev.stat().st_size:
                        index[key] = f
                except OSError:
                    pass
    if say:
        say(f"    datasheet library: {len(index)} file(s) indexed from "
            + ", ".join(str(r) for r in roots) if roots else
            "    datasheet library: none found")
    return index


_SCRIPTISH = re.compile(r"(?is)<(script|style|noscript|svg)\b.*?</\1\s*>")
_COMMENT = re.compile(r"(?s)<!--.*?-->")
_TAG = re.compile(r"(?s)<[^>]+>")


_SNIFF_BYTES = 65536


def _sniff(path):
    # 64 kB, not 1 kB. The corruption test counts UTF-8 replacement bytes, and a
    # 1 kB sample was too small to reach the threshold on the text-mangled Qorvo
    # PDFs -- so they were classed as readable, handed to pypdf, and it spent a
    # long time attempting xref recovery on each of nearly a thousand files
    # before returning nothing. 64 kB is the sample size that was measured to
    # separate them cleanly.
    try:
        head = Path(path).open("rb").read(_SNIFF_BYTES)
    except OSError:
        return "unreadable"
    # Corruption is tested BEFORE the PDF magic bytes. It used to come after, and
    # since a mangled PDF still begins with "%PDF-" the function returned "pdf"
    # and the corruption branch was unreachable for the entire population it
    # exists to catch. Every one of those files then went to pypdf, which spent a
    # long time on xref recovery before returning nothing.
    replacement_ratio = head.count(b"\xef\xbf\xbd") * 3 / max(1, len(head))
    if replacement_ratio > 0.02:
        return "corrupt"
    if head[:5] == b"%PDF-":
        return "pdf"
    low = head.lstrip()[:400].lower()
    if low.startswith(b"<!doctype html") or b"<html" in low:
        return "html"
    return "text"


def _quiet_pdf_logs():
    import logging
    for _n in ("pdfminer", "pdfminer.pdfinterp", "pdfminer.pdfpage",
               "pypdf", "pypdf._reader", "PyPDF2", "pdfplumber"):
        logging.getLogger(_n).setLevel(logging.ERROR)


def _pdf_pages_pypdf(path, pages):
    """Per-page text via pypdf. Measured at ~99 ms/file against ~448 ms for
    pdfplumber on the same seven real datasheets, and it extracted MORE text
    (44k vs 41k chars) -- pdfplumber builds a full layout model that this step
    does not use for PROSE. Kept as a generator so reading can stop early.
    (The layout model IS used, separately, by pdf_rows.)"""
    from pypdf import PdfReader
    reader = PdfReader(str(path))
    for pg in reader.pages[:pages]:
        try:
            yield pg.extract_text() or ""
        except Exception:
            yield ""


def _pdf_pages_plumber(path, pages):
    """Fallback for PDFs pypdf cannot read. Slower but differently capable."""
    import pdfplumber
    with pdfplumber.open(str(path)) as pdf:
        for pg in pdf.pages[:pages]:
            try:
                yield pg.extract_text() or ""
            except Exception:
                yield ""


# Text -> (rows, path) for the most recent few files read. This exists so that
# mine_text(text) alone can still reach the positional table data: callers
# (including dbg_datasheet_parse.py) read the text with datasheet_text(path) and
# then mine it with mine_text(text), with no path in between. Bounded, and a
# miss simply means the prose path is used.
_ROWS_MEMO = {}
_ROWS_MEMO_MAX = 8


def _memo_key(text):
    if not text:
        return None
    return (len(text), hash(text[:400]), hash(text[-400:]))


def _memo_put(text, rows, path):
    k = _memo_key(text)
    if k is None:
        return
    if len(_ROWS_MEMO) >= _ROWS_MEMO_MAX:
        _ROWS_MEMO.clear()
    _ROWS_MEMO[k] = (rows, str(path))


def _memo_get(text):
    return _ROWS_MEMO.get(_memo_key(text), (None, None))


def datasheet_text(path, max_chars=MAX_TEXT_CHARS, pages=6, want=None):
    """Readable text from a local datasheet, or ''.

    File type comes from the bytes, not the extension: parts of the library are
    PDFs saved with a .html name, and dispatching on the suffix fed PDF bytes to
    the HTML stripper and produced nothing at all.

    `want` is an optional callable taking the accumulated text and returning True
    once enough has been read. Datasheets put the summary table on page one, so
    stopping there avoids parsing five more pages for nothing -- which on a
    four-thousand-file library is most of the run.

    Side effect: the positional rows for this file are cached against the text
    that was returned, so mine_text(text) can use them (see _ROWS_MEMO).
    """
    path = Path(path)
    kind = _sniff(path)
    if kind in ("unreadable", "corrupt"):
        return ""
    text = ""
    if kind == "pdf":
        _quiet_pdf_logs()
        for reader in (_pdf_pages_pypdf, _pdf_pages_plumber):
            chunks = []
            try:
                for page_text in reader(path, pages):
                    chunks.append(page_text)
                    if want is not None and want("\n".join(chunks)):
                        break
                    if sum(len(c) for c in chunks) >= max_chars:
                        break
            except Exception:
                continue
            candidate = "\n".join(chunks)[:max_chars]
            # pypdf occasionally returns almost nothing for a PDF pdfplumber can
            # read, so a thin result falls through to the slower backend rather
            # than being accepted.
            if len(candidate.strip()) >= 200:
                text = candidate
                break
    else:
        try:
            raw = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return ""
        if kind == "html":
            raw = _SCRIPTISH.sub(" ", raw)
            raw = _COMMENT.sub(" ", raw)
            raw = re.sub(r"(?i)</(p|div|li|tr|td|th|h[1-6]|table)\s*>", "\n", raw)
            raw = _TAG.sub(" ", raw)
            raw = _html.unescape(raw)
        text = re.sub(r"[ \t\xa0]+", " ", raw)[:max_chars]
    if text and ROWS_ENABLED:
        try:
            _memo_put(text, rows_for(path), path)
        except Exception:
            pass
    return text


# ============================================================ positional rows
# A "row" is (page_number, [cell, ...]). Cells are split on horizontal gaps, so
# the spec table's columns survive instead of being concatenated into one string.

def _merge_fragments(rows):
    """Join label text that wrapped onto its own line.

    'Insertion' / 'Loss1' arrive as two rows because the cell wrapped, and a
    bare 'Isolation1' arrives as its own row sitting between the sub-band rows
    it labels. Both are label text rather than data, and both are recognisable
    by carrying no numeric cell."""
    out = []
    for top, cells in rows:
        numeric = any(_cell_num(c) is not None for c in cells)
        if not numeric and len(cells) <= 2 and out:
            prev_top, prev_cells = out[-1]
            if abs(top - prev_top) <= 8 and not any(
                    _cell_num(c) is not None for c in prev_cells):
                out[-1] = (prev_top, prev_cells + cells)
                continue
        out.append((top, list(cells)))
    merged, i = [], 0
    while i < len(out):
        top, cells = out[i]
        if (i + 1 < len(out) and not any(_cell_num(c) is not None for c in cells)
                and len(cells) <= 2 and abs(out[i + 1][0] - top) <= 10):
            nt, nc = out[i + 1]
            merged.append((nt, cells + nc))
            i += 2
            continue
        merged.append((top, cells))
        i += 1
    return merged


def pdf_rows(path, pages=ROW_PAGES, y_tol=3.0, x_gap=8.0):
    """[(page, [cell, ...]), ...] from word positions.

    y_tol groups words into a visual line; x_gap is the horizontal whitespace
    that separates one cell from the next. Both were tuned against real
    Mini-Circuits, MACOM and Marki tables -- at x_gap below ~6 the min and typ
    columns merge, above ~12 a wrapped condition splits."""
    import pdfplumber
    _quiet_pdf_logs()
    out = []
    with pdfplumber.open(str(path)) as pdf:
        for pno, page in enumerate(pdf.pages[:pages], 1):
            try:
                words = page.extract_words(use_text_flow=False,
                                           keep_blank_chars=False)
            except Exception:
                continue
            buckets = {}
            for w in words:
                buckets.setdefault(round(w["top"] / y_tol), []).append(w)
            raw = []
            for k in sorted(buckets):
                ws = sorted(buckets[k], key=lambda w: w["x0"])
                cells, cur, prev = [], [], None
                for w in ws:
                    if prev is not None and w["x0"] - prev > x_gap:
                        cells.append(" ".join(cur))
                        cur = []
                    cur.append(w["text"])
                    prev = w["x1"]
                if cur:
                    cells.append(" ".join(cur))
                raw.append((k * y_tol, cells))
            for _top, cells in _merge_fragments(raw):
                out.append((pno, cells))
    return out


_TR = re.compile(r"(?is)<tr[^>]*>(.*?)</tr>")
_TD = re.compile(r"(?is)<t[dh][^>]*>(.*?)</t[dh]>")


def html_rows(path):
    """[(1, [cell, ...]), ...] from real <tr>/<td> markup.

    Deliberately regex-based rather than BeautifulSoup: this module must not add
    a dependency the rebuild does not already have. Marki pages carry a proper
    DOM table, and stripping it to prose (what this module used to do) is why a
    boilerplate footnote -- "Mixer Noise Figure typically measures within 0.5 dB
    of conversion loss" -- beat the actual Noise Figure row on every Marki
    mixer in the library.
    """
    try:
        raw = Path(path).read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    raw = _SCRIPTISH.sub(" ", raw)
    raw = _COMMENT.sub(" ", raw)
    out, seen = [], set()
    for tr in _TR.findall(raw):
        cells = []
        for c in _TD.findall(tr):
            c = _TAG.sub(" ", c)
            cells.append(re.sub(r"\s+", " ", _html.unescape(c)).strip())
        if not any(cells):
            continue
        sig = "|".join(cells)
        if sig in seen:            # server-rendered + hydrated copy of one table
            continue
        seen.add(sig)
        out.append((1, cells))
    return out


def rows_for(path):
    """Positional rows for a datasheet, dispatching on the bytes."""
    if not ROWS_ENABLED:
        return []
    kind = _sniff(path)
    if kind == "pdf":
        return pdf_rows(path)
    if kind == "html":
        return html_rows(path)
    return []


def cells_xy(path, pno, y_tol=3.0, x_gap=8.0):
    """Rows whose cells keep their x extents, for column mapping on family
    sheets. Separate from pdf_rows because carrying the geometry everywhere
    would double the memory for the 99% of files that never need it."""
    import pdfplumber
    _quiet_pdf_logs()
    with pdfplumber.open(str(path)) as pdf:
        if pno > len(pdf.pages):
            return []
        words = pdf.pages[pno - 1].extract_words(use_text_flow=False,
                                                 keep_blank_chars=False)
    buckets = {}
    for w in words:
        buckets.setdefault(round(w["top"] / y_tol), []).append(w)
    rows = []
    for k in sorted(buckets):
        line = sorted(buckets[k], key=lambda w: w["x0"])
        cells, cur, prev = [], [], None
        for w in line:
            if prev is not None and w["x0"] - prev > x_gap:
                cells.append({"t": " ".join(x["text"] for x in cur),
                              "x0": cur[0]["x0"], "x1": cur[-1]["x1"]})
                cur = []
            cur.append(w)
            prev = w["x1"]
        if cur:
            cells.append({"t": " ".join(x["text"] for x in cur),
                          "x0": cur[0]["x0"], "x1": cur[-1]["x1"]})
        rows.append({"top": k * y_tol, "cells": cells})
    return rows


# --------------------------------------------------------------- cell helpers
_NUMERIC = re.compile(r"^[+-]?\d+(?:\.\d+)?$")
_LEADING_NUM = re.compile(
    r"^([+-]?\d+(?:\.\d+)?)\s*(?:\u00b1|W|mW|kW|dBm|dBc|dB|GHz|MHz|kHz|ns|"
    r"\u00b5s|\u03bcs|us|ms|mA|V|Degree|deg)\b", re.I)
# Footnote markers ride on the end of table labels: "Isolation1", "Loss1",
# "Noise Figure 3". Left in place they defeat every label match.
_FOOTNOTE = re.compile(r"(?<=[A-Za-z\)])\s?\d{1,2}\s*$")
_PLACEHOLDER = {"-", "--", "\u2013", "\u2014", "", "n/a", "na", "tbd"}
_UNIT_TOKEN = re.compile(
    r"^(dBm|dBc|dB|GHz|MHz|kHz|Hz|W|mW|kW|ns|us|\u00b5s|\u03bcs|ms|sec|s|"
    r"mA|A|V|Degree|deg|\u00b0|%|:1)$", re.I)


def _cell_num(cell):
    s = str(cell or "").strip().replace("\u2212", "-").replace(",", "")
    if _NUMERIC.match(s):
        return float(s)
    m = _LEADING_NUM.match(s)
    return float(m.group(1)) if m else None


def _clean_label(cell):
    return _FOOTNOTE.sub("", str(cell or "").strip()).strip()


def _row_unit(cells):
    """The unit token from the tail of a row, if any."""
    for c in reversed(cells[-3:]):
        t = str(c or "").strip()
        if _UNIT_TOKEN.match(t):
            return t
    tail = " ".join(str(c) for c in cells[-2:])
    m = re.search(r"\d\s*(dBm|dBc|dB|GHz|MHz|kHz|W|mW|kW|ns|\u00b5s|us|ms)\b",
                  tail, re.I)
    return m.group(1) if m else ""


def _row_numbers(cells):
    """Numeric cells after the label, with '-' placeholders preserved as None.

    Placeholders matter: 'Noise Figure | cond | - | 9 | - | dB' is a typ-only
    row, and collapsing the dashes would make 9 look like the minimum."""
    vals = []
    for c in cells[1:]:
        s = str(c or "").strip().lower()
        if s in _PLACEHOLDER:
            vals.append(None)
            continue
        if _UNIT_TOKEN.match(str(c).strip()):
            continue
        n = _cell_num(c)
        if n is not None:
            vals.append(n)
    # trailing placeholders carry no information
    while vals and vals[-1] is None:
        vals.pop()
    return vals


def _min_typ_max(vals):
    """(min, typ, max) from a row's numeric columns.

    With explicit placeholders the position is meaningful; without them, one
    number is a typ, two are min/max as vendors print them (Mini-Circuits' two
    columns are Typ. then Max.), three are min/typ/max."""
    if any(v is None for v in vals):
        slots = vals[:3] + [None] * (3 - len(vals[:3]))
        return slots[0], slots[1], slots[2]
    nums = [v for v in vals if v is not None]
    if not nums:
        return None, None, None
    if len(nums) == 1:
        return None, nums[0], None
    if len(nums) == 2:
        return None, nums[0], nums[1]
    return nums[0], nums[1], nums[2]


# ======================================================== table spec vocabulary
# (key, label pattern, canonical unit, kind)
#
# `kind` decides two things: which column is authoritative, and how several rows
# under one label aggregate. A `max` spec keeps the worst (largest) value across
# condition rows, a `min` spec keeps the worst (smallest). That is the only
# defensible reading of a part quoted at 75/66/55 dB isolation over three bands.
SPEC_ROWS = [
    ("gain_db",            r"(?:small[\s-]*signal\s+)?gain",              "dB",  "min"),
    ("nf_db",              r"noise\s*figure|^nf$",                        "dB",  "max"),
    ("p1db_dbm",           r"(?:output\s*)?p\s*1\s*-?\s*db|"
                           r"(?:output\s*)?1\s*db\s*compression",         "dBm", "min"),
    ("oip3_dbm",           r"(?:output\s*)?oip3|^output\s*ip3$|"
                           r"(?:third|3rd)[\s-]*order\s*(?:output\s*)?"
                           r"intercept|^ip3$",                            "dBm", "min"),
    ("psat_dbm",           r"(?:saturated\s*)?output\s*power|psat",       "dBm", "min"),
    ("isolation_db",       r"(?:\S+\s*(?:to|-|/)\s*\S+\s*)?isolation",    "dB",  "min"),
    ("insertion_loss_db",  r"insertion\s*loss|mainline\s*loss",           "dB",  "max"),
    ("conversion_loss_db", r"conversion\s*loss",                          "dB",  "max"),
    ("coupling_db",        r"coupling",                                   "dB",  "approx"),
    ("return_loss_db",     r"(?:input|output)?\s*return\s*loss",          "dB",  "min"),
    ("attenuation_db",     r"attenuation(?:\s*range)?",                   "dB",  "approx"),
    ("rejection_db",       r"(?:stopband\s*)?rejection|out[\s-]*of[\s-]*"
                           r"band\s*rejection",                           "dB",  "min"),
    ("power_w",            r"(?:rf\s*)?(?:input\s*)?power(?:\s*handling)?|"
                           r"rf\s*input\s*power|cw\s*power|rated\s*power|"
                           r"input\s*power\s*handling",                   "W",   "max"),
    ("switching_time_ns",  r"switching\s*(?:time|speed)|^t\s*(?:on|off)$|"
                           r"rise\s*/?\s*fall\s*time",                    "ns",  "max"),
    ("vswr",               r"vswr",                                       "",    "max"),
    ("impedance_ohm",      r"impedance",                                  "",    "approx"),
    ("current_ma",         r"(?:supply|dc|bias)\s*current|current"
                           r"\s*consumption",                             "mA",  "max"),
    ("supply_v",           r"(?:supply|bias)\s*voltage",                  "V",   "approx"),
]
SPEC_ROWS = [(k, re.compile(r"^(?:%s)$" % p, re.I), u, kind)
             for k, p, u, kind in SPEC_ROWS]

# Rows whose label names a port other than the part's main signal path. An IQ
# mixer's "LO Power Handling" is not its RF power rating.
_LABEL_OTHER_PORT = re.compile(r"^(lo|if|local\s*oscillator|intermediate)\b", re.I)
# Input-referred figures are a different spec from the output-referred one this
# vocabulary stores. "Input P1dB 9 dBm" is not P1dB(out).
_LABEL_INPUT_REFERRED = re.compile(r"^input\s*(p\s*1|1\s*db|ip3|iip3)", re.I)

# Physically possible windows. Outside these a value is a parse artifact, not a
# low-confidence measurement, and it is refused. Every one of these bounds was
# set by a real failure: 230914 W, 0.5 dB mixer NF, 2 dB isolation, 0 dBm OIP3.
PLAUSIBLE = {
    "gain_db": (-5.0, 90.0),
    "nf_db": (0.2, 30.0),
    "p1db_dbm": (-40.0, 60.0),
    "oip3_dbm": (-10.0, 80.0),
    "psat_dbm": (-20.0, 70.0),
    "isolation_db": (5.0, 130.0),
    "insertion_loss_db": (0.01, 20.0),
    "conversion_loss_db": (2.0, 25.0),
    "coupling_db": (1.0, 60.0),
    "return_loss_db": (3.0, 45.0),
    "attenuation_db": (0.0, 120.0),
    "rejection_db": (5.0, 120.0),
    "power_w": (1e-4, 3000.0),
    "switching_time_ns": (0.5, 1e10),
    "vswr": (1.0, 6.0),
    "impedance_ohm": (10.0, 300.0),
    "current_ma": (0.01, 20000.0),
    "supply_v": (-60.0, 60.0),
    "freq_min": (0.0, 500.0),
    "freq_max": (1e-6, 500.0),
}

_TIME_SCALE = {"ns": 1.0, "nsec": 1.0, "us": 1e3, "usec": 1e3,
               "\u00b5s": 1e3, "\u03bcs": 1e3, "ms": 1e6, "msec": 1e6,
               "s": 1e9, "sec": 1e9}
_POWER_SCALE = {"w": 1.0, "mw": 1e-3, "kw": 1e3}
_CURRENT_SCALE = {"ma": 1.0, "a": 1e3, "\u00b5a": 1e-3, "ua": 1e-3}

# A row whose first cell is a CONDITION rather than a label continues the block
# above it. Mini-Circuits prints one 'Isolation' label beside three band rows;
# without this only the row the label happened to land on is read, and a 55 dB
# part is recorded as a 60 dB part.
_CONDITIONISH = re.compile(
    r"^(DC|\d+(?:\.\d+)?)\s*(?:-|\u2013|to)\s*\d|"
    r"^(?:cold|hot)\s*switch|^into\s+|^over\s+|^at\s+|^RF\s*/\s*LO\s*=|"
    r"^f\s*=|^all\s+|^per\s+", re.I)
# Condition text that identifies the headline rating among several. "Cold
# switching 30 W" is a mechanical switch's power rating; the hot-switching
# figure is a lifetime derating, two orders of magnitude lower.
_COND_HEADLINE = re.compile(r"cold\s*switch|non[\s-]*operating|\bmax(?:imum)?\b",
                            re.I)


def _scale_for(key, unit):
    u = (unit or "").strip().lower()
    if key == "switching_time_ns":
        return _TIME_SCALE.get(u, 1.0 if not u else None)
    if key == "power_w":
        if u == "dbm":
            return "dbm"
        return _POWER_SCALE.get(u, 1.0 if not u else None)
    if key == "current_ma":
        return _CURRENT_SCALE.get(u, 1.0 if not u else None)
    return 1.0


def mine_rows(rows):
    """{key: {...}} from positional table rows.

    The returned dict carries min/typ/max, the literal row it came from and a
    confidence, so a caller can both filter on the conservative edge and compare
    typ-to-typ against a catalog value.
    """
    found = {}
    block_key = None
    for _pno, cells in rows:
        if not cells:
            continue
        label = _clean_label(cells[0])
        if not label or len(label) > 52:
            block_key = None
            continue
        unit = _row_unit(cells)
        vals = _row_numbers(cells)
        matched = [t for t in SPEC_ROWS if t[1].match(label)]
        if matched:
            block_key = matched[0][0]
            if _LABEL_OTHER_PORT.match(label) or _LABEL_INPUT_REFERRED.match(label):
                block_key = None
                continue
        elif block_key and _CONDITIONISH.match(label) and vals:
            matched = [t for t in SPEC_ROWS if t[0] == block_key]
        elif not _CONDITIONISH.match(label):
            block_key = None
        if not matched or not vals:
            continue
        key, _rx, want_unit, kind = matched[0]
        scale = _scale_for(key, unit)
        if scale is None:
            continue                    # unit present but not one we understand
        if want_unit and unit and not _UNIT_COMPATIBLE.get(key, lambda u: True)(unit):
            continue
        lo, typ, hi = _min_typ_max(vals)
        if scale == "dbm":              # power quoted in dBm
            conv = lambda v: None if v is None else 10 ** ((v - 30) / 10.0)
        elif isinstance(scale, (int, float)) and scale != 1.0:
            conv = lambda v, s=scale: None if v is None else v * s
        else:
            conv = lambda v: v
        lo, typ, hi = conv(lo), conv(typ), conv(hi)
        primary = {"max": hi, "min": lo}.get(kind, typ)
        if primary is None:
            primary = typ if typ is not None else (hi if hi is not None else lo)
        bounds = PLAUSIBLE.get(key)
        if bounds and (primary is None or not (bounds[0] <= primary <= bounds[1])):
            continue
        conf = CONF_TABLE if (unit or not want_unit) else CONF_TABLE_WEAK
        rec = {"value": primary, "min": lo, "typ": typ, "max": hi,
               "unit": want_unit, "kind": kind, "method": "table",
               "confidence": conf,
               "row": re.sub(r"\s+", " ", " | ".join(str(c) for c in cells))[:110]}
        prev = found.get(key)
        if prev is None:
            found[key] = rec
            continue
        # Several rows under one label: keep the worst case, but let an
        # explicitly headline condition ("cold switching") override outright.
        cond = " ".join(str(c) for c in cells[1:3])
        if _COND_HEADLINE.search(cond) and kind == "max":
            found[key] = rec
            continue
        agg = max if kind == "max" else min
        if kind in ("max", "min"):
            if agg(prev["value"], primary) != prev["value"]:
                rec["row"] = prev["row"] + "  //  " + rec["row"]
                found[key] = rec
            else:
                for edge, fn in (("min", min), ("max", max)):
                    a, b = prev.get(edge), rec.get(edge)
                    if a is not None and b is not None:
                        prev[edge] = fn(a, b)
    return found


# Unit sanity per spec: a dB value cannot satisfy a dBm spec, and "RF Power
# Handling 25 dBm" is 0.32 W, not 25 W.
_UNIT_COMPATIBLE = {
    "gain_db": lambda u: u.lower() in ("db",),
    "nf_db": lambda u: u.lower() in ("db",),
    "isolation_db": lambda u: u.lower() in ("db",),
    "insertion_loss_db": lambda u: u.lower() in ("db",),
    "conversion_loss_db": lambda u: u.lower() in ("db",),
    "coupling_db": lambda u: u.lower() in ("db",),
    "return_loss_db": lambda u: u.lower() in ("db",),
    "attenuation_db": lambda u: u.lower() in ("db",),
    "rejection_db": lambda u: u.lower() in ("db",),
    "p1db_dbm": lambda u: u.lower() in ("dbm",),
    "oip3_dbm": lambda u: u.lower() in ("dbm",),
    "psat_dbm": lambda u: u.lower() in ("dbm",),
    "power_w": lambda u: u.lower() in ("w", "mw", "kw", "dbm"),
    "switching_time_ns": lambda u: u.lower() in _TIME_SCALE,
    "current_ma": lambda u: u.lower() in _CURRENT_SCALE,
    "supply_v": lambda u: u.lower() in ("v",),
    "vswr": lambda u: u.lower() in (":1", ""),
    "impedance_ohm": lambda u: u.lower() in ("\u00b0", "", "ohm", "ohms"),
}


# ============================================================== family sheets
_MPNISH = re.compile(r"^[A-Z0-9]{2,}(?:[-/][A-Z0-9]+){1,4}\+?$", re.I)


def family_mpns(rows, min_cells=4):
    """MPN-shaped tokens that start a data row -- an ordering table's rows."""
    starts = []
    for _p, cells in rows:
        if len(cells) >= min_cells and _MPNISH.match(str(cells[0]).strip()):
            starts.append(str(cells[0]).strip().upper())
    return sorted(set(starts))


def is_family_sheet(rows):
    """Three or more distinct parts tabulated on one page.

    Deliberately not 'two': a datasheet often lists the part and one variant
    (a +RoHS suffix, a die version), and treating that as a family would
    suppress mining on ordinary single-part sheets."""
    return len(family_mpns(rows)) >= 3


def part_row(rows, mpn, min_cells=4):
    """The ordering-table row whose first cell is this MPN, or None."""
    want = _loose(mpn)
    if not want:
        return None
    for _p, cells in rows:
        if cells and _loose(cells[0]) == want and len(cells) >= min_cells:
            return cells
    return None


def family_column(xy_rows, part_top, header_cell, y_window=24.0, pad=6.0):
    """The cell under `header_cell`'s column nearest the part's row.

    Needed because ordering tables merge cells vertically: on a MACOM coupler
    sheet the Freq. Range cell spans a group of four part rows and therefore is
    not on the part's own row at all. Flattened text loses it completely, and
    the module used to fall back to the family's advertised span -- reading
    "0.5 through 18 GHz" for a 4-8 GHz part."""
    best = None
    for r in xy_rows:
        dy = abs(r["top"] - part_top)
        if dy > y_window:
            continue
        for c in r["cells"]:
            if c["x1"] > header_cell["x0"] - pad and c["x0"] < header_cell["x1"] + pad:
                if best is None or dy < best[0]:
                    best = (dy, c["t"])
    return best[1] if best else None


_FREQ_HDR = re.compile(r"^freq(?:uency)?\.?(?:\s*range)?$|^range$", re.I)


def family_band(path, mpn):
    """(lo, hi, evidence) for one part on an ordering-table sheet, or None."""
    try:
        for pno in range(1, ROW_PAGES + 1):
            xy = cells_xy(path, pno)
            if not xy:
                continue
            target = None
            for r in xy:
                if r["cells"] and _loose(r["cells"][0]["t"]) == _loose(mpn):
                    target = r
                    break
            if target is None:
                continue
            hdr = None
            for r in xy:
                if r["top"] >= target["top"]:
                    continue
                for c in r["cells"]:
                    if _FREQ_HDR.match(c["t"].strip()):
                        hdr = c
                if hdr is not None and r["top"] > target["top"] - 220:
                    break
            if hdr is None:
                continue
            cell = family_column(xy, target["top"], hdr)
            if not cell:
                continue
            band = _parse_band_text(cell)
            if band:
                return band[0], band[1], f"ordering table column: {cell!r}"
    except Exception:
        return None
    return None


_UNITLESS_RANGE = re.compile(
    r"^(DC|\d+(?:\.\d+)?)\s*(?:-|\u2013|to)\s*(\d+(?:\.\d+)?)$", re.I)


def _parse_band_text(text, default_unit="ghz"):
    """'4.0-8.0' or '1000 to 4500 MHz' -> (lo_ghz, hi_ghz)."""
    s = str(text or "").strip()
    m = _RANGE_RE.search(s)
    if m:
        lo_raw, lo_u, hi_raw, hi_u = m.groups()
        hs = _FREQ_UNIT.get((hi_u or "").lower())
        if hs is not None:
            ls = _FREQ_UNIT.get((lo_u or "").lower(), hs)
            lo = 0.0 if lo_raw.lower() == "dc" else float(lo_raw) * ls
            hi = float(hi_raw) * hs
            if 0 <= lo < hi <= 500:
                return round(lo, 9), round(hi, 9)
    m = _UNITLESS_RANGE.match(s)
    if m:
        scale = _FREQ_UNIT[default_unit]
        lo = 0.0 if m.group(1).lower() == "dc" else float(m.group(1)) * scale
        hi = float(m.group(2)) * scale
        if 0 <= lo < hi <= 500:
            return round(lo, 9), round(hi, 9)
    return None


# ============================================================ frequency band
_FREQ_UNIT = {"thz": 1e3, "ghz": 1.0, "mhz": 1e-3, "khz": 1e-6, "hz": 1e-9}
_RANGE_RE = re.compile(
    r"(?<![\w.])(DC|\d+(?:\.\d+)?)\s*(thz|ghz|mhz|khz)?\s*"
    r"(?:-|\u2013|\u2014|to|through)\s*"
    r"(\d+(?:\.\d+)?)\s*(thz|ghz|mhz|khz)\b", re.I)
_MIN_GHZ, _MAX_GHZ = 1e-6, 500.0

_FREQ_ROW_LABEL = re.compile(
    r"^(?:rf\s*)?(?:operating\s*)?freq(?:uency)?\.?\s*(?:range)?$|"
    r"^passband$|^tuning\s*range$|^bandwidth$", re.I)
_FREQ_BAD = re.compile(
    r"\b(series|family|portfolio|key features|product line|catalog|"
    r"other models|selection guide|available in|models? from)\b", re.I)
_FREQ_PORT_OTHER = re.compile(r"\b(if|lo|local\s*oscillator|"
                              r"intermediate\s*frequency)\b", re.I)
_FREQ_LOOSE = re.compile(r"\b(typ\.?|typical|wide\s*bandwidth|up to|nominal)\b",
                         re.I)
# Temperature ranges look exactly like frequency ranges once a unit lands
# nearby, so the word still has to be RECOGNISED even though no temperature
# spec is stored. The window is deliberately tight: at 90 characters an
# unrelated "Storage Temperature" three lines up was penalising the correct
# band on Mini-Circuits coupler sheets.
_FREQ_UNIT_ONLY = re.compile(r"\b(temperature|storage|humidity|altitude)\b", re.I)
# A range with dB values right after it is a per-band PERFORMANCE row, not the
# part's band. The old scorer REWARDED this (+1 for digits nearby), which is
# how "18-26.5 GHz" off an insertion-loss table beat "DC to 26.5 GHz" from the
# page header on every wideband switch in the library.
_PERF_AFTER = re.compile(r"\d[\d.\s]*\s*(dB|dBm)\b", re.I)
_FIFTY_OHM = re.compile(r"(\u03a9|\b50\s*ohm)", re.I)

_CAND_CACHE = {}


def _candidates(text):
    """{(lo, hi): {n, best_ctx_score}} for every plausible range in `text`."""
    key = _memo_key(text)
    hit = _CAND_CACHE.get(key)
    if hit is not None:
        return hit
    seen = {}
    for m in _RANGE_RE.finditer(text or ""):
        lo_raw, lo_u, hi_raw, hi_u = m.groups()
        hs = _FREQ_UNIT.get((hi_u or "").lower())
        if hs is None:
            continue
        # A unit given only on the second number governs both: "1 to 2500 MHz"
        # is megahertz at each end, not 1 GHz to 2.5 GHz.
        ls = _FREQ_UNIT.get((lo_u or "").lower(), hs)
        lo = 0.0 if lo_raw.lower() == "dc" else float(lo_raw) * ls
        hi = float(hi_raw) * hs
        if hi <= lo or hi > _MAX_GHZ or lo < 0 or hi < _MIN_GHZ:
            continue
        pair = (round(lo, 9), round(hi, 9))
        rec = seen.setdefault(pair, {"n": 0, "ctx": -99, "snippet": ""})
        rec["n"] += 1
        s = _context_score(text, m)
        if s > rec["ctx"]:
            rec["ctx"] = s
            rec["snippet"] = re.sub(r"\s+", " ", m.group(0))[:70]
    if len(_CAND_CACHE) > 8:
        _CAND_CACHE.clear()
    _CAND_CACHE[key] = seen
    return seen


def _context_score(text, m):
    """Wording immediately around one candidate."""
    before = text[max(0, m.start() - 70):m.start()]
    after = text[m.end():m.end() + 45]
    score = 0
    if _FREQ_BAD.search(before):
        score -= 6
    if _FREQ_PORT_OTHER.search(before[-26:]):
        score -= 5
    if _FREQ_LOOSE.search(before) or _FREQ_LOOSE.search(after):
        score -= 2
    if _FREQ_UNIT_ONLY.search(before[-22:]):
        score -= 8
    if _PERF_AFTER.search(after):
        score -= 4
    if _FIFTY_OHM.search(before[-22:]):
        score += 4
    return score


def _range_score(text, m):
    """Total score for one candidate: context, repetition and containment.

    Kept at this signature because the debug tooling re-derives the winning
    snippet by calling it directly, and a scorer that disagreed with
    freq_range_ghz would print evidence contradicting the answer.

    Repetition is the strong signal. A part's own band is repeated -- the page
    header on every page, the overview sentence, the features bullet -- while a
    sub-band from a performance table appears once. Containment is the other:
    the L/M/U segment legends that flattened tables are full of
    ("L = 5-50 MHz  M = 50-375 MHz  U = 375-750 MHz") are always strictly
    inside the real band.
    """
    lo_raw, lo_u, hi_raw, hi_u = m.groups()
    hs = _FREQ_UNIT.get((hi_u or "").lower())
    if hs is None:
        return -99
    ls = _FREQ_UNIT.get((lo_u or "").lower(), hs)
    lo = 0.0 if lo_raw.lower() == "dc" else float(lo_raw) * ls
    hi = float(hi_raw) * hs
    pair = (round(lo, 9), round(hi, 9))
    cands = _candidates(text)
    rec = cands.get(pair)
    if rec is None:
        return _context_score(text, m)
    score = rec["ctx"] + min(4, 2 * (rec["n"] - 1))
    for (olo, ohi), other in cands.items():
        if (olo, ohi) == pair:
            continue
        if olo <= lo and hi <= ohi and (hi - lo) < (ohi - olo) \
                and other["n"] >= rec["n"]:
            score -= 4
            break
    return score


def freq_from_rows(rows):
    """(lo, hi, evidence) from an explicit 'Frequency Range' row, or None.

    This is the highest-confidence band there is and it was not being read at
    all: 'Frequency Range | DC | 26.5 | GHz' has no separator between the two
    numbers, so the prose range regex cannot see it."""
    for _pno, cells in rows:
        if not cells:
            continue
        label = _clean_label(cells[0])
        if not _FREQ_ROW_LABEL.match(label):
            continue
        if _FREQ_PORT_OTHER.match(label):
            continue        # "IF Frequency Range" is not the part's band
        unit = _row_unit(cells) or "GHz"
        scale = _FREQ_UNIT.get(unit.lower())
        if scale is None:
            continue
        edges = []
        for c in cells[1:]:
            s = str(c).strip()
            if s.upper() == "DC":
                edges.append(0.0)
                continue
            if s.lower() in _PLACEHOLDER or _UNIT_TOKEN.match(s):
                continue
            band = _parse_band_text(s, default_unit=unit.lower())
            if band:
                edges.extend(band)
                continue
            n = _cell_num(c)
            if n is not None:
                edges.append(n * scale)
        if len(edges) >= 2:
            lo, hi = min(edges), max(edges)
            if hi > lo and hi <= _MAX_GHZ:
                return (round(lo, 9), round(hi, 9),
                        re.sub(r"\s+", " ", " | ".join(str(c) for c in cells))[:90])
    return None


def freq_range_ghz(text, head_chars=_HEAD_CHARS):
    """(low, high) in GHz for the part's own band, or None.

    Candidates are SCORED rather than taken in order: a datasheet's front page
    carries the family's span, the operating temperature and sometimes a
    competitor comparison, all of which look like ranges.
    """
    best, best_score = None, -99
    for chunk in (text[:head_chars], text):
        for m in _RANGE_RE.finditer(chunk or ""):
            lo_raw, lo_u, hi_raw, hi_u = m.groups()
            hi_scale = _FREQ_UNIT.get((hi_u or "").lower())
            if hi_scale is None:
                continue
            lo_scale = _FREQ_UNIT.get((lo_u or "").lower(), hi_scale)
            lo = 0.0 if lo_raw.lower() == "dc" else float(lo_raw) * lo_scale
            hi = float(hi_raw) * hi_scale
            if hi <= lo or hi > _MAX_GHZ or lo < 0 or hi < _MIN_GHZ:
                continue
            s = _range_score(chunk, m)
            if s > best_score:
                best, best_score = (round(lo, 9), round(hi, 9)), s
        if best is not None:
            break
    return best


# ============================================================ prose fallback
# The registry's patterns are used as-is except where a specific pattern was
# measured producing wrong values. Overriding here rather than in registry.py
# keeps the live-crawler path (extract.py) unchanged while every consumer of
# _PATTERNS -- including the debug tooling -- picks up the fix.
#
# The construct `(?:(?!BAD)[^.\n\r]){0,30}?` is a tempered gap: it spans up to
# thirty characters but refuses to cross any of the listed words, so a label
# cannot reach past a test condition to grab the condition's number. That is the
# entire cause of "IP3 Two-tone inputs up to +5 dBm" being read as OIP3 = 5,
# "OIP3 measured with 0 dBm" as OIP3 = 0, and "IP3 data shown for a +19 dBm" as
# OIP3 = 19.
_COND_WORDS = (r"two[- ]tone|per\s*tone|each\s*tone|measured|shown|drive|"
               r"input|referred|typical|within|assum|reference|example|"
               r"condition")
_GAP = r"(?:(?!%s)[^.\n\r]){0,30}?" % _COND_WORDS
_GAP_SHORT = r"(?:(?!%s)[^.\n\r]){0,20}?" % _COND_WORDS

_PATTERN_OVERRIDES = {
    # The bare `(\d+)\s*(?:W|watt)` fallback is DELETED, not tightened. With
    # re.I and no trailing boundary it matched a number followed by the footer
    # URL -- "251202\nwww.minicircuits.com" became a 251202 W transformer --
    # and with no leading boundary it matched inside part numbers, so
    # "MADL-000301-01340W" became a 1340 W limiter. Both appeared on hundreds
    # of files. There is no context in which a bare number beside the letter W
    # is trustworthy evidence of a power rating.
    "power_w": [
        r"(?:power\s*handling|input\s*power|cw\s*power|rated\s*power|"
        r"rf\s*power)" + _GAP_SHORT +
        r"(?<![\w.\-])(\d+(?:\.\d+)?)\s*(?:W|watts?)\b",
    ],
    "oip3_dbm": [
        r"OIP3" + _GAP + r"(?<![\w.\-])([+-]?\d+(?:\.\d+)?)\s*dBm\b",
        r"(?:third|3rd)[-\s]*order\s*(?:output\s*)?intercept" + _GAP +
        r"(?<![\w.\-])([+-]?\d+(?:\.\d+)?)\s*dBm\b",
        r"(?<!input\s)\bIP3\b" + _GAP +
        r"(?<![\w.\-])([+-]?\d+(?:\.\d+)?)\s*dBm\b",
    ],
    "nf_db": [
        r"noise\s*figure" + _GAP + r"(?<![\w.\-])(\d+(?:\.\d+)?)\s*dB\b",
        r"\bNF\b" + _GAP_SHORT + r"(?<![\w.\-])(\d+(?:\.\d+)?)\s*dB\b",
    ],
    "isolation_db": [
        r"isolation" + _GAP + r"(?<![\w.\-])(\d+(?:\.\d+)?)\s*dB\b",
    ],
    "p1db_dbm": [
        r"(?<!input\s)P\s*1\s*-?\s*dB" + _GAP +
        r"(?<![\w.\-])([+-]?\d+(?:\.\d+)?)\s*dBm\b",
        r"(?<!input\s)1\s*-?\s*dB\s*compression" + _GAP +
        r"(?<![\w.\-])([+-]?\d+(?:\.\d+)?)\s*dBm\b",
    ],
}


def _compile_patterns():
    out = {}
    for key, meta in PARAM_SPECS.items():
        pats = _PATTERN_OVERRIDES.get(key) or meta.get("patterns")
        if not pats:
            continue
        compiled = []
        for p in pats:
            try:
                compiled.append(re.compile(p, re.I))
            except re.error:
                continue
        if compiled:
            out[key] = compiled
    return out


_PATTERNS = _compile_patterns()

# Words that mark a nearby number as a test condition rather than a
# measurement. Applied as a second guard even after the tempered gaps, because
# a footnote can carry the condition wording AFTER the value: "Noise Figure
# typically measures within 0.5 dB of conversion loss" is the one that gave
# every Marki mixer a 0.5 dB noise figure.
_NEG_CTX = re.compile(
    r"\b(two[- ]tone|per tone|each tone|measured with|measured at|shown for|"
    r"test condition|input drive|drive level|referred to|typically measures|"
    r"within \d|approximately|assumes|for reference|for example|e\.g\.)\b",
    re.I)


def _prose_guard(text, m):
    before = text[max(0, m.start() - 90):m.start()]
    after = text[m.end():m.end() + 45]
    return not (_NEG_CTX.search(before) or _NEG_CTX.search(after))


# Table rows put the number AFTER the unit -- "Small Signal Gain (min) dB 8.5" --
# while the PARAM_SPECS patterns expect "Gain 8.5 dB". Neither ordering is more
# correct, and datasheets use both, so the reversed form is read here rather
# than doubling every pattern in the registry. This is a text-level fallback for
# files where positional extraction is unavailable; mine_rows supersedes it.
_TABLE_ROW = [
    ("gain_db", r"(?:small\s*signal\s*)?gain(?:\s*\((?:min|typ|max)\))?", "dB"),
    ("nf_db", r"noise\s*figure(?:\s*\((?:min|typ|max)\))?|\bNF\b", "dB"),
    ("p1db_dbm", r"(?:output\s*)?P\s*1\s*-?\s*dB(?:\s*\((?:min|typ|max)\))?", "dBm"),
    ("oip3_dbm", r"(?:output\s*)?(?:OIP3|IP3)(?:\s*\((?:min|typ|max)\))?", "dBm"),
    ("isolation_db", r"isolation(?:\s*\((?:min|typ|max)\))?", "dB"),
    ("insertion_loss_db", r"insertion\s*loss(?:\s*\((?:min|typ|max)\))?", "dB"),
    ("conversion_loss_db", r"conversion\s*loss(?:\s*\((?:min|typ|max)\))?", "dB"),
    ("psat_dbm", r"(?:saturated\s*)?output\s*power(?:\s*\((?:min|typ|max)\))?", "dBm"),
]
# The label must be wrapped: an un-grouped alternation like "noise figure|NF"
# binds only its last branch to what follows, so a match on the first branch
# leaves the value group unset and float(None) raises.
_TABLE_ROW = [(k, re.compile(rf"(?:{pat})\s*{unit}\s+"
                             rf"(?<![\w.\-])([-+]?\d+(?:\.\d+)?)", re.I), unit)
              for k, pat, unit in _TABLE_ROW]


def mine_table_rows(text):
    """Specs written as 'Label unit value', the way spec tables flatten."""
    out = {}
    for key, rx, unit in _TABLE_ROW:
        m = rx.search(text or "")
        if not m:
            continue
        try:
            value = float(m.group(1))
        except (TypeError, ValueError):
            continue
        bounds = PLAUSIBLE.get(key)
        if bounds and not (bounds[0] <= value <= bounds[1]):
            continue
        if not _prose_guard(text, m):
            continue
        out[key] = (value, unit)
    return out


# ============================================================== cross-checks
def cross_check(specs, note=None):
    """Drop values that contradict other values from the same datasheet.

    Cheap, and it catches what per-spec bounds cannot: 0.5 dB is a perfectly
    plausible noise figure in isolation, and impossible beside a 9 dB
    conversion loss on the same page."""
    dropped = []

    def _val(k):
        v = specs.get(k)
        if isinstance(v, dict):
            return v.get("value")
        if isinstance(v, (tuple, list)) and v:
            return v[0] if isinstance(v[0], (int, float)) else None
        return None

    nf, cl = _val("nf_db"), _val("conversion_loss_db")
    if nf is not None and cl is not None and abs(nf - cl) > 2.5:
        # A passive mixer's SSB noise figure equals its conversion loss to
        # within a fraction of a dB. Anything else on the same page is the
        # footnote, not the spec.
        method = specs.get("nf_db")
        if not (isinstance(method, dict) and method.get("method") == "table"):
            specs.pop("nf_db", None)
            dropped.append(("nf_db", f"{nf} dB beside a {cl} dB conversion loss"))
    oip3, p1db = _val("oip3_dbm"), _val("p1db_dbm")
    if oip3 is not None and p1db is not None and oip3 < p1db:
        specs.pop("oip3_dbm", None)
        dropped.append(("oip3_dbm", f"{oip3} dBm below P1dB {p1db} dBm"))
    fmin, fmax = _val("freq_min"), _val("freq_max")
    if fmin is not None and fmax is not None and fmax <= fmin:
        specs.pop("freq_min", None)
        specs.pop("freq_max", None)
        dropped.append(("freq_min/max", f"{fmin}-{fmax} GHz is not a band"))
    if note and dropped:
        for k, why in dropped:
            note(f"      dropped {k}: {why}")
    return dropped


# ------------------------------------------------- space-qualification hint
# Weighted evidence for how space-capable a datasheet SOUNDS. This is a hint for
# the many parts where no source states a qualification, not a replacement for
# the `space` field -- a stated qualification always wins, and this is stored
# under its own key so the two can never be confused.
#
# It is deliberately rule-based and explainable: every score comes with the list
# of terms that produced it, so a number can always be argued with. spacequal.py
# remains the statistical view; this is the cheap one that runs during a rebuild.
_SPACE_EVIDENCE = [
    # (weight, label, pattern)  -- strong: an actual qualification standard
    (30, "MIL-PRF-38534 Class K", r"38534.{0,20}class\s*k|class\s*k.{0,20}38534"),
    (30, "MIL-PRF-38535 Class V/QML-V", r"38535|qml-?\s*v\b|class\s*v\b"),
    (28, "JANS", r"\bjans\b"),
    (26, "ESCC", r"\bescc\b|european space components"),
    (26, "radiation hardened", r"radiation[- ]hardened|rad[- ]?hard\b"),
    (22, "TID rating", r"\btid\b.{0,24}\d+\s*k?rad|\d+\s*krad"),
    (22, "SEL/SEE rating", r"\bsel\b.{0,24}mev|mev\s*[\u00b7*x]?\s*cm|single event"),
    (20, "space qualified", r"space[- ]qualified|qualified for space|space[- ]grade"),
    (18, "Class S", r"\bclass\s*s\b"),
    # moderate: screening and construction that space parts require
    (12, "hermetic", r"\bhermetic|hermetically sealed"),
    (12, "MIL-STD-883", r"mil-?std-?883|method\s*20\d\d"),
    (10, "screened", r"\bscreen(?:ed|ing)\b|\bburn-?in\b|\b100%\s*test"),
    (10, "MIL-STD (other)", r"mil-?std-?(?!883)\d{3}"),
    (8,  "outgassing/ASTM E595", r"outgassing|astm\s*e-?595|tml\b"),
    # weak: materials common in space parts but also in ordinary ones
    (6,  "LTCC/ceramic", r"\bltcc\b|\bceramic\b|\balumina\b"),
    (5,  "GaAs", r"\bgaas\b|gallium arsenide"),
    (5,  "GaN", r"\bgan\b|gallium nitride"),
    (4,  "Kovar/gold", r"\bkovar\b|gold[- ]plated|au plated"),
    (4,  "MMIC", r"\bmmic\b"),
    # negative: statements that rule it out
    (-30, "commercial only", r"commercial\s*(use|grade)\s*only|not\s*for\s*space"),
    (-14, "plastic encapsulated", r"plastic\s*(encapsulat|package)"),
    (-10, "consumer/automotive", r"\bconsumer\b|\bautomotive\b|aec-?q\d+"),
]
_SPACE_EVIDENCE = [(w, lbl, re.compile(pat, re.I)) for w, lbl, pat in _SPACE_EVIDENCE]

# Above this, calling it a strong hint is fair; the cap keeps one very wordy
# datasheet from scoring higher than a genuinely qualified part.
_SPACE_MAX = 100


def space_score(text):
    """(percent 0-100, [evidence labels]) for how space-capable a datasheet reads.

    Returns (None, []) when nothing at all fires, because "no evidence" and
    "evidence for zero" are different things and storing 0 for the first would
    look like a judgement that was never made.

    The clamp at zero used to hide the most informative case: a part with a
    positive material signal and an explicit negative came out as 0, which is
    indistinguishable from "found nothing". The raw sum now rides along in the
    evidence list so the two can be told apart.
    """
    if not text:
        return None, []
    hits, score = [], 0
    for weight, label, rx in _SPACE_EVIDENCE:
        if rx.search(text):
            score += weight
            hits.append(label if weight > 0 else f"NOT: {label}")
    if not hits:
        return None, []
    pct = max(0, min(_SPACE_MAX, score))
    if score < 0:
        hits.append(f"(raw {score})")
    return pct, hits


# ============================================================ the mine itself
# Keys that are not evidence the electrical table has been reached, and so must
# not count toward the early exit. Counting them is why paging stopped on page
# one across the whole library: freq_min, freq_max, space_score_pct,
# space_evidence and throw_config all come off the front page, and that is five.
_SOFT_KEYS = {"freq_min", "freq_max", "space_score_pct", "space_evidence",
              "throw_config"}


def hard_spec_count(mined):
    return sum(1 for k in mined if k not in _SOFT_KEYS)


def mine_text(text, path=None, rows=None, mpn=None):
    """{spec key: (value, unit)} for one datasheet.

    Signature is backward compatible: mine_text(text) still works, and will
    still reach the positional table data when the text came from
    datasheet_text() (see _ROWS_MEMO). Pass `path` explicitly for the
    unambiguous route.

    Provenance for the most recent call -- which extractor produced each value,
    the literal row or snippet, the confidence -- is left in
    `mine_text.provenance` rather than folded into the return value, so callers
    that unpack (value, unit) keep working.
    """
    out, prov = {}, {}
    if not text and not rows:
        mine_text.provenance = prov
        return out
    if rows is None:
        rows, memo_path = _memo_get(text)
        if path is None:
            path = memo_path
    if rows is None and path is not None:
        try:
            rows = rows_for(path)
        except Exception:
            rows = []
    rows = rows or []
    if mpn is None and path:
        mpn = Path(path).stem

    # --- family sheets -----------------------------------------------------
    # One MACOM coupler sheet tabulates 23 parts; one limiter sheet lists the
    # requested MPN only as a cross-reference to a different part number. Mining
    # either one part-blind hands every sharer the same values, which is how two
    # byte-identical files produced identical specs for parts the catalog knows
    # differ.
    family = is_family_sheet(rows)
    own_row = part_row(rows, mpn) if (family and mpn) else None
    if family and own_row is None:
        # Refuse per-part specs. Qualification wording is a property of the
        # family and stays.
        pct, why = space_score(text)
        if pct is not None:
            out["space_score_pct"] = (float(pct), "%")
            out["space_evidence"] = (", ".join(why)[:180], "")
        prov["_family"] = {"mpns": len(family_mpns(rows)),
                           "note": "family sheet; this part's row was not found "
                                   "-- per-part specs suppressed"}
        mine_text.provenance = prov
        return out

    # --- table rows (primary) ---------------------------------------------
    if rows:
        for key, rec in mine_rows(rows).items():
            out[key] = (rec["value"], rec["unit"])
            prov[key] = rec

    # --- prose regex (fills blanks only) ----------------------------------
    for key, pats in _PATTERNS.items():
        if key in out:
            continue
        meta = PARAM_SPECS[key]
        ugroup = meta.get("unit_group")
        uscale = meta.get("unit_scale") or {}
        for pat in pats:
            for m in pat.finditer(text or ""):
                try:
                    value = float(m.group(1))
                except (TypeError, ValueError, IndexError):
                    continue
                if ugroup:
                    try:
                        unit = (m.group(ugroup) or "").strip().lower()
                    except (IndexError, re.error):
                        unit = ""
                    factor = uscale.get(unit)
                    if factor is None:
                        continue        # unknown unit: refuse rather than guess
                    # round: scaling by a float factor leaves binary noise
                    # (700 * 1e-3 -> 0.7000000000000001)
                    value = round(value * factor, 9)
                bounds = PLAUSIBLE.get(key)
                if bounds and not (bounds[0] <= value <= bounds[1]):
                    continue
                if not _prose_guard(text, m):
                    continue
                out[key] = (value, meta.get("unit", ""))
                prov[key] = {"value": value, "unit": meta.get("unit", ""),
                             "method": "prose", "confidence": CONF_PROSE,
                             "row": re.sub(r"\s+", " ", m.group(0))[:110]}
                break
            if key in out:
                break

    # Reversed 'Label unit value' ordering, for files with no usable geometry.
    for k, v in mine_table_rows(text).items():
        if k not in out:
            out[k] = v
            prov[k] = {"value": v[0], "unit": v[1], "method": "table-text",
                       "confidence": CONF_TABLE_WEAK, "row": ""}

    # --- frequency band ---------------------------------------------------
    band = None
    if rows:
        fr = freq_from_rows(rows)
        if fr:
            band = (fr[0], fr[1])
            prov["freq_min"] = prov["freq_max"] = {
                "method": "table", "confidence": CONF_TABLE, "row": fr[2]}
    if band is None and family and own_row is not None and path:
        fb = family_band(path, mpn)
        if fb:
            band = (fb[0], fb[1])
            prov["freq_min"] = prov["freq_max"] = {
                "method": "family-column", "confidence": CONF_TABLE,
                "row": fb[2]}
    if band is None:
        b = freq_range_ghz(text)
        if b:
            band = b
            cands = _candidates(text)
            rec = cands.get((round(b[0], 9), round(b[1], 9)), {})
            prov["freq_min"] = prov["freq_max"] = {
                "method": "prose-vote", "confidence": CONF_DERIVED,
                "row": f"{rec.get('snippet','')} (seen {rec.get('n',1)}x, "
                       f"score {_score_of(text, b)})"}
    if band:
        out["freq_min"] = (band[0], "GHz")
        out["freq_max"] = (band[1], "GHz")

    # --- non-numeric -------------------------------------------------------
    cfg = specmatch.parse_throw_config(text[:4000]) if text else ""
    if cfg:
        out["throw_config"] = (cfg, "")
        prov["throw_config"] = {"method": "prose", "confidence": CONF_PROSE}
    pct, why = space_score(text)
    if pct is not None:
        out["space_score_pct"] = (float(pct), "%")
        out["space_evidence"] = (", ".join(why)[:180], "")

    cross_check(out)
    if family:
        prov["_family"] = {"mpns": len(family_mpns(rows)),
                           "note": "family sheet; this part's row was located"}
    mine_text.provenance = prov
    return out


mine_text.provenance = {}


def _score_of(text, pair):
    rec = _candidates(text).get((round(pair[0], 9), round(pair[1], 9)))
    if not rec:
        return 0
    return rec["ctx"] + min(4, 2 * (rec["n"] - 1))


# ---------------------------------------------------------------- parse cache
# Parsing is the whole cost of this step: several thousand PDFs at up to six
# pages each. Without a cache that work is repeated in full on EVERY rebuild,
# which is what made the enrichment pass take ten minutes every single time.
# Keyed on path + size + mtime AND the parser version, so an edited datasheet is
# re-read, a parser change re-reads everything once, and nothing else is touched.
def _cache_path():
    from .paths import CACHE_DIR
    return Path(CACHE_DIR) / "datasheet_mining.json"


def load_cache():
    fp = _cache_path()
    if fp.is_file():
        try:
            import json
            data = json.loads(fp.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
        except Exception:
            pass
    return {}


def save_cache(cache):
    fp = _cache_path()
    try:
        import json
        fp.parent.mkdir(parents=True, exist_ok=True)
        fp.write_text(json.dumps(cache), encoding="utf-8")
        return True
    except OSError as e:
        # Never silent: a cache that fails to persist looks exactly like "mining
        # is slow again", which is the bug this exists to fix.
        print(f"  ! could not save the datasheet mining cache: {e}")
        return False


def _file_key(path):
    try:
        st = Path(path).stat()
        return f"{st.st_size}:{int(st.st_mtime)}"
    except OSError:
        return ""


def part_file_key(mpn, index):
    """Identity of the datasheet that would be used for this part.

    Path + size + mtime + parser version, so replacing or editing the file
    re-enriches the part, a parser change re-enriches everything once, and an
    untouched file with an untouched parser is skipped."""
    path = index.get(_loose(mpn))
    if not path:
        return ""
    fk = _file_key(path)
    return f"{path}|{fk}|v{PARSER_VERSION}" if fk else ""


def has_datasheet(mpn, index):
    """Is there a local datasheet for this part? O(1), no file opened."""
    return _loose(mpn) in index


def mine_part(mpn, index, cache=None, disk_cache=None, stats=None):
    """SpecRows mined from this part's datasheet, or [].

    Rows carry min/typ/max where the table supplied them, so a filter can use
    the conservative edge while a comparison against a catalog value can use
    typ. Storing only typ is what made honest band-dependent differences look
    like parse errors in the debug diff."""
    key = _loose(mpn)
    path = index.get(key)
    if not path:
        return []
    provenance = {}
    if cache is not None and key in cache:
        mined, provenance = cache[key]           # already parsed this run
    else:
        mined = None
        fkey = _file_key(path)
        if disk_cache is not None and fkey:
            hit = disk_cache.get(str(path))
            if isinstance(hit, dict) and hit.get("k") == fkey \
                    and hit.get("v") == PARSER_VERSION:
                mined = {kk: tuple(vv) for kk, vv in (hit.get("s") or {}).items()}
                provenance = hit.get("p") or {}
                if stats is not None:
                    stats["reused"] = stats.get("reused", 0) + 1
        if mined is None:
            # Stop reading pages as soon as the mine is productive -- counting
            # only HARD specs, so front-page boilerplate cannot end the read
            # before the electrical table.
            def _enough(text, _n=EARLY_EXIT_SPECS):
                return hard_spec_count(mine_text(text)) >= _n
            # Count REAL parses. Overwriting an existing cache entry does not
            # change the dict length, so measuring progress by len(cache)
            # reported "0 newly parsed" even when a changed datasheet had just
            # been re-read.
            if stats is not None:
                stats["parsed"] = stats.get("parsed", 0) + 1
            text = datasheet_text(path, want=_enough)
            mined = mine_text(text, path=path, mpn=mpn)
            provenance = {k: {kk: vv for kk, vv in v.items()
                              if kk in ("method", "confidence", "row",
                                        "min", "typ", "max", "note")}
                          for k, v in (mine_text.provenance or {}).items()}
            if disk_cache is not None and fkey:
                disk_cache[str(path)] = {
                    "k": fkey, "v": PARSER_VERSION,
                    "s": {kk: list(vv) for kk, vv in mined.items()},
                    "p": provenance}
            if stats is not None and provenance.get("_family"):
                stats["family"] = stats.get("family", 0) + 1
        if cache is not None:
            cache[key] = (mined, provenance)
    rows = []
    fname = Path(path).name
    for spec_key, (value, unit) in mined.items():
        p = provenance.get(spec_key) or {}
        method = p.get("method", "datasheet")
        conf = float(p.get("confidence", CONF_PROSE))
        detail = p.get("row") or ""
        snippet = f"mined from {fname}" + (f": {detail}" if detail else "")
        if isinstance(value, str):
            rows.append(SpecRow(key=spec_key, value_text=value[:60],
                                method="datasheet", confidence=conf,
                                snippet=snippet[:240]))
        else:
            rows.append(SpecRow(key=spec_key, value_typ=float(value),
                                value_min=p.get("min"), value_max=p.get("max"),
                                unit=unit, method="datasheet", confidence=conf,
                                snippet=snippet[:240]))
    return rows


def mine_parts(parts, roots=None, say=None, every=250, limit=None):
    """Mine a sequence of {'mpn': ...} records. Returns (rows_by_mpn, stats)."""
    index = build_index(roots, say=say)
    if not index:
        if say:
            say("    no local datasheets found; skipping datasheet mining")
        return {}, {"indexed": 0, "matched": 0, "mined": 0}
    out, cache = {}, {}
    stats = {"indexed": len(index), "matched": 0, "mined": 0, "parsed": 0,
             "reused": 0, "family": 0}
    for i, p in enumerate(parts, 1):
        mpn = p.get("mpn") if isinstance(p, dict) else p
        if not mpn:
            continue
        if _loose(mpn) in index:
            stats["matched"] += 1
            rows = mine_part(mpn, index, cache, stats=stats)
            if rows:
                out[mpn] = rows
                stats["mined"] += 1
        if say and every and i % every == 0:
            say(f"      mined {i} part(s): {stats['matched']} with a datasheet, "
                f"{stats['mined']} yielding specs")
        if limit and i >= limit:
            break
    if say:
        say(f"    datasheet mining: {stats['matched']} part(s) had a datasheet, "
            f"{stats['mined']} yielded at least one spec"
            + (f"; {stats['family']} were family sheets with no locatable row"
               if stats.get("family") else ""))
    return out, stats
