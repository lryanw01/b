"""Offline self-checks: URL filter, spec extraction, package/space, evaluation, ranking.

No network required. Run with:  pytest -q   (or:  python tests/test_rfparts.py)
"""
from rfparts import extract, rank
from rfparts.discover import _url_ok
from rfparts.spec import _canon_category, _canon_package, _parse_range


# --- canonicalization / range parsing ------------------------------------
def test_canon_category():
    assert _canon_category("LNA") == "amplifier"
    assert _canon_category("low noise amplifier") == "amplifier"
    assert _canon_category("pad") == "attenuator"
    assert _canon_category("impedance matching pad") == "attenuator"


def test_canon_package():
    assert _canon_package("surface mount") == "smt"
    assert _canon_package("SMT") == "smt"
    assert _canon_package("coax") == "connectorized"
    assert _canon_package("bare die") == "die"


def test_parse_range():
    assert _parse_range("4-8") == [4.0, 8.0]
    assert _parse_range("DC-18") == [0.0, 18.0]
    assert _parse_range("") is None


# --- URL filter ----------------------------------------------------------
def test_url_filter():
    toks = ["attenuator", "atten", "pad"]
    assert _url_ok("https://x.com/product/2082-6241-cryo-attenuator/", toks, "attenuator")
    assert not _url_ok("https://x.com/about-us/", toks, "attenuator")
    assert not _url_ok("https://x.com/products/attenuators/", toks, "attenuator")
    assert not _url_ok("https://x.com/product/cryo-isolator-4-8/", toks, "attenuator")


# --- package / interface detection ---------------------------------------
def test_mount_type():
    assert extract._mount_type("50 ohm surface mount SMT termination", False) == "smt"
    assert extract._mount_type("bare die MMIC amplifier, wirebond", False) == "die"
    assert extract._mount_type("connectorized module with SMA input/output", True) == "connectorized"
    assert extract._mount_type("SMA female connector", True) == "connectorized"
    assert extract._mount_type("no interface clues here", False) == "unknown"
    # explicit SMT keyword outweighs a stray connector mention
    assert extract._mount_type("surface mount, eval board uses SMA", True) == "smt"


# --- space / hi-rel signal detection -------------------------------------
def test_space_signal():
    assert extract._space_signal("Space-qualified LNA with flight heritage") == "qualified"
    assert extract._space_signal("radiation hardened, rad-hard") == "qualified"
    assert extract._space_signal("MIL-PRF-38534 Class K screening available") == "hi_rel"
    assert extract._space_signal("hermetically sealed, QML listed") == "hi_rel"
    assert extract._space_signal("commercial COTS part") == "none"


# --- spec extraction regexes ---------------------------------------------
def test_extract_freq_and_gain():
    text = ("Low Noise Amplifier. Frequency: 4 - 8 GHz. Typical gain 32 dB. "
            "Noise temperature 4 K. SMA connectors. Lead time 6 weeks.")
    specs = _mine(text)
    assert specs["freq_ghz"] == [4.0, 8.0]
    assert specs["gain_db"] == 32.0
    assert specs["noise_k"] == 4.0
    assert specs["connector"] == "SMA"
    assert specs["lead_weeks"] == 6.0


# --- evaluation with package + space -------------------------------------
SPEC = {"category": "lna", "freq_ghz": [4, 8], "temp_k": 4, "gain_db_min": 30,
        "noise_k_max": 5, "connector": "SMA", "package": "connectorized", "space": True}


def test_evaluate_package_and_space():
    c = {"title": "cryo LNA", "url": "u1",
         "specs": {"freq_ghz": [4, 8], "cryo": True, "gain_db": 32, "noise_k": 4,
                   "connector": "SMA", "mount_type": "connectorized", "space": "qualified"}}
    rank.evaluate(c, SPEC)
    assert c["criteria"]["pkg"] == "met"
    assert c["criteria"]["space"] == "met"
    assert rank.tier(c) == "A"


def test_package_miss_and_space_unknown():
    c = {"title": "LNA", "url": "u2",
         "specs": {"freq_ghz": [4, 8], "cryo": True, "gain_db": 32, "noise_k": 4,
                   "connector": "SMA", "mount_type": "smt", "space": "hi_rel"}}
    rank.evaluate(c, SPEC)
    assert c["criteria"]["pkg"] == "miss"      # smt != connectorized
    assert c["criteria"]["space"] == "unknown"  # hi-rel is not a hard 'qualified'
    assert rank.tier(c) == "C"                   # a hard miss -> tier C


# --- ranking order + markdown renders (no unicode crash) -----------------
def test_rank_and_markdown():
    cands = [
        {"url": "a", "title": "cryo LNA A", "vendor": "V",
         "specs": {"freq_ghz": [4, 8], "cryo": True, "gain_db": 32, "noise_k": 4,
                   "connector": "SMA", "mount_type": "connectorized", "space": "qualified",
                   "price_usd": 500}},
        {"url": "err", "title": "404", "vendor": "V", "specs": {"_error": True}},
    ]
    r = rank.rank(cands, SPEC)
    assert [c["url"] for c in r] == ["a"]        # error dropped
    md = rank.markdown(r, SPEC)
    assert "Interface" in md and "Space" in md
    assert "space-qual" in md and "conn" in md
    md.encode("utf-8")                            # ✓ marks encode cleanly


def _mine(text):
    specs = {}
    fg = extract._freq_ghz(text)
    if fg:
        specs["freq_ghz"] = fg
    g = extract.GAIN.search(text)
    if g:
        specs["gain_db"] = float(g.group(1))
    nk = extract.NOISE_K.search(text)
    if nk:
        specs["noise_k"] = float(nk.group(1))
    conn = extract.CONNECTOR.search(text)
    if conn:
        specs["connector"] = conn.group(1).upper().replace(" ", "")
    lw = extract._lead_weeks(text)
    if lw is not None:
        specs["lead_weeks"] = lw
    return specs


if __name__ == "__main__":
    import sys
    import traceback

    failed = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"ok   {name}")
            except Exception:
                failed += 1
                print(f"FAIL {name}")
                traceback.print_exc()
    sys.exit(1 if failed else 0)
