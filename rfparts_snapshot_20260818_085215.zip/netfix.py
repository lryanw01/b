"""Make Python trust the OS certificate store (corporate TLS inspection fix).

Networks like BAE's Prisma Access decrypt and re-sign HTTPS with an internal
CA. Browsers trust it because IT installs the cert in the Windows store, but
Python ships its own `certifi` bundle which doesn't include it — so every
requests call dies with CERTIFICATE_VERIFY_FAILED (self-signed certificate in
certificate chain).

`truststore` (pip install truststore — pure Python, no deps) patches Python's
ssl module to use the OS store, so the corporate CA is trusted exactly the way
the browser trusts it. The injection is process-global, so importing this
module anywhere covers ALL network code: crawler, datasheet, and fetch.py.

This is the correct fix — never disable verification (verify=False), which
would silently accept anyone's certificate.

Import it for side effects:  from . import netfix   # noqa: F401
Degrades silently when truststore isn't installed (e.g. on a machine without
TLS inspection where nothing needs fixing).
"""
try:
    import truststore

    truststore.inject_into_ssl()
    ACTIVE = True
except ImportError:
    ACTIVE = False
