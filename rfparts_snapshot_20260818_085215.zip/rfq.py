"""Draft a plain-text RFQ (request-for-quote) email for a vendor or supplier.

This only *drafts* text — it does not send anything, open a mail client, or
touch the network. You paste it into your own email tooling.

`vendor` is a plain dict; every field is optional so this works for a catalog
vendor, a registry vendor, or a recommended-supplier entry alike:
    name       display name              (default "Sales team")
    url        product / vendor URL      (default "")
    rfq_email  quote address, if known   -> becomes the To: line
    rfq_url    quote form / contact URL  -> used in To: when no email
    quals      list of qualification flows the supplier offers (optional)
    kind       manufacturer|distributor|... (optional, tunes wording)
"""


def _fmt_range(rng):
    try:
        return f"{rng[0]:g}\u2013{rng[1]:g}"
    except Exception:
        return ""


def _req_line(spec):
    bits = []
    if spec.get("category"):
        bits.append(str(spec["category"]).replace("_", " "))
    if spec.get("freq_ghz"):
        r = _fmt_range(spec["freq_ghz"])
        if r:
            bits.append(f"{r} GHz")
    if spec.get("temp_k") is not None:
        bits.append(f"operating at {spec['temp_k']:g} K")
    if spec.get("gain_db_min") is not None:
        bits.append(f"gain \u2265 {spec['gain_db_min']:g} dB")
    if spec.get("noise_k_max") is not None:
        bits.append(f"noise temp \u2264 {spec['noise_k_max']:g} K")
    if spec.get("attenuation_db") is not None:
        bits.append(f"{spec['attenuation_db']:g} dB attenuation")
    if spec.get("package"):
        bits.append(f"{spec['package']} package")
    if spec.get("connector"):
        bits.append(f"{spec['connector']} connectors")
    if spec.get("mount"):
        bits.append(str(spec["mount"]))
    for o in spec.get("other", []) or []:
        bits.append(str(o))
    return ", ".join(bits) if bits else "the part described below"


def _part_label(p):
    return (p.get("model") or p.get("title") or p.get("mpn")
            or p.get("url") or "part")


def draft(vendor, parts, spec, requester="[your name]", org="[your organization]"):
    """Return (to_address, subject, body) for an RFQ to `vendor` about `parts`.

    Robust to partial vendor dicts and empty part lists — never raises on a
    missing key (this is what previously limited drafting to one vendor)."""
    vendor = vendor or {}
    spec = spec or {}
    name = vendor.get("name") or "Sales team"
    url = vendor.get("url") or ""
    email = vendor.get("rfq_email") or ""
    form = vendor.get("rfq_url") or url

    if email:
        to = email
    elif form:
        to = f"(no public RFQ email \u2014 submit via {form})"
    else:
        to = "(no contact on file \u2014 see the supplier's website)"

    cat = spec.get("category", "RF component")
    freq = _fmt_range(spec.get("freq_ghz")) if spec.get("freq_ghz") else ""
    subject = f"RFQ: {cat}" + (f" {freq} GHz" if freq else "")

    lines = [
        f"Hello {name},",
        "",
        f"We are sourcing {_req_line(spec)} and would like pricing and lead time.",
        "",
    ]

    if parts:
        lines.append("Parts of interest:")
        for p in parts:
            price = (p.get("specs", {}) or {}).get("price_usd")
            price_s = f" (listed ${price:,.0f})" if isinstance(price, (int, float)) else ""
            lines.append(f"  - {_part_label(p)}{price_s}")
            if p.get("url"):
                lines.append(f"    {p['url']}")
    else:
        # e.g. drafting to a recommended supplier with no matching catalog rows
        lines.append("We are open to your recommendation for the requirement above.")

    ask = ["Please include unit price at qty 1 and 10, lead time,"]
    if spec.get("space"):
        # Space build: make the qualification ask explicit.
        quals = vendor.get("quals") or []
        if quals:
            ask.append("your applicable space flow (" + ", ".join(quals[:3]) + "),")
        else:
            ask.append("qualification status \u2014 QMLV/Class V or"
                       " MIL-PRF-38534 Class K/H,")
        ask.append("available screening/upscreening, hermeticity, and any")
        ask.append("radiation data (TID / SEE) or flight heritage.")
        if vendor.get("kind") in ("distributor", "screening"):
            ask.append("If stocked as COTS, note upscreening options to the"
                       " above and QCI availability.")
    else:
        ask.append("RoHS/qualification status, and any datasheet not on your site.")

    lines += ["", " ".join(ask), "", "Thank you,", f"{requester}", f"{org}"]
    if url:
        lines.append("")
        lines.append(f"(Referencing your catalog: {url})")
    return to, subject.strip(), "\n".join(lines)
