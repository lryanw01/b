"""DigiKey Product Information V4 adapter (strategy: api).

Live, credentialed source for price / stock / lead / datasheet plus whatever RF
parameters DigiKey publishes. It is *opt-in by credentials*: with no client ID
/ secret in the environment it logs once and returns an empty list, so a default
install behaves exactly as before.

Auth is OAuth 2.0 two-legged (client-credentials) — no user login — which is the
flow DigiKey documents for Product Information V4. The bearer token is cached to
disk with its expiry and reused across runs; search responses are cached with a
short TTL so re-runs and the per-day rate quota (roughly 1000 requests/day for
standard products) are respected.

Credentials / config (environment):
    DIGIKEY_CLIENT_ID        OAuth client id      (required)
    DIGIKEY_CLIENT_SECRET    OAuth client secret  (required)
    DIGIKEY_SANDBOX=1        use the sandbox host (default: production)
    DIGIKEY_LOCALE_SITE      X-DIGIKEY-Locale-Site header, e.g. US (optional)
    DIGIKEY_LOCALE_CURRENCY  currency, e.g. USD (optional)
    RFPARTS_DIGIKEY_LIMIT    products per search  (default 25)
    RFPARTS_DIGIKEY_TTL      response cache seconds (default 86400)

Product Information V4 field names are accessed defensively (several fallback
keys) so the adapter tolerates minor V3/V4 shape differences without a live
endpoint to test against. Category-id filtering is intentionally left for later;
this first cut drives the keyword-search endpoint with a spec-derived query.
"""
import json
import os
import re
import threading
import time
from urllib.parse import quote

import requests

from .. import fetch
from ..registry import CATEGORY_SYNONYMS, DATA, synonyms

PROD_HOST = "https://api.digikey.com"
SANDBOX_HOST = "https://sandbox-api.digikey.com"

TOKEN_CACHE = DATA / "digikey_token.json"
SEARCH_CACHE = DATA / "digikey_search_cache.json"

TIMEOUT = 20
MAX_RETRIES = 3
RETRY_STATUS = {429, 500, 502, 503, 504}
CACHE_MAX_ENTRIES = 500

_LOCK = threading.RLock()
_NO_CREDS_LOGGED = False


def _host():
    return SANDBOX_HOST if os.environ.get("DIGIKEY_SANDBOX") else PROD_HOST


def _creds():
    return (os.environ.get("DIGIKEY_CLIENT_ID", "").strip(),
            os.environ.get("DIGIKEY_CLIENT_SECRET", "").strip())


def _limit():
    try:
        return max(1, min(50, int(os.environ.get("RFPARTS_DIGIKEY_LIMIT", "25"))))
    except ValueError:
        return 25


def _ttl():
    try:
        return max(0, int(os.environ.get("RFPARTS_DIGIKEY_TTL", "86400")))
    except ValueError:
        return 86400


# --- injectable transport (tests replace _request) -----------------------
def _request(method, url, headers=None, data=None, json_body=None):
    """Single HTTP call. Returns (status_code, parsed_json_or_None). Never raises
    for HTTP errors; only transport exceptions propagate to the retry loop."""
    r = requests.request(method, url, headers=headers, data=data, json=json_body,
                         timeout=TIMEOUT)
    body = None
    try:
        body = r.json()
    except ValueError:
        body = None
    return r.status_code, body, r.headers


def _retry_after(headers, fallback):
    ra = (headers or {}).get("Retry-After")
    if ra:
        try:
            return max(0.0, float(ra))
        except (TypeError, ValueError):
            pass
    return fallback


def _call(method, url, headers=None, data=None, json_body=None):
    """Retry wrapper honoring Retry-After on 429/5xx. Returns parsed json or None."""
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            status, body, hdrs = _request(method, url, headers=headers, data=data,
                                          json_body=json_body)
        except requests.RequestException as exc:
            fetch.log(f"digikey transport {type(exc).__name__} ({attempt})")
            if attempt >= MAX_RETRIES:
                return None
            time.sleep(0.5 * attempt)
            continue
        if status in RETRY_STATUS and attempt < MAX_RETRIES:
            wait = _retry_after(hdrs, 0.5 * attempt)
            fetch.log(f"digikey retry {status} ({attempt}) in {wait:g}s")
            time.sleep(wait)
            continue
        if status >= 400:
            fetch.log(f"digikey HTTP {status}")
            return None
        return body
    return None


# --- token cache ----------------------------------------------------------
def _load_token():
    try:
        raw = json.loads(TOKEN_CACHE.read_text(encoding="utf-8"))
        if isinstance(raw, dict) and raw.get("access_token") and raw.get("expires_at", 0) > time.time() + 30:
            return raw["access_token"]
    except (OSError, ValueError):
        pass
    return None


def _store_token(token, expires_in):
    try:
        TOKEN_CACHE.write_text(json.dumps(
            {"access_token": token, "expires_at": time.time() + float(expires_in or 0)}),
            encoding="utf-8")
    except OSError:
        pass


def _token():
    """Return a valid bearer token, fetching a fresh one if needed. None on failure."""
    cid, secret = _creds()
    if not cid or not secret:
        return None
    with _LOCK:
        tok = _load_token()
        if tok:
            return tok
        body = _call(
            "POST", f"{_host()}/v1/oauth2/token",
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data={"client_id": cid, "client_secret": secret,
                  "grant_type": "client_credentials"})
        if not isinstance(body, dict) or not body.get("access_token"):
            fetch.log("digikey token request failed")
            return None
        _store_token(body["access_token"], body.get("expires_in", 0))
        return body["access_token"]


# --- response cache -------------------------------------------------------
def _cache_get(key):
    if _ttl() <= 0:
        return None
    try:
        raw = json.loads(SEARCH_CACHE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    row = raw.get(key) if isinstance(raw, dict) else None
    if isinstance(row, dict) and time.time() - row.get("ts", 0) < _ttl():
        return row.get("products")
    return None


def _cache_put(key, products):
    if _ttl() <= 0:
        return
    try:
        raw = json.loads(SEARCH_CACHE.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raw = {}
    except (OSError, ValueError):
        raw = {}
    raw[key] = {"ts": time.time(), "products": products}
    if len(raw) > CACHE_MAX_ENTRIES:
        # drop the oldest entries
        for k in sorted(raw, key=lambda k: raw[k].get("ts", 0))[:len(raw) - CACHE_MAX_ENTRIES]:
            raw.pop(k, None)
    try:
        SEARCH_CACHE.write_text(json.dumps(raw), encoding="utf-8")
    except OSError:
        pass


# --- query + response mapping ---------------------------------------------
def _first(d, *keys, default=None):
    if not isinstance(d, dict):
        return default
    for k in keys:
        if k in d and d[k] not in (None, "", []):
            return d[k]
    return default


def _num(value):
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if not isinstance(value, str):
        return None
    m = re.search(r"-?\d+(?:\.\d+)?", value.replace(",", ""))
    return float(m.group()) if m else None


def _to_ghz(value):
    """Parse a frequency string to GHz. Returns float or None."""
    if value is None:
        return None
    s = str(value).lower()
    m = re.search(r"(-?\d+(?:\.\d+)?)\s*(ghz|mhz|khz|hz)?", s)
    if not m:
        return None
    n = float(m.group(1))
    unit = m.group(2) or "ghz"
    return {"ghz": n, "mhz": n / 1e3, "khz": n / 1e6, "hz": n / 1e9}[unit]


def _freq_range_ghz(value):
    """Parse 'a - b <unit>' or 'DC-18GHz' to [lo, hi] GHz, else None."""
    if value is None:
        return None
    s = str(value)
    low = 0.0 if "dc" in s.lower() else None
    nums = re.findall(r"(-?\d+(?:\.\d+)?)\s*(ghz|mhz|khz|hz)?", s.lower())
    # keep only tokens that actually had a digit
    vals = []
    for n, u in nums:
        vals.append(_to_ghz(f"{n}{u or 'ghz'}"))
    vals = [v for v in vals if v is not None]
    if not vals:
        return None
    if low == 0.0 and len(vals) >= 1:
        return [0.0, max(vals)]
    if len(vals) >= 2:
        return [min(vals), max(vals)]
    return None


def _mount(value):
    s = str(value or "").lower()
    if "surface" in s or "smd" in s or "smt" in s:
        return "smt"
    if "die" in s or "bare" in s or "chip" in s:
        return "die"
    if "flange" in s:
        return "flange"
    if "connector" in s or "coax" in s or "sma" in s or "bnc" in s or "n-type" in s:
        return "connectorized"
    return None


def _ports(value):
    n = _num(value)
    if n is None or n <= 0:
        return None
    return int(n)


def _abs_url(url):
    """DigiKey datasheet/photo links are often protocol-relative ('//host/..')."""
    u = str(url or "").strip()
    if u.startswith("//"):
        return "https:" + u
    return u


def _digikey_category(product):
    """Best-effort canonical category from DigiKey's own taxonomy, else None.

    DigiKey classifies every part; using that (instead of blindly stamping the
    searched-for category) is what keeps a coax connector returned by a "switch"
    search from being scored as a switch.
    """
    cat = product.get("Category")
    names = []
    if isinstance(cat, dict):
        names.append(str(_first(cat, "Name", "Value", default="")))
        for ch in (cat.get("ChildCategories") or cat.get("Children") or []):
            if isinstance(ch, dict):
                names.append(str(_first(ch, "Name", "Value", default="")))
    elif isinstance(cat, str):
        names.append(cat)
    for key in ("CategoryName", "Family"):
        v = product.get(key)
        if isinstance(v, dict):
            names.append(str(_first(v, "Name", "Value", default="")))
        elif isinstance(v, str):
            names.append(v)
    blob = " ".join(n for n in names if n).lower()
    if not blob:
        return None
    # A DigiKey category name can contain several canonical synonyms (e.g.
    # "Coaxial Connectors" hits both 'coaxial'->cable and 'connector'->connector).
    # Pick the longest matching token so the most specific category wins.
    best, best_len = None, 0
    for canon, syns in CATEGORY_SYNONYMS.items():
        for token in [canon.replace("_", " ")] + [s.lower() for s in syns]:
            if token and token in blob and len(token) > best_len:
                best, best_len = canon, len(token)
    return best


# Parameter-name substring -> (schema key, parser). First match wins.
_PARAM_MAP = [
    ("impedance", ("impedance_ohm", _num)),
    ("gain", ("gain_db", _num)),
    ("frequency range", ("freq_ghz", _freq_range_ghz)),
    ("operating frequency", ("freq_ghz", _freq_range_ghz)),
    ("frequency", ("freq_ghz", _freq_range_ghz)),
    ("mounting type", ("mount_type", _mount)),
    ("package / case", ("mount_type", _mount)),
    ("connector type", ("connector", str)),
    ("number of ports", ("ports", _ports)),
]


def _param_text(par):
    return str(_first(par, "ParameterText", "Parameter", "ParameterType", default="")).lower()


def _param_value(par):
    return _first(par, "ValueText", "Value", "ParameterValue", default="")


def _map_specs(product):
    """Map a DigiKey product record to the pipeline's common specs schema."""
    specs = {}
    price = _num(_first(product, "UnitPrice", "unitPrice"))
    if price is not None:
        specs["price_usd"] = price
    qty = _first(product, "QuantityAvailable", "quantityAvailable")
    qn = _num(qty)
    if qn is not None:
        specs["stock_qty"] = int(qn)
        if qn > 0:
            specs["lead_weeks"] = 0
    ds = _first(product, "DatasheetUrl", "PrimaryDatasheet", "datasheetUrl")
    if ds:
        specs["datasheet"] = _abs_url(ds)
    mfr = _first(_first(product, "Manufacturer", default={}), "Name", "Value") \
        or _first(product, "ManufacturerName")
    if mfr:
        specs["manufacturer"] = mfr

    params = _first(product, "Parameters", "parameters", default=[]) or []
    pmap = {}
    for par in params:
        text = _param_text(par)
        if text:
            pmap[text] = _param_value(par)
        for needle, (key, parser) in _PARAM_MAP:
            if needle in text:
                val = parser(_param_value(par))
                if val not in (None, ""):
                    specs.setdefault(key, val)
                break

    # DigiKey commonly splits frequency into 'frequency - min' / 'frequency - max'
    # (each a single value), which the range parser above can't use alone. Merge
    # them into freq_ghz when a plain range parameter didn't already set it.
    if "freq_ghz" not in specs:
        fmin = _to_ghz(pmap.get("frequency - min"))
        fmax = _to_ghz(pmap.get("frequency - max"))
        if fmin is not None or fmax is not None:
            lo = fmin if fmin is not None else 0.0
            hi = fmax if fmax is not None else fmin
            if hi is not None:
                specs["freq_ghz"] = [lo, hi]
    return specs


def _product_url(product):
    url = _first(product, "ProductUrl", "productUrl")
    if url:
        return url
    pn = _first(product, "ManufacturerProductNumber", "ManufacturerPartNumber",
                "DigiKeyProductNumber", default="")
    return f"https://www.digikey.com/en/products/result?keywords={quote(str(pn))}"


def _to_candidate(product, requested_category):
    pn = _first(product, "ManufacturerProductNumber", "ManufacturerPartNumber",
                "DigiKeyProductNumber", default="")
    desc = _first(_first(product, "Description", default={}), "ProductDescription",
                  "DetailedDescription") \
        or _first(product, "ProductDescription", "DetailedDescription", "Description", default="")
    mfr = _first(_first(product, "Manufacturer", default={}), "Name", "Value") \
        or _first(product, "ManufacturerName", default="")
    base = " ".join(str(x) for x in (mfr, pn) if x).strip()
    short = str(desc)[:70]
    # Surface the DigiKey description in the title so rank's category check (which
    # reads title + url) can tell a real RF switch from a coax connector, and so
    # the GUI Part column is meaningful.
    title = f"{base} — {short}" if base and short else (base or short or "DigiKey product")
    specs = _map_specs(product)
    params = _first(product, "Parameters", "parameters", default=[]) or []
    param_text = " ".join(
        f"{_param_text(p)}: {_param_value(p)}" for p in params if _param_text(p))
    text = " ".join(str(x) for x in (desc, param_text) if x)
    # Use DigiKey's own classification, NOT the searched-for category, so
    # irrelevant hits are scored honestly (and de-ranked) rather than trusted.
    category = _digikey_category(product)
    return {
        "url": _product_url(product),
        "title": title[:180],
        "category": category,   # may be None -> rank falls back to text match
        "_catalog": True,        # reuse the no-network extract path
        "_api": True,
        "_specs": specs,
        "text": text,
        "_api_record": product,
    }


def _build_keyword(spec):
    # DigiKey keyword search spans all of electronics, so lead with "RF <category>"
    # to bias toward RF/microwave parts. Impedance is deliberately NOT a keyword
    # term — "50 ohm" pulls in coax connectors; it stays a ranking criterion.
    parts = []
    cat = spec.get("category")
    if cat:
        parts.append(f"RF {cat.replace('_', ' ')}")
    if spec.get("connector"):
        parts.append(str(spec["connector"]))
    for tok in spec.get("other", []) or []:
        parts.append(str(tok))
    return " ".join(parts).strip() or (cat or "")


def candidates(vendor, spec):
    """Return DigiKey candidates for a spec, or [] when unavailable/uncredentialed."""
    global _NO_CREDS_LOGGED
    cid, secret = _creds()
    if not cid or not secret:
        if not _NO_CREDS_LOGGED:
            fetch.log("digikey: no DIGIKEY_CLIENT_ID/SECRET set; skipping (opt-in source)")
            _NO_CREDS_LOGGED = True
        return []

    keyword = _build_keyword(spec)
    if not keyword:
        return []
    limit = _limit()
    cache_key = f"{'sbx' if os.environ.get('DIGIKEY_SANDBOX') else 'prod'}|{limit}|{keyword.lower()}"

    products = _cache_get(cache_key)
    if products is None:
        token = _token()
        if not token:
            return []
        headers = {
            "Authorization": f"Bearer {token}",
            "X-DIGIKEY-Client-Id": cid,
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": fetch.UA,
        }
        site = os.environ.get("DIGIKEY_LOCALE_SITE")
        cur = os.environ.get("DIGIKEY_LOCALE_CURRENCY")
        if site:
            headers["X-DIGIKEY-Locale-Site"] = site
        if cur:
            headers["X-DIGIKEY-Locale-Currency"] = cur
        body = _call(
            "POST", f"{_host()}/products/v4/search/keyword", headers=headers,
            json_body={"Keywords": keyword, "Limit": limit, "Offset": 0})
        if not isinstance(body, dict):
            return []
        products = _first(body, "Products", "products", default=[]) or []
        _cache_put(cache_key, products)

    out = []
    for p in products:
        if isinstance(p, dict):
            out.append(_to_candidate(p, spec.get("category")))
    return out
