
"""debug_sources.py — hands-on probes for the two live sources.

Read-only diagnostics: this never writes project files. It exercises the real
adapter code in rfparts/ so what you see is what the pipeline will do.

Subcommands
-----------
  digikey    End-to-end DigiKey Product Information V4 check: acquire an OAuth
             token, run a keyword search, and print the RAW product JSON beside
             the MAPPED specs, plus every parameter name seen — so you can fix
             field names / extend _PARAM_MAP in rfparts/sources/digikey.py.

  websearch  Probe your SearXNG instance and tune the fallback: confirm JSON
             output is enabled, show the exact query variants built from a spec,
             run the fallback, and print ranked links with domain-trust scores
             so you can adjust websearch._TRUST / _RF_MANUFACTURERS.

Examples
--------
  # DigiKey (needs a developer app; see the printed setup guide if unset)
  export DIGIKEY_CLIENT_ID=... DIGIKEY_CLIENT_SECRET=...
  python debug_sources.py digikey --keywords "SP2T RF switch" --limit 5
  python debug_sources.py digikey --sandbox --category switch --impedance 50

  # SearXNG web fallback
  export RFPARTS_SEARXNG_URL=http://localhost:8888
  python debug_sources.py websearch --category phase_shifter --freq 2-8
  python debug_sources.py websearch --query "HMC547 s-parameters" --raw
"""
import argparse
import json
import os
import pathlib
import sys

# --- make the rfparts package importable when run from anywhere -----------
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

try:
    import requests
    from rfparts import fetch, spec as specmod, websearch
    from rfparts.sources import digikey
    from rfparts.registry import synonyms
except Exception as exc:  # noqa: BLE001
    print(f"could not import the rfparts package from {PROJECT_ROOT}: "
          f"{type(exc).__name__}: {exc}", file=sys.stderr)
    print("run this script from the project root (next to scan_minicircuits_snp.py).",
          file=sys.stderr)
    sys.exit(2)


def rule(title):
    print("\n" + "=" * 72)
    print(title)
    print("=" * 72)


def kv(label, value):
    print(f"  {label:<26} {value}")


# =========================================================================
# DigiKey
# =========================================================================
DIGIKEY_SETUP = """\
No DigiKey credentials found. The Product Information API is free but needs an app.

  1. Sign in at https://developer.digikey.com with a myDigiKey account.
  2. Create an organization, then create an app. For Product Information V4 the
     two-legged (client-credentials) OAuth flow is enough — no user login.
  3. Copy the app's Client ID and Client Secret, then:
         export DIGIKEY_CLIENT_ID=xxxxxxxx
         export DIGIKEY_CLIENT_SECRET=xxxxxxxx
  4. Start against the sandbox (structure matches production, data may differ):
         python debug_sources.py digikey --sandbox --keywords "attenuator"
     Standard products are rate-limited (per-minute and ~1000/day), so keep runs
     small while iterating.
"""


def _digikey_headers(token, client_id):
    headers = {
        "Authorization": f"Bearer {token}",
        "X-DIGIKEY-Client-Id": client_id,
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": fetch.UA,
    }
    site = os.environ.get("DIGIKEY_LOCALE_SITE")
    cur = os.environ.get("DIGIKEY_LOCALE_CURRENCY")
    if site:
        headers["X-DIGIKEY-Locale-Site"] = site
    if cur:
        headers["X-DIGIKEY-Locale-Currency"] = cur
    return headers


def cmd_digikey(args):
    fetch.VERBOSE = True  # surface the adapter's own log lines
    if args.sandbox:
        os.environ["DIGIKEY_SANDBOX"] = "1"

    rule("DigiKey — configuration")
    cid, secret = digikey._creds()
    kv("client id set", bool(cid))
    kv("client secret set", bool(secret))
    kv("host", digikey._host())
    if not cid or not secret:
        print(DIGIKEY_SETUP)
        return 2

    rule("DigiKey — OAuth token (client-credentials)")
    token = digikey._token()
    if not token:
        print("  FAILED to obtain a token. Check the client id/secret, that the app "
              "is enabled for Product Information V4, and sandbox-vs-production.")
        return 1
    kv("token acquired", f"{token[:10]}… (len {len(token)})")

    # Build the keyword the adapter would use, or take an explicit --keywords.
    query_spec = _spec_from_args(args)
    keyword = args.keywords or digikey._build_keyword(query_spec)
    rule("DigiKey — keyword search")
    kv("keyword", repr(keyword))
    kv("limit", args.limit)

    headers = _digikey_headers(token, cid)
    body = digikey._call(
        "POST", f"{digikey._host()}/products/v4/search/keyword",
        headers=headers,
        json_body={"Keywords": keyword, "Limit": args.limit, "Offset": 0})
    if not isinstance(body, dict):
        print("  search returned no JSON body — see log lines above for the status.")
        return 1

    products = digikey._first(body, "Products", "products", default=[]) or []
    kv("top-level response keys", ", ".join(sorted(body.keys()))[:200])
    kv("products returned", len(products))
    if not products:
        print("  No products. Try a broader --keywords, or --sandbox (sandbox data is sparse).")
        return 0

    rule("DigiKey — RAW product[0] (verify these field names!)")
    print(json.dumps(products[0], indent=2, ensure_ascii=False)[:4000])

    rule("DigiKey — MAPPED specs (what the adapter extracts)")
    param_names = {}
    for i, p in enumerate(products):
        cand = digikey._to_candidate(p, query_spec.get("category"))
        print(f"\n  [{i}] {cand['title'][:60]}")
        kv("    url", cand["url"][:90])
        kv("    _specs", json.dumps(cand["_specs"], ensure_ascii=False))
        for par in (digikey._first(p, "Parameters", "parameters", default=[]) or []):
            name = digikey._param_text(par)
            if name:
                param_names.setdefault(name, digikey._param_value(par))

    rule("DigiKey — parameter names seen (extend _PARAM_MAP for the unmapped ones)")
    mapped = {needle for needle, _ in digikey._PARAM_MAP}
    for name in sorted(param_names):
        hit = next((k for (needle, (k, _)) in
                    ((n, m) for n, m in digikey._PARAM_MAP) if needle in name), None)
        flag = f"-> {hit}" if hit else "(unmapped)"
        print(f"  {name:<34} {flag:<18} e.g. {str(param_names[name])[:30]!r}")
    print("\n  To map an unmapped parameter, add a (substring, (schema_key, parser)) "
          "row to _PARAM_MAP in rfparts/sources/digikey.py.")
    return 0


# =========================================================================
# SearXNG web fallback
# =========================================================================
def _spec_from_args(args):
    s = {}
    cat = getattr(args, "category", None)
    if cat:
        s["category"] = specmod._canon_category(cat)
    freq = getattr(args, "freq", None)
    if freq:
        rng = specmod._parse_range(freq)
        if rng:
            s["freq_ghz"] = rng
    imp = getattr(args, "impedance", None)
    if imp:
        z = specmod._parse_impedance(imp)
        if z is not None:
            s["impedance_ohm"] = z
    other = getattr(args, "other", None)
    if other:
        s["other"] = other
    return s


def cmd_websearch(args):
    fetch.VERBOSE = True
    base = (args.url or os.environ.get("RFPARTS_SEARXNG_URL")
            or websearch.DEFAULT_SEARXNG).rstrip("/")

    rule("SearXNG — connectivity + JSON format check")
    kv("base url", base)
    probe = f"{base}/search?q=rf+attenuator&format=json"
    try:
        r = requests.get(probe, headers={"User-Agent": fetch.UA,
                                         "Accept": "application/json"}, timeout=15)
        kv("HTTP status", r.status_code)
        kv("content-type", r.headers.get("Content-Type", "?"))
        try:
            payload = r.json()
            n = len(payload.get("results", []) or []) if isinstance(payload, dict) else 0
            kv("JSON parsed", f"yes ({n} raw results)")
            if n == 0:
                print("  Reachable but 0 results — check that engines are enabled and "
                      "that 'json' is in search.formats in your searxng settings.yml.")
        except ValueError:
            print("  Response was NOT JSON. Enable it: add 'json' under "
                  "search.formats in settings.yml and restart SearXNG.")
            return 1
    except requests.RequestException as exc:
        print(f"  UNREACHABLE: {type(exc).__name__}: {exc}")
        print("  Is the instance running? Set --url or RFPARTS_SEARXNG_URL.")
        return 1

    spec = _spec_from_args(args)
    rule("SearXNG — query variants the fallback will run")
    variants = websearch._query_variants(spec, args.query)
    if not variants:
        print("  No query could be built — pass --query or --category.")
        return 1
    for q, is_snp in variants:
        kv("snp-focused" if is_snp else "main", repr(q))

    if args.raw:
        rule("SearXNG — RAW results for the first variant")
        rows = websearch.SearxngBackend(base_url=base).search(variants[0][0], n=args.limit)
        print(json.dumps(rows, indent=2, ensure_ascii=False)[:3000])

    rule("SearXNG — fallback output (trust-ranked, deduped, sNp-flagged)")
    backend = websearch.SearxngBackend(base_url=base)
    web = websearch.web_fallback(spec, backend=backend, query=args.query, limit=args.limit)
    kv("links returned", len(web))
    for c in web:
        tag = " [sNp]" if c.get("snp") else ""
        print(f"  score {c['score']:>2}  {c['source']:<24}{tag}")
        print(f"            {c['title'][:66]}")
        print(f"            {c['url']}")

    rule("SearXNG — domain trust table (edit to tailor ranking)")
    for dom, score in sorted(websearch._TRUST.items(), key=lambda kv: -kv[1]):
        print(f"  {score:>2}  {dom}")
    print("\n  Tailor ranking by editing _RF_MANUFACTURERS / _DISTRIBUTORS / "
          "_AGGREGATORS (and _TRUST) in rfparts/websearch.py. Add query terms or a "
          "site: bias in _query_variants() to steer results.")
    return 0


def build_parser():
    p = argparse.ArgumentParser(
        prog="debug_sources",
        description="Read-only probes for the DigiKey API and SearXNG web fallback.")
    sub = p.add_subparsers(dest="cmd", required=True)

    d = sub.add_parser("digikey", help="probe the DigiKey Product Information V4 API")
    d.add_argument("--keywords", help="explicit search keywords (else built from spec args)")
    d.add_argument("--category", help="canonical category, e.g. switch, attenuator")
    d.add_argument("--impedance", help="impedance in ohms, e.g. 50")
    d.add_argument("--other", nargs="+", help="extra keyword terms")
    d.add_argument("--limit", type=int, default=5, help="products to request (default 5)")
    d.add_argument("--sandbox", action="store_true", help="use the DigiKey sandbox host")
    d.set_defaults(func=cmd_digikey)

    w = sub.add_parser("websearch", help="probe SearXNG and tune the web fallback")
    w.add_argument("--url", help="SearXNG base url (else RFPARTS_SEARXNG_URL)")
    w.add_argument("--query", help="explicit free-text query (else built from spec args)")
    w.add_argument("--category", help="canonical category, e.g. phase_shifter")
    w.add_argument("--freq", help="passband in GHz, e.g. 2-8 or DC-18")
    w.add_argument("--impedance", help="impedance in ohms, e.g. 50")
    w.add_argument("--other", nargs="+", help="extra query terms")
    w.add_argument("--limit", type=int, default=12, help="max links (default 12)")
    w.add_argument("--raw", action="store_true", help="also dump raw SearXNG JSON")
    w.set_defaults(func=cmd_websearch)
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())