"""Recursive search-driven part discovery.

Flow per search:
  spec -> query planner -> SearXNG -> seed frontier -> work frontier:
    listing page  -> push its product links (same registrable domain only)
    product page  -> resolve datasheet PDF -> datasheet.parse_datasheet()
                     (download, mine, DELETE) -> partdb upsert + spacequal
    PDF hit       -> parse directly (part identity mined from the PDF/URL)
    junk          -> mark done, move on

Bounds (all configurable): MAX_DEPTH from a search hit, per-domain page budget,
wall-clock cap. Cross-domain links are never followed — they are only noted, so
recursion can't become a general web crawl. Politeness (robots, rate limits,
honest UA, caching) is inherited from the project's fetch.py when importable.

Search backend is pluggable and pip-only by default:
  1. ddgs (DuckDuckGo, `pip install ddgs`) — zero infrastructure, the default.
  2. SearXNG — used automatically instead when RFPARTS_SEARXNG_URL is set to a
     reachable instance (kept for anyone who later gets Docker approved).
Backend failures degrade to an empty hit list, never an exception; a warm
partdb still answers from previously mined parts.

This module is the v2 replacement for websearch.py's link-only fallback:
search hits are mined instead of merely listed.
"""
from __future__ import annotations

import os
import re
import time
from dataclasses import dataclass, field
from urllib.parse import urljoin, urlparse, quote_plus

import requests
from bs4 import BeautifulSoup

from . import netfix  # noqa: F401  (process-global TLS fix, import first)
from . import datasheet, erf, partdb, seeds, spacequal
from .partdb import SpecRow

try:
    from . import fetch as _fetch
except ImportError:
    _fetch = None

try:
    from .registry import CATEGORY_SYNONYMS
except ImportError:
    CATEGORY_SYNONYMS = {}

SEARXNG_URL = os.environ.get("RFPARTS_SEARXNG_URL", "")   # empty = use ddgs

SEARCH_MAX_RESULTS = int(os.environ.get("RFPARTS_SEARCH_RESULTS", 20))

SEARCH_PAUSE = float(os.environ.get("RFPARTS_SEARCH_PAUSE", 2.0))

UA = {"User-Agent": "rfparts/2.0 (component sourcing; contact: set-me)"}

MAX_DEPTH = int(os.environ.get("RFPARTS_MAX_DEPTH", 3))

DOMAIN_BUDGET = int(os.environ.get("RFPARTS_DOMAIN_BUDGET", 25))

RUN_SECONDS = int(os.environ.get("RFPARTS_RUN_SECONDS", 300))

MAX_QUERIES = 8

# Domain trust (superset of websearch.py's tables). Higher seeds higher priority.
_TRUST = {}
for _d in ("minicircuits.com", "analog.com", "qorvo.com", "macom.com",
           "markimicrowave.com", "psemi.com", "custommmic.com", "narda-miteq.com",
           "krytar.com", "ditom.com", "lownoisefactory.com", "pasternack.com",
           "fairviewmicrowave.com", "jfwindustries.com", "svmicrowave.com",
           "rlcelectronics.com", "apitech.com", "smithsinterconnect.com",
           "teledynedefense.com", "cobham.com", "qpirad.com", "vptpower.com",
           "xma-corp.com", "atceramics.com", "knowlescapacitors.com"):
    _TRUST[_d] = 5
for _d in ("satnow.com", "everythingrf.com"):
    _TRUST[_d] = 3
for _d in ("digikey.com", "mouser.com", "richardsonrfpd.com", "rfmw.com"):
    _TRUST[_d] = 2

_JUNK_PATH = re.compile(
    r"/(?:news|blog|careers?|about|press|events?|privacy|legal|terms|"
    r"login|cart|account|contact)(?:/|$)|\.(?:jpg|png|gif|svg|css|js|zip)$", re.I)

_GOOD_PATH = re.compile(
    r"/(?:products?|parts?|models?|series|catalog|store|component)s?/|"
    r"\.pdf$|datasheet|dashboard\.html", re.I)

_PN_LIKE = re.compile(r"\b[A-Z]{1,6}[-_]?\d{2,6}[A-Z0-9\-+/]*\b")

# Case-insensitive variant for URL paths and page headings: vendors write
# lowercase part numbers in URLs (marki: /amplifiers/amm-7200uc-k/), and the
# uppercase-only pattern silently failed on all of them.
_PN_LIKE_I = re.compile(r"\b[A-Za-z]{1,6}[-_]?\d{2,6}[A-Za-z0-9\-+/]*\b")

DEBUG = os.environ.get("RFPARTS_DEBUG", "") not in ("", "0")


def _dbg(msg):
    if DEBUG:
        print(f"[crawl] {msg}")

_SPACE_TERMS = ["space qualified", "QML class K", "MIL-PRF-38534 class K",
                "hi-rel", "rad hard"]

# URL path tokens per category, for keeping a shared persistent frontier from
# feeding one category's crawl with another category's pages (an amplifier
# search was popping /filters/ URLs queued by earlier nav-link expansion).
_CATEGORY_URL_TOKENS = {
    "amplifier": ("amplifier", "/lna", "gain-block"),
    "filter": ("filter", "diplexer", "multiplexer"),
    "mixer": ("mixer",),
    "attenuator": ("attenuator",),
    "coupler": ("coupler", "quad-hybrid"),
    "divider": ("divider", "splitter", "combiner"),
    "switch": ("switch",),
    "oscillator": ("oscillator",),
    "limiter": ("limiter",),
    "isolator": ("isolator",),
    "circulator": ("circulator",),
    "phase_shifter": ("phase-shifter", "phase_shifter"),
    "termination": ("termination", "/load"),
    "equalizer": ("equalizer",),
    "multiplier": ("multiplier", "doubler", "tripler"),
    "balun": ("balun",),
    "bias_tee": ("bias-tee", "bias_tee", "dc-block"),
    "detector": ("detector",),
    "inverter": ("inverter",),
}


# Page-content category words: when the URL carries no category token (Qorvo
# /products/p/QPK1521), the page itself must vote. "no vote" means category
# UNKNOWN — never default to the search's category, which turned every Qorvo
# attenuator and every SATNow satellite bus into an "amplifier".
_PAGE_CATEGORY_WORDS = {
    "amplifier": ("amplifier", "lna", "low noise amp", "gain block", "power amp"),
    "attenuator": ("attenuator",),
    "filter": ("bandpass filter", "lowpass filter", "highpass filter",
               "band pass", "low pass", "high pass", "diplexer", "filter"),
    "mixer": ("mixer",),
    "coupler": ("coupler", "quad hybrid", "hybrid coupler"),
    "divider": ("power divider", "splitter", "combiner"),
    "switch": ("switch",),
    "oscillator": ("oscillator", "vco", "pll"),
    "limiter": ("limiter",),
    "phase_shifter": ("phase shifter",),
    "bias_tee": ("bias tee", "dc block"),
    "balun": ("balun",),
    "detector": ("detector",),
    "multiplier": ("multiplier", "frequency doubler"),
    "circulator": ("circulator", "isolator"),
    # Non-component pages that must never enter the parts table as RF parts:
    "_not_a_component": ("satellite bus", "satellite platform", "thruster",
                         "star tracker", "sun sensor", "reaction wheel",
                         "flight computer", "solar array", "ground station",
                         "propulsion system", "complete satellite"),
}


def _category_from_page(title, head, text):
    """Vote on a category from page words. Returns (category|None, hits).

    Title/heading words weigh 5x and body occurrences cap at 2 per word:
    vendor nav sidebars repeat every category name ("Couplers" appeared ~10x
    on Marki multiplier pages and outvoted the title's own "4F Multiplier",
    mis-filing the whole MMD doubler line as couplers).
    """
    strong = f"{title} {head}".lower()
    body = text[:2500].lower()
    best, best_hits = None, 0
    for cat, words in _PAGE_CATEGORY_WORDS.items():
        hits = sum(5 for w in words if w in strong)
        hits += sum(min(body.count(w), 2) for w in words)
        if hits > best_hits:
            best, best_hits = cat, hits
    return best, best_hits


def _off_category_tokens(category):
    """Tokens that mark a URL as belonging to a DIFFERENT category. A URL that
    also names the current category is never excluded by these."""
    if not category or category not in _CATEGORY_URL_TOKENS:
        return ()
    mine = _CATEGORY_URL_TOKENS[category]
    out = []
    for cat, toks in _CATEGORY_URL_TOKENS.items():
        if cat != category:
            out.extend(t for t in toks if t not in mine)
    return tuple(out)


# Links never worth crawling for ANY component search: consumer/infra
# verticals and non-component product families (the Qorvo nav pushed wifi,
# power-management, motor-control, transformer pages into an amplifier crawl).
_IRRELEVANT = ("wifi", "wireless-connectivity", "internet-of-things", "-iot",
               "power-management", "power-solutions", "battery", "motor-control",
               "power-loss-protection", "esd-protection", "transformers",
               "automotive", "/mobile", "infrastructure", "touch-sensors")


def _url_names_current(url, category):
    toks = _CATEGORY_URL_TOKENS.get(category or "", ())
    low = url.lower()
    return any(t in low for t in toks)


# --------------------------------------------------------------------------
# Query planner
# --------------------------------------------------------------------------

def plan_queries(spec):
    """Requirement spec dict -> ordered search query strings (<= MAX_QUERIES)."""
    cat = spec.get("category", "")
    syns = list(CATEGORY_SYNONYMS.get(cat, [cat])) or [cat]
    base = syns[0]

    frag = []
    fg = spec.get("freq_ghz")
    if fg:
        lo, hi = fg
        frag.append(("DC" if lo == 0 else f"{lo:g}") + f"-{hi:g} GHz")
    if spec.get("nf_db_max") is not None:
        frag.append(f"noise figure {spec['nf_db_max']:g} dB")
    if spec.get("gain_db_min") is not None:
        frag.append(f"gain {spec['gain_db_min']:g} dB")
    if spec.get("attenuation_db") is not None:
        frag.append(f"{spec['attenuation_db']:g} dB")
    if spec.get("connector"):
        frag.append(spec["connector"])
    spec_text = " ".join(frag[:3])

    queries = [f"{base} {spec_text}".strip()]
    for syn in syns[1:2]:
        queries.append(f"{syn} {spec_text}".strip())
    queries.append(f"{base} {spec_text} datasheet filetype:pdf".strip())
    if spec.get("space"):
        for term in _SPACE_TERMS[:3]:
            queries.append(f"{term} {base} {spec_text}".strip())
    for vendor in (spec.get("prefer") or [])[:2]:
        queries.append(f"{base} {spec_text} {vendor}".strip())
    # Dedupe, cap.
    seen, out = set(), []
    for q in queries:
        if q and q not in seen:
            seen.add(q)
            out.append(q)
    return out[:MAX_QUERIES]


# --------------------------------------------------------------------------
# Discovery (SearXNG, same backend as v1)
# --------------------------------------------------------------------------

def _search_searxng(query, timeout=15):
    try:
        r = requests.get(
            f"{SEARXNG_URL}/search",
            params={"q": query, "format": "json"},
            headers=UA, timeout=timeout)
        r.raise_for_status()
        return [(h.get("url", ""), h.get("title", ""), h.get("content", ""))
                for h in r.json().get("results", [])]
    except (requests.RequestException, ValueError):
        return []


def search(query):
    """One web query -> [(url, title, snippet)].

    Only SearXNG remains as a true search backend (used when
    RFPARTS_SEARXNG_URL is set). With no backend configured this returns [] and
    discovery comes from seeds.seed_frontier() — vendor sitemaps — instead.
    (ddgs was dropped: its `primp` dependency is a browser-impersonation
    client, i.e. the anti-bot evasion this project's design rules out, and
    corporate security blocks the wheel anyway.)"""
    if not SEARXNG_URL:
        return []
    hits = _search_searxng(query)
    time.sleep(SEARCH_PAUSE)
    return hits


searx = search        # back-compat alias for anything importing the old name


def _domain(url):
    host = (urlparse(url).hostname or "").lower()
    # crude registrable-domain: last two labels (good enough for vendor sites)
    parts = host.split(".")
    return ".".join(parts[-2:]) if len(parts) >= 2 else host


def _url_priority(url, title="", depth=0):
    d = _domain(url)
    p = 0.0
    for known, trust in _TRUST.items():
        if known in d:
            p += trust
            break
    path = urlparse(url).path
    if _GOOD_PATH.search(url):
        p += 3
    if _JUNK_PATH.search(url):
        p -= 6
    if _PN_LIKE.search(path) or _PN_LIKE.search(title or ""):
        p += 2
    p -= depth * 1.5
    return p


# --------------------------------------------------------------------------
# Page fetch + classification
# --------------------------------------------------------------------------

def _get(url, timeout=20):
    """(body_bytes, content_type) via the project's polite fetcher when present."""
    if _fetch is not None and hasattr(_fetch, "get_bytes"):
        try:
            body = _fetch.get_bytes(url)
            ctype = "application/pdf" if url.lower().endswith(".pdf") else "text/html"
            return body or b"", ctype
        except Exception:
            return b"", ""
    try:
        r = requests.get(url, headers=UA, timeout=timeout)
        r.raise_for_status()
        return r.content, r.headers.get("Content-Type", "")
    except requests.RequestException:
        return b"", ""


_SPACE_CATALOG = re.compile(
    r"space[-\s]?(?:qualified|grade|rated)\s*(?:rf\s*)?"
    r"(?:products?|parts?|components?|catalog|amplifiers?|switches|filters)|"
    r"hi[-\s]?rel\s*(?:products?|catalog|component)", re.I)


def classify_page(url, body, ctype):
    """-> 'pdf' | 'listing' | 'product' | 'junk'.

    Product-first: a part number in the title, first heading, or last URL
    segment marks a product page NO MATTER how many links surround it. The old
    link-count-first rule misclassified every Marki product page as a listing,
    because their nav menu alone carries dozens of /products/ links — the crawl
    visited real product pages and ingested none of them.
    """
    if "pdf" in (ctype or "").lower() or body[:5] == b"%PDF-":
        return "pdf"
    if not body:
        return "junk"
    # Per-part sub-pages (Marki's /datasheet/ and /materials-compliance/
    # wrappers) are handled by resolve_datasheet from the REAL product page —
    # classified alone they ingest as duplicate products whose description is
    # a bare MPN, overwriting the real record.
    path = urlparse(url).path.rstrip("/")
    if path.endswith(("/datasheet", "/materials-compliance", "/s-parameters",
                      "/environmental-ratings")):
        return "junk"
    soup = BeautifulSoup(body, "html.parser")
    title = (soup.title.get_text(" ", strip=True) if soup.title else "")
    h1 = soup.find(["h1", "h2"])
    head = h1.get_text(" ", strip=True) if h1 else ""
    tail = urlparse(url).path.rstrip("/").rsplit("/", 1)[-1]
    pn_hit = (_PN_LIKE.search(title) or _PN_LIKE.search(head)
              or _PN_LIKE_I.fullmatch(tail))
    links = soup.find_all("a", href=True)
    has_ds_anchor = any("datasheet" in (a.get_text(" ") + a["href"]).lower()
                        for a in links)
    if pn_hit:
        return "product"
    # Aggregator quirk: SATNow part pages are /products/<cat>/<mfr>/<part> with
    # part slugs that can start with digits (100-2-cma-545g1), which the PN
    # patterns don't match. Scoped to satnow.com so MACOM-style numeric
    # category slugs elsewhere aren't misread as products.
    if "satnow.com" in _domain(url) and re.search(
            r"/products?/[^/]+/[^/]+/[^/]+", urlparse(url).path):
        return "product"
    prodlinks = [a for a in links
                 if _GOOD_PATH.search(a["href"]) or _PN_LIKE.search(a.get_text(" "))]
    if len(prodlinks) >= 8:
        return "listing"
    if has_ds_anchor:
        return "product"
    return "junk"


# Compliance/legal/marketing PDFs linked in page footers — never a datasheet.
# MACOM's footer links its Protections-Against-Trafficking statement on every
# product page, and the any-.pdf fallback stamped it as EVERY part's datasheet.
_JUNK_PDF = re.compile(
    r"trafficking|conflict[-\s]?mineral|\breach\b|rohs|certificat|iso[-_\s]?9001|"
    r"privacy|terms|statement|policy|ppap|quality\s*(?:manual|supply)|warranty|"
    r"brochure|company|counterfeit|"
    # Multi-product catalogs: a catalog PDF covers many parts at low detail
    # and was winning as the "best" fallback when a page had no MPN-named
    # file or /datasheet/ wrapper (Marki's MM_Catalog_... covering an entire
    # product family). A single product's OWN link is virtually always
    # better when one exists.
    r"\bcatalog\b|\bcatalogue\b|full[-\s]?line[-\s]?card|product[-\s]?line[-\s]?card",
    re.I)

# When a catalog PDF is the ONLY pdf-shaped link on the page (no MPN file, no
# /datasheet/ wrapper), it is worth one extra look: a same-domain, product-
# shaped HTML link elsewhere on the SAME page is followed instead of settling
# for the catalog. This is the "go to that product link" case — a catalog
# page or a thin product page sometimes links out to the real per-part page.
def _catalog_fallback_link(url, soup, mpn):
    mpn_n = re.sub(r"[^a-z0-9]", "", (mpn or "").lower())
    best = None
    for a in soup.find_all("a", href=True):
        href = urljoin(url, a["href"]).split("#")[0]
        if href.rstrip("/") == url.rstrip("/"):
            continue
        if _domain(href) != _domain(url):
            continue
        low = href.lower()
        if _JUNK_PDF.search(low) or is_request_form_url(low):
            continue
        if not _GOOD_PATH.search(low):
            continue
        if mpn_n and mpn_n in re.sub(r"[^a-z0-9]", "", low):
            return href                     # exact part match: take it
        best = best or href
    return best


def is_request_form_url(url):
    try:
        from .seeds import is_request_form
        return is_request_form(url)
    except Exception:
        return False


def find_datasheet_url(url, body, mpn=""):
    """Best datasheet target on a page: a .pdf link, an embedded PDF viewer
    frame, or a link whose text says 'datasheet' even without a .pdf ending
    (vendors like Marki serve /datasheet/ HTML wrappers around the PDF)."""
    soup = BeautifulSoup(body, "html.parser")
    best = wrapper = mpn_hit = None
    mpn_n = re.sub(r"[^a-z0-9]", "", (mpn or "").lower())
    for a in soup.find_all("a", href=True):
        href = urljoin(url, a["href"])
        label = (a.get_text(" ") + " " + a["href"]).lower()
        if _JUNK_PDF.search(label):
            continue
        if href.lower().split("?")[0].endswith(".pdf"):
            if "datasheet" in label or "data sheet" in label:
                return href
            fname = re.sub(r"[^a-z0-9]", "", href.rsplit("/", 1)[-1].lower())
            if mpn_n and mpn_n in fname:
                mpn_hit = mpn_hit or href     # filename carries the part number
            best = best or href
        elif "datasheet" in label and _domain(href) == _domain(url):
            wrapper = wrapper or href
    for tag in soup.find_all(("iframe", "embed", "object")):
        src = tag.get("src") or tag.get("data") or ""
        if ".pdf" in src.lower():
            return urljoin(url, src)
    # Precedence: MPN-named PDF > per-part /datasheet/ wrapper > any other PDF.
    # (An unlabeled generic .pdf ranks last: on Marki it's the 100+-page
    # catalog, on MACOM it was a footer compliance statement before the junk
    # filter above.)
    return mpn_hit or wrapper or best


def resolve_datasheet(url, body, mpn=""):
    """find_datasheet_url + one extra hop: when the found target is an HTML
    wrapper page, fetch it and pull the real .pdf out of it. When the ONLY
    pdf-shaped thing on the page is a catalog (now rejected by _JUNK_PDF),
    try one same-domain product-shaped HTML link before giving up."""
    target = find_datasheet_url(url, body, mpn)
    if not target:
        soup = BeautifulSoup(body, "html.parser")
        alt = _catalog_fallback_link(url, soup, mpn)
        if alt:
            _dbg(f"catalog avoided, following product link instead: {alt}")
            abody, actype = _get(alt)
            if abody:
                inner = find_datasheet_url(alt, abody, mpn)
                if inner:
                    return inner
        return None
    if target.lower().split("?")[0].endswith(".pdf"):
        return target
    wbody, wtype = _get(target)
    if not wbody:
        return None
    if "pdf" in (wtype or "").lower() or wbody[:5] == b"%PDF-":
        return target                       # wrapper URL serves the PDF itself
    inner = find_datasheet_url(target, wbody, mpn)
    if inner and inner.lower().split("?")[0].endswith(".pdf"):
        return inner
    return None


# MPN patterns, tried in order of specificity:
#  1. letter-prefixed with optional letter-dash-letter groups: ERZ-LNA-0100,
#     AMM-7200UC-K, TDLNA002093SEP (the old single-group pattern truncated
#     ERZ-LNA-0100 to LNA-0100)
#  2. letter+digit core with numeric tail: RL1-107128 (MITEQ/legacy L3Harris
#     style, which previously extracted nothing at all)
_PN_PATTERNS = [
    re.compile(r"\b[A-Z]{1,6}(?:-[A-Z]{1,4})?-?\d{2,6}[A-Z0-9\-+/]*\b"),
    re.compile(r"\b[A-Z]{1,4}\d{1,4}-\d{3,7}[A-Z0-9\-]*\b"),
]


def _find_mpn(text):
    best = ""
    for pat in _PN_PATTERNS:
        m = pat.search(text or "")
        if m and len(m.group(0)) > len(best):
            best = m.group(0)
    return best


# Domain -> display name, so crawled parts show "MACOM" not "macom". Anything
# absent falls back to a title-cased domain label.
_VENDOR_DISPLAY = {
    "macom.com": "MACOM", "qorvo.com": "Qorvo", "analog.com": "Analog Devices",
    "psemi.com": "pSemi", "narda-miteq.com": "Narda-MITEQ",
    "nardamiteq.com": "Narda-MITEQ", "apitech.com": "API Technologies",
    "smithsinterconnect.com": "Smiths Interconnect",
    "frontgrade.com": "Frontgrade (CAES)", "erzia.com": "ERZIA",
    "micross.com": "Micross", "craneae.com": "Crane Aerospace",
    "teledynedefenseelectronics.com": "Teledyne Defense Electronics",
    "markimicrowave.com": "Marki Microwave", "minicircuits.com": "Mini-Circuits",
    "pasternack.com": "Pasternack", "fairviewmicrowave.com": "Fairview Microwave",
    "jfwindustries.com": "JFW Industries", "krytar.com": "Krytar",
    "ditom.com": "DiTom Microwave", "lownoisefactory.com": "Low Noise Factory",
    "xma-corp.com": "XMA", "xmacorp.com": "XMA",
    "rlcelectronics.com": "RLC Electronics", "svmicrowave.com": "SV Microwave",
    "satnow.com": "SATNow", "everythingrf.com": "everythingRF",
}

# Aggregator product URLs carry the MANUFACTURER as a path segment:
#   satnow.com/products/<category>/<manufacturer>/<ids>-<part>
# The manufacturer is the real vendor; the aggregator is where we found it.
_AGGREGATORS = {"satnow.com": "SATNow", "everythingrf.com": "everythingRF"}


def _mfr_from_aggregator_url(url):
    """'…/products/microwave-rf-amplifiers/marki-microwave/100-1723-amm-9024ch'
    -> 'Marki Microwave'. None when the URL isn't shaped like that."""
    segs = [x for x in urlparse(url).path.strip("/").split("/") if x]
    if len(segs) >= 4 and segs[0].lower() in ("products", "product"):
        slug = segs[-2]
        if slug and not re.fullmatch(r"[\d\-]+", slug):
            words = [w for w in re.split(r"[-_]+", slug) if w]
            # keep known acronyms upper, title-case the rest
            out = []
            for w in words:
                out.append(w.upper() if w.lower() in
                           ("rf", "hq", "llc", "inc", "usa", "uk", "ums", "cml",
                            "e2v", "mmic", "gmbh") else w.capitalize())
            return " ".join(out)
    return None


def vendor_label(url, mfr=None):
    """Display vendor for a part. On aggregators: 'Manufacturer (SATNow)'."""
    dom = _domain(url)
    agg = _AGGREGATORS.get(dom)
    if agg:
        name = mfr or _mfr_from_aggregator_url(url)
        return f"{name} ({agg})" if name else agg
    return _VENDOR_DISPLAY.get(dom, dom.split(".")[0].title())


def _part_identity(url, body):
    """(mpn, vendor, description) mined from a product page. Prefers the
    uppercase PN in the heading; falls back to the (lowercase) URL tail,
    uppercased — vendors print AMM-7200UC-K but link amm-7200uc-k."""
    soup = BeautifulSoup(body, "html.parser")
    title = (soup.title.get_text(" ", strip=True) if soup.title else "")
    h1 = soup.find(["h1", "h2"])
    head = h1.get_text(" ", strip=True) if h1 else title
    mpn = _find_mpn(head) or _find_mpn(title)
    if not mpn:
        tail = urlparse(url).path.rstrip("/").rsplit("/", 1)[-1]
        if _PN_LIKE_I.fullmatch(tail) or _find_mpn(tail.upper()):
            mpn = tail.upper()
    vendor = vendor_label(url)
    return mpn, vendor, (head or title)[:200]


# --------------------------------------------------------------------------
# Crawl run
# --------------------------------------------------------------------------

@dataclass
class CrawlStats:
    pages: int = 0
    datasheets: int = 0
    parts: int = 0
    errors: int = 0
    started: float = field(default_factory=time.time)


def _harvest_erf(url, body, category, spec, on_part=None):
    """Ingest every part on an everythingRF listing page. Returns # ingested.

    Specs, manufacturer, and the manufacturer's own product URL all come from
    the listing card. Space qualification comes from the card's "Industry
    Application" field (a structured value), not from prose.
    """
    try:
        items = erf.parse_listing(
            body.decode("utf-8", "replace") if isinstance(body, bytes) else body,
            url)
    except Exception as e:
        _dbg(f"erf parse FAILED: {type(e).__name__}: {e}")
        return 0
    _dbg(f"erf listing: {len(items)} card(s) parsed from {url}")
    want_space = bool(spec.get("space"))
    n = 0
    for it in items:
        if want_space and not it["space_application"]:
            continue                      # space-only mode: skip COTS entries
        if erf.is_request_form(it["url"]):
            continue
        vendor_disp = (f'{it["vendor"]} (everythingRF)' if it["vendor"]
                       else "everythingRF")
        part_id = partdb.upsert_part(
            mpn=it["mpn"], vendor=vendor_disp, category=category or "",
            product_url=it["url"], description=it["description"] or it["title"])
        if it["spec_rows"]:
            partdb.put_specs(part_id, it["spec_rows"])
        if it.get("vendor_url"):
            partdb.put_specs(part_id, [SpecRow(
                key="vendor_url", value_text=it["vendor_url"], method="aggregator",
                confidence=0.8, source_url=it["url"])])
        ev = []
        tier = None
        if it["space_application"]:
            ev.append(("erf-space-application", 8.0, it["url"],
                       "everythingRF Industry Application includes Space"))
            tier = "qualified"
        if partdb.mpn_in_satnow(it["mpn"]):
            ev.append(("satnow-cross-listed", 8.0, it["url"],
                       "same MPN listed in SATNow space database"))
            tier = "qualified"
        if tier:
            partdb.put_specs(part_id, [SpecRow(
                key="space", value_text=tier, method="evidence", confidence=0.85,
                source_url=it["url"],
                snippet="; ".join(e[3] for e in ev)[:200])])
            partdb.put_evidence(part_id, ev)
        partdb.apply_satnow_crosslink(it["mpn"], it["url"])
        n += 1
        if on_part:
            on_part(part_id, it["mpn"], it["vendor"])
    return n


def _ingest_product(url, body, category, on_part=None,
                    extra_space_evidence=None, require_space=False):
    """Product page -> datasheet pipeline -> partdb. Returns part_id or None."""
    mpn, vendor, desc = _part_identity(url, body)
    if not mpn:
        _dbg(f"product page but no MPN found: {url}")
        return None
    # Evaluation boards are not the component: EVB-AKA-1400P used to strip to
    # AKA-1400P and overwrite the actual amplifier's record.
    if "/evaluation-board/" in url.lower() or mpn.upper().startswith(
            ("EVB-", "EVAL", "EV-KIT", "DEMO-")):
        _dbg(f"skip evaluation board: {mpn} {url}")
        return None
    page_text = BeautifulSoup(body, "html.parser").get_text(" ", strip=True)
    # Category resolution, most-trusted first: URL token, then page-content
    # vote, then UNKNOWN (''). The search's category is only accepted when the
    # page actually mentions it — the old fallback stamped whatever the user
    # happened to be searching onto every category-less product page.
    url_cat = None
    low = url.lower()
    for cat, toks in _CATEGORY_URL_TOKENS.items():
        if any(t in low for t in toks):
            url_cat = cat
            break
    _t = BeautifulSoup(body, "html.parser")
    _title = _t.title.get_text(" ", strip=True) if _t.title else ""
    page_cat, hits = _category_from_page(_title, desc, page_text)
    if page_cat == "_not_a_component" and not url_cat:
        _dbg(f"skip non-component page ({hits} system-level words): {url}")
        return None
    final_cat = url_cat or (page_cat if page_cat != "_not_a_component" else None)
    if not final_cat and category:
        # accept the search category only on page evidence
        words = _PAGE_CATEGORY_WORDS.get(category, (category,))
        if any(w in f"{desc} {page_text[:2000]}".lower() for w in words):
            final_cat = category
    if final_cat != category:
        _dbg(f"category: {mpn} -> {final_cat or 'UNKNOWN'} "
             f"(searching {category}; url={bool(url_cat)}, page_hits={hits})")
    part_id = partdb.upsert_part(mpn=mpn, vendor=vendor,
                                 category=final_cat or "",
                                 product_url=url, description=desc)

    # Surface the part to the GUI the moment identity + page specs exist —
    # BEFORE the datasheet fetch, which can take 10-20s on a slow PDF. The GUI
    # updates the same row in place when the richer specs land below.
    early_rows = datasheet.rows_from_page_text(page_text, url)
    if early_rows:
        partdb.put_specs(part_id, early_rows)
    if on_part:
        on_part(part_id, mpn, vendor)

    rows, ds_text = [], ""
    ds_url = resolve_datasheet(url, body, mpn)
    _dbg(f"product {mpn}: datasheet -> {ds_url}")
    if ds_url:
        rows, sha, nbytes, pages = datasheet.parse_datasheet(ds_url)
        if sha:
            if partdb.document_seen(sha):
                pass                     # already mined at this parser version
            else:
                partdb.put_document(sha, ds_url, part_id, nbytes, pages)
            ds_text = datasheet.datasheet_text_for_qual(ds_url) if not rows else ""
    if rows:
        _dbg(f"product {mpn}: {len(rows)} spec(s) from datasheet")
    if rows:
        partdb.put_specs(part_id, rows)

    qual = spacequal.classify(
        ds_text or "", category=category,
        vendor_facts=partdb.vendor_facts(_domain(url)),
        page_text=page_text, source_url=url)
    # Space-marketplace provenance: a part listed in SATNow's space & satellite
    # database is space-positioned by its own vendor. Strong evidence, recorded
    # as such — the GUI shows the source so an engineer can verify the level.
    if extra_space_evidence:
        qual.evidence.insert(0, extra_space_evidence)
        qual.score += extra_space_evidence[1]
        qual.tier = "qualified"
    if partdb.mpn_in_satnow(mpn) and "satnow.com" not in _domain(url):
        # The part exists in SATNow's space database — qualification follows
        # the PART across sites, not the page it happened to be found on.
        qual.evidence.insert(0, ("satnow-cross-listed", 8.0,
                                 "same MPN listed in SATNow space database"))
        qual.score += 8.0
        qual.tier = "qualified"
    if "satnow.com" in _domain(url):
        qual.evidence.insert(0, ("satnow-space-listing", 8.0,
                                 "listed in SATNow space & satellite parts database"))
        qual.score += 8.0
        partdb.apply_satnow_crosslink(mpn, url)
        # A SATNow listing is a space-marketplace placement by the vendor, so
        # it sets the tier outright rather than only filling a blank. The
        # evidence row names the source, so the engineer still sees WHY and
        # can confirm the actual screening level (K / H / heritage) before
        # anything goes near flight hardware.
        qual.tier = "qualified"
    if qual.tier:
        partdb.put_specs(part_id, [SpecRow(
            key="space", value_text=qual.tier, method="evidence",
            confidence=0.9 if qual.tier != "qualifiable" else 0.6,
            source_url=url, snippet=qual.summary())])
        partdb.put_evidence(part_id, [(s, w, url, sn) for s, w, sn in qual.evidence])
    if qual.variant_hint:
        partdb.put_specs(part_id, [SpecRow(
            key="space_variant", value_text=qual.variant_hint,
            method="evidence", confidence=0.5, source_url=url)])

    if spacequal.looks_like_hirel_program_page(page_text):
        partdb.put_vendor_fact(_domain(url), hirel_program=1)

    # Space-only mode: a part with no qualification evidence at all is not a
    # candidate. It stays in the database (a later non-space search will want
    # it) but is not streamed to the GUI as a space result.
    if require_space and qual.tier is None:
        _dbg(f"space-only: {mpn} has no qualification evidence — not surfaced")
        return None

    # Teach this site's product-URL template so the next seeding pass can pull
    # the whole catalog branch straight out of the sitemap.
    partdb.save_template(_domain(url), seeds.url_template(url))

    if on_part:
        on_part(part_id, mpn, vendor)
    return part_id


def crawl(spec, *, on_part=None, on_progress=None,
          max_depth=MAX_DEPTH, domain_budget=DOMAIN_BUDGET,
          run_seconds=RUN_SECONDS, cancel=None):
    """Run one bounded recursive search for a requirement spec.

    on_part(part_id, mpn, vendor): streamed to the GUI as parts land.
    on_progress(stats): periodic progress callback.
    cancel: optional threading.Event — mirrors the GUI's cancel button.
    Returns CrawlStats. Frontier state persists in partdb for warm restarts.
    """
    stats = CrawlStats()
    category = spec.get("category")
    budgets: dict[str, int] = {}
    recent_domains: list[str] = []        # round-robin: avoid repeating a domain
    # Drift detection: fraction of recent pops that name the target category.
    # When it collapses, the crawl is wandering (nav-link soup) and re-seeds
    # itself: aggregator facets re-queued, on-category pending boosted, and —
    # when a search backend is configured — "space qualified <category>"
    # queries fired to inject fresh on-topic URLs.
    drift_window: list[bool] = []
    reseeds_left = 2
    # URLs of listing pages recognized as space-parts catalogs; product pages
    # linked from them inherit space-catalog evidence at ingest.
    space_catalog_children: set = set()
    space_catalog_urls: set = set()
    # Never pop a URL that names a DIFFERENT category than this search; a URL
    # naming the current category is exempt even if it also matches another.
    _off = _off_category_tokens(category)
    _skip_tokens = tuple(_off) if category else ()
    # Space marketplace URLs are only crawled when space qualification is part
    # of the requirement — previously queued satnow rows kept popping in
    # ordinary searches.
    if not spec.get("space"):
        _skip_tokens = _skip_tokens + ("satnow.com",)

    # 1. Seed the frontier: search backend when configured, vendor sitemaps
    # otherwise — but ONLY when the persisted frontier is thin. Sitemap-walking
    # 17 domains through the rate-limited fetch layer takes minutes, and on the
    # first deployment it consumed the entire run_seconds budget before the
    # crawl loop popped a single URL (CrawlStats(pages=0) with 400+ pending).
    # SATNow space-facet seeding is a handful of frontier_push calls with ZERO
    # network cost, so it runs on EVERY space search — the pending-count gate
    # below exists only to avoid re-walking vendor sitemaps, and gating SATNow
    # behind it meant a space search against a full frontier never queued the
    # one source that actually lists space-qualified parts.
    if spec.get("space"):
        n = seeds.seed_satnow(spec) + seeds.seed_everythingrf(spec)
        seeds.mark_space_vendors()
        # Repair pass: product rows queued by pre-inheritance runs sit at
        # priority ~6-7, starved below the vendor bulk. Lift them to 19 so the
        # space parts already discovered actually get crawled.
        boosted = partdb.frontier_boost("satnow.com", "/products/", 19.0)
        if n or boosted:
            _dbg(f"SATNow: {n} listing(s) (re)queued, {boosted} stranded "
                 f"product URL(s) boosted to 19")

    pending = partdb.db().execute(
        "SELECT COUNT(*) FROM frontier WHERE status='pending'").fetchone()[0]
    if pending < 30:
        _dbg("frontier thin -> walking vendor sitemaps (first run after a DB "
             "reset takes 1-3 min; per-domain progress follows)")
        seeded = 0
        if SEARXNG_URL:
            for q in plan_queries(spec):
                for url, title, _snip in search(q):
                    if _JUNK_PATH.search(url):
                        continue
                    dom = _domain(url)
                    budgets.setdefault(dom, domain_budget)
                    if partdb.frontier_push(url, _url_priority(url, title, 0), 0, dom):
                        seeded += 1
        if seeded == 0:
            seeds.seed_frontier(
                spec,
                on_progress=lambda d, total, kept: _dbg(
                    f"  seeded {d}: {total} sitemap URLs, kept {kept}"))

    # Seeding time must not count against the crawl budget: restart the clock.
    stats.started = time.time()

    # 2. Work the frontier.
    while time.time() - stats.started < run_seconds:
        if cancel is not None and cancel.is_set():
            break
        item = partdb.frontier_pop(budgets, default_budget=domain_budget,
                                   avoid_domains=recent_domains[-2:],
                                   skip_url_tokens=_skip_tokens)
        if item is None:
            break
        url, depth, dom = item["url"], item["depth"], item["domain"]
        recent_domains.append(dom)
        del recent_domains[:-4]

        if category:
            drift_window.append(_url_names_current(url, category)
                                or "satnow.com" in dom
                                or "everythingrf.com" in dom)
            if len(drift_window) >= 25:
                on_cat = sum(drift_window) / len(drift_window)
                drift_window.clear()
                if on_cat < 0.30 and reseeds_left > 0:
                    reseeds_left -= 1
                    n = 0
                    if spec.get("space"):
                        n += seeds.seed_satnow(spec)
                        n += seeds.seed_everythingrf(spec)
                    toks = _CATEGORY_URL_TOKENS.get(category, (category,))
                    boosted = partdb.frontier_boost_tokens(toks, delta=4.0)
                    injected = 0
                    if SEARXNG_URL:
                        for q in plan_queries(spec)[:4]:
                            for u, title, _sn in search(q):
                                if not _JUNK_PATH.search(u):
                                    d2 = _domain(u)
                                    budgets.setdefault(d2, domain_budget)
                                    if partdb.frontier_push(
                                            u, _url_priority(u, title, 0), 0, d2):
                                        injected += 1
                    _dbg(f"DRIFT ({on_cat:.0%} on-category): reseeded — "
                         f"{n} aggregator listing(s), {boosted} pending "
                         f"boosted, {injected} search hits injected")
        budgets.setdefault(dom, domain_budget)
        budgets[dom] -= 1

        body, ctype = _get(url)
        stats.pages += 1
        if not body:
            stats.errors += 1
            partdb.frontier_mark(url, "error")
            continue

        # everythingRF filtered listings carry COMPLETE specs for ~20 parts in
        # the listing markup itself, so they are harvested in place rather than
        # expanded into 20 product-page fetches.
        if "everythingrf.com" in dom and "/search/" in url:
            n_new = _harvest_erf(url, body, category, spec, on_part)
            stats.parts += n_new
            stats.pages += 0
            _dbg(f"erf-listing harvested {n_new} part(s) from {url}")
            partdb.frontier_mark(url, "done")
            if on_progress:
                on_progress(stats)
            continue

        kind = classify_page(url, body, ctype)
        _dbg(f"{kind:<8} depth={depth} {url}")
        if kind == "pdf":
            # App notes, catalogs, and misc PDFs are not parts. AN60-040 and a
            # rack-chassis summary sheet were ingested as "amplifiers" here.
            fname = urlparse(url).path.rsplit("/", 1)[-1]
            # Precision matters here: the old pattern's bare 'guide' matched
            # WAVEGUIDE datasheets and bare 'summary' matched Mini-Circuits'
            # legitimate *_Summary_Sheet part documents — real datasheets were
            # being skipped as junk. Word-bounded, phrase-level terms only.
            if re.search(r"/app/|/appnotes?/|(?:^|[\s/_-])AN\d{2}|"
                         r"(?<![a-z])catalog(?![a-z])|user[\s_-]*guide|"
                         r"selection[\s_-]*guide|design[\s_-]*guide|"
                         r"quick[\s_-]*start|primer|(?<![a-z])manual(?![a-z])|"
                         r"brochure", f"{urlparse(url).path} {fname}", re.I):
                _dbg(f"skip non-part pdf: {url}")
                partdb.frontier_mark(url, "skipped")
                continue
            rows, sha, nbytes, pages = datasheet.parse_datasheet(url)
            stats.datasheets += 1
            # Quality gate: a bare PDF only becomes a part when its specs look
            # like a component datasheet (a frequency range, or 2+ mined
            # values) — filename alone proved far too trusting.
            if rows and not (any(r.key == "freq_ghz" for r in rows)
                             or len(rows) >= 2):
                rows = []
            if rows:
                mpn = re.sub(r"\.pdf$", "", fname, flags=re.I)
                m = _find_mpn(mpn.upper())
                mpn = (m or mpn)[:40]
                part_id = partdb.upsert_part(
                    mpn=mpn, vendor=vendor_label(url),
                    category=category or "", product_url=url)
                partdb.put_specs(part_id, rows)
                if sha:
                    partdb.put_document(sha, url, part_id, nbytes, pages)
                stats.parts += 1
                if on_part:
                    on_part(part_id, mpn, _domain(url))
        elif kind == "product":
            try:
                extra = (("space-catalog-listing", 6.0,
                          "linked from a vendor space-parts catalog page")
                         if url in space_catalog_urls else None)
                ok = _ingest_product(url, body, category, on_part,
                                     extra_space_evidence=extra,
                                     require_space=bool(spec.get("space")))
            except Exception as e:
                _dbg(f"ingest error {url}: {type(e).__name__}: {e}")
                ok = None
                stats.errors += 1
            if ok:
                stats.parts += 1
                stats.datasheets += 1
        elif kind == "listing" and depth < max_depth:
            soup = BeautifulSoup(body, "html.parser")
            parent_pri = float(item.get("priority") or 0)
            # SATNow leash: their nav links every space-systems vertical
            # (thrusters, bus platforms, star trackers). On satnow.com, only
            # follow links carrying the seeded category's slug(s) — the fix
            # for whole satellites flooding an amplifier search.
            satnow_slugs = seeds.leash_slugs(dom, category)
            # A listing page that IS a space-parts catalog ("Space Qualified
            # Products", "Hi-Rel Product List") marks every product it links:
            # appearing in a vendor's space-application catalog is itself
            # qualification evidence for the part.
            l_title = (soup.title.get_text(" ", strip=True)
                       if soup.title else "")
            l_h1 = soup.find(["h1", "h2"])
            l_head = l_h1.get_text(" ", strip=True) if l_h1 else ""
            if _SPACE_CATALOG.search(f"{l_title} {l_head}"):
                space_catalog_children.add(url)
                _dbg(f"space-catalog listing: {l_title[:60]!r}")
            # Scan ALL anchors, then push only the best-scored 200. The old
            # first-150 anchor cap truncated inside SATNow's ~100-link nav
            # header — the product grid comes AFTER it in document order, so
            # the 55 product links were never even seen by the expander.
            scored_children = []
            for a in soup.find_all("a", href=True):
                child = urljoin(url, a["href"]).split("#")[0]
                if _domain(child) != dom:      # same-domain recursion only
                    continue
                if _JUNK_PATH.search(child):
                    continue
                # Nav menus link every category; only queue links that name the
                # current category or are category-neutral (product pages etc.).
                low = child.lower()
                if satnow_slugs is not None and not any(
                        sl in low for sl in satnow_slugs):
                    continue
                if any(t in low for t in _IRRELEVANT):
                    continue
                if (_off and any(t in low for t in _off)
                        and not _url_names_current(child, category)):
                    continue
                # Priority inheritance: product links found on a high-priority
                # listing must OUTRANK stale lower-priority frontier bulk, or
                # they starve. Concretely: SATNow space-facet seeds enter at
                # 20, but their product children scored ~6-7 fresh — below the
                # hundreds of priority-11 Marki URLs — so the space parts were
                # queued yet never popped inside a search's crawl window.
                # Children now floor at parent-1 (product-shaped links only).
                pri = _url_priority(child, a.get_text(" "), depth + 1)
                if _GOOD_PATH.search(child):
                    pri = max(pri, parent_pri - 1.0)
                scored_children.append((pri, child))
            scored_children.sort(key=lambda x: -x[0])
            from_space_catalog = url in space_catalog_children
            for pri, child in scored_children[:200]:
                partdb.frontier_push(child, pri, depth + 1, dom)
                if from_space_catalog:
                    space_catalog_urls.add(child)

        partdb.frontier_mark(url, "done")
        if on_progress:
            on_progress(stats)

    return stats
