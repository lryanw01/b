"""Mini-Circuits catalog repair — load-time fix for the positional-scrape damage.

The shipped minicircuits_products_full.json was scraped with positional column
mapping, and Mini-Circuits varies dashboard column layout per product family.
Observed damage in the shipped file (15,939 records):

  1. Filter families (XBF/XHF/XLF, 27 records): the STOPBAND RANGE landed in
     `specs.nf` ("nf": "DC-10000 30000-40000"). catalog.py's _num() then fails
     silently -> "NF isn't being scraped properly".
  2. Adapters (~145 records): every spec shifted one column
     ("f_low": "1.0mm", "f_high": "DC", "vswr": "110", "impedance": "1.07").
  3. Slash values digit-concatenated: "18/24" V -> vcc 1824; "350/480" mA ->
     icc_ma 350480 (37 amplifiers).

Usage — one call in catalog.py right after json.load:

    from .mc_fix import repair_catalog
    records = repair_catalog(json.load(f))

Every repair is value-plausibility-driven, never index-driven, so a partially
fixed future scrape passes through unchanged. Long term the real fix is the v2
datasheet pipeline (header-named table extraction makes positional bugs
structurally impossible); this module just makes the existing JSON sane today.
"""
from __future__ import annotations

import re

_RANGE = re.compile(r"(?:DC|\d+(?:\.\d+)?)\s*-\s*\d+(?:\.\d+)?")

_SLASH = re.compile(r"^\s*(\d+(?:\.\d+)?)\s*/\s*(\d+(?:\.\d+)?)\s*$")

_CONNECTOR = re.compile(
    r"^(?:1\.0|1\.85|2\.4|2\.92|3\.5)\s*mm$|^(?:SMA|N|BNC|TNC|SMP|SMPM|SSMA|"
    r"MCX|MMCX|QMA|4\.?3-?10|7/16|F|UFL|U\.FL)(?:[-\s].*)?$", re.I)

# Model-prefix -> subcategory (from the capture-script taxonomy). Fixes e.g.
# HPA- parts ranking inside LNA searches.
FAMILY_SUBCATEGORY = {
    "HPA": ("amp", "power_amplifier"),
    "ZHL": ("amp", "power_amplifier"),
    "LZY": ("amp", "power_amplifier"),
    "PMA": ("amp", "lna"),
    "PSA": ("amp", "lna"),
    "ZX60": ("amp", "gain_block"),
    "GALI": ("amp", "gain_block"),
    "ERA": ("amp", "gain_block"),
    "XLF": ("flt", "lowpass"),
    "XHF": ("flt", "highpass"),
    "XBF": ("flt", "bandpass"),
    "ZVBP": ("flt", "bandpass"),
}

# Plausibility gates: key -> (lo, hi) inclusive. Values outside are dropped
# (and, where a home exists, re-routed).
PLAUSIBLE = {
    "nf": (0.05, 30.0),          # dB
    "gain": (-90.0, 90.0),       # dB (negative = loss-style entries)
    "vswr": (1.0, 50.0),
    "vcc": (0.5, 60.0),          # V
    "icc_ma": (0.1, 50000.0),    # mA
    "impedance": (10.0, 300.0),  # ohm — 1.07 "impedance" on adapters is VSWR
    "p1db": (-30.0, 70.0),       # dBm
    "oip3": (-20.0, 80.0),       # dBm
}


def _num(v):
    if v is None:
        return None
    try:
        return float(str(v).strip())
    except ValueError:
        return None


def _fix_slash_values(rec, stats):
    """'18/24' -> keep both bounds; expose max for single-number consumers."""
    for key, out_min, out_max in (("vcc", "vcc_min", "vcc"),
                                  ("icc_ma", "icc_ma_min", "icc_ma")):
        raw = None
        specs = rec.get("specs") or {}
        for src in ({"vcc": "voltage", "icc_ma": "current"}[key],):
            raw = specs.get(src)
        m = _SLASH.match(str(raw or ""))
        if m:
            lo, hi = float(m.group(1)), float(m.group(2))
            rec[out_min], rec[out_max] = min(lo, hi), max(lo, hi)
            stats["slash_fixed"] += 1
        else:
            # Undo an existing digit-concatenation when the source shows a slash
            # is impossible to recover from; just gate it below instead.
            pass
    return rec


def _fix_filter_nf(rec, stats):
    """Non-numeric string in nf -> relocate. Filter families put the stopband
    range there (-> stopband_mhz); switch families put other column text there
    (-> nf_raw, kept for forensics). Either way, nf never holds garbage."""
    specs = rec.get("specs") or {}
    nf = specs.get("nf")
    if nf is not None and _num(nf) is None:
        dest = "stopband_mhz" if _RANGE.search(str(nf)) else "nf_raw"
        specs[dest] = str(nf)
        specs.pop("nf", None)
        rec.pop("nf", None)
        stats["nf_relocated"] += 1
    return rec


def _fix_adapter_shift(rec, stats):
    """Adapter records shifted one column: f_low holds a connector, f_high 'DC'.

    Observed layout after the shift (true meaning in parentheses):
        conn_2   = second connector           (correct)
        f_low    = first-connector text       (belongs in conn_1)
        f_high   = 'DC'                       (true f_low)
        vswr     = number in MHz-ish units    (true f_high, MHz)
        impedance= ~1.0-2.0                   (true VSWR)
    """
    specs = rec.get("specs") or {}
    if not (_CONNECTOR.match(str(specs.get("f_low", ""))) and
            str(specs.get("f_high", "")).strip().upper() == "DC"):
        return rec
    conn1 = str(specs.get("f_low"))
    true_fhi = _num(specs.get("vswr"))
    true_vswr = _num(specs.get("impedance"))
    specs["conn_1"] = conn1
    specs["f_low"] = "0"
    rec["flo"] = 0.0
    if true_fhi is not None:
        specs["f_high"] = str(true_fhi)
        rec["fhi"] = true_fhi
    else:
        specs.pop("f_high", None)
        rec.pop("fhi", None)
    if true_vswr is not None and 1.0 <= true_vswr <= 50.0:
        specs["vswr"] = str(true_vswr)
        rec["vswr"] = true_vswr
    else:
        specs.pop("vswr", None)
        rec.pop("vswr", None)
    specs.pop("impedance", None)
    rec.pop("impedance", None)
    stats["adapters_deshifted"] += 1
    return rec


def _gate_implausible(rec, stats):
    """Drop any numeric spec outside its plausibility window (both levels)."""
    specs = rec.get("specs") or {}
    for key, (lo, hi) in PLAUSIBLE.items():
        for container in (rec, specs):
            v = _num(container.get(key))
            if v is not None and not (lo <= v <= hi):
                container.pop(key, None)
                stats["gated"] += 1
    return rec


def _tag_subcategory(rec, stats):
    pn = str(rec.get("pn") or "")
    for prefix, (cat, sub) in FAMILY_SUBCATEGORY.items():
        if pn.upper().startswith(prefix):
            if rec.get("cat") in (None, "", cat):
                rec.setdefault("cat", cat)
                if rec.get("subcat") != sub:
                    rec["subcat"] = sub
                    stats["subcat_tagged"] += 1
            break
    return rec


def repair_catalog(records, verbose=False):
    """Repair a list of Mini-Circuits catalog records in place; returns it.

    Order matters: de-shift first (so gates see the corrected values), then
    relocate filter nf, then slash values, then plausibility gates, then
    subcategory tags.
    """
    stats = {"adapters_deshifted": 0, "nf_relocated": 0, "slash_fixed": 0,
             "gated": 0, "subcat_tagged": 0}
    for rec in records:
        if not isinstance(rec, dict):
            continue
        _fix_adapter_shift(rec, stats)
        _fix_filter_nf(rec, stats)
        _fix_slash_values(rec, stats)
        _gate_implausible(rec, stats)
        _tag_subcategory(rec, stats)
    if verbose:
        print("mc_fix:", ", ".join(f"{k}={v}" for k, v in stats.items()))
    repair_catalog.last_stats = stats
    return records


repair_catalog.last_stats = {}
