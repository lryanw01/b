"""Every on-disk location the pipeline uses, in one place.

Three modules import from here (gui, space_dataset, erf_space_ingest), but this
file was never shipped with the patches that introduced those imports, so a clean
tree died with ModuleNotFoundError before anything ran. It is shipped now.

LAYOUT.  Sources and data live in sibling folders at the top level of the repo,
next to the package rather than inside it, so a `git clean` or a package
reinstall cannot take the database with it:

    <repo root>/
        rfparts/            the package (this file lives here)
        Data/               parts.db, caches, datasheets, exports
        Sources/            inputs you supply
            EverythingRFSpaceQual/
            newSources/
            ADIParametrics/

OVERRIDES.  Every root can be redirected with an environment variable, which is
what makes the whole thing testable without touching a real tree:

    RFPARTS_HOME          -> DATA_ROOT        (default <repo>/Data)
    RFPARTS_SOURCES       -> SOURCES_ROOT     (default <repo>/Sources)
    RFPARTS_EVERYTHINGRF  -> EVERYTHING_RF
    RFPARTS_NEWSOURCES    -> NEW_SOURCES
    RFPARTS_ADI           -> ADI_PARAMETRICS

partdb reads RFPARTS_HOME directly for the same default, so the two agree.
"""
from __future__ import annotations

import os
from pathlib import Path

# <repo root> is the parent of the package directory.
PACKAGE_DIR = Path(__file__).resolve().parent
REPO_ROOT = PACKAGE_DIR.parent


def _root(env_var: str, default: Path) -> Path:
    raw = os.environ.get(env_var, "").strip()
    return Path(raw).expanduser() if raw else default


DATA_ROOT = _root("RFPARTS_HOME", REPO_ROOT / "Data")
SOURCES_ROOT = _root("RFPARTS_SOURCES", REPO_ROOT / "Sources")

# --- data (written by us) ---------------------------------------------------
DB_PATH = DATA_ROOT / "parts.db"
CACHE_DIR = _root("RFPARTS_CACHE", DATA_ROOT / "cache")
VENDOR_CACHE = DATA_ROOT / "vendor_cache"
DATASHEET_DIR = DATA_ROOT / "datasheets"
EXPORT_DIR = DATA_ROOT / "export"
PARSE_DEBUG_DIR = DATA_ROOT / "parse_debug"

# --- sources (supplied by you) ---------------------------------------------
EVERYTHING_RF = _root("RFPARTS_EVERYTHINGRF", SOURCES_ROOT / "EverythingRFSpaceQual")
NEW_SOURCES = _root("RFPARTS_NEWSOURCES", SOURCES_ROOT / "newSources")
# Qorvo parametric tables saved from a browser by rfparts_save_pages.py.
# They must be saved rather than fetched: the tables are built client-side,
# so an HTTP GET returns an app shell with no rows in it.
QORVO_PAGES = SOURCES_ROOT / "QorvoParametric"
ADI_PARAMETRICS = _root("RFPARTS_ADI", SOURCES_ROOT / "ADIParametrics")

_WRITABLE = (DATA_ROOT, CACHE_DIR, VENDOR_CACHE, DATASHEET_DIR, EXPORT_DIR,
             PARSE_DEBUG_DIR)


def ensure_dirs() -> None:
    """Create the directories we write to. Never creates source folders: an
    auto-created empty Sources/EverythingRFSpaceQual would look like a real but
    empty input, and 'ingested 0 parts' is far harder to diagnose than 'folder
    not found'."""
    for d in _WRITABLE:
        try:
            d.mkdir(parents=True, exist_ok=True)
        except OSError:
            pass


def describe() -> str:
    """Human-readable dump of every resolved root, for the log and the GUI."""
    rows = [
        ("repo root", REPO_ROOT, None),
        ("data root", DATA_ROOT, "RFPARTS_HOME"),
        ("  database", DB_PATH, None),
        ("  local cache", CACHE_DIR, "RFPARTS_CACHE"),
        ("  vendor page cache", VENDOR_CACHE, None),
        ("  datasheets", DATASHEET_DIR, None),
        ("  exports", EXPORT_DIR, None),
        ("  parse debug", PARSE_DEBUG_DIR, None),
        ("sources root", SOURCES_ROOT, "RFPARTS_SOURCES"),
        ("  everythingRF", EVERYTHING_RF, "RFPARTS_EVERYTHINGRF"),
        ("  newSources", NEW_SOURCES, "RFPARTS_NEWSOURCES"),
        ("  ADI parametrics", ADI_PARAMETRICS, "RFPARTS_ADI"),
    ]
    out = []
    for label, path, env in rows:
        mark = "exists" if Path(path).exists() else "MISSING"
        via = f"  [{env}]" if env and os.environ.get(env) else ""
        out.append(f"  {label:<20} {mark:<8} {path}{via}")
    return "\n".join(out)


ensure_dirs()
