"""Lightweight, thread-safe timing instrumentation for the extract pipeline.

Purpose: answer "why is extraction slow?" without a profiler. It records how long
each phase takes (HTTP fetch, page parse, datasheet-PDF parse, whole-candidate
extract), tallies per-vendor and per-domain cost, and remembers the slowest
candidates. ``print_summary`` prints a breakdown that usually points straight at
the bottleneck (PDF parsing, per-domain politeness serialization, or sheer
candidate volume).

Output goes to the *real* console (``sys.__stderr__``) so the lines appear in the
PowerShell window even during a GUI run, where ``fetch.LOG_SINK`` is redirected to
the status bar. Lines are also appended to ``DATA/extract_timing.log``.

Enabled by default; set ``RFPARTS_TIMING=0`` to silence entirely. Overhead when
enabled is a few ``perf_counter`` calls per candidate.
"""
import os
import sys
import threading
import time
from collections import defaultdict

from .registry import DATA

ENABLED = os.environ.get("RFPARTS_TIMING", "1") != "0"
LOG_FILE = DATA / "extract_timing.log"

_LOCK = threading.Lock()
_phase_seconds = defaultdict(float)   # phase name -> total seconds
_phase_count = defaultdict(int)       # phase name -> number of calls
_vendor_seconds = defaultdict(float)  # vendor -> total extract seconds
_vendor_count = defaultdict(int)
_domain_requests = defaultdict(int)   # domain -> number of HTTP GETs
_slowest = []                         # [(seconds, label)], top-N kept sorted desc
_SLOW_KEEP = 25


def enabled():
    return ENABLED


def tlog(msg):
    """Print a line to the real console + append to the timing log. No-op when off."""
    if not ENABLED:
        return
    line = f"[{time.strftime('%H:%M:%S')}] {msg}"
    try:
        print(line, file=sys.__stderr__, flush=True)
    except Exception:
        pass
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError:
        pass


def record(phase, seconds, vendor=None, label=None):
    """Record a completed timed span."""
    if not ENABLED:
        return
    with _LOCK:
        _phase_seconds[phase] += seconds
        _phase_count[phase] += 1
        if vendor:
            _vendor_seconds[vendor] += seconds
            _vendor_count[vendor] += 1
        if label is not None:
            _slowest.append((seconds, label))
            _slowest.sort(key=lambda x: x[0], reverse=True)
            del _slowest[_SLOW_KEEP:]


def note_request(domain):
    if not ENABLED or not domain:
        return
    with _LOCK:
        _domain_requests[domain] += 1


def reset():
    with _LOCK:
        _phase_seconds.clear()
        _phase_count.clear()
        _vendor_seconds.clear()
        _vendor_count.clear()
        _domain_requests.clear()
        _slowest.clear()


class span:
    """Context manager: ``with timing.span("pdf_parse", vendor, label): ...``."""

    def __init__(self, phase, vendor=None, label=None):
        self.phase, self.vendor, self.label = phase, vendor, label

    def __enter__(self):
        self.t0 = time.perf_counter()
        return self

    def __exit__(self, *exc):
        record(self.phase, time.perf_counter() - self.t0, self.vendor, self.label)
        return False


def summary_lines(delay=0.5):
    lines = ["", "=================== EXTRACT TIMING SUMMARY ==================="]
    with _LOCK:
        lines.append(f"  RFPARTS_PDF (datasheet parsing): "
                     f"{'ON' if os.environ.get('RFPARTS_PDF', '1') != '0' else 'OFF'}")
        lines.append("  -- time by phase (wall time summed across worker threads) --")
        for phase in sorted(_phase_seconds, key=lambda p: -_phase_seconds[p]):
            n = _phase_count[phase]
            t = _phase_seconds[phase]
            per = f"{t / n * 1000:.0f} ms/call" if n else "-"
            lines.append(f"    {phase:<16} {t:9.1f}s  x{n:<6d} ({per})")
        lines.append("  -- extract time by vendor --")
        for v in sorted(_vendor_seconds, key=lambda x: -_vendor_seconds[x]):
            lines.append(f"    {v:<24} {_vendor_seconds[v]:9.1f}s  {_vendor_count[v]} parts")
        if _domain_requests:
            lines.append("  -- HTTP requests per domain (politeness forces >= delay apart PER DOMAIN) --")
            for dom in sorted(_domain_requests, key=lambda x: -_domain_requests[x]):
                n = _domain_requests[dom]
                lines.append(f"    {dom:<30} {n:5d} req  ~{n * delay:7.1f}s min, serialized @ {delay}s/req")
        if _slowest:
            lines.append("  -- slowest individual candidates --")
            for s, lbl in _slowest[:15]:
                lines.append(f"    {s:8.2f}s  {lbl}")
    # A one-line interpretation of the dominant cost.
    with _LOCK:
        pdf = _phase_seconds.get("pdf_total", 0.0)
        http = _phase_seconds.get("http_fetch", 0.0)
        max_dom = max(_domain_requests.values(), default=0) * delay
    culprit = max(("datasheet PDF parsing", pdf),
                  ("network fetches", http),
                  ("per-domain politeness delay", max_dom),
                  key=lambda kv: kv[1])
    lines.append(f"  >> dominant cost looks like: {culprit[0]} (~{culprit[1]:.0f}s)")
    lines.append("=============================================================")
    return lines


def print_summary(emit=None, delay=0.5):
    for ln in summary_lines(delay):
        tlog(ln)
        if emit:
            emit(ln)
