"""Verify that a missing spec really was missing from the source.

After a rebuild, some parts have no gain, no NF, no frequency. There are three
very different reasons, and the health report cannot tell them apart:

    1. the parser DOES extract it now -- the stored row is stale, re-ingest
    2. the value is in the source but our parser misses it -- A PARSER GAP
    3. the source genuinely never stated it -- nothing to fix

This finds parts with gaps, locates the file each one was parsed from, re-runs the
parser on it, and reports which of the three applies. The result is a zip holding
the source file, the current parse, and a verdict per missing spec -- so case 2
can be fixed without guessing.

    python -m rfparts.nospec_audit                     # a few parts per vendor
    python -m rfparts.nospec_audit --per-vendor 5 --category amplifier
    python -m rfparts.nospec_audit --vendors Qorvo "Marki Microwave"

GUI: "Audit missing specs…" in the main window.

Nothing is written to the database.
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import re
import sys
import time
import zipfile
from collections import Counter, defaultdict
from pathlib import Path

try:
    from . import parse_debug, partdb
    from .paths import (ADI_PARAMETRICS, EVERYTHING_RF, NEW_SOURCES,
                        PARSE_DEBUG_DIR, VENDOR_CACHE)
except ImportError:                                     # loose-script fallback
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from rfparts import parse_debug, partdb                  # type: ignore
    from rfparts.paths import (                              # type: ignore
        ADI_PARAMETRICS, EVERYTHING_RF, NEW_SOURCES, PARSE_DEBUG_DIR,
        VENDOR_CACHE)

# Words that would appear near a value in the source, per spec key. Used to tell
# "the source says nothing about NF" from "the source states NF and we missed it".
# Word-boundary REGEXES, not substrings, and matched against VISIBLE TEXT only.
# Substring matching over raw HTML produced nonsense: "sel" matched "Select to
# compare" (71 false SEL findings) and "outline" matched the CSS class
# "btn-outline-primary" (42 false package findings).
_EVIDENCE_WORDS = {
    "freq_ghz": (r"\bfrequency\b", r"\bfreq\b", r"\bGHz\b", r"\bMHz\b",
                 r"\bbandwidth\b"),
    "gain_db": (r"\bgain\b",),
    "nf_db": (r"\bnoise\s+figure\b", r"\bNF\b"),
    "p1db_dbm": (r"\bP1\s?dB\b", r"1\s?dB\s+compression",
                 r"\bOP1dB\b", r"\bIP1dB\b"),
    "oip3_dbm": (r"\bO?IP3\b", r"third[- ]order", r"\bintercept\b"),
    "psat_dbm": (r"\bPsat\b", r"\bsaturated\b", r"\boutput\s+power\b",
                 r"\bPout\b"),
    "insertion_loss_db": (r"\binsertion\s+loss\b",),
    "isolation_db": (r"\bisolation\b",),
    # Added after a run showed switching speed empty across the whole dataset
    # with no audit finding to explain it: a spec the audit does not probe is a
    # spec whose absence is invisible.
    "switching_time_ns": (r"\bswitching\s+(?:speed|time)\b", r"\bt(?:ON|OFF)\b",
                          r"\brise\s*/?\s*fall\s+time\b"),
    "throw_config": (r"\bSP\d+T\b", r"\bSPDT\b", r"\bSPST\b", r"\bDPDT\b",
                     r"single\s+pole", r"\bthrow\b"),
    "attenuation_db": (r"\battenuation\b",),
    "conversion_loss_db": (r"\bconversion\s+(?:loss|gain)\b",),
    "return_loss_db": (r"\breturn\s+loss\b", r"\bVSWR\b"),
    "package": (r"\bpackage\b", r"\bpackage\s+type\b"),
    "tid_krad": (r"\bTID\b", r"total\s+ionizing", r"\bkRad\b"),
    "sel_mev": (r"\bSEL\b", r"single\s+event", r"MeV\s*\*?\s*cm"),
    "supply_v": (r"\bsupply\s+voltage\b", r"\bVcc\b", r"\bVdd\b",
                 r"\bbias\s+voltage\b"),
    "current_ma": (r"\bsupply\s+current\b", r"\bIcc\b", r"\bIdd\b",
                   r"\bcurrent\s+consumption\b"),
    "temp_min_c": (r"\btemperature\s+range\b", r"operating\s+temperature"),
    "temp_max_c": (r"\btemperature\s+range\b", r"operating\s+temperature"),
}
_TAGS = re.compile(r"<[^>]+>")
_STYLE = re.compile(r"<(script|style)\b.*?</\1>", re.S | re.I)


def visible_text(raw):
    """Markup stripped, so a CSS class name cannot be mistaken for a spec label."""
    if "<" not in raw:
        return raw
    t = _STYLE.sub(" ", raw)
    t = _TAGS.sub(" ", t)
    import html as _h
    return re.sub(r"[ \t\xa0]+", " ", _h.unescape(t))
_NUM_NEAR = re.compile(r"-?\d+(?:\.\d+)?")


# ---------------------------------------------------------------- source groups
# Grouping by VENDOR was wrong for this job. "Analog Devices" covers two entirely
# different inputs -- the parametric exports and the space-qualified product list
# -- with different columns and different expectations, so a per-vendor sample of
# three could easily miss one of them completely. What matters is which SOURCE a
# part was read from.
SOURCE_GROUPS = [
    "ADI Parametrics",
    "ADI space qualified product list",
    "MACOM",
    "Marki",
    "EverythingRF",
    "Qorvo",
    "Skyworks",
    "Mini-Circuits",
]

# evidence signal prefix -> group
_SIGNAL_GROUP = [
    ("adi-parametric", "ADI Parametrics"),
    ("adi-space-portfolio", "ADI space qualified product list"),
    ("radiation-characterized", "ADI space qualified product list"),
    ("erf-space", "EverythingRF"),
    ("adi-space-products", "ADI space qualified product list"),
    ("qorvo-brochure", "Qorvo"),
    ("ti-space", "TI Space Products Guide"),
]
# vendor-catalog rows carry the walker's own tag in the snippet: "qorvo:ca0021",
# "macom:/products/...", "marki:surface-mount/mixers", "skyworks:Amplifiers"
_TAG_GROUP = {"qorvo": "Qorvo", "macom": "MACOM", "marki": "Marki",
              "skyworks": "Skyworks", "minicircuits": "Mini-Circuits",
              "adi": "ADI Parametrics"}
# last resort: the host of the product URL
_HOST_GROUP = [
    ("qorvo.com", "Qorvo"), ("macom.com", "MACOM"),
    ("markimicrowave.com", "Marki"), ("skyworksinc.com", "Skyworks"),
    ("minicircuits.com", "Mini-Circuits"),
    ("everythingrf.com", "EverythingRF"),
    ("analog.com", "ADI Parametrics"),
]


def source_group_for(signals, snippets, product_url):
    """Which input a part was read from, judged from its evidence."""
    for sig in signals:
        low = (sig or "").lower()
        for prefix, group in _SIGNAL_GROUP:
            if low.startswith(prefix):
                return group
    for snip in snippets:
        tag = str(snip or "").split(":", 1)[0].strip().lower()
        tag = re.sub(r"[^a-z]", "", tag)
        if tag in _TAG_GROUP:
            return _TAG_GROUP[tag]
    host = str(product_url or "").lower()
    for needle, group in _HOST_GROUP:
        if needle in host:
            return group
    return "other / unknown source"


def expected_keys(category):
    """The spec keys the coverage report expects for a category."""
    try:
        return [key for _label, key in partdb._coverage_specs_for(category)]
    except Exception:
        return ["freq_ghz"]


def parts_with_gaps(sources=None, categories=None, per_source=3,
                    require_missing=None):
    """Parts that lack one or more expected specs, grouped BY SOURCE, worst first.

    `sources` filters on the group names in SOURCE_GROUPS (case-insensitive
    substring), not on vendor names."""
    conn = partdb.db()
    rows = conn.execute("SELECT id, mpn, vendor, category, subcategory, "
                        "product_url, description FROM parts").fetchall()
    have = defaultdict(set)
    for r in conn.execute("SELECT part_id, key FROM specs"):
        have[r["part_id"]].add(r["key"])
    sig = defaultdict(list)
    snip = defaultdict(list)
    for r in conn.execute("SELECT part_id, signal, snippet FROM qual_evidence"):
        sig[r["part_id"]].append(r["signal"])
        snip[r["part_id"]].append(r["snippet"])
    wanted = [str(s).lower() for s in (sources or [])]
    out = defaultdict(list)
    for r in rows:
        group = source_group_for(sig[r["id"]], snip[r["id"]], r["product_url"])
        if wanted and not any(w in group.lower() for w in wanted):
            continue
        if categories and r["category"] not in categories:
            continue
        want = expected_keys(r["category"])
        missing = [k for k in want if k not in have[r["id"]]]
        if require_missing:
            missing = [k for k in missing if k in require_missing]
        if not missing:
            continue
        out[group].append({
            "id": r["id"], "mpn": r["mpn"], "vendor": r["vendor"],
            "source_group": group,
            "category": r["category"], "subcategory": r["subcategory"],
            "product_url": r["product_url"] or "",
            "description": r["description"] or "",
            "missing": missing, "present": sorted(have[r["id"]]),
        })
    picked = {}
    for group, items in out.items():
        # most-incomplete first: those are the informative ones
        items.sort(key=lambda x: (-len(x["missing"]), x["mpn"]))
        picked[group] = items[:per_source]
    return picked, {g: len(i) for g, i in out.items()}


# ------------------------------------------------------------- source lookup
def _candidate_files():
    """Everything a part could have been parsed from, cheapest first."""
    files = []
    for root in (VENDOR_CACHE,):
        r = Path(root)
        if r.is_dir():
            files += [p for p in r.rglob("*.html")]
    for root in (EVERYTHING_RF, NEW_SOURCES):
        r = Path(root)
        if r.is_dir():
            files += [p for p in r.rglob("*.html")] + \
                     [p for p in r.rglob("*.htm")]
    for root in (ADI_PARAMETRICS, NEW_SOURCES):
        r = Path(root)
        if r.is_dir():
            files += [p for p in r.rglob("*.xlsx")
                      if not p.name.startswith("~$")]
    seen, out = set(), []
    for f in files:
        k = str(f).lower()
        if k not in seen:
            seen.add(k)
            out.append(f)
    return out


def _mpn_variants(mpn):
    m = str(mpn).strip()
    flat = re.sub(r"[^A-Za-z0-9]", "", m).upper()
    return {m, m.upper(), m.lower(), flat}


def locate_sources(mpns, progress=None):
    """{normalised MPN: [files that mention it]}. One pass over the candidates."""
    say = progress or (lambda m: None)
    wanted = {}
    for mpn in mpns:
        wanted[re.sub(r"[^A-Za-z0-9]", "", str(mpn)).upper()] = str(mpn)
    found = defaultdict(list)
    files = _candidate_files()
    say(f"    scanning {len(files)} candidate source file(s) for "
        f"{len(wanted)} part number(s)")
    for i, f in enumerate(files, 1):
        try:
            if f.suffix.lower() in (".xlsx", ".xlsm"):
                text = _workbook_text(f)
            else:
                text = f.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        flat = re.sub(r"[^A-Za-z0-9]", "", text).upper()
        for key in wanted:
            if len(key) >= 4 and key in flat:
                found[key].append(f)
        if i % 200 == 0:
            say(f"      {i}/{len(files)} scanned, "
                f"{len(found)}/{len(wanted)} located")
    say(f"    located {len(found)}/{len(wanted)} part number(s) in a source")
    return found


_WB_CACHE = {}


def _workbook_text(path):
    key = str(path)
    if key in _WB_CACHE:
        return _WB_CACHE[key]
    try:
        import openpyxl
        wb = openpyxl.load_workbook(str(path), read_only=True, data_only=False)
        chunks = []
        for ws in wb.worksheets:
            for row in ws.iter_rows(values_only=True):
                chunks.append(" ".join("" if c is None else str(c) for c in row))
        wb.close()
        text = "\n".join(chunks)
    except Exception:
        text = ""
    _WB_CACHE[key] = text
    return text


# ------------------------------------------------------------------ verdicts
def region_for(text, mpn, span=2600):
    """The part's own slice of a multi-part source.

    A listing page holds ~24 parts, so searching the WHOLE page for "gain" finds
    some other part's gain and declares a parser gap for every row. Scoping to the
    region around this part number is what makes the verdict mean anything."""
    flat_text = text
    i = flat_text.find(str(mpn))
    if i < 0:
        # try a punctuation-insensitive search
        target = re.sub(r"[^A-Za-z0-9]", "", str(mpn)).upper()
        squashed = re.sub(r"[^A-Za-z0-9]", "", flat_text).upper()
        j = squashed.find(target)
        if j < 0 or not target:
            return text[:span]          # single-part source; use the head
        # map back approximately: count non-alnum chars consumed
        count = 0
        for k, ch in enumerate(flat_text):
            if ch.isalnum():
                count += 1
                if count > j:
                    i = k
                    break
        if i < 0:
            return text[:span]
    return text[max(0, i - span // 3): i + span]


def source_mentions(text, key):
    """(mentioned, snippet) for a spec key in a source text."""
    patterns = _EVIDENCE_WORDS.get(key, (r"\b" + re.escape(key.split("_")[0])
                                         + r"\b",))
    text = visible_text(text)
    for pat in patterns:
        for m in re.finditer(pat, text, re.I):
            window = text[max(0, m.start() - 60): m.end() + 140]
            if _NUM_NEAR.search(window):
                return True, re.sub(r"\s+", " ", window).strip()[:160]
    return False, ""


def verdict_for(part, source_file, parsed_specs, source_text):
    """One verdict per missing spec, judged against THIS PART'S region."""
    rows = []
    source_text = region_for(source_text, part["mpn"])
    for key in part["missing"]:
        # 1. does the CURRENT parser get it from this source?
        got = None
        for cand in (key, key.replace("_ghz", "_min"), "freq_min"
                     if key == "freq_ghz" else key):
            if cand in parsed_specs:
                got = parsed_specs[cand]
                break
        if got is not None:
            rows.append({
                "spec": key, "verdict": "STALE ROW",
                "detail": f"the parser extracts this now ({got}); the stored row "
                          f"predates a parser fix -- re-ingest this source",
                "snippet": "",
            })
            continue
        mentioned, snippet = source_mentions(source_text, key)
        if mentioned:
            rows.append({
                "spec": key, "verdict": "PARSER GAP",
                "detail": "the source states this but our parser does not pick "
                          "it up",
                "snippet": snippet,
            })
        else:
            rows.append({
                "spec": key, "verdict": "NOT IN SOURCE",
                "detail": "the source does not state this; nothing to fix",
                "snippet": "",
            })
    return rows


def _flat_parsed(report, mpn):
    """The parsed spec dict for one MPN out of an inspector report."""
    flat = re.sub(r"[^A-Za-z0-9]", "", str(mpn)).upper()
    for p in report.get("parts", []) or []:
        if re.sub(r"[^A-Za-z0-9]", "", str(p.get("mpn", ""))).upper() == flat:
            specs = p.get("specs") or {}
            out = {}
            for k, v in specs.items():
                out[k] = v.get("parsed") if isinstance(v, dict) else v
            return out
    ds = report.get("marki_datasheet") or {}
    return {k: v.get("value") for k, v in (ds.get("parsed_specs") or {}).items()}


def build_audit(sources=None, categories=None, per_source=3, out_path=None,
                progress=None, missing_only=None, vendors=None,
                per_vendor=None):
    """`vendors`/`per_vendor` are accepted as the old argument names."""
    say = progress or print
    sources = sources or vendors
    per_source = per_source if per_vendor is None else per_vendor
    started = time.time()
    say("=" * 64)
    say("MISSING-SPEC AUDIT — checking gaps against the original source")
    say("  grouped by SOURCE, not by vendor: 'Analog Devices' spans two very")
    say("  different inputs and a per-vendor sample could miss one entirely")
    say("=" * 64)
    picked, totals = parts_with_gaps(sources, categories, per_source,
                                     missing_only)
    if not picked:
        say("  no parts with missing expected specs — nothing to audit")
        return None
    for v, n in sorted(totals.items()):
        say(f"  {v:<36} {n:>6} part(s) with gaps, sampling "
            f"{len(picked.get(v, []))}")
    sampled = [p for items in picked.values() for p in items]
    located = locate_sources([p["mpn"] for p in sampled], progress=say)

    files = {}
    findings = []
    counts = Counter()
    for part in sampled:
        flat = re.sub(r"[^A-Za-z0-9]", "", part["mpn"]).upper()
        srcs = located.get(flat, [])
        folder = (re.sub(r"[^A-Za-z0-9]+", "-",
                         part.get("source_group", "unknown")).strip("-")
                  + "/" + re.sub(r"[^A-Za-z0-9._+-]", "_", part["mpn"])[:60])
        if not srcs:
            counts["no_source_found"] += 1
            files[f"{folder}/verdict.txt"] = (
                f"{part['mpn']}  [{part.get('source_group', '?')}]  "
                f"({part['vendor']} / {part['category']})\n"
                f"missing: {', '.join(part['missing'])}\n\n"
                f"NO SOURCE FILE FOUND that mentions this part number.\n"
                f"Either it came from a source no longer on disk, or it was\n"
                f"reached through a page that was never cached. Nothing can be\n"
                f"verified for it.\n").encode()
            for key in part["missing"]:
                findings.append({"source_group": part.get("source_group", ""),
                                 "mpn": part["mpn"], "vendor": part["vendor"],
                                 "category": part["category"], "spec": key,
                                 "verdict": "NO SOURCE", "source": "",
                                 "detail": "", "snippet": ""})
            continue
        # rank candidate sources by how much the parser gets out of them, and
        # judge each missing spec against the BEST source, not the first
        best = None
        per_source = []
        for cand in srcs[:6]:
            try:
                if cand.suffix.lower() in (".xlsx", ".xlsm"):
                    rep = parse_debug.inspect_path(cand)
                    txt = _excerpt_rows(cand, part["mpn"], data_only=True)
                else:
                    rep = parse_debug.inspect_path(cand)
                    txt = cand.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue
            parsed_here = _flat_parsed(rep, part["mpn"])
            score = len([k for k in part["missing"] if k in parsed_here])
            per_source.append((score, len(parsed_here), cand, rep, txt,
                               parsed_here))
        if per_source:
            per_source.sort(key=lambda t: (-t[0], -t[1], str(t[2])))
            best = per_source[0]
        src = best[2] if best else srcs[0]
        try:
            if src.suffix.lower() in (".xlsx", ".xlsm"):
                report = parse_debug.inspect_path(src)
                raw_name = f"{folder}/source_{src.name}.txt"
                excerpt = _excerpt_rows(src, part["mpn"])
                files[raw_name] = excerpt.encode("utf-8", "replace")
                # Evidence must come from THIS PART'S rows. Searching the whole
                # workbook quoted a neighbouring part's numbers -- AD8131's
                # "missing frequency" was evidenced by AD8350's row -- which is
                # the same false positive as searching a whole listing page.
                text = _excerpt_rows(src, part["mpn"], data_only=True)
            else:
                text = src.read_text(encoding="utf-8", errors="replace")
                report = parse_debug.inspect_path(src)
                raw_name = f"{folder}/source_{src.name}"
                files[raw_name] = text.encode("utf-8", "replace")
        except Exception as e:
            counts["source_unreadable"] += 1
            files[f"{folder}/verdict.txt"] = (
                f"could not read {src}: {type(e).__name__}: {e}\n").encode()
            continue
        parsed = _flat_parsed(report, part["mpn"])
        if best:
            report, text, parsed = best[3], best[4], best[5]
        rows = verdict_for(part, src, parsed, text)
        # a spec counts as NOT IN SOURCE only if NO candidate source states it
        if len(per_source) > 1:
            for r in rows:
                if r["verdict"] != "NOT IN SOURCE":
                    continue
                for _sc, _n, cand, _rep, cand_text, cand_parsed in per_source[1:]:
                    if r["spec"] in cand_parsed:
                        r["verdict"] = "STALE ROW"
                        r["detail"] = (f"the parser extracts this from "
                                       f"{cand.name} ({cand_parsed[r['spec']]}); "
                                       f"re-ingest that source")
                        break
                    mentioned, snippet = source_mentions(
                        region_for(cand_text, part["mpn"]), r["spec"])
                    if mentioned:
                        r["verdict"] = "PARSER GAP"
                        r["detail"] = (f"{cand.name} states this and our parser "
                                       f"does not pick it up")
                        r["snippet"] = snippet
                        break
        for r in rows:
            counts[r["verdict"]] += 1
            findings.append({"source_group": part.get("source_group", ""),
                             "mpn": part["mpn"], "vendor": part["vendor"],
                             "category": part["category"], "spec": r["spec"],
                             "verdict": r["verdict"], "source": src.name,
                             "detail": r["detail"], "snippet": r["snippet"]})
        lines = [
            f"{part['mpn']}   [{part.get('source_group', '?')}]  "
            f"({part['vendor']} / {part['category']}"
            + (f" / {part['subcategory']}" if part["subcategory"] else "") + ")",
            f"source           {src}",
            (f"other sources    {len(srcs) - 1} more mention this part; "
             f"{len(per_source)} checked, best one shown above"
             if len(srcs) > 1 else "other sources    none"),
            f"stored specs     {', '.join(part['present']) or '(none)'}",
            f"missing specs    {', '.join(part['missing'])}",
            "",
            "what the parser gets from this source RIGHT NOW:",
        ]
        for k in sorted(parsed):
            lines.append(f"    {k:<24} {parsed[k]}")
        if not parsed:
            lines.append("    (nothing)")
        lines += ["", "verdict per missing spec:"]
        for r in rows:
            lines.append(f"  {r['spec']:<22} {r['verdict']}")
            lines.append(f"      {r['detail']}")
            if r["snippet"]:
                lines.append(f"      source says: \"{r['snippet']}\"")
        files[f"{folder}/verdict.txt"] = "\n".join(lines).encode("utf-8",
                                                                "replace")
        files[f"{folder}/parsed.txt"] = parse_debug.render(
            report, max_parts=4, show_rejects=6).encode("utf-8", "replace")
        say(f"    {part['mpn']:<22} {src.name[:34]:<34} "
            + " ".join(sorted({r['verdict'] for r in rows})))

    # ---- summary + csv
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=["source_group", "vendor", "mpn",
                                        "category", "spec", "verdict",
                                        "source", "detail", "snippet"])
    w.writeheader()
    for f in findings:
        w.writerow(f)
    files["findings.csv"] = buf.getvalue().encode("utf-8", "replace")

    summary = [
        "MISSING-SPEC AUDIT",
        f"generated {time.strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        "verdicts across every missing spec checked",
    ]
    for k, n in counts.most_common():
        summary.append(f"  {k:<18} {n}")
    summary += ["", "what each verdict means", ""]
    summary += [
        "  STALE ROW      the parser extracts this value from the source today.",
        "                 The stored row predates a parser fix. Re-ingest that",
        "                 source (or Reset) and the gap closes by itself.",
        "",
        "  PARSER GAP     the source states the value and our parser misses it.",
        "                 These are the actionable ones -- the snippet in",
        "                 verdict.txt shows the text we failed to read.",
        "",
        "  NOT IN SOURCE  the source never stated it. Nothing to fix; the part",
        "                 legitimately has no value for that spec.",
        "",
        "  NO SOURCE      no file on disk mentions this part number, so nothing",
        "                 could be checked.",
        "",
        "parts with gaps, BY SOURCE (full dataset, not just the sample)",
    ]
    for v, n in sorted(totals.items(), key=lambda kv: -kv[1]):
        summary.append(f"  {v:<36} {n}")
    summary += ["", "gaps by source and spec"]
    per = Counter((f["source_group"], f["spec"], f["verdict"])
                  for f in findings)
    for (grp, spec, verdict), n in sorted(per.items()):
        summary.append(f"  {grp:<34} {spec:<20} {verdict:<14} {n}")
    summary += ["", "specific source files consulted"]
    for name, n in Counter(f["source"] for f in findings if f["source"]
                           ).most_common():
        summary.append(f"  {name:<52} {n} finding(s)")
    files["summary.txt"] = "\n".join(summary).encode("utf-8", "replace")
    files["README.txt"] = (
        "Missing-spec audit\n==================\n\n"
        "One folder PER SOURCE, then per audited part -- because 'Analog\n"
        "Devices' covers two different inputs (the parametric exports and the\n"
        "space-qualified product list) whose gaps mean different things:\n"
        "  ADI-Parametrics/ ADI-space-qualified-product-list/ MACOM/ Marki/\n"
        "  EverythingRF/ Qorvo/ Skyworks/ Mini-Circuits/\n\n"
        "Inside each part folder:\n"
        "  source_<name>            the file the part was parsed from (for a\n"
        "                           spreadsheet, the header plus that part's row)\n"
        "  parsed.txt               what the parser extracts from it today\n"
        "  verdict.txt              per missing spec: STALE ROW / PARSER GAP /\n"
        "                           NOT IN SOURCE, with the source text quoted\n"
        "\nsummary.txt  verdict totals and what each one means\n"
        "findings.csv one row per (part, missing spec) for sorting\n"
        "\nOnly a few parts per vendor, chosen most-incomplete-first. Nothing was\n"
        "written to the database.\n").encode()

    out_path = Path(out_path or (PARSE_DEBUG_DIR /
                                 f"rfparts_nospec_audit_"
                                 f"{time.strftime('%Y%m%d_%H%M')}.zip"))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
        for arc in sorted(files):
            z.writestr(arc, files[arc])
    say("")
    for k, n in counts.most_common():
        say(f"  {k:<18} {n}")
    say(f"\n  {len(files)} file(s) -> {out_path}")
    say(f"  ({out_path.stat().st_size / 1024:.0f} kB, "
        f"{time.time() - started:.1f}s)")
    return out_path


def _excerpt_rows(path, mpn, data_only=False):
    """Header plus the rows mentioning one part, as CSV.

    `data_only=True` omits the header. The saved excerpt keeps the header because
    it is useful context, but EVIDENCE must not be read from it: a header row
    naming "Frequency Response min" made every part look like it stated a
    frequency, even when its own cell said 'None'."""
    flat = re.sub(r"[^A-Za-z0-9]", "", str(mpn)).upper()
    try:
        import openpyxl
        wb = openpyxl.load_workbook(str(path), read_only=True, data_only=False)
    except Exception as e:
        return f"# could not open {path.name}: {e}\n"
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow([f"# source: {path.name}"])
    for ws in wb.worksheets:
        header_written = False
        for row in ws.iter_rows(values_only=True):
            cells = ["" if c is None else str(c) for c in row]
            joined = re.sub(r"[^A-Za-z0-9]", "", " ".join(cells)).upper()
            low = " ".join(cells).lower()
            if not header_written and ("part number" in low or
                                       "generic part number" in low):
                if not data_only:
                    w.writerow([f"# sheet: {ws.title} (header)"])
                    w.writerow(cells)
                header_written = True
                continue
            if flat and flat in joined:
                w.writerow(cells)
    wb.close()
    return out.getvalue()


def main(argv=None):
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--sources", nargs="*",
                    help="source groups to audit (substring match): "
                         + ", ".join(SOURCE_GROUPS))
    ap.add_argument("--vendors", nargs="*", dest="sources",
                    help="deprecated alias for --sources")
    ap.add_argument("--category", nargs="*", dest="categories")
    ap.add_argument("--per-source", type=int, default=3, dest="per_source")
    ap.add_argument("--per-vendor", type=int, dest="per_source",
                    help="deprecated alias for --per-source")
    ap.add_argument("--missing", nargs="*",
                    help="only audit these spec keys, e.g. nf_db gain_db")
    ap.add_argument("--out")
    args = ap.parse_args(argv)
    build_audit(sources=args.sources, categories=args.categories,
                per_source=args.per_source, out_path=args.out,
                missing_only=args.missing)
    return 0


if __name__ == "__main__":
    sys.exit(main())
