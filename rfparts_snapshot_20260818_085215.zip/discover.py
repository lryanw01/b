"""Discover candidate product pages for a vendor.

Strategies:
  * catalog: load a local scraped JSON catalog (see catalog.py) — no network.
  * sitemap: read robots.txt-declared sitemaps (plus common paths), expand
    sitemap indexes (gzip-aware) up to SITEMAP_DEPTH levels, then keep URLs
    that look like product pages for the requested category.
  * search: hit the vendor's own search endpoint and scrape result links.

`candidates()` never raises — a broken vendor yields an empty list so one bad
site can't sink a whole run.
"""
import gzip
import os
import re
import xml.etree.ElementTree as ET
from urllib.parse import quote_plus, urljoin, urlparse

from bs4 import BeautifulSoup

from . import catalog, fetch
from .registry import synonyms

MAX_CANDIDATES = int(os.environ.get("RFPARTS_MAX_PER_VENDOR", "1500"))
MAX_SITEMAP_URLS = 8000
MAX_INDEX_CHILDREN = 1500
SITEMAP_DEPTH = 3

LISTING_HINT = re.compile(
    r"/(about|contact|news|blog|category|categories|search|cart|account|policy|"
    r"terms|privacy|support|resources|literature)(/|$)", re.I)
PRODUCT_HINT = re.compile(r"/(product|products|part|parts|item|p)/", re.I)


def _tokens(spec):
    toks = list(synonyms(spec.get("category")))
    if spec.get("temp_k") is not None and spec["temp_k"] <= 120:
        toks += ["cryo", "cryogenic"]
    return [t.lower() for t in toks if t]


def _matches(text, toks):
    t = text.lower()
    return any(tok in t for tok in toks)


def _url_ok(url, toks, category=None):
    path = urlparse(url).path.lower().replace("_", "-")
    if not path or path in ("/", ""):
        return False
    if LISTING_HINT.search(path):
        return False
    if category:
        cat_syn = [s.replace(" ", "-") for s in synonyms(category)]
        last = path.rstrip("/").rsplit("/", 1)[-1]
        if last in cat_syn or last in {c + "s" for c in cat_syn}:
            return False
    looks_product = bool(PRODUCT_HINT.search(path)) or bool(
        re.search(r"/[a-z0-9]+-?\d[\w-]*/?$", path))
    if toks == [""]:
        return looks_product
    return looks_product and _matches(path, toks)


def _fetch_sitemap(url):
    raw = fetch.get(url, ttl=86400, binary=True)
    if not raw:
        return None
    if url.lower().endswith(".gz") or raw[:2] == b"\x1f\x8b":
        try:
            raw = gzip.decompress(raw)
        except OSError:
            return None
    return raw.decode("utf-8", "replace")


def _sitemap_index(base):
    found = []
    robots = fetch.get(urljoin(base, "/robots.txt"), ttl=86400)
    if robots:
        for line in robots.splitlines():
            if line.lower().startswith("sitemap:"):
                found.append(line.split(":", 1)[1].strip())
    found += [urljoin(base, "/sitemap.xml"), urljoin(base, "/sitemap_index.xml"),
              urljoin(base, "/sitemap.xml.gz"), urljoin(base, "/sitemap-index.xml")]
    seen, out = set(), []
    for u in found:
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out


def _expand_sitemap(xml, depth):
    urls = []
    try:
        root = ET.fromstring(xml)
    except ET.ParseError:
        return urls
    ns = {"s": "http://www.sitemaps.org/schemas/sitemap/0.9"}
    locs = [e.text.strip() for e in root.findall(".//s:loc", ns) if e.text]
    if not locs:
        locs = [e.text.strip() for e in root.iter() if e.tag.endswith("loc") and e.text]
    is_index = root.tag.endswith("sitemapindex")
    if is_index and depth > 0:
        for child in locs[:MAX_INDEX_CHILDREN]:
            cxml = _fetch_sitemap(child)
            if cxml:
                urls += _expand_sitemap(cxml, depth - 1)
                if len(urls) >= MAX_SITEMAP_URLS:
                    break
    else:
        urls += locs
    return urls[:MAX_SITEMAP_URLS]


def _sitemap_urls(base):
    for sm in _sitemap_index(base):
        xml = _fetch_sitemap(sm)
        if xml:
            urls = _expand_sitemap(xml, depth=SITEMAP_DEPTH)
            if urls:
                return urls
    return []


def _by_sitemap(vendor, spec, toks):
    urls = _sitemap_urls(vendor["url"])
    hits = [u for u in urls if _url_ok(u, toks, spec.get("category"))]
    return [{"url": u, "title": u.rstrip("/").rsplit("/", 1)[-1].replace("-", " ")}
            for u in hits[:MAX_CANDIDATES]]


def _by_search(vendor, spec, toks):
    q = " ".join(
        [spec.get("category", "")] + spec.get("other", [])).strip() or spec.get("category", "")
    html = fetch.get(vendor["search_url"].format(q=quote_plus(q)))
    if not html:
        return []
    soup = BeautifulSoup(html, "html.parser")
    out, seen = [], set()
    for a in soup.find_all("a", href=True):
        href = urljoin(vendor["url"], a["href"])
        text = a.get_text(" ", strip=True)
        ok = _url_ok(href, toks, spec.get("category")) or (
            text and _matches(text, toks) and _url_ok(href, [""], spec.get("category")))
        if ok and href not in seen:
            seen.add(href)
            out.append({"url": href, "title": text or href.rsplit("/", 1)[-1]})
        if len(out) >= MAX_CANDIDATES:
            break
    return out


def candidates(vendor, spec):
    toks = _tokens(spec)
    try:
        if vendor.get("strategy") == "catalog":
            return catalog.candidates(vendor, spec)
        if vendor.get("strategy") == "api":
            from . import sources
            return sources.candidates(vendor, spec)
        if vendor.get("strategy") == "search" and vendor.get("search_url"):
            return _by_search(vendor, spec, toks)
        return _by_sitemap(vendor, spec, toks)
    except Exception as e:
        fetch.log(f"discover fail {vendor['name']}: {type(e).__name__}")
        return []
