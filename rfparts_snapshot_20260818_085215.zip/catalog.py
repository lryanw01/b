"""Load a local vendor catalog (scraped JSON) into ranked-ready candidates.

Used by vendors with strategy: catalog. No network — the whole catalog is on
disk. data_file is resolved package-folder-first (see _resolve), so the JSON can
be zipped with the package.

Catalogs store terse category codes under a "cat" field (att, sw, flt, ...) and
scatter specs across a nested "specs" object with many field names. This module
maps codes to canonical categories (CODE_TO_CATEGORY) and pulls structured specs
(frequency in MHz -> GHz, gain, nf, vswr, interface, impedance-from-part-number)
directly from the fields; extract.py fills any remaining gaps from text.
"""
import json
import pathlib
import re
from urllib.parse import parse_qsl, quote, urlencode, urljoin, urlsplit, urlunsplit

from .mc_fix import repair_catalog
from .registry import CATEGORY_SYNONYMS, DATA, synonyms

PKG_DIR = pathlib.Path(__file__).resolve().parent

# Catalog category code -> canonical tool category (registry.CATEGORY_SYNONYMS).
CODE_TO_CATEGORY = {
    "amp": "amplifier", "lna": "amplifier",
    "att": "attenuator",
    "flt": "filter",
    "mix": "mixer",
    "cpl": "coupler",
    "spl": "divider",
    "sw": "switch",
    "dcb": "dc_block",
    "bias": "bias_tee",
    "term": "termination",
    "cable": "cable",
    "adapter": "connector",
    "ps": "phase_shifter",
    "eq": "equalizer",
    "mult": "frequency_multiplier",
    "lim": "limiter",
    "match": "attenuator",
    "psen": "power_sensor",
    "pdet": "power_detector",
    "pd": "phase_detector",
    "xfmr": "balun",
    "osc": "oscillator",
    "syn": "synthesizer",
    "die": "mmic_die",
    "wg": "waveguide",
    # NOTE: "mod" (Modulators / Demodulators) is intentionally left unmapped so a
    # record's group text can match either the modulator or demodulator category
    # via the token fallback in candidates(); a single code can't be both.
}

MODEL_KEYS = ("pn", "model", "model_name", "modelName", "partNumber",
              "part_number", "sku", "name")
CATEGORY_KEYS = ("cat", "category", "categories", "type", "product_type",
                 "productType", "family", "group", "section")
DESC_KEYS = ("desc", "description", "summary", "title", "subtitle",
             "shortDescription")
URL_KEYS = ("url", "link", "productUrl", "product_url", "href", "page")

# Frequency low/high field pairs (dotted paths), tried in order. Values are MHz.
FREQ_PAIRS = [
    ("flo", "fhi"),
    ("specs.frequency_low", "specs.frequency_high"),
    ("specs.f_low", "specs.f_high"),
    ("specs.passband_f1", "specs.passband_f2"),
    ("specs.rf_freq_low", "specs.rf_freq_high"),
    ("specs.input_freq_low", "specs.input_freq_high"),
    ("specs.output_freq_low", "specs.output_freq_high"),
    ("specs.lo_freq_low", "specs.lo_freq_high"),
]

# specs.interface / technology text -> canonical package label.
MOUNT_MAP = {
    "smt": "smt", "surface mount": "smt", "surface-mount": "smt", "qfn": "smt",
    "connectorized": "connectorized", "coaxial": "connectorized", "coax": "connectorized",
    "die": "die", "bare die": "die", "mmic die": "die",
    "flange": "flange",
    "connector": "connectorized", "sma": "connectorized",
    "bnc": "connectorized", "n-type": "connectorized", "type n": "connectorized",
    "2.92mm": "connectorized", "2.4mm": "connectorized",
    "1.85mm": "connectorized", "1.0mm": "connectorized",
    "male": "connectorized", "female": "connectorized", "con": "connectorized",
}


def _first(rec, keys, default=None):
    for k in keys:
        if k in rec and rec[k] not in (None, "", []):
            return rec[k]
    return default


def _get(rec, path):
    cur = rec
    for part in path.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return None
    return cur


def _num(v):
    """Coerce a catalog value to a float, or None. 'DC' -> 0; unit-tagged
    non-frequency junk (e.g. '1.0mm', '35 dB') -> None; ranges take the first."""
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    if not isinstance(v, str):
        return None
    s = v.strip()
    if not s:
        return None
    if s.upper() == "DC":
        return 0.0
    if re.search(r"(mm|\bdb\b|dbm|ns\b|ohm|\bw\b|\bv\b|\bma\b|°|deg)", s, re.I):
        return None
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    return float(m.group()) if m else None


def _flatten(value, out):
    if isinstance(value, dict):
        for v in value.values():
            _flatten(v, out)
    elif isinstance(value, (list, tuple)):
        for v in value:
            _flatten(v, out)
    elif isinstance(value, bool):
        pass
    elif isinstance(value, (str, int, float)):
        out.append(str(value))


def _freq_string(rec):  # kept for inspect_db compatibility
    lo = _num(_get(rec, "flo"))
    hi = _num(_get(rec, "fhi"))
    if lo is not None and hi is not None:
        return f"{lo:g}-{hi:g} MHz"
    return ""


FREQ_STR_KEYS = ("specs.frequency", "frequency", "specs.freq_range", "freq_range",
                 "specs.bandwidth", "bandwidth", "specs.freq", "freq")
FREQ_FIELD_HINT = re.compile(r"freq|passband|\bflo\b|\bfhi\b|band", re.I)
FREQ_FIELD_SKIP = re.compile(
    r"suppress|slope|insertion|rejection|vswr|isolation|ratio|impedance|bandwidth", re.I)

FREQ_UNIT = re.compile(r"\b(khz|mhz|ghz|hz)\b", re.I)
SWITCH_PN = re.compile(r"(?:^|[-_])(?:[A-Z]*SW[A-Z]*|USB-SP|RC-|ZSWA?|HSWA?|JSWA?|CSWA?)(\d{1,2})(?:[-_]|$)", re.I)
TOUCHSTONE_PORTS = re.compile(r"(?:^|[_-])S(\d{1,2})P(?:[._-]|$)", re.I)


def _flat_scalars(rec):
    flat = {k: v for k, v in rec.items() if not isinstance(v, (dict, list))}
    s = rec.get("specs")
    if isinstance(s, dict):
        for k, v in s.items():
            if not isinstance(v, (dict, list)):
                flat[f"specs.{k}"] = v
    return flat


def _freq_from_str(value):
    """Parse a frequency range and honor explicit Hz/kHz/MHz/GHz units.

    If only one unit is present, it applies to both endpoints. Catalog values
    without units are treated as MHz, matching the Mini-Circuits export.
    """
    text = str(value).replace(",", "")
    m = re.search(
        r"(dc|\d+(?:\.\d+)?)\s*(khz|mhz|ghz|hz)?\s*"
        r"(?:-|–|—|to)\s*(\d+(?:\.\d+)?)\s*(khz|mhz|ghz|hz)?",
        text, re.I)
    if not m:
        return None
    lo = 0.0 if m.group(1).lower() == "dc" else float(m.group(1))
    hi = float(m.group(3))
    unit = (m.group(4) or m.group(2) or "mhz").lower()
    scale = {"hz": 1e9, "khz": 1e6, "mhz": 1e3, "ghz": 1.0}[unit]
    return [round(min(lo, hi) / scale, 6), round(max(lo, hi) / scale, 6)]


def _freq_catchall(rec):
    vals = []
    for k, v in _flat_scalars(rec).items():
        if FREQ_FIELD_HINT.search(k) and not FREQ_FIELD_SKIP.search(k):
            n = _num(v)
            if n is not None:
                vals.append(n)
    if vals and max(vals) > 0:
        return [round(min(vals) / 1000.0, 4), round(max(vals) / 1000.0, 4)]
    return None


def _freq_ghz(rec):
    for lo_k, hi_k in FREQ_PAIRS:
        lo, hi = _num(_get(rec, lo_k)), _num(_get(rec, hi_k))
        vals = [x for x in (lo, hi) if x is not None]
        if not vals:
            continue
        lo2, hi2 = min(vals), max(vals)
        if hi2 <= 0:
            continue
        return [round(lo2 / 1000.0, 4), round(hi2 / 1000.0, 4)]
    for k in FREQ_STR_KEYS:
        v = _get(rec, k)
        if isinstance(v, str):
            fg = _freq_from_str(v)
            if fg and fg[1] > 0:
                return fg
    return _freq_catchall(rec)


def _mount_from(value):
    if not value:
        return None
    v = str(value).strip().lower()
    for key, canon in MOUNT_MAP.items():
        if key in v:
            return canon
    return None


def _impedance_from_pn(pn):
    """Whitelisted characteristic impedance mined from a part number.
    Handles JFW-style '<Z>S...' switch prefixes and trailing '-75' suffixes."""
    p = str(pn).upper()
    m = re.match(r"(50|75|33|90|100)S", p)
    if m:
        return float(m.group(1))
    m = re.search(r"[-_](50|75|33)(?=\D|$)", p)
    if m:
        return float(m.group(1))
    return None



def _normalize_url(value, base, model=""):
    """Return a valid absolute URL while preserving encoded model characters."""
    if not value:
        if not model:
            return base
        value = f"/WebStore/dashboard.html?model={quote(str(model), safe='')}"
    url = urljoin(base.rstrip("/") + "/", str(value).strip())
    parts = urlsplit(url)
    pairs = parse_qsl(parts.query, keep_blank_values=True)
    if pairs:
        query = urlencode(pairs, doseq=True, quote_via=quote)
        url = urlunsplit((parts.scheme, parts.netloc, parts.path, query, parts.fragment))
    return url


def _connector_value(rec):
    keys = (
        "specs.connector_e", "specs.conn_1", "specs.conn_2",
        "specs.connector", "connector", "interface",
    )
    vals = []
    for key in keys:
        value = _get(rec, key)
        if value not in (None, "", []):
            vals.append(str(value).strip())
    return "/".join(dict.fromkeys(vals)) if vals else None


def _mount_type(rec, connector=None):
    values = (
        _get(rec, "specs.interface"), _get(rec, "specs.technology"),
        _get(rec, "interface"), _get(rec, "technology"),
        _get(rec, "specs.case_style"), _get(rec, "case_style"), connector,
    )
    joined = " ".join(str(v) for v in values if v not in (None, ""))
    mt = _mount_from(joined)
    if mt:
        return mt
    # Mini-Circuits case identifiers alone are not enough to distinguish SMT
    # from connectorized packages, so do not guess from an opaque case code.
    return None


def _touchstone_ports(rec):
    """Return the network-port count encoded by a Touchstone/SNP filename.

    Mini-Circuits usually stores this in ``sparams_url`` as ``_S2P``,
    ``_S3P``, etc.  This is an RF-network count, so control, DC-power, USB,
    trigger and programming connectors are naturally excluded.
    """
    values = []
    for path in ("sparams_url", "specs.sparams_url", "snp", "specs.snp",
                 "touchstone", "specs.touchstone"):
        value = _get(rec, path)
        if value not in (None, "", []):
            values.append(str(value))
    for value in values:
        m = TOUCHSTONE_PORTS.search(value)
        if m:
            n = int(m.group(1))
            if 1 <= n <= 64:
                return n
    return None


def _rf_ports(rec, category, model):
    """Infer RF signal ports only; never count control, DC, USB, or bias pins."""
    ways = None
    for path in ("specs.no_of_ways", "no_of_ways", "specs.ways", "ways"):
        ways = _num(_get(rec, path))
        if ways is not None:
            break
    if ways is not None and ways >= 1:
        return int(ways) + 1

    pn = str(model or "").upper()
    if category == "switch":
        # Common Mini-Circuits switch families encode throw count directly,
        # e.g. HSWA4..., JSW2..., ZSW4..., resulting in N+1 RF ports.
        m = re.search(r"(?:^|[-_])(?:HSWA|JSW|CSWA|ZSWA?|MSW|RSW)(\d{1,2})", pn)
        if m:
            return int(m.group(1)) + 1
        m = re.search(r"\bSP(\d{1,2})T\b", pn)
        if m:
            return int(m.group(1)) + 1
        # A switch-state S2P file often describes one selected RF path rather
        # than every physical RF connector.  Only use SNP as a switch fallback
        # when it explicitly represents three or more network ports.
        snp_ports = _touchstone_ports(rec)
        return snp_ports if snp_ports and snp_ports >= 3 else None

    # Some categories have a physical topology that is more reliable than an
    # S2P measurement file.  For example, couplers are normally four-port RF
    # devices even when Mini-Circuits publishes two-port data for one path.
    topology_fixed = {"circulator": 3, "mixer": 3, "coupler": 4, "bias_tee": 3}
    if category in topology_fixed:
        return topology_fixed[category]

    # For ordinary one- and two-path parts, the Touchstone extension is an
    # RF-only count and excludes power/control wiring.
    snp_ports = _touchstone_ports(rec)
    if snp_ports is not None:
        return snp_ports

    fixed = {
        "termination": 1, "attenuator": 2, "dc_block": 2, "filter": 2,
        "amplifier": 2, "lna": 2, "isolator": 2, "detector": 2,
    }
    return fixed.get(category)

def _dimensions_from_record(rec):
    """Best-effort physical size from catalog fields, or None.

    Checks free-text size fields (reusing the extract-layer LxWxH parser) and
    explicit numeric length/width/height field trios. Best-effort: catalog
    schemas vary, so a miss is fine (the GUI just shows no size).
    """
    from . import extract  # lazy import to avoid an import cycle
    # Mini-Circuits embeds size in case_style, e.g. "KC3009 LxWxH .059x.059x.024"
    # (inches). This is the primary size source across most MC categories.
    cs = _get(rec, "specs.case_style") or _get(rec, "case_style")
    if isinstance(cs, str):
        m = re.search(r"l\s*x\s*w\s*x\s*h\s*([\d.]+)\s*x\s*([\d.]+)\s*x\s*([\d.]+)",
                      cs, re.I)
        if m:
            try:
                l, w, h = (float(m.group(1)), float(m.group(2)), float(m.group(3)))
                return {"l": l, "w": w, "h": h, "unit": "in",
                        "raw": f"{l:g}×{w:g}×{h:g} in"}
            except ValueError:
                pass
    for key in ("specs.size", "size", "specs.dimensions", "dimensions",
                "specs.package_size", "specs.body_size", "specs.outline",
                "specs.case_size", "outline", "package_size"):
        v = _get(rec, key)
        if isinstance(v, str) and v.strip():
            d = extract._dimensions(v, "")
            if d:
                return d
    # explicit numeric L/W/H trio (values may carry a unit string)
    def _dim_num(paths):
        for p in paths:
            v = _get(rec, p)
            if v not in (None, "", "-"):
                n = _num(v) if not isinstance(v, (int, float)) else float(v)
                if n is not None:
                    unit = "in" if '"' in str(v) or "in" in str(v).lower() else \
                        ("mm" if "mm" in str(v).lower() else ("cm" if "cm" in str(v).lower() else None))
                    return n, unit
        return None, None
    l, ul = _dim_num(("specs.length", "length", "specs.l", "length_in"))
    w, uw = _dim_num(("specs.width", "width", "specs.w", "width_in"))
    h, uh = _dim_num(("specs.height", "height", "specs.h", "height_in", "specs.thickness"))
    if l is not None and w is not None:
        out = {"l": l, "w": w, "unit": ul or uw or uh or "in"}
        if h is not None:
            out["h"] = h
        out["raw"] = "×".join(f"{x:g}" for x in (l, w, h) if x is not None) + f" {out['unit']}"
        return out
    return None


def _space_from_record(rec, category=None):
    """Best-effort space/hi-rel/qualifiable signal from catalog fields.

    Mini-Circuits rarely marks parts per-record, but it up-screens the vast
    majority of its catalog in-house and its LTCC/ceramic/core-&-wire passives
    are explicit space-level screening candidates (app note AN00-018). So parts
    built on those constructions, or any passive from an up-screening vendor, are
    surfaced as 'qualifiable' (upscreenable) rather than blank. Explicit space /
    hi-rel wording, if present anywhere in the record, still wins.
    """
    blob = " ".join(str(v) for v in (
        _get(rec, "specs.technology"), _get(rec, "specs.construction"),
        _get(rec, "specs.case_style"), _get(rec, "group"),
        _get(rec, "desc"), _get(rec, "specs.description"),
        _first(rec, MODEL_KEYS, ""))).lower()
    if re.search(r"class\s*[kvy]\b|qml-?[vy]|\bjans\b|space[-\s]?(?:level|grade|"
                 r"qualified|flight)|\bclass\s*s\b|rad(?:iation)?[-\s]?hard", blob):
        return "qualified"
    if re.search(r"\bhi-?rel\b|mil-?prf-?3853[45]|mil-?std-?883|\bqml\b|"
                 r"\bjantxv?\b|hermetic", blob):
        return "hi_rel"
    ceramic = re.search(r"\bltcc\b|ceramic|core\s*&?\s*wire|hermetic|low[-\s]?temp",
                        blob)
    passive = category in ("attenuator", "filter", "coupler", "divider",
                           "termination", "limiter", "phase_shifter")
    if ceramic or passive:
        return "qualifiable"
    return None


def _structured_specs(rec, category=None):
    s = {}
    fg = _freq_ghz(rec)
    if fg:
        s["freq_ghz"] = fg
    g = _num(_get(rec, "specs.gain"))
    if g is None:
        g = _num(_get(rec, "gain"))
    if g is not None:
        s["gain_db"] = g
    nf = _num(_get(rec, "specs.nf"))
    if nf is None:
        nf = _num(_get(rec, "nf"))
    if nf is not None:
        s["noise_nf_db"] = nf
    for out_key, path in (("p1db_dbm", "specs.p1db"), ("p1db_dbm", "p1db"),
                          ("oip3_dbm", "specs.oip3"), ("oip3_dbm", "oip3"),
                          ("insertion_loss_db", "specs.insertion_loss"),
                          ("isolation_db", "specs.isolation"),
                          ("power_dbm", "specs.power")):
        if out_key not in s:
            val = _num(_get(rec, path))
            if val is not None:
                s[out_key] = val
    vs = (_num(_get(rec, "specs.vswr")) or _num(_get(rec, "vswr"))
          or _num(_get(rec, "specs.input_vswr")))
    if vs is not None:
        s["vswr"] = vs
    ir = _num(_get(rec, "specs.impedance_ratio")) or _num(_get(rec, "impedance"))
    if ir is not None:
        s["impedance_ratio"] = ir
    conn = _connector_value(rec)
    if conn:
        s["connector"] = conn.upper().replace(" ", "")
    mt = _mount_type(rec, conn)
    if mt:
        s["mount_type"] = mt
    z = _impedance_from_pn(_first(rec, MODEL_KEYS, ""))
    if z is not None:
        s["impedance_ohm"] = z
    ports = _rf_ports(rec, category, _first(rec, MODEL_KEYS, ""))
    if ports is not None:
        s["ports"] = ports
    tech = _get(rec, "specs.technology")
    if tech:
        s["technology"] = str(tech)
    # Additional Mini-Circuits catalog fields -> structured specs (from the full
    # catalog field inventory). Best-effort; a missing field is simply skipped.
    for out_key, paths in (
            ("attenuation_db", ("specs.attenuation",)),
            ("psat_dbm", ("specs.psat", "psat")),
            ("coupling_db", ("specs.coupling", "coup_db")),
            ("directivity_db", ("specs.directivity",)),
            ("mainline_loss_db", ("specs.mainline_loss",)),
            ("phase_unbalance_deg", ("specs.phase_unbalance",)),
            ("amplitude_unbalance_db", ("specs.amplitude_unbalance",)),
            ("no_of_ways", ("specs.no_of_ways",)),
            ("power_w", ("specs.power", "specs.power_input", "specs.input_power")),
            ("vswr_in", ("specs.input_vswr", "specs.vswr_in")),
            ("vswr_out", ("specs.output_vswr", "specs.vswr_out")),
            ("current_ma", ("icc_ma",)),
            ("voltage_v", ("specs.voltage", "vcc")),
    ):
        if out_key in s:
            continue
        for p in paths:
            val = _num(_get(rec, p))
            if val is not None:
                s[out_key] = val
                break
    # Fixed-attenuator value from the model name (BAT-3+ -> 3 dB) when the
    # catalog has no attenuation field (only ~40 of 441 do; the rest encode it).
    if category == "attenuator" and "attenuation_db" not in s:
        from . import extract  # lazy import to avoid an import cycle
        av = extract._attenuation_db(_first(rec, MODEL_KEYS, ""), "", "attenuator") \
            if hasattr(extract, "_attenuation_db") else None
        if av is not None:
            s["attenuation_db"] = av
    # Subcategory hint fields (coupler type, divider/hybrid description).
    hint = _get(rec, "specs.e") or _get(rec, "specs.description") or _get(rec, "desc")
    if hint:
        s["subcategory_hint"] = str(hint)
    grp = _get(rec, "group")
    if grp:
        s["group"] = str(grp)
    # power_w sanity: drop nonsense values (some categories reuse 'power' fields
    # for non-watt quantities, e.g. a filter power-rejection figure).
    pw = s.get("power_w")
    if pw is not None and not (0 <= pw <= 5000):
        s.pop("power_w", None)
    sp = _space_from_record(rec, category)
    if sp:
        s["space"] = sp
    ds = _get(rec, "datasheet_url")
    if ds:
        s["datasheet"] = str(ds)
    dims = _dimensions_from_record(rec)
    if dims:
        s["dimensions"] = dims
    return s


# Filter response type (keys match registry.subcategories("filter")). Text first,
# then Mini-Circuits family prefixes as a fallback for terse records.
_FILTER_SUB_TEXT = (
    ("bsf", ("band stop", "bandstop", "band reject", "band-reject", "notch")),
    ("bpf", ("band pass", "bandpass")),
    ("lpf", ("low pass", "lowpass")),
    ("hpf", ("high pass", "highpass")),
    ("diplexer", ("diplexer",)),
    ("duplexer", ("duplexer",)),
)
_MC_FILTER_FAMILY = (
    (re.compile(r"\b(LFCN|LFTC|SLP|VLF|RLP|BLP|NLP|MLP)\b", re.I), "lpf"),
    (re.compile(r"\b(HFCN|SHP|VHF|RHP|BHP|NHP|MHP)\b", re.I), "hpf"),
    (re.compile(r"\b(BFCN|SXBP|SBP|VBF|RBP|BBP|ZABP|ZBPF)\b", re.I), "bpf"),
    (re.compile(r"\b(SXBS|SBS|VBS|RBS|ZBSF|NSBP)\b", re.I), "bsf"),
)


def _filter_subcat(text):
    t = (text or "").lower()
    for key, needles in _FILTER_SUB_TEXT:
        if any(n in t for n in needles):
            return key
    for rx, key in _MC_FILTER_FAMILY:
        if rx.search(text or ""):
            return key
    return ""


def _cat_code(rec):
    v = _first(rec, CATEGORY_KEYS, "")
    if isinstance(v, (list, tuple)):
        v = v[0] if v else ""
    return str(v).strip().lower()


def _canon(code):
    return CODE_TO_CATEGORY.get(code) or (code if code in CATEGORY_SYNONYMS else None)


def _resolve(path_str):
    p = pathlib.Path(path_str).expanduser()
    if p.is_absolute():
        return p
    for base in (PKG_DIR, PKG_DIR / "data", DATA):
        cand = base / path_str
        if cand.exists():
            return cand
    return PKG_DIR / path_str


def load(path_str):
    p = _resolve(path_str)
    if not p.exists():
        raise FileNotFoundError(f"catalog data_file not found: {p}")
    data = json.loads(p.read_text(encoding="utf-8"))
    if isinstance(data, dict):
        for key in ("products", "models", "items", "data", "results"):
            if isinstance(data.get(key), list):
                return repair_catalog(data[key])
        return repair_catalog(list(data.values()))
    if isinstance(data, list):
        return repair_catalog(data)
    return []


def _is_product_url(url):
    """True if a URL looks like an individual product page rather than a catalog,
    landing, or navigation page.

    Real product pages carry a query (e.g. the Mini-Circuits '?model=' parameter)
    or end in a part-number-like segment (one that contains a digit). Section
    pages such as '/Automotive-Applications.html' have neither.
    """
    try:
        parts = urlsplit(str(url))
    except ValueError:
        return False
    if parts.query:
        return True
    last = parts.path.rstrip("/").rsplit("/", 1)[-1]
    return any(ch.isdigit() for ch in last)


def candidates(vendor, spec):
    data_file = vendor.get("data_file")
    if not data_file:
        return []
    records = load(data_file)
    requested = spec.get("category")
    toks = [t.lower() for t in synonyms(requested) if t]
    base = vendor["url"].rstrip("/")
    out = []
    for rec in records:
        if not isinstance(rec, dict):
            continue
        code = _cat_code(rec)
        canon = _canon(code)
        parts = []
        _flatten(rec, parts)
        blob = " ".join(parts)
        if requested:
            if canon is not None:
                if canon != requested:
                    continue
            elif not any(t in (code + " " + blob).lower() for t in toks):
                continue
        model = _first(rec, MODEL_KEYS, "")
        desc = _first(rec, DESC_KEYS, "")
        url = _normalize_url(_first(rec, URL_KEYS), base, model)
        if requested and canon is None and not _is_product_url(url):
            # This record matched only because its free text mentions the
            # category; without a product-looking URL it's a catalog/landing page
            # (e.g. "Automotive Applications"), so skip it.
            continue
        title = " ".join(str(x) for x in (model, desc) if x).strip() or str(url)
        if requested and not any(t in title.lower() for t in toks):
            title = f"{title} — {requested.replace('_', ' ')}"
        text = " ".join(str(x) for x in (model, desc, blob) if x)
        cat = canon or requested
        out.append({"url": str(url), "title": title[:180], "category": cat,
                    "subcategory": (_filter_subcat(text) if cat == "filter" else None),
                    "_catalog": True, "text": text,
                    "_catalog_record": rec,
                    "_catalog_data_file": str(_resolve(data_file)),
                    "_specs": _structured_specs(rec, cat)})
    return out
