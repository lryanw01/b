"""Ephemeral datasheet pipeline: download PDF -> temp file -> parse -> DELETE.

The PDF never persists. What persists (via partdb) is: the mined SpecRow list,
the doc's sha256 + URL + page count, and nothing else. Re-crawls skip a
datasheet whose hash is already recorded at the current parser version.

Extraction is header-driven, never positional:
  pass 1  pdfplumber extract_tables() -> spec-table recognizer. The header row
          is found by fuzzy-matching cell text against {parameter, condition,
          min, typ, max, unit}; every data row's parameter cell is matched
          against PARAM_LEXICON. Columns are addressed BY NAME, so a vendor
          reordering columns can't shift values into the wrong spec (the exact
          failure mode of the old Mini-Circuits positional scrape).
  pass 2  page-text regex mining fills gaps at lower confidence.

Dependencies: requests (or the project's fetch module if importable),
pdfplumber. Both already ship with rfparts v1.
"""
from __future__ import annotations

import hashlib
import io
import os
import re
import tempfile
import time

from . import netfix  # noqa: F401  (process-global TLS fix)
from .partdb import SpecRow

try:                                    # prefer the project's polite fetcher
    from . import fetch as _fetch
except ImportError:
    _fetch = None

import requests

MAX_PDF_BYTES = int(os.environ.get("RFPARTS_MAX_PDF", 25 * 1024 * 1024))

MAX_PAGES = int(os.environ.get("RFPARTS_PDF_PAGES", 6))

UA = {"User-Agent": "rfparts/2.0 (component sourcing; contact: set-me)"}


# --------------------------------------------------------------------------
# Parameter lexicon: canonical key -> (row-label patterns, unit hints, polarity)
# polarity: which bound is the *guarantee* — 'max' (NF, VSWR, loss) or 'min'
# (gain, P1dB, isolation). All three of min/typ/max are stored when present.
# --------------------------------------------------------------------------
PARAM_LEXICON = {
    "nf_db": {
        "labels": [r"noise\s*figure", r"\bNF\b", r"\bSSB\s*NF\b", r"\bDSB\s*NF\b"],
        "units": ("db",), "polarity": "max",
    },
    "gain_db": {
        "labels": [r"(?<!conversion )gain(?!\s*flat)", r"small\s*signal\s*gain",
                   r"\bS21\b"],
        "units": ("db",), "polarity": "min",
    },
    "p1db_dbm": {
        "labels": [r"P\s*1\s*dB", r"output\s*power\s*@?\s*1\s*dB",
                   r"1\s*dB\s*compression", r"\bOP1dB\b"],
        "units": ("dbm",), "polarity": "min",
    },
    "oip3_dbm": {
        "labels": [r"\bOIP3\b", r"output\s*(?:third|3rd)[-\s]*order",
                   r"\bIP3\b(?!.*input)"],
        "units": ("dbm",), "polarity": "min",
    },
    "insertion_loss_db": {
        "labels": [r"insertion\s*loss", r"\bIL\b"],
        "units": ("db",), "polarity": "max",
    },
    "isolation_db": {
        "labels": [r"isolation"],
        "units": ("db",), "polarity": "min",
    },
    "return_loss_db": {
        "labels": [r"return\s*loss", r"\bS11\b", r"\bS22\b"],
        "units": ("db",), "polarity": "min",
    },
    "vswr": {
        "labels": [r"\bVSWR\b", r"\bSWR\b"],
        "units": ("", ":1"), "polarity": "max",
    },
    "attenuation_db": {
        "labels": [r"^attenuation(?!\s*accuracy)", r"attenuation\s*value"],
        "units": ("db",), "polarity": "typ",
    },
    "conversion_loss_db": {
        "labels": [r"conversion\s*loss"],
        "units": ("db",), "polarity": "max",
    },
    "power_w": {
        "labels": [r"(?:input\s*)?power\s*handling", r"\bRF\s*power\b",
                   r"average\s*power"],
        "units": ("w", "watts"), "polarity": "min",
    },
    "vcc_v": {
        "labels": [r"supply\s*voltage", r"\bVcc\b", r"\bVdd\b",
                   r"operating\s*voltage", r"dc\s*voltage"],
        "units": ("v",), "polarity": "typ",
    },
    "icc_ma": {
        "labels": [r"supply\s*current", r"\bIcc\b", r"\bIdd\b",
                   r"operating\s*current", r"dc\s*current"],
        "units": ("ma", "a"), "polarity": "max",
    },
    "temp_c": {
        "labels": [r"operating\s*temp\w*", r"case\s*temp\w*"],
        "units": ("c", "°c", "deg"), "polarity": "range",
    },
    "freq_ghz": {
        "labels": [r"frequency\s*range", r"operating\s*frequency",
                   r"^frequency$", r"passband"],
        "units": ("ghz", "mhz", "khz"), "polarity": "range",
    },
}

_HEADER_ALIASES = {
    "parameter": ("parameter", "characteristic", "description", "item", "spec"),
    "condition": ("condition", "conditions", "test condition", "note"),
    "min": ("min", "min.", "minimum"),
    "typ": ("typ", "typ.", "typical", "nom", "nom.", "nominal"),
    "max": ("max", "max.", "maximum"),
    "unit": ("unit", "units"),
}

_NUM = re.compile(r"[+-]?\d+(?:\.\d+)?")

_RANGE = re.compile(
    r"([+-]?\d+(?:\.\d+)?)\s*(?:-|–|—|to|~)\s*([+-]?\d+(?:\.\d+)?)")

# Frequency range with unit, for band-conditioned spec rows ("NF, 1-6 GHz").
_FREQ_COND = re.compile(
    r"(\d+(?:\.\d+)?)\s*(?:-|–|—|to|~)\s*(\d+(?:\.\d+)?)\s*(GHz|MHz)", re.I)

# Specs vendors commonly quote PER FREQUENCY BAND. When the Conditions (or
# Parameter) cell names a band, the row is stored as "key@lo-hiGHz" so every
# band survives; partdb picks the band overlapping the requested frequency.
# Collapsing to one row per key loses exactly the value the user needs (e.g.
# Marki quotes NF separately for 1-6 GHz and 6-16 GHz).
BANDED_KEYS = {"nf_db", "gain_db", "p1db_dbm", "oip3_dbm", "vswr",
               "return_loss_db", "insertion_loss_db", "isolation_db"}


def _band_of(*cells):
    """(lo_ghz, hi_ghz) named in any of the given cells, else None."""
    for cell in cells:
        m = _FREQ_COND.search(str(cell or ""))
        if m:
            lo, hi, unit = float(m.group(1)), float(m.group(2)), m.group(3)
            if unit.lower() == "mhz":
                lo, hi = lo / 1000.0, hi / 1000.0
            if hi > lo:
                return lo, hi
    return None


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _unlink_retry(path, attempts=5, delay=0.1):
    """Delete a temp PDF, retrying briefly.

    Windows can hold a lock on a just-closed file for a few ms (pdfplumber /
    AV scanners), so a single os.unlink can raise PermissionError. Retries with
    a short backoff. A final miss leaves the file in %TEMP% only -- it is never
    a persisted datasheet -- so we never raise from a cleanup path.
    """
    for i in range(attempts):
        try:
            os.unlink(path)
            return True
        except FileNotFoundError:
            return True
        except OSError:
            time.sleep(delay * (i + 1))
    return False


def download_pdf(url, timeout=30):
    """Stream a PDF to a NamedTemporaryFile. Returns (path, nbytes) or (None, 0).

    Caller MUST unlink the path (parse_datasheet does this for you). Uses the
    project's cached fetch when available so robots/rate limiting apply.
    """
    if _fetch is not None and hasattr(_fetch, "get_bytes"):
        try:
            body = _fetch.get_bytes(url)
        except Exception:
            body = None
        if body:
            if len(body) > MAX_PDF_BYTES:
                return None, 0
            tmp = tempfile.NamedTemporaryFile(suffix=".pdf", delete=False)
            tmp.write(body)
            tmp.close()
            return tmp.name, len(body)
    # Fallback: direct streamed GET with size guard.
    try:
        with requests.get(url, headers=UA, stream=True, timeout=timeout) as r:
            r.raise_for_status()
            clen = int(r.headers.get("Content-Length") or 0)
            if clen > MAX_PDF_BYTES:
                return None, 0
            tmp = tempfile.NamedTemporaryFile(suffix=".pdf", delete=False)
            n = 0
            for chunk in r.iter_content(1 << 16):
                n += len(chunk)
                if n > MAX_PDF_BYTES:
                    tmp.close()
                    _unlink_retry(tmp.name)
                    return None, 0
                tmp.write(chunk)
            tmp.close()
            return tmp.name, n
    except requests.RequestException:
        return None, 0


# --------------------------------------------------------------------------
# Table recognizer
# --------------------------------------------------------------------------

def _clean(cell):
    return re.sub(r"\s+", " ", str(cell or "")).strip()


def _header_map(row):
    """Map column index -> semantic name if this row looks like a spec header."""
    mapping = {}
    for idx, cell in enumerate(row):
        text = _clean(cell).lower().rstrip(":")
        for name, aliases in _HEADER_ALIASES.items():
            if text in aliases and name not in mapping.values():
                mapping[idx] = name
                break
    names = set(mapping.values())
    # A usable header names the parameter column and at least one value column.
    if "parameter" in names and names & {"min", "typ", "max"}:
        return mapping
    return None


def _match_param(label):
    low = _clean(label).lower()
    if not low:
        return None
    for key, meta in PARAM_LEXICON.items():
        for pat in meta["labels"]:
            if re.search(pat, low, re.I):
                return key
    return None


def _num_or_none(text):
    m = _NUM.search(_clean(text))
    return float(m.group()) if m else None


def _freq_to_ghz(val, unit_text):
    u = unit_text.lower()
    if "mhz" in u:
        return val / 1000.0
    if "khz" in u:
        return val / 1e6
    return val


def _rows_from_table(table, source_url):
    """Yield SpecRow objects from one pdfplumber table."""
    header = None
    for row in table:
        if header is None:
            header = _header_map(row)
            continue
        cols = {name: _clean(row[idx]) if idx < len(row) else ""
                for idx, name in header.items()}
        key = _match_param(cols.get("parameter", ""))
        if not key:
            continue
        meta = PARAM_LEXICON[key]
        unit = cols.get("unit", "")
        vmin = _num_or_none(cols.get("min", ""))
        vtyp = _num_or_none(cols.get("typ", ""))
        vmax = _num_or_none(cols.get("max", ""))
        # Range-style specs (frequency, temperature): min/max ARE the range; a
        # single "1-6 GHz" string in typ also counts.
        if meta["polarity"] == "range":
            if vmin is None and vmax is None:
                m = _RANGE.search(cols.get("typ", "") or cols.get("parameter", ""))
                if m:
                    vmin, vmax = float(m.group(1)), float(m.group(2))
            if vmin is None or vmax is None:
                continue
            if key == "freq_ghz":
                vmin = _freq_to_ghz(vmin, unit)
                vmax = _freq_to_ghz(vmax, unit)
        if vmin is None and vtyp is None and vmax is None:
            continue
        # Unit sanity: reject a match whose unit column contradicts the lexicon
        # (e.g. "Gain ... MHz" is a mis-hit).
        hints = meta["units"]
        if hints and unit and not any(h and h in unit.lower() for h in hints):
            if key not in ("vswr",):        # vswr is often unitless
                continue
        if key == "icc_ma" and unit.lower().strip() == "a":
            vmin, vtyp, vmax = [v * 1000 if v is not None else None
                                for v in (vmin, vtyp, vmax)]
        snippet = " | ".join(v for v in (cols.get("parameter"),
                                         cols.get("condition"),
                                         cols.get("min"), cols.get("typ"),
                                         cols.get("max"), unit) if v)
        out_key = key
        if key in BANDED_KEYS:
            band = _band_of(cols.get("condition"), cols.get("parameter"))
            if band:
                out_key = f"{key}@{band[0]:g}-{band[1]:g}GHz"
        yield SpecRow(key=out_key, value_min=vmin, value_typ=vtyp,
                      value_max=vmax, unit=unit, method="table",
                      confidence=0.9, source_url=source_url, snippet=snippet)


# --------------------------------------------------------------------------
# Regex fallback over page text
# --------------------------------------------------------------------------

_TEXT_PATTERNS = {
    "nf_db": [r"noise\s*figure[^.\n\r]{0,40}?(\d+(?:\.\d+)?)\s*dB",
              r"\bNF\b[^.\n\r]{0,20}?(\d+(?:\.\d+)?)\s*dB"],
    "gain_db": [r"gain[^.\n\r]{0,40}?(\d{1,2}(?:\.\d+)?)\s*dB\b"],
    "p1db_dbm": [r"P\s*1\s*dB[^.\n\r]{0,30}?([+-]?\d+(?:\.\d+)?)\s*dBm"],
    "oip3_dbm": [r"OIP3[^.\n\r]{0,30}?([+-]?\d+(?:\.\d+)?)\s*dBm"],
}

_FREQ_TEXT = [
    (re.compile(r"(\d+(?:\.\d+)?)\s*(?:GHz)?\s*(?:-|–|—|to)\s*(\d+(?:\.\d+)?)\s*GHz", re.I), 1.0),
    (re.compile(r"\bDC\s*(?:-|–|—|to)\s*(\d+(?:\.\d+)?)\s*GHz", re.I), 1.0),
    (re.compile(r"(\d+(?:\.\d+)?)\s*(?:MHz)?\s*(?:-|–|—|to)\s*(\d+(?:\.\d+)?)\s*MHz", re.I), 1e-3),
]


def _rows_from_text(text, source_url, have_keys):
    for key, pats in _TEXT_PATTERNS.items():
        if key in have_keys:
            continue
        for pat in pats:
            m = re.search(pat, text, re.I)
            if m:
                yield SpecRow(key=key, value_typ=float(m.group(1)),
                              method="regex", confidence=0.6,
                              source_url=source_url,
                              snippet=m.group(0)[:120])
                break
    if "freq_ghz" not in have_keys:
        for pat, scale in _FREQ_TEXT:
            m = pat.search(text)
            if m:
                g = m.groups()
                lo, hi = (0.0, float(g[0])) if len(g) == 1 else (float(g[0]), float(g[1]))
                yield SpecRow(key="freq_ghz", value_min=lo * scale,
                              value_max=hi * scale, unit="GHz",
                              method="regex", confidence=0.6,
                              source_url=source_url, snippet=m.group(0)[:120])
                break


# --------------------------------------------------------------------------
# Top-level entry
# --------------------------------------------------------------------------

def parse_datasheet(url):
    """Download, mine, DISCARD. Returns (spec_rows, sha256, nbytes, pages) —
    ([], None, 0, 0) on failure. The temp PDF is always deleted."""
    import pdfplumber                    # deferred: slow import

    path, nbytes = download_pdf(url)
    if not path:
        return [], None, 0, 0
    try:
        sha = _sha256_file(path)
        rows, pages_parsed = [], 0
        with pdfplumber.open(path) as pdf:
            for page in pdf.pages[:MAX_PAGES]:
                pages_parsed += 1
                try:
                    for table in (page.extract_tables() or []):
                        rows.extend(_rows_from_table(table, url))
                except Exception:
                    pass                 # tables are best-effort per page
            have = {r.key for r in rows}
            text = "\n".join((p.extract_text() or "")
                             for p in pdf.pages[:MAX_PAGES])
            rows.extend(_rows_from_text(text, url, have))
        # Keep only the highest-confidence row per key.
        best = {}
        for r in rows:
            if r.key not in best or r.confidence > best[r.key].confidence:
                best[r.key] = r
        return list(best.values()), sha, nbytes, pages_parsed
    except Exception:
        return [], None, nbytes, 0
    finally:
        _unlink_retry(path)              # the whole point: the PDF does not persist


def datasheet_text_for_qual(url, max_pages=8):
    """Fetch + full-text a datasheet for the space-qual engine, then discard.
    Returns '' on failure. Used when qual evidence, not specs, is the target."""
    import pdfplumber

    path, _ = download_pdf(url)
    if not path:
        return ""
    try:
        with pdfplumber.open(path) as pdf:
            return "\n".join((p.extract_text() or "") for p in pdf.pages[:max_pages])
    except Exception:
        return ""
    finally:
        _unlink_retry(path)


def rows_from_page_text(text, source_url):
    """Mine specs from PRODUCT-PAGE text (no datasheet available). Same regex
    lexicon as the PDF fallback pass, at page-level confidence, plus simple
    'Label: value' table rows that aggregator pages (SATNow) render as HTML.
    """
    rows = list(_rows_from_text(text, source_url, set()))
    have = {r.key for r in rows}
    # 'Frequency: 2 to 6 GHz' / 'Noise Figure: 1.5 dB' label-style lines
    lab = re.findall(
        r"(Frequency|Gain|Noise\s*Figure|P1dB|OIP3|VSWR)\s*[:\-]\s*"
        r"([^\n<]{1,60})", text, re.I)
    keymap = {"frequency": "freq_ghz", "gain": "gain_db",
              "noise figure": "nf_db", "p1db": "p1db_dbm",
              "oip3": "oip3_dbm", "vswr": "vswr"}
    for label, val in lab:
        key = keymap.get(re.sub(r"\s+", " ", label.lower()))
        if not key or key in have:
            continue
        if key == "freq_ghz":
            m = _FREQ_COND.search(val) or _RANGE.search(val)
            if m:
                lo, hi = float(m.group(1)), float(m.group(2))
                unit = (m.group(3) if m.lastindex and m.lastindex >= 3 else "GHz")
                if str(unit).lower() == "mhz":
                    lo, hi = lo / 1000, hi / 1000
                rows.append(SpecRow(key="freq_ghz", value_min=lo, value_max=hi,
                                    unit="GHz", method="page", confidence=0.5,
                                    source_url=source_url, snippet=f"{label}: {val}"[:120]))
                have.add(key)
            continue
        m = _NUM.search(val)
        if m:
            rows.append(SpecRow(key=key, value_typ=float(m.group()),
                                method="page", confidence=0.5,
                                source_url=source_url,
                                snippet=f"{label}: {val}"[:120]))
            have.add(key)
    for r in rows:
        if r.method == "regex":
            r.confidence = 0.5          # page prose < datasheet prose
    return rows
