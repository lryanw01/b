"""Per-vendor cache of extracted specs, so re-runs only fetch/mine new URLs.

The raw-page cache in fetch.py stops re-downloading, but extract still re-parses
those bytes (PDF parsing is slow) on every run. This stores the *mined result*
keyed by URL, in a separate JSON per vendor (specs_<vendor>.json under
$RFPARTS_HOME), so a URL already seen is skipped entirely next time. Delete a
file to force a fresh extraction for that vendor.
"""
import json
import re
import time

from .registry import DATA

SPECS_TTL = 30 * 86400
PARSER_VERSION = 6  # bump when extract/catalog/digikey spec mining changes


def _path(vendor):
    slug = re.sub(r"[^a-z0-9]+", "-", vendor.lower()).strip("-") or "vendor"
    return DATA / f"specs_{slug}.json"


def load(vendor):
    p = _path(vendor)
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def get(store, url):
    row = store.get(url)
    if not row or time.time() - row.get("ts", 0) > SPECS_TTL:
        return None
    if row.get("parser_version") != PARSER_VERSION:
        return None
    return row.get("specs")


def put(store, url, specs):
    store[url] = {"ts": time.time(), "parser_version": PARSER_VERSION, "specs": specs}


def save(vendor, store):
    try:
        _path(vendor).write_text(json.dumps(store), encoding="utf-8")
    except OSError:
        pass
