"""Ingest the Qorvo defense & aerospace solutions brochure (.pdf) into partdb.

Reads the LOCAL brochure PDF — no network. The brochure is a set of parametric
selector tables (amplifiers, LNAs, mixers, switches, attenuators, limiters,
phase shifters, filters, beamformers, transistors). Each table is parsed by its
own header row, so a page that mixes table types classifies each table on its
own signature rather than the page title alone.

Every part is treated as space-ready (Qorvo runs a space screening &
qualification flow; the whole brochure targets defense/space). Parts are marked
space="qualified", space_variant="space_grade" — the RF parametrics carry the
real selection value:
    freq_ghz (range), gain_db, nf_db, p1db_dbm, oip3_dbm, psat_dbm/power_w,
    insertion_loss_db, isolation_db, conversion_loss_db, attenuation_db, package

Run:
    python -m rfparts.qorvo_ingest "C:\\path\\qorvo-...-brochure.pdf"
    python -m rfparts.qorvo_ingest FILE --dry-run --verbose
"""
from __future__ import annotations

import argparse
import re
import warnings
from collections import Counter
from pathlib import Path

import pdfplumber

try:
    from .partdb import SpecRow, upsert_part, put_specs, put_evidence
except ImportError:
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from rfparts.partdb import (                        # type: ignore
        SpecRow, upsert_part, put_specs, put_evidence)

warnings.filterwarnings("ignore")
VENDOR = "Qorvo"
BASE = "https://www.qorvo.com/products/p/"

_NUM = re.compile(r"[-+]?\d+(?:\.\d+)?")
_RANGE = re.compile(r"([-+]?\d+(?:\.\d+)?)\s*(?:to|–|—|-|/)\s*([-+]?\d+(?:\.\d+)?)")


def _norm(h) -> str:
    return re.sub(r"\s+", " ", str(h or "").replace("\n", " ").strip().lower())


def _first_num(text):
    m = _NUM.search(str(text or "").replace("<", "").replace(">", ""))
    return float(m.group()) if m else None


def _freq_range(text, default_unit="GHz"):
    """'DC-20' / '2-18' / '0.03-2.5' / '8' -> (lo, hi) GHz, or None."""
    t = str(text or "").strip()
    if not t or t in ("–", "—", "-"):
        return None
    unit = "MHz" if "mhz" in t.lower() else default_unit
    scale = 1e-3 if unit == "MHz" else 1.0
    dc = re.search(r"\bdc\b", t, re.I) is not None
    # unsigned: frequencies are never negative, and a signed regex would read the
    # range separator ("2-18") as a minus sign and flip the band.
    nums = re.findall(r"\d+(?:\.\d+)?", re.sub(r"(?i)dc", "0", t))
    if not nums:
        return (0.0, 0.0) if dc else None
    vals = [float(n) * scale for n in nums[:2]]
    if len(vals) == 1:
        lo = 0.0 if dc else vals[0]
        return (min(lo, vals[0]), max(lo, vals[0]))
    return (min(vals), max(vals))


# normalized-header substring -> (spec key, unit, kind)
#   kind "typ" stores the first number as value_typ; "min" stores as value_typ
#   too (single-column typ values). Frequency + part are handled specially.
_COLMAP = [
    ("nf", ("nf_db", "dB", "typ")),
    ("oip3", ("oip3_dbm", "dBm", "typ")),
    ("iip3", ("oip3_dbm", "dBm", "typ")),
    ("op1db", ("p1db_dbm", "dBm", "typ")),
    ("p1db", ("p1db_dbm", "dBm", "typ")),
    ("conver", ("conversion_loss_db", "dB", "typ")),
    ("insertion", ("insertion_loss_db", "dB", "typ")),
    ("il (", ("insertion_loss_db", "dB", "typ")),
    ("iso", ("isolation_db", "dB", "typ")),
    ("attenuation", ("attenuation_db", "dB", "typ")),
    ("gain", ("gain_db", "dB", "typ")),
]


def _classify_table(headers, page_header):
    """Canonical category for a table from its own header signature, then the
    page title as a fallback."""
    hs = " | ".join(headers)
    ph = page_header.lower()
    if "switch type" in hs or "abs/" in hs:
        return "switch", ""
    if "attenuator range" in hs or ("attenuation" in hs and "bits" in hs) \
            or "number bits" in hs:
        return "attenuator", ""
    if "phase err" in hs:
        return "phase_shifter", ""
    if "conver. loss" in hs or "conversion" in hs or "lo drive" in hs \
            or "lo-rf" in hs:
        return "mixer", ""
    if "flat leakage" in hs:
        return "limiter", ""
    if "bands" in hs and "technology" in hs:
        return "filter", "bpf"
    if "ic type" in hs or "beamformer" in hs or "beamformer" in ph:
        return "beamformer", ""
    if "tx gain" in hs or "rx gain" in hs:
        return "amplifier", ""       # integrated front-end module
    # page-title fallback
    for needle, canon, sub in (
            ("low noise amplifier", "amplifier", "lna"), ("lna", "amplifier", "lna"),
            ("power amplifier", "amplifier", "pa"),
            ("distributed amplifier", "amplifier", ""),
            ("power transistor", "amplifier", ""), ("pallet", "amplifier", ""),
            ("amplifier", "amplifier", ""),
            ("limiter", "limiter", ""), ("mixer", "mixer", ""),
            ("phase shifter", "phase_shifter", ""),
            ("vector modulator", "phase_shifter", ""),
            ("attenuator", "attenuator", ""), ("switch", "switch", ""),
            ("filter", "filter", ""), ("beamformer", "beamformer", ""),
            ("multiplier", "frequency_multiplier", ""),
            ("front-end", "amplifier", ""), ("converter", "mixer", "")):
        if needle in ph:
            return canon, sub
    # header-based last resort
    if "nf" in hs and "gain" in hs:
        return "amplifier", "lna"
    if "psat" in hs or "pae" in hs:
        return "amplifier", ""
    return "", ""


def _valid_pn(tok: str) -> bool:
    tok = tok.strip()
    return (3 <= len(tok) <= 24 and any(c.isalpha() for c in tok)
            and any(c.isdigit() for c in tok)
            and re.fullmatch(r"[A-Za-z0-9./\-]+", tok) is not None)


def parse_pdf(path: Path):
    with pdfplumber.open(str(path)) as pdf:
        for page in pdf.pages:
            text = page.extract_text() or ""
            page_header = text.split("\n", 1)[0][:80]
            for table in page.extract_tables():
                if not table or len(table) < 2:
                    continue
                headers = [_norm(c) for c in table[0]]
                if not any("part" in h for h in headers):
                    continue          # no part-number column -> not a selector
                pn_col = next(i for i, h in enumerate(headers) if "part" in h)
                fmin = next((i for i, h in enumerate(headers)
                             if "freq" in h and "min" in h), None)
                fmax = next((i for i, h in enumerate(headers)
                             if "freq" in h and "max" in h), None)
                frange = next((i for i, h in enumerate(headers)
                               if "freq" in h and "min" not in h and "max" not in h),
                              None)
                pkg_col = next((i for i, h in enumerate(headers)
                                if "package" in h or "dimension" in h), None)
                category, subcat = _classify_table(headers, page_header)
                yield from _emit_rows(table[1:], headers, pn_col, fmin, fmax,
                                      frange, pkg_col, category, subcat, page_header)


def _emit_rows(rows, headers, pn_col, fmin, fmax, frange, pkg_col,
               category, subcat, page_header):
    for row in rows:
        if pn_col >= len(row) or not row[pn_col]:
            continue
        raw_pn = str(row[pn_col]).replace("\n", " ").strip()
        # "CMD275P4/CMD275" -> two orderable variants sharing the specs
        pns = [p.strip() for p in raw_pn.split("/") if _valid_pn(p)]
        if not pns:
            continue
        spec_rows = []

        def add(key, unit, val, snippet):
            if val is not None:
                spec_rows.append(SpecRow(
                    key=key, value_typ=val, unit=unit, method="table",
                    confidence=0.7, source_url="", snippet=snippet[:120]))

        # frequency
        fr = None
        if fmin is not None and fmax is not None and fmin < len(row) and fmax < len(row):
            lo = _freq_range(row[fmin])
            hi = _freq_range(row[fmax])
            if lo and hi:
                fr = (lo[0], hi[1] if hi[1] else hi[0])
        if fr is None and frange is not None and frange < len(row):
            fr = _freq_range(row[frange])
        # column-mapped numeric specs
        for i, h in enumerate(headers):
            if i in (pn_col, fmin, fmax, frange, pkg_col) or i >= len(row):
                continue
            for needle, (key, unit, _kind) in _COLMAP:
                if needle in h:
                    # Psat may be in W (high-power GaN page) -> power_w
                    if "psat" in h and ("(w)" in h or " w" in h):
                        add("power_w", "W", _first_num(row[i]), f"{h}: {row[i]}")
                    else:
                        add(key, unit, _first_num(row[i]), f"{h}: {row[i]}")
                    break
            else:
                if "psat" in h:
                    if "(w)" in h:
                        add("power_w", "W", _first_num(row[i]), f"{h}: {row[i]}")
                    else:
                        add("psat_dbm", "dBm", _first_num(row[i]), f"{h}: {row[i]}")
        pkg_text = ""
        if pkg_col is not None and pkg_col < len(row) and row[pkg_col]:
            pkg_text = str(row[pkg_col]).replace("\n", " ").strip()

        for pn in pns:
            yield {
                "mpn": pn, "category": category, "subcategory": subcat,
                "freq": fr, "spec_rows": list(spec_rows),
                "package": pkg_text, "section": page_header,
            }


def _write(part: dict) -> int:
    url = BASE + re.sub(r"[^A-Za-z0-9]", "", part["mpn"])
    pid = upsert_part(mpn=part["mpn"], vendor=VENDOR, category=part["category"],
                      subcategory=part["subcategory"], product_url=url,
                      description=f"Qorvo {part['section']}".strip())
    rows = []
    for r in part["spec_rows"]:
        r.source_url = url
        rows.append(r)
    if part["freq"]:
        lo, hi = part["freq"]
        rows.append(SpecRow(key="freq_ghz", value_min=lo, value_max=hi, unit="GHz",
                            method="table", confidence=0.7, source_url=url,
                            snippet=f"frequency {lo:g}-{hi:g} GHz"))
    if part["package"]:
        rows.append(SpecRow(key="package", value_text=part["package"][:120],
                            method="table", confidence=0.6, source_url=url,
                            snippet="Qorvo package/size"))
    rows.append(SpecRow(key="space", value_text="qualified", method="catalog",
                        confidence=0.8, source_url=url,
                        snippet="Qorvo defense/aerospace brochure"))
    rows.append(SpecRow(key="space_variant", value_text="space_grade",
                        method="catalog", confidence=0.8, source_url=url,
                        snippet="Qorvo space screening & qualification flow"))
    put_specs(pid, rows)
    put_evidence(pid, [("qorvo-aerospace-brochure", 7.0, url,
                        f"Qorvo defense/aerospace brochure — {part['section']}"[:150])])
    return pid


def ingest(path: Path, dry_run: bool = False, verbose: bool = False) -> dict:
    path = Path(path)
    if not path.is_file():
        raise SystemExit(f"file not found: {path}")
    best: dict[str, dict] = {}
    counts = Counter()
    for part in parse_pdf(path):
        counts["rows"] += 1
        if not part["category"]:
            counts["no_category"] += 1
            continue
        key = re.sub(r"\s+", "", part["mpn"]).upper()
        prev = best.get(key)
        # keep the richest (most spec rows) instance of a repeated part number
        if prev is None or len(part["spec_rows"]) > len(prev["spec_rows"]):
            best[key] = part
    for part in best.values():
        counts["parts"] += 1
        if verbose:
            print(f"  {part['mpn']:<16} {part['category']:<14} "
                  f"{len(part['spec_rows'])} specs  [{part['section'][:30]}]")
        if not dry_run:
            _write(part)
    return dict(counts)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file", help="Qorvo defense/aerospace brochure .pdf")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args(argv)
    c = ingest(Path(args.file), args.dry_run, args.verbose)
    print("\n=== Qorvo brochure ingest "
          + ("(dry run) ===" if args.dry_run else "===")
          + f"\n  table rows scanned {c.get('rows', 0)}"
          + f"\n  unique parts       {c.get('parts', 0)}"
          + (f"\n  skipped (no category) {c['no_category']}"
             if c.get("no_category") else ""))
    if args.dry_run:
        print("  (nothing written -- drop --dry-run to commit)")


if __name__ == "__main__":
    main()
