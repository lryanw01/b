"""Ingest the RF sections of the Texas Instruments Space Products Guide (.pdf).

Reads the LOCAL guide PDF -- no network.

RF-ONLY BY DESIGN. The guide is overwhelmingly a rad-hard *IC* catalog (power
management, data converters, logic, interface, sensors, op-amps). Ingesting all
of it buried the RF dataset under ~380 non-RF parts with no frequency at all, so
this adapter now ingests ONLY the guide's genuinely RF tables:

    Low-Noise Amplifiers (LNAs)             -> amplifier / lna
    RF Fully Differential Amplifiers (FDAs) -> amplifier
    RF PLLs and Synthesizers                -> synthesizer

Deliberately skipped: "RF-Sampling Transceivers" (a converter SoC whose table
carries no parseable frequency columns) and every non-RF table. To narrow this
further -- e.g. LNAs only -- delete entries from _RF_SECTIONS below.

Frequency units differ per table (the LNA and PLL tables are MHz, the RF FDA
table is GHz), so the unit is read from each table's own header block and
converted to GHz; a table whose unit can't be determined contributes no
frequency rather than a wrong one.

TI space suffixes -> pedigree:
    -SP / QML-SP    radiation-hardened, QMLV / class V   -> space_qualified
    -SEP            space enhanced plastic               -> space_grade
    -EP -HB -HT     enhanced/hi-rel companion            -> space_grade

Run:
    python -m rfparts.ti_ingest "C:\\path\\slyt532l.pdf" --dry-run --verbose
"""
from __future__ import annotations

import argparse
import re
import warnings
from collections import Counter
from pathlib import Path

import pdfplumber

try:
    from .partdb import SpecRow, upsert_part, put_specs, put_evidence
except ImportError:
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from rfparts.partdb import (                        # type: ignore
        SpecRow, upsert_part, put_specs, put_evidence)

warnings.filterwarnings("ignore")
VENDOR = "Texas Instruments"

# --- which tables to take ---------------------------------------------------
# heading substring (lowercased) -> how to file the parts in it.
#   category    canonical pipeline category
#   subcategory canonical subcategory key ('' for none)
#   params      True to also parse P1dB / gain / OIP3 / NF (amplifier layout)
_RF_SECTIONS = {
    "low-noise amplifiers": dict(category="amplifier", subcategory="lna",
                                 params=True, what="LNA"),
    "rf fully differential amplifiers": dict(category="amplifier", subcategory="",
                                             params=True, what="RF FDA"),
    "rf plls and synthesizer": dict(category="synthesizer", subcategory="",
                                    params=False, what="RF PLL/synthesizer"),
}

# Lines belonging to a table's multi-line column header (never a new section).
_HEADER_HINTS = (
    "qualifi", "military", "part number", "tid", "sel", "krad", "mev", "spec",
    "level", "freq", "noise", "output", "package", "supply", "voltage",
    "available", "ecc", "typ", "max", "min", "group", "res.", "channels",
    "number of", "(v)", "(db", "(ghz)", "(mhz)", "features", "input",
)

_PN = re.compile(r"^([A-Z][A-Z0-9]{2,}(?:QML)?)-(SP|SEP|EP|HB|HT|SPHT|HR|HIREL)\b")
_FREQ_UNIT_PAIR = re.compile(r"\((MHz|GHz)\)\s*\((MHz|GHz)\)", re.I)
_NUMERIC = re.compile(r"^[-+]?\d+(?:\.\d+)?$")
_RANGE_JOIN = re.compile(r"^(?:-|–|—|to)$", re.I)

# sanity windows: a mis-parsed column is dropped rather than stored
_LIMITS = {"p1db_dbm": (-40.0, 45.0), "gain_db": (0.0, 60.0),
           "oip3_dbm": (-20.0, 70.0), "nf_db": (0.0, 25.0)}


def _variant(suffix, qml):
    s = suffix.upper()
    if s == "SP" or qml:
        return "space_qualified", f"TI -{s}{' QML' if qml else ''} (rad-hard/QMLV)"
    if s in ("HIREL", "HR"):
        return "space_qualified", "TI hi-rel"
    return "space_grade", f"TI -{s} (space-grade companion)"


def _is_header_line(line):
    low = line.lower()
    return any(h in low for h in _HEADER_HINTS)


def _section_of(line):
    """The RF section config for a heading line, or None."""
    low = line.strip().lower()
    for needle, cfg in _RF_SECTIONS.items():
        if low.startswith(needle) or low == needle:
            return cfg
    return None


def _looks_like_heading(line):
    """A table title: not a data row and not part of a column header block."""
    s = line.strip()
    if not s or _PN.match(s) or _is_header_line(s):
        return False
    return bool(re.match(r"^[A-Z0-9]", s)) and len(s) < 70


def _normalize_minus(line):
    """En/em dashes used as MINUS signs become ASCII '-'. A dash preceded by a
    digit is a range separator and is left alone, so '-236' converts while
    '0.6-10.2' does not."""
    return re.sub(r"(?<![\d.])[\u2013\u2212](?=\s?\d)", "-", line)


def _tokens(line):
    """Whitespace tokens with numeric ones parsed. Values may carry a comparator
    or a parenthetical condition ('<0.85', '12 (2GHz)'); parentheticals become
    their own non-numeric token and are ignored."""
    out = []
    for raw in _normalize_minus(line).split():
        t = raw.strip().lstrip("<>~\u2264\u2265").rstrip(",;")
        out.append((raw, float(t) if _NUMERIC.match(t) else None))
    return out


def _find_anchor(nums_idx, tokens):
    """Index (into tokens) just past the TID / TID-RLAT / SEL integer triple that
    precedes the data columns in every table of this guide."""
    for a in range(len(nums_idx) - 2):
        i, j, k = nums_idx[a], nums_idx[a + 1], nums_idx[a + 2]
        if j == i + 1 and k == j + 1:
            vals = [tokens[i][1], tokens[j][1], tokens[k][1]]
            if all(v is not None and v >= 0 and float(v).is_integer()
                   and v <= 1000 for v in vals):
                return k + 1
    return None


def _parse_row(line, unit, want_params):
    """One data row -> dict, or None when it isn't a part row."""
    s = line.strip()
    m = _PN.match(s)
    if not m:
        return None
    base_raw, suffix = m.group(1), m.group(2)
    qml = base_raw.endswith("QML")
    base = base_raw[:-3] if qml else base_raw
    mpn = f"{base_raw}-{suffix}"
    variant, reason = _variant(suffix, qml)
    rec = {"mpn": mpn, "base": base, "suffix": suffix,
           "variant": variant, "reason": reason}

    tokens = _tokens(s)
    nums_idx = [i for i, (_r, v) in enumerate(tokens) if v is not None]
    start = _find_anchor(nums_idx, tokens)
    if start is None:
        return rec

    # frequency: the first two NON-NEGATIVE numbers after the TID/SEL triple
    # (the PLL table puts negative phase-noise figures in between).
    freq_positions = [i for i in nums_idx if i >= start and tokens[i][1] >= 0][:2]
    if len(freq_positions) == 2 and unit:
        lo, hi = (tokens[freq_positions[0]][1], tokens[freq_positions[1]][1])
        if unit.lower() == "mhz":
            lo, hi = lo / 1e3, hi / 1e3
        if hi < lo:
            lo, hi = hi, lo
        if 0 <= lo <= hi <= 1000:
            rec["freq_ghz"] = (round(lo, 6), round(hi, 6))

    if not (want_params and len(freq_positions) == 2):
        return rec

    # after the frequency pair: supply voltage (a single value or a range),
    # then P1dB, gain, OIP3/IP3, NF in that column order.
    rest = [i for i in nums_idx if i > freq_positions[1]]
    if not rest:
        return rec
    cursor = 1                                  # consume the supply value
    if len(rest) > 1:
        between = tokens[rest[0] + 1:rest[1]]
        if any(_RANGE_JOIN.match(r.strip()) for r, _v in between):
            cursor = 2                          # supply was a range, e.g. 1.8 - 3.3
    for key, pos in zip(("p1db_dbm", "gain_db", "oip3_dbm", "nf_db"),
                        rest[cursor:cursor + 4]):
        val = tokens[pos][1]
        lo, hi = _LIMITS[key]
        if lo <= val <= hi:
            rec[key] = val
    return rec


def parse_pdf(path):
    """Yield part records from the RF sections only."""
    with pdfplumber.open(str(path)) as pdf:
        for page in pdf.pages:
            section = None
            unit = ""
            for line in (page.extract_text() or "").split("\n"):
                s = line.strip()
                if not s:
                    continue
                hit = _section_of(s)
                if hit is not None:               # entering an RF table
                    section, unit = hit, ""
                    continue
                if section is None:
                    continue
                if _PN.match(s):                 # data row
                    rec = _parse_row(s, unit, section["params"])
                    if rec:
                        rec["category"] = section["category"]
                        rec["subcategory"] = section["subcategory"]
                        rec["section"] = section["what"]
                        yield rec
                    continue
                if _is_header_line(s):           # column header: learn the unit
                    um = _FREQ_UNIT_PAIR.search(s)
                    if um:
                        unit = um.group(1)
                    continue
                if _looks_like_heading(s):       # a different table starts
                    section, unit = None, ""


def _write(rec):
    url = f"https://www.ti.com/product/{rec['base']}"
    pid = upsert_part(mpn=rec["mpn"], vendor=VENDOR, category=rec["category"],
                      subcategory=rec.get("subcategory", ""), product_url=url,
                      description=f"TI space {rec['section']}".strip()[:200])
    rows = [
        SpecRow(key="ti_suffix", value_text=rec["suffix"], method="catalog",
                confidence=0.9, source_url=url, snippet=rec["reason"][:120]),
        SpecRow(key="space", value_text="qualified", method="catalog",
                confidence=0.9, source_url=url, snippet=rec["reason"][:120]),
        SpecRow(key="space_variant", value_text=rec["variant"], method="catalog",
                confidence=0.9, source_url=url, snippet=rec["reason"][:120]),
    ]
    if rec.get("freq_ghz"):
        lo, hi = rec["freq_ghz"]
        rows.append(SpecRow(key="freq_ghz", value_min=lo, value_max=hi, unit="GHz",
                            method="catalog", confidence=0.85, source_url=url,
                            snippet=f"{rec['section']} table"))
    for key, unit in (("p1db_dbm", "dBm"), ("gain_db", "dB"),
                      ("oip3_dbm", "dBm"), ("nf_db", "dB")):
        if rec.get(key) is not None:
            rows.append(SpecRow(key=key, value_typ=rec[key], unit=unit,
                                method="catalog", confidence=0.8, source_url=url,
                                snippet=f"{rec['section']} table"))
    put_specs(pid, rows)
    signal = ("ti-space-products-guide-qualified"
              if rec["variant"] == "space_qualified"
              else "ti-space-products-guide-grade")
    weight = 9.0 if rec["variant"] == "space_qualified" else 7.0
    put_evidence(pid, [(signal, weight, url, rec["reason"])])
    return pid


def ingest(path, dry_run=False, verbose=False):
    path = Path(path)
    if not path.is_file():
        raise SystemExit(f"file not found: {path}")
    best = {}
    for rec in parse_pdf(path):
        key = rec["mpn"].upper()
        prev = best.get(key)
        # keep the richest record; qualified beats grade for the same PN
        if (prev is None
                or (prev["variant"] == "space_grade"
                    and rec["variant"] == "space_qualified")
                or (len(rec) > len(prev))):
            best[key] = rec
    counts = Counter()
    for rec in best.values():
        counts["parts"] += 1
        counts[rec["variant"]] += 1
        if rec.get("freq_ghz"):
            counts["with_freq"] += 1
        if verbose:
            f = rec.get("freq_ghz")
            fs = f"{f[0]:g}-{f[1]:g} GHz" if f else "no freq"
            extra = " ".join(f"{k}={rec[k]:g}" for k in
                             ("gain_db", "nf_db", "p1db_dbm", "oip3_dbm")
                             if rec.get(k) is not None)
            print(f"  {rec['mpn']:<16} {rec['category']:<12} {fs:<18} "
                  f"{rec['variant']:<16} {extra}")
        if not dry_run:
            _write(rec)
    return dict(counts)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file", help="TI Space Products Guide .pdf")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args(argv)
    c = ingest(Path(args.file), args.dry_run, args.verbose)
    print("\n=== TI space products guide: RF sections only "
          + ("(dry run) ===" if args.dry_run else "===")
          + f"\n  RF parts          {c.get('parts', 0)}"
          + f"\n    with frequency  {c.get('with_freq', 0)}"
          + f"\n    space_qualified {c.get('space_qualified', 0)}"
          + f"\n    space_grade     {c.get('space_grade', 0)}")
    if args.dry_run:
        print("  (nothing written -- drop --dry-run to commit)")


if __name__ == "__main__":
    main()
