"""Network-free, thread-safe reader for the standalone Mini-Circuits S-parameter
port cache.

The cache is produced by the root-level ``scan_minicircuits_snp.py`` process and
lives at ``DATA / "minicircuits_live_specs.json"``. This module only *reads* that
file — it never performs any network access, never spawns the scanner, and never
writes the cache. The main GUI/CLI pipeline uses it to overlay the S-parameter
port count (and its provenance) onto Mini-Circuits catalog candidates.

Public API:
    reload_if_changed(force=False) -> bool
    cached_for(candidate) -> dict
    cache_mtime_ns() -> int | None

``cached_for`` returns only the four S-parameter-derived fields and only when the
evidence is complete (a positive integer port count *and* a filename/source):

    ports, ports_source, sparams_url, sparams_filename

Anything else (scanner bookkeeping, observations, timestamps) is never exposed.
The reader tolerates a missing, partially written, malformed, or old-schema file
by degrading to an empty cache instead of raising.
"""
import json
import re
import threading
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode

from .registry import DATA

CACHE_FILE = DATA / "minicircuits_live_specs.json"

# Only these keys ever leave this module.
EXPORT_KEYS = ("ports", "ports_source", "sparams_url", "sparams_filename")

# Keys that may hold a Mini-Circuits model/part number inside a catalog record.
MODEL_KEYS = ("pn", "model", "part_number", "partNumber", "model_name",
              "modelName", "sku", "name")

_LOCK = threading.RLock()

# In-memory state, guarded by _LOCK.
_MTIME_NS = None            # last-seen file mtime_ns, or None when absent
_BY_MODEL = {}              # normalized model -> exported-specs dict
_BY_URL = {}               # exact url -> exported-specs dict
_BY_URL_Q = {}             # model-preserving normalized url -> exported-specs dict
_BY_URL_NORM = {}          # normalized url (no query/fragment) -> exported-specs dict
_LOADED = False


def _normalize_model(value):
    """Stable, case-insensitive model key with surrounding/internal whitespace
    stripped. Mini-Circuits part numbers keep their '+' and '-' characters."""
    if value is None:
        return ""
    return re.sub(r"\s+", "", str(value)).strip().upper()


def _normalize_url(value):
    """Absolute URL with the query and fragment removed, lowercased and de-slashed.

    For Mini-Circuits this is deliberately a *last-resort* matcher: the store URL
    carries the model in the query string, so dropping the query collapses many
    parts onto the same path. Model and exact-URL matching run first.
    """
    if not value:
        return ""
    try:
        parts = urlsplit(str(value).strip())
    except (ValueError, TypeError):
        return ""
    cleaned = urlunsplit((parts.scheme, parts.netloc, parts.path, "", ""))
    return cleaned.rstrip("/").lower()


def _normalize_url_keep_query(value):
    """Normalized URL that *keeps* the query (which carries the Mini-Circuits
    model), so it is safe to match even when a model is present.

    Lowercases scheme/host, drops the fragment, and canonicalizes the query by
    decoding then re-encoding its parameters in sorted order. This absorbs
    fragment, host-capitalization, query-ordering, and escaped-vs-unescaped
    differences while preserving the model that identifies the part.
    """
    if not value:
        return ""
    try:
        parts = urlsplit(str(value).strip())
    except (ValueError, TypeError):
        return ""
    query = urlencode(sorted(parse_qsl(parts.query, keep_blank_values=True)))
    cleaned = urlunsplit(
        (parts.scheme.lower(), parts.netloc.lower(), parts.path, query, ""))
    return cleaned.rstrip("/")


def _model_from_title(title):
    """Best-effort Mini-Circuits model token from a free-text title.

    Prefers a token that mixes letters and digits (the usual part-number shape,
    e.g. ``ZASWA-2-50DR+``) instead of blindly taking the first word, which for
    ``Mini-Circuits ZASWA-2-50DR+ RF Switch`` would wrongly return the brand.
    """
    if not isinstance(title, str) or not title.strip():
        return ""
    best = ""
    for tok in re.findall(r"[A-Za-z0-9][A-Za-z0-9._-]*\+?", title):
        has_alpha = any(c.isalpha() for c in tok)
        has_digit = any(c.isdigit() for c in tok)
        if has_alpha and has_digit:
            return tok
        if not best and (has_alpha or has_digit):
            best = tok
    return best


def cache_mtime_ns():
    """Return the cache file's mtime in nanoseconds, or None when it is absent."""
    try:
        return CACHE_FILE.stat().st_mtime_ns
    except OSError:
        return None


def _extract_export_specs(specs):
    """Pull only the four S-parameter fields out of a specs dict, validating that
    both a positive integer port count and filename/source evidence are present.

    Returns an exported dict on success, or None when evidence is insufficient.
    """
    if not isinstance(specs, dict):
        return None

    ports = specs.get("ports")
    if isinstance(ports, bool):
        return None
    try:
        ports_int = int(ports)
    except (TypeError, ValueError):
        return None
    if ports_int <= 0:
        return None

    filename = specs.get("sparams_filename")
    url = specs.get("sparams_url")
    source = specs.get("ports_source")
    # Require at least one concrete piece of S-parameter evidence.
    if not (filename or url or source):
        return None

    out = {"ports": ports_int}
    if source:
        out["ports_source"] = source
    else:
        out["ports_source"] = "background_product_page_snp"
    if url:
        out["sparams_url"] = url
    if filename:
        out["sparams_filename"] = filename
    # Guarantee the key set never exceeds EXPORT_KEYS.
    return {k: out[k] for k in EXPORT_KEYS if k in out}


def _row_model(row, key):
    """Best-effort model string for a cache row, preferring the stored original."""
    if isinstance(row, dict):
        for mk in ("model", "original_model", "pn", "part_number"):
            val = row.get(mk)
            if isinstance(val, str) and val.strip():
                return val
    return key


def _index(raw):
    """Rebuild the model/url lookup tables from a parsed cache document.

    Tolerates both the current schema (``parts`` keyed by normalized model with a
    nested ``specs`` object) and older/looser shapes. Unusable rows are skipped.
    """
    by_model, by_url, by_url_q, by_url_norm = {}, {}, {}, {}
    # Track which normalized URL came from which cache key so we can drop
    # ambiguous ones: Mini-Circuits store URLs carry the model in the query
    # string, so many parts collapse onto the same query-stripped path. A
    # normalized-URL match is only trustworthy when exactly one part maps to it.
    url_norm_owner = {}
    url_norm_ambiguous = set()
    if not isinstance(raw, dict):
        return by_model, by_url, by_url_q, by_url_norm

    parts = raw.get("parts")
    if not isinstance(parts, dict):
        # Old/degenerate schema: maybe the whole doc is {model: specs-ish}.
        parts = {k: v for k, v in raw.items()
                 if isinstance(v, dict) and k not in {
                     "schema_version", "request_state", "updated_at"}}

    for key, row in parts.items():
        if not isinstance(row, dict):
            continue
        specs = row.get("specs")
        if not isinstance(specs, dict):
            # Some old rows may have stored the four fields at the top level.
            specs = row
        exported = _extract_export_specs(specs)
        if exported is None:
            continue

        model = _row_model(row, key)
        norm_model = _normalize_model(model)
        if norm_model:
            by_model.setdefault(norm_model, exported)
        # Also index by the normalized cache key itself (already normalized when
        # the scanner wrote it), so lookups still work if `model` was omitted.
        norm_key = _normalize_model(key)
        if norm_key:
            by_model.setdefault(norm_key, exported)

        url = row.get("url") or specs.get("sparams_url")
        if isinstance(url, str) and url.strip():
            by_url.setdefault(url.strip(), exported)
            # Model-preserving normalized URL is unambiguous (the model stays in
            # the query), so it is always safe to match against.
            nq = _normalize_url_keep_query(url)
            if nq:
                by_url_q.setdefault(nq, exported)
            nu = _normalize_url(url)
            if nu:
                owner = url_norm_owner.get(nu)
                if owner is None:
                    url_norm_owner[nu] = norm_key or norm_model
                    by_url_norm[nu] = exported
                elif owner != (norm_key or norm_model):
                    url_norm_ambiguous.add(nu)

    # Ambiguous normalized URLs (shared by multiple distinct parts) are unsafe.
    for nu in url_norm_ambiguous:
        by_url_norm.pop(nu, None)

    return by_model, by_url, by_url_q, by_url_norm


def reload_if_changed(force=False):
    """Reload the cache when the file mtime changed (or when ``force``).

    Returns True when a (re)load actually happened, False otherwise. Never raises
    and never touches the network.
    """
    global _MTIME_NS, _BY_MODEL, _BY_URL, _BY_URL_Q, _BY_URL_NORM, _LOADED
    with _LOCK:
        current = cache_mtime_ns()
        if not force and _LOADED and current == _MTIME_NS:
            return False

        if current is None:
            _MTIME_NS = None
            _BY_MODEL, _BY_URL, _BY_URL_Q, _BY_URL_NORM = {}, {}, {}, {}
            _LOADED = True
            return True

        try:
            text = CACHE_FILE.read_text(encoding="utf-8")
            raw = json.loads(text)
        except (OSError, UnicodeDecodeError, ValueError):
            # Missing/partial/malformed: degrade to empty, remember mtime so we do
            # not thrash re-parsing the same broken file every call.
            _MTIME_NS = current
            _BY_MODEL, _BY_URL, _BY_URL_Q, _BY_URL_NORM = {}, {}, {}, {}
            _LOADED = True
            return True

        _BY_MODEL, _BY_URL, _BY_URL_Q, _BY_URL_NORM = _index(raw)
        _MTIME_NS = current
        _LOADED = True
        return True


def _is_minicircuits(candidate):
    if not isinstance(candidate, dict):
        return False
    if candidate.get("vendor") == "Mini-Circuits":
        return True
    # Vendor may be unset on a bare catalog candidate; fall back to provenance.
    data_file = str(candidate.get("_catalog_data_file") or "").lower()
    url = str(candidate.get("url") or "").lower()
    if "minicircuits" in data_file or "minicircuits.com" in url:
        return True
    return False


def _candidate_model(candidate):
    rec = candidate.get("_catalog_record")
    if isinstance(rec, dict):
        for key in MODEL_KEYS:
            val = rec.get(key)
            if isinstance(val, str) and val.strip():
                return val.strip()
            if isinstance(val, (int, float)) and not isinstance(val, bool):
                return str(val)
    # Discovery sometimes promotes the model onto the candidate itself without
    # keeping it in _catalog_record; check the common direct keys next.
    for key in MODEL_KEYS:
        val = candidate.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()
        if isinstance(val, (int, float)) and not isinstance(val, bool):
            return str(val)
    # Last resort: a model-like token from the title (letters+digits) rather
    # than the first word.
    return _model_from_title(candidate.get("title"))


def cached_for(candidate):
    """Return the S-parameter export dict for a Mini-Circuits candidate.

    Empty dict for non-Mini-Circuits candidates, for unknown parts, or when the
    cached row lacks a valid positive port count with filename/source evidence.
    Matching order: normalized model -> exact URL -> model-preserving normalized
    URL -> (only when the candidate has no model) query-stripped URL.
    """
    if not _is_minicircuits(candidate):
        return {}

    reload_if_changed(force=False)

    with _LOCK:
        model = _normalize_model(_candidate_model(candidate))
        if model and model in _BY_MODEL:
            return dict(_BY_MODEL[model])

        url = candidate.get("url")
        if isinstance(url, str) and url.strip():
            exact = url.strip()
            # Exact URL is precise (it keeps the ?model= query), so it is always
            # safe to consult.
            if exact in _BY_URL:
                return dict(_BY_URL[exact])
            # Model-preserving normalized URL keeps the identifying query, so it
            # tolerates fragment/host-case/query-order/escaping differences and
            # is safe even when a model is present.
            nq = _normalize_url_keep_query(exact)
            if nq and nq in _BY_URL_Q:
                return dict(_BY_URL_Q[nq])
            # The query-stripped URL is lossy for Mini-Circuits store links (the
            # model lives in the query). Only fall back to it when the candidate
            # has no model identity of its own; a candidate that carries a known
            # model that simply is not cached must return empty rather than
            # cross-matching a different part that shares the store path.
            if not model:
                nu = _normalize_url(exact)
                if nu and nu in _BY_URL_NORM:
                    return dict(_BY_URL_NORM[nu])

    return {}
