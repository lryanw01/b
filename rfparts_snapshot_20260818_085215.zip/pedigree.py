"""Canonical space-qualification pedigree + family (base part number) logic.

Vendors describe qualification a dozen ways (QMLV / Class V / Class S, space
grade, MIL-PRF-38534 K/H, SEP, EP, hi-rel, upscreenable COTS...). This module
maps whatever the ingesters recorded onto one small ladder so the GUI, filters,
family grouping and the health report all treat pedigree the same way.

DESIGN NOTE — pedigree is informational, NOT a quality score. In a real RF
dataset it is extremely common for a part to carry no stated pedigree at all,
and a part must NEVER rank higher merely for having one. Pedigree is used only
for display, optional filtering, and grouping a base part with its qualified
siblings — it contributes zero points to fit_score (see rank.evaluate).
"""
from __future__ import annotations

import re

# canonical ladder, strongest -> weakest. NONE is the common case in the wild.
QUALIFIED = "space_qualified"
GRADE = "space_grade"
HI_REL = "hi_rel"
QUALIFIABLE = "qualifiable"
NONE = "none"

LADDER = [QUALIFIED, GRADE, HI_REL, QUALIFIABLE, NONE]
_RANK = {v: i for i, v in enumerate(LADDER)}       # 0 = strongest

_LABEL = {
    QUALIFIED: "space-qualified",
    GRADE: "space-grade",
    HI_REL: "hi-rel",
    QUALIFIABLE: "upscreenable",
    NONE: "\u2014",                                  # em dash
}

# free-text tokens the ingesters may have stored in the 'space' spec.
_QUALIFIED_WORDS = {"qualified", "space", "class v", "classv", "qmlv",
                    "class s", "classs", "qmls"}
_GRADE_WORDS = {"grade", "space_grade", "space grade", "class b", "qmlq",
                "sep", "enhanced plastic"}
_HIREL_WORDS = {"hi_rel", "hi-rel", "hirel", "high reliability", "ep",
                "enhanced product"}
_UPSCREEN_WORDS = {"qualifiable", "upscreen", "upscreenable", "cots+",
                   "screenable"}


def normalize(specs) -> str:
    """Canonical pedigree for a candidate's specs dict (or a bare space string).

    Reads the explicit space_variant first (space_qualified / space_grade the
    ingesters emit), then falls back to interpreting the free-text 'space'
    signal. Anything unrecognized -> NONE."""
    if isinstance(specs, str):
        specs = {"space": specs}
    specs = specs or {}
    v = specs.get("space_variant")
    if v in (QUALIFIED, GRADE):
        return v
    s = str(specs.get("space") or "").strip().lower()
    if not s:
        return NONE
    if s in _QUALIFIED_WORDS:
        return QUALIFIED
    if s in _GRADE_WORDS:
        return GRADE
    if s in _HIREL_WORDS:
        return HI_REL
    if s in _UPSCREEN_WORDS:
        return QUALIFIABLE
    return NONE


def label(specs_or_canonical) -> str:
    canonical = (specs_or_canonical if isinstance(specs_or_canonical, str)
                 and specs_or_canonical in _LABEL else normalize(specs_or_canonical))
    return _LABEL.get(canonical, _LABEL[NONE])


def has_pedigree(specs_or_canonical) -> bool:
    c = (specs_or_canonical if isinstance(specs_or_canonical, str)
         and specs_or_canonical in _RANK else normalize(specs_or_canonical))
    return c != NONE


def rank_of(canonical) -> int:
    return _RANK.get(canonical, len(LADDER))


def at_least(canonical, minimum) -> bool:
    """True if `canonical` is at least as strong as `minimum` on the ladder."""
    return _RANK.get(canonical, 99) <= _RANK.get(minimum, -1)


# --- family (base) part number ---------------------------------------------
# A base part number is what a part shares with its pedigree variants, e.g.
# TPS7H4011-SP and TPS7H4011-SEP both reduce to TPS7H4011. We strip only known
# qualification/space suffixes so genuinely different parts don't collapse.
_SUFFIX_RE = re.compile(
    r"(?:[-/ ](?:SP|SEP|EP|HB|HT|SPHT|HR|HIREL|QMLV|QMLR|QMLQ|QMLP|QML|"
    r"883B|883|CLASSV|CLASSS|CLASSB|CLASSK|CLASSH|RHA|RH))+$", re.I)
_QML_INLINE = re.compile(r"QML[-/ ]?(?:SP|V|R|Q|P)$", re.I)


def family_base(mpn) -> str:
    """Base part number shared by a part and its pedigree variants.

    Conservative: strips trailing space/qualification tokens (repeatedly, since
    parts stack them like ...QML-SP), then reduces to alphanumerics. Returns ''
    for empty input."""
    s = str(mpn or "").upper().strip()
    prev = None
    while prev != s and s:
        prev = s
        s = _QML_INLINE.sub("", s)
        s = _SUFFIX_RE.sub("", s)
        s = s.rstrip("-/ ")
    return re.sub(r"[^A-Z0-9]", "", s)
