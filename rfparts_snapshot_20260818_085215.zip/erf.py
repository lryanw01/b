"""everythingRF listing harvester — full parts WITHOUT crawling product pages.

everythingRF renders complete parametric specs inside each listing card:

    <div class="product-box">
      <h3 class="prod-title"><a href="/products/<cat>/<mfr>/<ids>-<slug>"
                               dname="APM-6848CH">Marki Microwave - APM-6848CH</a>
      <a class="manuName">Marki Microwave</a>
      <a class="website" href="https://markimicrowave.com/...">Visit Website</a>
      <div class="descriptiontext">Low Phase Noise Amplifier from 2 to 30 GHz</div>
      <div class="specs">
        <div class="data-row"><div class="attribute">Frequency:</div>
                              <div class="value">2 to 30 GHz</div></div>
        ... Noise Figure, P1dB, Output Power, Industry Application, ...

One filtered listing page therefore yields ~20 complete parts, and the
space-qualification answer comes from the "Industry Application" row rather
than from prose guessing. With sindustry_application=;Space; in the query
string, every result is space-application by construction.

Also captured: the manufacturer's own product-page URL ("Visit Website"),
stored as `vendor_url` so a later pass can chase the real datasheet on the
manufacturer's domain.

NOT captured: the "Download Datasheet" button — it is href="javascript:void(0)"
opening a lead-capture request form, never a PDF. Request-form URLs are
recognized and rejected (see _REQUEST_FORM).
"""
from __future__ import annotations

import re
from urllib.parse import urlencode, urlparse

from bs4 import BeautifulSoup

from .partdb import SpecRow

BASE = "https://www.everythingrf.com"

# Category -> everythingRF search slug. Verified against live markup: the slug
# is 'microwave-rf-amplifiers', NOT 'rf-amplifiers' (an earlier guess that
# produced junk pages).
SLUGS = {
    "amplifier": "microwave-rf-amplifiers",
    "lna": "microwave-rf-amplifiers",
    "power_amplifier": "microwave-rf-amplifiers",
    "attenuator": "rf-attenuators",
    "filter": "rf-filters",
    "mixer": "rf-mixers",
    "switch": "rf-switches",
    "coupler": "rf-directional-couplers",
    "divider": "rf-power-dividers",
    "phase_shifter": "phase-shifters",
    "limiter": "rf-limiters",
    "oscillator": "rf-oscillators",
    "circulator": "rf-circulators",
    "isolator": "rf-isolators",
    "detector": "rf-detectors",
    "multiplier": "frequency-multipliers",
}

# Attribute label -> (spec key, parser kind)
_ATTRS = {
    "frequency": ("freq_ghz", "freq"),
    "noise figure": ("nf_db", "num"),
    "gain": ("gain_db", "num"),
    "p1db": ("p1db_dbm", "num"),
    "oip3": ("oip3_dbm", "num"),
    "output power": ("power_w", "num"),
    "saturated power": ("psat_dbm", "num"),
    "vswr": ("vswr", "num"),
    "insertion loss": ("insertion_loss_db", "num"),
    "isolation": ("isolation_db", "num"),
    "attenuation": ("attenuation_db", "num"),
    # Switch speed. everythingRF labels this several ways depending on the
    # switch family, and the unit varies (ns for solid state, ms for
    # electromechanical), so it needs the unit-aware "time_ns" parser.
    "switching speed": ("switching_time_ns", "time_ns"),
    "switching time": ("switching_time_ns", "time_ns"),
    "rise time": ("switching_time_ns", "time_ns"),
    "rise/fall time": ("switching_time_ns", "time_ns"),

    "package type": ("package", "text"),
    "configuration": ("configuration", "text"),
    "type": ("subtype", "text"),
    "industry application": ("industry_application", "text"),
    "operating temperature": ("temp_c", "text"),
}

_RANGE = re.compile(
    r"([-+]?\d+(?:\.\d+)?)\s*(?:to|-|–|—)\s*([-+]?\d+(?:\.\d+)?)\s*"
    r"(GHz|MHz|kHz)?", re.I)

_SINGLE = re.compile(r"([-+]?\d+(?:\.\d+)?)\s*(GHz|MHz|kHz)?", re.I)

# Lead-capture / RFQ / datasheet-request pages: these carry part numbers and
# look like product pages to a URL-shape matcher, but contain no specs.
_REQUEST_FORM = re.compile(
    r"request[-_/]?(?:a[-_]?)?(?:datasheet|quote|sample|info|pricing)|"
    r"/rfq|/quote|/inquiry|/contact|/enquir|datasheet[-_]?request|"
    r"/download[-_]?request|lead[-_]?form|/register|/login", re.I)


def is_request_form(url: str) -> bool:
    """True when a URL is a quote/datasheet-request form rather than a part."""
    return bool(_REQUEST_FORM.search(url or ""))


def search_url(category, page=1, space_only=True, country="global"):
    """Filtered listing URL for a category. space_only adds the Space
    industry-application facet, which is what makes every hit space-relevant."""
    slug = SLUGS.get(category)
    if not slug:
        return None
    q = f"page={page}&country={country}"
    if space_only:
        # literal semicolons, matching the site's own facet links
        q += "&sindustry_application=;Space;"
    return f"{BASE}/search/{slug}/filters?{q}"


def _to_ghz(val, unit):
    u = (unit or "GHz").lower()
    if u == "mhz":
        return val / 1000.0
    if u == "khz":
        return val / 1e6
    return val


_TIME_UNITS = {"ns": 1.0, "nsec": 1.0, "us": 1e3, "usec": 1e3,
               "\u00b5s": 1e3, "\u03bcs": 1e3, "ms": 1e6, "msec": 1e6,
               "s": 1e9, "sec": 1e9}
_TIME_RE = re.compile(
    r"([-+]?\d+(?:\.\d+)?)\s*(ns|nsec|us|usec|\u00b5s|\u03bcs|ms|msec|s|sec)\b",
    re.I)


def _parse_time_ns(text):
    """A switching-speed attribute normalised to nanoseconds.

    The unit is mandatory: a bare '500' could be 500 ns or 500 us and guessing
    would put an electromechanical switch and a PIN diode switch in the same
    bucket, which is exactly the comparison this spec exists to make."""
    hits = _TIME_RE.findall(text or "")
    if not hits:
        return None
    vals = []
    for num, unit in hits:
        factor = _TIME_UNITS.get(unit.lower())
        if factor is None:
            continue
        try:
            vals.append(float(num) * factor)
        except ValueError:
            continue
    if not vals:
        return None
    if len(vals) > 1:
        return {"value_min": min(vals), "value_max": max(vals), "unit": "ns"}
    return {"value_typ": vals[0], "unit": "ns"}


def _parse_value(kind, text, key):
    """-> list of SpecRow kwargs dicts (min/typ/max/text) for one attribute."""
    t = (text or "").strip()
    if not t:
        return None
    if kind == "text":
        return {"value_text": t[:200]}
    if kind == "time_ns":
        return _parse_time_ns(t)
    m = _RANGE.search(t)
    if kind == "freq":
        if m:
            lo = _to_ghz(float(m.group(1)), m.group(3))
            hi = _to_ghz(float(m.group(2)), m.group(3))
            return {"value_min": lo, "value_max": hi, "unit": "GHz"}
        m1 = _SINGLE.search(t)
        if m1:
            v = _to_ghz(float(m1.group(1)), m1.group(2))
            return {"value_min": 0.0, "value_max": v, "unit": "GHz"}
        return None
    # numeric: a range means min/max, otherwise a typical value
    if m:
        return {"value_min": float(m.group(1)), "value_max": float(m.group(2))}
    m1 = _SINGLE.search(t)
    if m1:
        return {"value_typ": float(m1.group(1))}
    return None


def parse_listing(html, source_url=""):
    """Parse one everythingRF listing page.

    Returns a list of dicts:
      {mpn, vendor, title, url, vendor_url, description, spec_rows[, space]}
    """
    soup = BeautifulSoup(html, "html.parser")
    out = []
    for box in soup.find_all("div", class_="product-box"):
        link = box.find("a", href=re.compile(r"/products/"))
        if not link:
            continue
        url = link["href"]
        if is_request_form(url):
            continue
        title_a = box.find("h3", class_="prod-title")
        title_link = title_a.find("a") if title_a else None
        # dname carries the clean part number; the visible text prefixes the
        # manufacturer ("Marki Microwave - APM-6848CH").
        mpn = ""
        if title_link is not None:
            mpn = (title_link.get("dname") or "").strip()
            if not mpn:
                txt = title_link.get_text(" ", strip=True)
                mpn = txt.split("-", 1)[-1].strip() if "-" in txt else txt
        mpn = re.sub(r"\s*\((?:obsolete|new|featured)\)\s*", "", mpn,
                     flags=re.I).strip()
        if not mpn:
            continue

        mfr_a = box.find("a", class_=re.compile("manuName"))
        vendor = (mfr_a.get("manu-name") or mfr_a.get_text(strip=True)
                  if mfr_a else "")
        site_a = box.find("a", class_=re.compile(r"\bwebsite\b"))
        vendor_url = site_a["href"].split("?utm_source")[0] if site_a else ""
        desc_d = box.find("div", class_="descriptiontext")
        description = desc_d.get_text(" ", strip=True) if desc_d else ""

        rows, attrs = [], {}
        for dr in box.find_all("div", class_="data-row"):
            a_d = dr.find("div", class_="attribute")
            v_d = dr.find("div", class_="value")
            if not (a_d and v_d):
                continue
            label = a_d.get_text(strip=True).rstrip(":").lower()
            value = v_d.get_text(" ", strip=True)
            attrs[label] = value
            mapped = _ATTRS.get(label)
            if not mapped:
                continue
            key, kind = mapped
            parsed = _parse_value(kind, value, key)
            if not parsed:
                continue
            rows.append(SpecRow(key=key, method="aggregator", confidence=0.75,
                                source_url=source_url or url,
                                snippet=f"{label}: {value}"[:150], **parsed))

        space_app = "space" in (attrs.get("industry application", "").lower())
        out.append({
            "mpn": mpn, "vendor": vendor or "everythingrf", "url": url,
            "vendor_url": vendor_url, "title": (title_link.get_text(" ", strip=True)
                                                if title_link else mpn),
            "description": description, "spec_rows": rows,
            "space_application": space_app, "attrs": attrs,
        })
    return out


def page_count(html):
    """Total listing pages, from 'Page 1 of 125'. 1 when absent."""
    m = re.search(r"Page\s+\d+\s+of\s+([\d,]+)", html or "", re.I)
    return int(m.group(1).replace(",", "")) if m else 1
