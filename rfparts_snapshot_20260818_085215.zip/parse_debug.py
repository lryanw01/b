"""Show exactly what the parsers extract from a vendor page.

The build log tells you a page produced 37 parts. It does not tell you which
columns were recognised, what a spec cell actually contained before it became a
number, or why the other 12 rows on that page were thrown away. This module
answers those questions against a real file or URL, without touching the
database.

    python -m rfparts.parse_debug --list
    python -m rfparts.parse_debug "Data/vendor_cache/www.qorvo.com/ab12cd.html"
    python -m rfparts.parse_debug "Sources/newSources/ADM-10699PSM.html"
    python -m rfparts.parse_debug --url "https://www.qorvo.com/products/product-list?categoryID=ca0021"
    python -m rfparts.parse_debug --all-cached --vendor qorvo --json report.json

WHAT IT REPORTS
    * which vendor parser was chosen, and why
    * every table found, its header row, and the header -> spec-key mapping,
      including headers that were NOT recognised (the usual cause of a missing
      spec is an unmapped column, not a broken number parser)
    * per part: the raw cell text alongside the parsed value and unit, so a
      wrong number can be traced to the cell it came from
    * rejected rows with the reason (no part number, category filtered,
      looks like a facet/slug, no digits, ...)
    * for a Marki datasheet page: extracted text length, which spec sections
      were found, and the pipe-table column mapping
    * construction cues present in the text, which is what the space-qualifiable
      classifier will eventually read

Nothing here writes to partdb.
"""
from __future__ import annotations

import argparse
import json
import re
import urllib.parse
from collections import Counter
from pathlib import Path

try:
    from . import vendor_catalogs as vc
    from .paths import PARSE_DEBUG_DIR, VENDOR_CACHE
except ImportError:                                     # loose-script fallback
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from rfparts import vendor_catalogs as vc            # type: ignore
    from rfparts.paths import PARSE_DEBUG_DIR, VENDOR_CACHE   # type: ignore

# Shared with the walkers so the inspector can never drift from the parser.
_HREF = vc._HREF
pn_from_filename = getattr(vc, "_pn_from_filename", None) or (
    lambda stem: __import__("re").sub(r"\.pdf.*$", "", str(stem), flags=2))
looks_like_pn = vc.looks_like_pn

CUES = ("hermetic", "ceramic", "GaAs", "GaN", "alumina", "bare die", "MIL-",
        "screened", "laser weld", "plastic", "epoxy", "-55", "kovar",
        "glass-to-metal", "hi-rel", "LTCC", "thin film", "space")

# =========================================================================
# URL RULES — the source's URL decides how it is parsed
# =========================================================================
# Dispatch used to key on a VENDOR, which conflated two different questions.
# "Qorvo" is not a parsing strategy: a Qorvo product-list page, a Qorvo product
# page and a Qorvo datasheet all need different handling, while a listing page
# from a vendor we have never named needs the generic link parser rather than
# nothing at all.
#
# So the URL (host + path shape) selects the parser, and the vendor is just a
# label carried along for grouping. Adding support for a new page means adding a
# RULE, not a vendor.
#
# Local files have no URL, so a file-path rule set mirrors it: the same idea
# applied to "Sources/EverythingRFSpaceQual/.../page_001.html".

PAGE_RULES = [
    # ---- Qorvo
    {"name": "qorvo-product-list", "host": r"(^|\.)qorvo\.com$",
     "path": r"^/products/product-list", "parser": "qorvo_table",
     "kind": "parametric listing", "vendor": "Qorvo"},
    {"name": "qorvo-datasheet-redirect", "host": r"(^|\.)qorvo\.com$",
     "path": r"^/products/d/", "parser": "pdf_or_landing",
     "kind": "datasheet link", "vendor": "Qorvo"},
    {"name": "qorvo-product", "host": r"(^|\.)qorvo\.com$",
     "path": r"^/products/p/", "parser": "generic_links",
     "kind": "product page", "vendor": "Qorvo"},
    {"name": "qorvo-other", "host": r"(^|\.)qorvo\.com$", "path": r".*",
     "parser": "qorvo_table", "kind": "page", "vendor": "Qorvo"},
    # ---- Marki: a listing and a datasheet page are completely different
    {"name": "marki-datasheet", "host": r"(^|\.)markimicrowave\.com$",
     "path": r"/datasheet/?$", "parser": "marki_datasheet",
     "kind": "datasheet page", "vendor": "Marki Microwave"},
    {"name": "marki-listing", "host": r"(^|\.)markimicrowave\.com$",
     "path": r"^/products/[a-z-]+/[a-z0-9-]+/?$", "parser": "marki_listing",
     "kind": "listing", "vendor": "Marki Microwave"},
    {"name": "marki-part", "host": r"(^|\.)markimicrowave\.com$",
     "path": r"^/products/[a-z-]+/[a-z0-9-]+/[^/]+/?$",
     "parser": "marki_datasheet", "kind": "product page",
     "vendor": "Marki Microwave"},
    {"name": "marki-other", "host": r"(^|\.)markimicrowave\.com$",
     "path": r".*", "parser": "marki_listing", "kind": "page",
     "vendor": "Marki Microwave"},
    # ---- MACOM
    {"name": "macom-product-detail", "host": r"(^|\.)macom\.com$",
     "path": r"^/products/product-detail/", "parser": "generic_links",
     "kind": "product page", "vendor": "MACOM"},
    {"name": "macom-category", "host": r"(^|\.)macom\.com$",
     "path": r"^/products", "parser": "macom_links", "kind": "category listing",
     "vendor": "MACOM"},
    # ---- Skyworks
    {"name": "skyworks-part", "host": r"(^|\.)skyworksinc\.com$",
     "path": r"^/en/Products/[^/]+/[^/]+/?$", "parser": "skyworks_links",
     "kind": "product page", "vendor": "Skyworks"},
    {"name": "skyworks-category", "host": r"(^|\.)skyworksinc\.com$",
     "path": r"^/en/Products", "parser": "skyworks_links",
     "kind": "category listing", "vendor": "Skyworks"},
    # ---- everythingRF
    {"name": "everythingrf-listing", "host": r"(^|\.)everythingrf\.com$",
     "path": r".*", "parser": "everythingrf", "kind": "aggregator listing",
     "vendor": "everythingRF"},
    # ---- anything else that is still a web page
    {"name": "generic-web", "host": r".*", "path": r".*",
     "parser": "generic_links", "kind": "page", "vendor": ""},
]

# Local files, matched on the path instead of a URL.
FILE_RULES = [
    {"name": "adi-space-portfolio", "path": r"space[ _-]?portfolio.*\.xlsx?$",
     "parser": "adi_space_workbook", "kind": "spreadsheet",
     "vendor": "Analog Devices"},
    {"name": "adi-parametric", "path": r"parametric.*\.xlsx?$",
     "parser": "adi_parametric_workbook", "kind": "spreadsheet",
     "vendor": "Analog Devices"},
    {"name": "workbook", "path": r"\.xls[xm]$", "parser": "adi_parametric_workbook",
     "kind": "spreadsheet", "vendor": ""},
    {"name": "everythingrf-file", "path": r"everythingrf",
     "parser": "everythingrf", "kind": "aggregator listing",
     "vendor": "everythingRF"},
]

# Markup fingerprints, used only when neither a URL nor a recognisable path is
# available (for example a cached page whose URL was not recorded).
_MARKUP_HINTS = [
    (r"qorvo\.com", "qorvo-other"),
    (r"markimicrowave\.com", "marki-other"),
    (r"macom\.com", "macom-category"),
    (r"skyworksinc\.com", "skyworks-category"),
    (r"everythingrf\.com", "everythingrf-listing"),
    (r"/products/product-list|/products/d/", "qorvo-product-list"),
    (r"/products/product-detail/", "macom-product-detail"),
]


def _rule_by_name(name):
    for r in PAGE_RULES + FILE_RULES:
        if r["name"] == name:
            return r
    return PAGE_RULES[-1]


def match_url(url):
    """First PAGE_RULE whose host AND path both match."""
    pr = urllib.parse.urlparse(str(url))
    host, path = pr.netloc.lower(), pr.path or "/"
    for rule in PAGE_RULES:
        if re.search(rule["host"], host) and re.search(rule["path"], path, re.I):
            return rule
    return PAGE_RULES[-1]


def match_source(url=None, path=None, html=None, forced=None):
    """(rule, why). URL first, then file path, then markup fingerprint."""
    if forced:
        # a forced parser name or a legacy vendor key
        for r in PAGE_RULES + FILE_RULES:
            if r["name"] == forced or r["parser"] == forced:
                return r, f"forced: {forced}"
        alias = {"qorvo": "qorvo-product-list", "marki": "marki-listing",
                 "macom": "macom-category", "skyworks": "skyworks-category",
                 "everythingrf": "everythingrf-listing",
                 "adi": "adi-parametric"}
        if str(forced).lower() in alias:
            return _rule_by_name(alias[str(forced).lower()]), \
                f"forced vendor '{forced}'"
    if url and str(url).startswith("http"):
        rule = match_url(url)
        return rule, f"URL rule '{rule['name']}'"
    if path:
        low = str(path).replace("\\", "/").lower()
        for rule in FILE_RULES:
            if re.search(rule["path"], low, re.I):
                return rule, f"file rule '{rule['name']}'"
    if html:
        head = html[:200_000].lower()
        for pat, name in _MARKUP_HINTS:
            if re.search(pat, head):
                rule = _rule_by_name(name)
                return rule, f"markup fingerprint -> '{rule['name']}'"
    return PAGE_RULES[-1], "no rule matched; generic link parser"


_HOST_PARSER = [
    ("qorvo.com", "qorvo"),
    ("macom.com", "macom"),
    ("skyworksinc.com", "skyworks"),
    ("markimicrowave.com", "marki"),
    ("everythingrf.com", "everythingrf"),
]


def detect_vendor(html, source_hint=""):
    """(vendor_key, why). Host in the hint wins; otherwise sniff the markup."""
    hint = str(source_hint).lower()
    for needle, key in _HOST_PARSER:
        if needle in hint:
            return key, f"source path/URL contains {needle}"
    low = html[:200_000].lower()
    for needle, key in _HOST_PARSER:
        if needle in low:
            return key, f"page markup references {needle}"
    if "/products/product-list" in low or "/products/d/" in low:
        return "qorvo", "found Qorvo product-list markers"
    if "/products/product-detail/" in low:
        return "macom", "found MACOM product-detail links"
    return "unknown", "no vendor marker found"


# --------------------------------------------------------------------- tables
def inspect_tables(html, categories=None):
    """Every table, its header mapping, and each row's raw-vs-parsed values."""
    out = []
    for ti, (headers, rows) in enumerate(vc.parse_tables(html)):
        colmap = vc.map_headers(headers)
        mapped, unmapped = [], []
        for i, h in enumerate(headers):
            if i in colmap:
                key, unit = colmap[i]
                mapped.append({"column": i, "header": h, "spec_key": key,
                               "unit_from_header": unit or "(none)"})
            else:
                unmapped.append({"column": i, "header": h})
        out.append({"table": ti, "headers": headers, "row_count": len(rows),
                    "mapped_columns": mapped, "unmapped_columns": unmapped})
    return out


def inspect_qorvo(html, base, categories=None):
    """Reproduce walk_qorvo's extraction, keeping the raw cell text."""
    import html as _h
    heads = [_h.unescape(x).strip() for x in vc._QORVO_HEAD.findall(html)]
    if not heads:
        heads = [x[0] for x in vc._QORVO_HEAD_ALT.findall(html)]
    tables = vc.parse_tables(html)
    parts, rejects = [], []
    for ti, (headers, rows) in enumerate(tables):
        section = heads[ti] if ti < len(heads) else ""
        cat, sub = vc._qorvo_category(section)
        colmap = vc.map_headers(headers)
        cat_ok = vc.category_allowed(cat, categories)
        for ri, cells in enumerate(rows):
            joined = " ".join(c[1] for c in cells)
            pn = ds = ""
            for kind, ident in vc._QORVO_PD.findall(joined):
                if kind.lower() == "p" and not pn:
                    pn = urllib.parse.unquote(ident).strip("/")
                elif kind.lower() == "d" and not ds:
                    ds = f"https://www.qorvo.com/products/d/{ident}"
            if not pn:
                rejects.append({"table": ti, "row": ri, "reason":
                                "no /products/p/ link in the row",
                                "first_cells": [c[0] for c in cells[:3]]})
                continue
            if not vc.looks_like_pn(pn):
                rejects.append({"table": ti, "row": ri, "candidate": pn,
                                "reason": "did not look like a part number "
                                          "(no digit, or a word-like segment)"})
                continue
            if not vc.is_orderable_part(pn):
                rejects.append({"table": ti, "row": ri, "candidate": pn,
                                "reason": "evaluation board / dev kit"})
                continue
            if not cat_ok:
                rejects.append({"table": ti, "row": ri, "candidate": pn,
                                "reason": f"category '{cat}' excluded by filter"})
                continue
            rec = {"specs": {}}
            raw = {}
            for i, (text, _h) in enumerate(cells):
                if i not in colmap:
                    continue
                key, unit = colmap[i]
                before = dict(rec["specs"])
                vc._absorb_spec(rec, key, text, unit)
                for k, v in rec["specs"].items():
                    if k not in before or before[k] != v:
                        raw[k] = {"header": headers[i] if i < len(headers) else "",
                                  "raw_cell": text, "parsed": v[0],
                                  "unit": v[1]}
            parts.append({
                "mpn": pn, "section": section, "category": cat,
                "subcategory": sub, "datasheet_url": ds or "(none on this row)",
                "description": cells[1][0][:160] if len(cells) > 1 else "",
                "specs": raw,
                "unparsed_cells": [
                    {"header": headers[i] if i < len(headers) else f"col{i}",
                     "text": c[0]}
                    for i, c in enumerate(cells)
                    if i in colmap and not any(
                        r for k, r in raw.items() if r["raw_cell"] == c[0])][:6],
            })
    return {"sections": heads, "parts": parts, "rejects": rejects}


def inspect_link_vendor(html, base, vendor, categories=None):
    """MACOM / Skyworks / Marki: which links became parts, which did not."""
    host = urllib.parse.urlparse(base).netloc or {
        "macom": "www.macom.com", "skyworks": "www.skyworksinc.com",
        "marki": "markimicrowave.com"}.get(vendor, "")
    parts, rejects = [], []
    seen = set()
    for href in vc._HREF.findall(html):
        u = urllib.parse.urljoin(base or f"https://{host}/", href.strip())
        pr = urllib.parse.urlparse(u)
        if host and pr.netloc != host:
            continue
        path = pr.path
        cand = None
        if vendor == "macom":
            m = vc._MACOM_PART.search(path)
            cand = urllib.parse.unquote(m.group(1)) if m else None
            if not m and re.search(r"/products?/", path, re.I):
                rejects.append({"url": path, "reason":
                                "not under /products/product-detail/ "
                                "(category page or filter facet)"})
                continue
        elif vendor == "skyworks":
            m = vc._SKY_PART.match(path)
            cand = urllib.parse.unquote(m.group(2)) if m else None
            if not m and path.lower().startswith("/en/products"):
                rejects.append({"url": path,
                                "reason": "category page, not /Products/<cat>/<PN>"})
                continue
        elif vendor == "marki":
            m = vc._MARKI_PART.match(href.strip())
            cand = m.group(2) if m else None
        if not cand:
            continue
        if cand.upper() in seen:
            continue
        if not vc.looks_like_pn(cand):
            rejects.append({"url": path, "candidate": cand, "reason":
                            "rejected by looks_like_pn (no digit, or a "
                            "word-like segment after the first)"})
            continue
        if not vc.is_orderable_part(cand):
            rejects.append({"url": path, "candidate": cand,
                            "reason": "evaluation board / dev kit, not a part"})
            continue
        cat, sub = vc._category_from_path(path)
        if not vc.category_allowed(cat, categories):
            rejects.append({"url": path, "candidate": cand,
                            "reason": f"category '{cat}' excluded by filter"})
            continue
        seen.add(cand.upper())
        rec = {"mpn": cand, "category": cat, "subcategory": sub,
               "product_url": u}
        if vendor == "macom":
            rec["datasheet_url"] = (
                "https://cdn.macom.com/datasheets/"
                + urllib.parse.quote(cand, safe="+-_.") + ".pdf")
        parts.append(rec)
    return {"parts": parts, "rejects": rejects}


def inspect_marki_datasheet(html):
    """A Marki /datasheet/ page: the text, its sections, and the pipe tables."""
    text = vc.marki_datasheet_text(html)
    lines = text.split("\n")
    sections = [ln for ln in lines
                if re.match(r"^(general description|features|applications|"
                            r"absolute maximum|recommended operating|"
                            r"electrical specification|package information|"
                            r"port functions|mechanical data)", ln, re.I)]
    tables, cur = [], None
    for ln in lines:
        if "|" not in ln:
            cur = None
            continue
        cells = [c.strip() for c in ln.split("|")]
        if cells and cells[0].lower().startswith("parameter"):
            cur = {"header": cells, "rows": []}
            tables.append(cur)
        elif cur is not None:
            cur["rows"].append(cells)
    rec = {"specs": {}}
    vc._marki_specs_from_text(rec, text)
    return {
        "text_chars": len(text), "text_words": len(text.split()),
        "sections_found": sections,
        "has_spec_table": bool(vc._SPEC_MARK.search(text)),
        "pipe_tables": [{"header": t["header"],
                         "row_count": len(t["rows"]),
                         "sample_rows": t["rows"][:6]} for t in tables],
        "parsed_specs": {k: {"value": v[0], "unit": v[1]}
                         for k, v in rec["specs"].items()},
        "cues": [c for c in CUES if re.search(re.escape(c), text, re.I)],
        "text_head": " ".join(text.split())[:400],
    }


# ------------------------------------------------------------------- driver
def inspect_path(path, categories=None, vendor=None):
    """Inspect any local file.

    A cached vendor page carries its original URL in a .url sidecar, so the same
    URL rules apply to it as to a live fetch -- which is the point of keying on
    the URL rather than on a vendor."""
    p = Path(path)
    rule, _why = match_source(path=str(p), forced=vendor)
    if p.suffix.lower() in (".xlsx", ".xlsm"):
        return _spreadsheet_report(p, categories)
    html = p.read_text(encoding="utf-8", errors="replace")
    return inspect_source(html, str(p), categories, vendor,
                          url=cached_url_for(p))


def cached_url_for(path):
    """The URL a cached page came from, if it was recorded."""
    side = Path(str(path) + ".url")
    if side.is_file():
        try:
            return side.read_text(encoding="utf-8").strip()
        except OSError:
            return ""
    return ""


def inspect_source(html, source="", categories=None, vendor=None, url=None):
    """Parse a page according to the RULE its URL matches.

    `vendor` is accepted for compatibility and treated as a forced rule/parser.
    The vendor name in the report is derived FROM the rule, not the other way
    round."""
    rule, why = match_source(url=url or source, path=source, html=html,
                             forced=vendor)
    base = url or (source if str(source).startswith("http") else "")
    if not base:
        base = {"Qorvo": "https://www.qorvo.com/",
                "MACOM": "https://www.macom.com/",
                "Skyworks": "https://www.skyworksinc.com/",
                "Marki Microwave": "https://markimicrowave.com/"}.get(
            rule.get("vendor", ""), "")
    report = {"source": str(source), "url": base, "bytes": len(html),
              "rule": rule["name"], "parser": rule["parser"],
              "kind": rule.get("kind", "page"),
              "vendor": rule.get("vendor", "") or "(unknown)",
              "vendor_reason": why,
              "categories_filter": sorted(categories or []) or "all",
              "tables": inspect_tables(html, categories)}
    parser = rule["parser"]

    if parser == "everythingrf":
        try:
            from . import erf_space_ingest as erf
            folder = Path(str(source)).parent.name if source else ""
            rows = list(erf.parse_page(html, folder))
            report["parts"] = [{
                "mpn": r.get("mpn"), "category": r.get("category", ""),
                "subcategory": r.get("subcategory", ""),
                "description": (r.get("description") or "")[:160],
                "datasheet_url": r.get("url", ""),
                "variant": r.get("variant", ""),
                "specs": {k: {"header": "(everythingRF attribute)",
                              "raw_cell": str(v), "parsed": v, "unit": ""}
                          for k, v in erf.flat_specs(r).items()},
            } for r in rows]
            report["rejects"] = []
        except Exception as e:
            report["parts"] = []
            report["rejects"] = [{"reason": f"everythingRF parse failed: "
                                            f"{type(e).__name__}: {e}"}]
    elif parser == "qorvo_table":
        report.update(inspect_qorvo(html, base or "https://www.qorvo.com/",
                                    categories))
    elif parser == "marki_datasheet":
        report["marki_datasheet"] = inspect_marki_datasheet(html)
        report.update(inspect_link_vendor(html, base or
                                          "https://markimicrowave.com/",
                                          "marki", categories))
    elif parser == "marki_listing":
        # a listing that happens to carry spec tables is still worth reporting
        if re.search(r"electrical specification|device overview", html, re.I):
            report["marki_datasheet"] = inspect_marki_datasheet(html)
        report.update(inspect_link_vendor(html, base or
                                          "https://markimicrowave.com/",
                                          "marki", categories))
    elif parser == "macom_links":
        report.update(inspect_link_vendor(html, base or
                                          "https://www.macom.com/",
                                          "macom", categories))
    elif parser == "skyworks_links":
        report.update(inspect_link_vendor(html, base or
                                          "https://www.skyworksinc.com/",
                                          "skyworks", categories))
    elif parser == "pdf_or_landing":
        pdfs = [urllib.parse.urljoin(base or "", h)
                for h in _HREF.findall(html)
                if re.search(r"\.pdf($|[?#])", h, re.I)]
        report["parts"] = []
        report["rejects"] = [{"reason": "datasheet link target: "
                                        + (f"{len(pdfs)} pdf link(s) found"
                                           if pdfs else
                                           "an HTML landing page with no pdf "
                                           "link")}]
        report["pdf_links"] = pdfs[:8]
    else:
        report.update(inspect_generic(html, base, categories))
    report.setdefault("parts", [])
    report.setdefault("rejects", [])
    return report


def inspect_generic(html, base, categories=None):
    """No vendor knowledge: every .pdf link plus anything that looks like a
    product URL. Enough to say whether a page is server-rendered at all."""
    parts, rejects = [], []
    host = urllib.parse.urlparse(base or "").netloc
    seen = set()
    for href in _HREF.findall(html):
        u = urllib.parse.urljoin(base or "", href.strip())
        pr = urllib.parse.urlparse(u)
        if host and pr.netloc and pr.netloc != host:
            continue
        if re.search(r"\.pdf($|[?#])", pr.path, re.I):
            pn = pn_from_filename(pr.path.rsplit("/", 1)[-1])
            if vc.looks_like_pn(pn) and pn.upper() not in seen:
                seen.add(pn.upper())
                parts.append({"mpn": pn, "category": "", "subcategory": "",
                              "product_url": u, "datasheet_url": u,
                              "specs": {}})
            continue
        last = urllib.parse.unquote(pr.path.rstrip("/").rsplit("/", 1)[-1])
        if vc.looks_like_pn(last) and vc.is_orderable_part(last):
            if last.upper() in seen:
                continue
            seen.add(last.upper())
            cat, sub = vc._category_from_path(pr.path)
            if not vc.category_allowed(cat, categories):
                rejects.append({"url": pr.path, "candidate": last,
                                "reason": f"category '{cat}' excluded"})
                continue
            parts.append({"mpn": last, "category": cat, "subcategory": sub,
                          "product_url": u, "datasheet_url": "", "specs": {}})
    return {"parts": parts, "rejects": rejects}


def _spreadsheet_report(path, categories=None):
    """Column mapping and sample parsed rows for an ADI workbook.

    Shows which columns were recognised and which were IGNORED -- an unmapped
    column is the usual reason a part arrives with no specs."""
    import re as _re
    rule, why = match_source(path=str(path))
    is_space = rule["parser"] == "adi_space_workbook"
    out = {"source": str(path), "url": "",
           "bytes": Path(path).stat().st_size,
           "rule": rule["name"], "parser": rule["parser"],
           "kind": "spreadsheet",
           "vendor": rule.get("vendor") or "(unknown)",
           "vendor_reason": why,
           "categories_filter": sorted(categories or []) or "all",
           "tables": [], "parts": [], "rejects": []}
    try:
        import openpyxl
    except ImportError:
        out["rejects"] = [{"reason": "openpyxl not installed"}]
        return out
    try:
        if is_space:
            from . import adi_space_ingest as mod
            merged = mod.parse_workbook(Path(path))
            out["parts"] = [{
                "mpn": k, "category": v.get("category", ""), "subcategory": "",
                "datasheet_url": v.get("datasheet_url", ""),
                "description": v.get("description", ""),
                "specs": {kk: {"header": "(space portfolio column)",
                               "raw_cell": str(vv), "parsed": vv, "unit": ""}
                          for kk, vv in v.get("specs", {}).items()},
            } for k, v in merged.items()]
        else:
            from . import adi_parametric_ingest as mod
            recs = []
            for r in mod.parse_workbook(Path(path)):
                src = r.get("spec_source", {})
                recs.append({
                    "mpn": r["mpn"], "category": r.get("category", ""),
                    "subcategory": r.get("subcategory", ""),
                    "description": r.get("description", ""),
                    "datasheet_url": "",
                    "specs": {k: {"header": ("DESCRIPTION fallback"
                                             if src.get(k) == "description"
                                             else "(sheet column)"),
                                  "raw_cell": str(v[0]), "parsed": v[0],
                                  "unit": v[1]}
                              for k, v in r.get("specs", {}).items()}})
            out["parts"] = recs
    except Exception as e:
        out["rejects"] = [{"reason": f"{type(e).__name__}: {e}"}]
        return out

    wb = openpyxl.load_workbook(str(path), read_only=True, data_only=False)
    ws = (wb["Web Display"] if "Web Display" in wb.sheetnames
          else wb[wb.sheetnames[0]])
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    hdr_i = 0
    if is_space:
        for i, r in enumerate(rows[:20]):
            if any("generic part number" in str(c or "").lower() for c in r):
                hdr_i = i
                break
    headers = [str(c or "").replace("\n", " ").strip() for c in rows[hdr_i]]
    mapped, unmapped = [], []
    if is_space:
        known = ("generic part number", "description", "orderable", "category",
                 "sub-category", "qualification level", "temperature",
                 "radiation hardness", "tid threshold", "sel threshold",
                 "displacement damage", "package", "package material",
                 "lead finish", "datasheet url")
        for i, h in enumerate(headers):
            hl = h.lower()
            if any(k in hl for k in known):
                mapped.append({"column": i, "header": h,
                               "spec_key": "(mapped)",
                               "unit_from_header": ""})
            elif h:
                unmapped.append({"column": i, "header": h})
    else:
        from . import adi_parametric_ingest as ap
        for i, h in enumerate(headers):
            hl = h.lower()
            hit = None
            for pat, key, unit in ap._COL_SPECS:
                if _re.search(pat, hl):
                    hit = (key, unit)
                    break
            if hit:
                mapped.append({"column": i, "header": h, "spec_key": hit[0],
                               "unit_from_header": hit[1] or "(none)"})
            elif any(t in hl for t in ("temperature", "lifecycle", "type",
                                       "configuration", "description",
                                       "part number")):
                mapped.append({"column": i, "header": h,
                               "spec_key": "(handled separately)",
                               "unit_from_header": ""})
            elif h:
                unmapped.append({"column": i, "header": h})
    out["tables"] = [{"table": 0, "headers": headers,
                      "row_count": max(0, len(rows) - hdr_i - 1),
                      "mapped_columns": mapped,
                      "unmapped_columns": unmapped}]
    return out


def local_sources(vendor=None):
    """Local input files: everythingRF HTML and the ADI workbooks. Tagged by the
    FILE rule that would parse each one."""
    try:
        from .paths import ADI_PARAMETRICS, EVERYTHING_RF, NEW_SOURCES
    except Exception:
        return []
    out = []
    for root in (EVERYTHING_RF, NEW_SOURCES, ADI_PARAMETRICS):
        r = Path(root)
        if not r.is_dir():
            continue
        for f in sorted(r.rglob("*")):
            if f.suffix.lower() not in (".html", ".htm", ".xlsx", ".xlsm"):
                continue
            if f.name.startswith("~$"):
                continue
            rule, _why = match_source(path=str(f))
            out.append((rule.get("vendor") or rule["name"], f))
    if vendor:
        v = vendor.lower()
        out = [(t, f) for t, f in out if v in str(t).lower()]
    return out


def all_sources(vendor=None):
    """Everything inspectable, tagged by the RULE that would parse it: cached
    vendor pages (identified by their recorded URL) plus local input files."""
    items = []
    for f in cached_files():
        rule, _why = match_source(url=cached_url_for(f), path=str(f))
        items.append((rule.get("vendor") or rule["name"], f))
    items += local_sources()
    if vendor:
        v = vendor.lower()
        items = [(t, f) for t, f in items if v in str(t).lower()]
    items.sort(key=lambda tf: (str(tf[0]), str(tf[1])))
    return items


def vendors_available():
    return Counter(t for t, _f in all_sources())


def cached_files(vendor=None):
    if not VENDOR_CACHE.exists():
        return []
    out = []
    for f in sorted(VENDOR_CACHE.rglob("*.html")):
        if f.name.endswith(".url"):
            continue
        host = f.parent.name
        if vendor and vendor.lower() not in host.lower():
            continue
        out.append(f)
    return out


def render(report, max_parts=12, show_rejects=12):
    L = []
    A = L.append
    A("=" * 78)
    A(f"PARSE REPORT  {report['source']}")
    A("=" * 78)
    A(f"  {report['bytes']:,} bytes"
      f"    rule={report.get('rule', '?')}  parser={report.get('parser', '?')}"
      f"    kind={report.get('kind', 'page')}")
    A(f"  vendor={report['vendor']}   selected by: {report['vendor_reason']}")
    if report.get("url"):
        A(f"  url={report['url']}")
    A(f"  category filter: {report['categories_filter']}")
    tabs = report.get("tables", [])
    A(f"\n  TABLES FOUND: {len(tabs)}")
    for t in tabs[:6]:
        A(f"    table {t['table']}: {t['row_count']} row(s), "
          f"{len(t['headers'])} column(s)")
        for m in t["mapped_columns"]:
            A(f"      col {m['column']:>2}  {m['header'][:34]:<34} -> "
              f"{m['spec_key']}  [{m['unit_from_header']}]")
        if t["unmapped_columns"]:
            A(f"      UNMAPPED (a missing spec usually starts here):")
            for u in t["unmapped_columns"][:8]:
                A(f"        col {u['column']:>2}  {u['header'][:56]}")
    if report.get("sections"):
        A(f"\n  SECTION HEADINGS: {'; '.join(report['sections'][:8])}")
    ds = report.get("marki_datasheet")
    if ds:
        A(f"\n  MARKI DATASHEET PAGE")
        A(f"    text: {ds['text_chars']:,} chars / {ds['text_words']:,} words"
          f"    spec table present: {ds['has_spec_table']}")
        A(f"    sections: {'; '.join(ds['sections_found'][:8]) or '(none)'}")
        for t in ds["pipe_tables"][:3]:
            A(f"    pipe table header: {' | '.join(t['header'][:8])}")
            for r in t["sample_rows"][:4]:
                A(f"        {' | '.join(r[:8])[:96]}")
        A(f"    parsed specs:")
        for k, v in sorted(ds["parsed_specs"].items()):
            A(f"      {k:<24} {v['value']} {v['unit']}")
        A(f"    construction cues: {', '.join(ds['cues']) or 'NONE'}")
        A(f"    text starts: \"{ds['text_head'][:180]}\"")
    parts = report.get("parts", [])
    A(f"\n  PARTS EXTRACTED: {len(parts)}")
    for p in parts[:max_parts]:
        A(f"    {p['mpn']:<24} {p.get('category', ''):<14}"
          f"{p.get('subcategory', '')}")
        if p.get("description"):
            A(f"      {p['description'][:70]}")
        if p.get("datasheet_url"):
            A(f"      datasheet: {p['datasheet_url'][:70]}")
        for k, r in (p.get("specs") or {}).items():
            if isinstance(r, dict):
                A(f"      {k:<20} {str(r['parsed']):>10} {r['unit']:<5} "
                  f"<- \"{r['raw_cell'][:26]}\"  ({r['header'][:24]})")
    if len(parts) > max_parts:
        A(f"    ... and {len(parts) - max_parts} more")
    rej = report.get("rejects", [])
    A(f"\n  ROWS/LINKS REJECTED: {len(rej)}")
    for r in Counter(x.get("reason", "?") for x in rej).most_common():
        A(f"    {r[1]:>5}  {r[0]}")
    for r in rej[:show_rejects]:
        who = r.get("candidate") or r.get("url") or r.get("first_cells") or ""
        A(f"      {str(who)[:56]:<56} {r.get('reason', '')[:40]}")
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("path", nargs="?", help="an HTML file to inspect")
    ap.add_argument("--url", help="fetch and inspect a live URL (uses the cache)")
    ap.add_argument("--vendor", help="force a parser: qorvo macom skyworks marki")
    ap.add_argument("--categories", nargs="*", help="apply a category filter")
    ap.add_argument("--list", action="store_true",
                    help="list cached vendor pages and exit")
    ap.add_argument("--all-cached", action="store_true",
                    help="inspect every cached page and local file "
                         "(combine with --vendor to scope it)")
    ap.add_argument("--max-parts", type=int, default=12)
    ap.add_argument("--limit", type=int, default=6,
                    help="max sources to inspect when scanning by vendor")
    ap.add_argument("--json", help="also write the full report as JSON")
    args = ap.parse_args(argv)

    if args.list:
        items = all_sources(args.vendor)
        counts = vendors_available()
        print(f"{len(items)} inspectable source(s)  "
              f"(cached vendor pages + local everythingRF / ADI files)")
        print("  by vendor: " + ", ".join(f"{k}={v}" for k, v in
                                          sorted(counts.items())))
        last = None
        for tag, f in items[:400]:
            if tag != last:
                print(f"\n  [{tag}]")
                last = tag
            try:
                size = f.stat().st_size
            except OSError:
                size = 0
            print(f"    {size:>9,}  {f.name}")
        return 0

    reports = []
    if args.url:
        fetcher = vc.Fetcher(rate=1.0, progress=print)
        html, src = fetcher.get(args.url)
        reports.append(inspect_source(html, args.url, args.categories,
                                      args.vendor))
    elif args.all_cached or args.vendor and not args.path:
        items = all_sources(args.vendor)
        if args.limit:
            items = items[: args.limit]
        print(f"inspecting {len(items)} source(s)"
              + (f" for vendor '{args.vendor}'" if args.vendor else ""))
        for _tag, f in items:
            reports.append(inspect_path(f, args.categories, args.vendor))
    elif args.path:
        f = Path(args.path)
        if not f.is_file():
            raise SystemExit(f"not a file: {f}")
        reports.append(inspect_path(f, args.categories, args.vendor))
    else:
        ap.error("give a file, --url, --all-cached, or --list")

    for r in reports:
        print(render(r, max_parts=args.max_parts))
        print()
    total = sum(len(r.get("parts", [])) for r in reports)
    rej = sum(len(r.get("rejects", [])) for r in reports)
    print(f"{len(reports)} source(s): {total} part(s) extracted, "
          f"{rej} row(s)/link(s) rejected")
    if args.json:
        out = Path(args.json)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(reports, indent=2, default=str),
                       encoding="utf-8")
        print(f"full JSON -> {out.resolve()}")
    return 0


if __name__ == "__main__":
    main()
