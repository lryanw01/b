"""Recommended suppliers for a space-qualified RF/microwave part search.

CURATED and OFFLINE. This is a hand-maintained industry map compiled from the
manufacturers' and distributors' own space/aerospace pages, not a live web
search (the tool does no scraping and often runs without outbound network).
Treat entries as leads to verify against the current source, not an exhaustive
or authoritative list. Ownership/branding in this field changes often — e.g.
Cobham AES -> CAES -> Frontgrade Technologies; Intersil -> Renesas; Microsemi
-> Microchip; Peregrine hi-rel sold through Teledyne e2v.

Each entry carries the categories it serves, its space qualification flows, a
short knowledgeable note, and a contact path so a supplier can be selected to
draft an RFQ/email.

    suggest(category, space=True, freq_ghz=None) -> list[entry dict]
    draft_context(entry, query=None)             -> vendor dict for rfq.draft
"""
from __future__ import annotations

# canonical categories (see registry.CATEGORY_SYNONYMS). "*" == broad catalog.
ALL = "*"

# Supplier record fields:
#   name, kind (manufacturer|distributor|marketplace|authority|screening),
#   url, space_url, email (public RFQ/sales, if any), form (quote/contact URL),
#   cats (set of canonical categories or {ALL}), quals (list), note
_SUPPLIERS = [
    # ---- space semiconductor + RF manufacturers ------------------------
    dict(name="Analog Devices (ADI)", kind="manufacturer",
         url="https://www.analog.com",
         space_url="https://www.analog.com/en/applications/markets/aerospace-and-defense-pavilion-home/space-solution.html",
         form="https://www.analog.com/en/support/contact-us.html",
         cats={"amplifier", "mixer", "switch", "attenuator", "phase_shifter",
               "beamformer", "synthesizer", "detector", "data_converter",
               "power", "clock", "interface", "sensor", "transceiver", "ic"},
         quals=["QMLV Class V", "MIL-PRF-38535", "space grade / RH",
                "Enhanced Products (hi-rel COTS)"],
         note="50+ yr space heritage (Greensboro NC space group). Broadest "
              "signal chain: beamformers (ADAR), RF/µW (ADRF/HMC), data "
              "converters, precision, and LT/ADP rad-hard power."),
    dict(name="Texas Instruments (TI)", kind="manufacturer",
         url="https://www.ti.com",
         space_url="https://www.ti.com/applications/industrial/aerospace-defense/space/overview.html",
         form="https://www.ti.com/company/contact.html",
         cats={"power", "data_converter", "amplifier", "clock", "interface",
               "sensor", "synthesizer", "ic"},
         quals=["QMLV", "QMLP", "Space EP (enhanced plastic)", "RHA"],
         note="250+ QMLV parts plus the Space EP plastic flow. Strongest in "
              "rad-hard power management, data converters, and clocks."),
    dict(name="Qorvo", kind="manufacturer",
         url="https://www.qorvo.com",
         space_url="https://www.qorvo.com/applications/defense-aerospace/space",
         form="https://www.qorvo.com/support/contact",
         cats={"amplifier", "switch", "attenuator", "phase_shifter", "limiter",
               "filter", "mixer", "beamformer", "oscillator"},
         quals=["space screening flows", "MIL-PRF-38534 Class K equiv",
                "GaN/GaAs, 250k+ launched components"],
         note="PAs, LNAs, gain blocks, switches, attenuators, phase shifters, "
              "VCOs; Spatium power combining. In-house US space screening "
              "services for die and packaged parts."),
    dict(name="Teledyne e2v HiRel", kind="manufacturer",
         url="https://www.teledynedefenseelectronics.com",
         space_url="https://www.teledynedefenseelectronics.com/e2vhirel",
         form="https://www.teledynedefenseelectronics.com/Pages/Contact-Us.aspx",
         cats={"data_converter", "amplifier", "switch", "attenuator", "mixer",
               "synthesizer", "limiter", "power", "ic"},
         quals=["MIL-PRF-38534 Class K/H equiv", "Space EP (SEP)",
                "ESCC 9000", "QML V/Y/Q", "AS9100"],
         note="Rad-tolerant ADCs/DACs to ~6.4/8 GSPS and an RF signal chain "
              "(TDLNA LNAs, TDSW switches, DVGAs, limiters, PLLs, mixers); GaN "
              "power. Sole source for Peregrine hi-rel RF. DoD-trusted Milpitas."),
    dict(name="Frontgrade Technologies", kind="manufacturer",
         url="https://www.frontgrade.com",
         space_url="https://www.frontgrade.com/markets/space",
         form="https://www.frontgrade.com/contact",
         cats={"synthesizer", "amplifier", "filter", "power", "data_converter",
               "oscillator", "interface", "ic"},
         quals=["rad-hard QMLV", "MIL-PRF-38535", "60+ yr space heritage"],
         note="Formerly CAES / Cobham AES / Aeroflex (Colorado Springs). "
              "Frequency converters, synthesizers, preselectors, waveguides, "
              "rotary joints, antennas; rad-hard power, MRAM/SRAM, custom ASICs."),
    dict(name="Frontgrade Gaisler", kind="manufacturer",
         url="https://www.gaisler.com", space_url="https://www.gaisler.com",
         form="https://www.gaisler.com/index.php/about-us/contact",
         cats={"ic"},
         quals=["rad-hard processors & IP"],
         note="LEON (SPARC) and NOEL-V (RISC-V) rad-hard/rad-tolerant "
              "processors, SoCs and fault-tolerant IP cores."),
    dict(name="Renesas (incl. Intersil)", kind="manufacturer",
         url="https://www.renesas.com",
         space_url="https://www.renesas.com/en/products/space-harsh-environment",
         form="https://www.renesas.com/en/support/contact",
         cats={"power", "data_converter", "clock", "interface", "ic"},
         quals=["rad-hard / rad-tolerant", "QML"],
         note="Intersil RadHard heritage: rad-hard POL & LDO power, references, "
              "data converters, level translators; space-grade clocks."),
    dict(name="Microchip (incl. Microsemi)", kind="manufacturer",
         url="https://www.microchip.com",
         space_url="https://www.microchip.com/en-us/solutions/aerospace-and-defense/space",
         form="https://www.microchip.com/en-us/about/contact-us",
         cats={"ic", "oscillator", "clock", "power", "interface",
               "data_converter", "sensor"},
         quals=["RT FPGA (RTG4, RT PolarFire)", "MIL-PRF-55310",
                "MIL-STD-975", "QML"],
         note="Rad-tolerant FPGAs (RTG4, RT PolarFire), space OCXOs/crystals/"
              "SAW (Mt Holly Springs PA), rad-hard power, MRAM and memories."),
    dict(name="STMicroelectronics", kind="manufacturer",
         url="https://www.st.com",
         space_url="https://www.st.com/en/applications/aerospace-and-defense.html",
         form="https://www.st.com/content/st_com/en/contact-us.html",
         cats={"power", "data_converter", "interface", "ic"},
         quals=["rad-hard", "QML / ESCC"],
         note="Rad-hard power, logic and mixed-signal; European space supply "
              "with ESCC-qualified and QMLV parts."),
    dict(name="Infineon (HiRel)", kind="manufacturer",
         url="https://www.infineon.com",
         space_url="https://www.infineon.com/cms/en/product/space-solutions/",
         form="https://www.infineon.com/cms/en/about-infineon/company/contacts/",
         cats={"power", "ic"},
         quals=["HiRel", "rad-hard (MIL/space)"],
         note="Space power from the International Rectifier HiRel heritage: "
              "rad-hard MOSFETs, DC-DC converters and controllers."),
    dict(name="BAE Systems (RAD)", kind="manufacturer",
         url="https://www.baesystems.com",
         space_url="https://www.baesystems.com/en-us/definition/radiation-hardened-electronics",
         form="https://www.baesystems.com/en-us/our-company/inc-businesses/electronic-systems/contact-us",
         cats={"ic"},
         quals=["rad-hard QMLV", "strategic/space"],
         note="RAD750 / RAD5545 rad-hard processors and rad-hard memory/logic "
              "(Manassas VA). Deep-space and strategic heritage."),
    dict(name="MACOM", kind="manufacturer",
         url="https://www.macom.com",
         space_url="https://www.macom.com/aerospace-and-defense",
         form="https://www.macom.com/support/request-information",
         cats={"amplifier", "mixer", "switch", "attenuator", "limiter",
               "detector", "phase_shifter"},
         quals=["hi-rel screening / SCD", "MIL-qualified diodes"],
         note="Broad RF/µW MMICs, diodes, switches and control products. Space "
              "parts via hi-rel screening / source-control drawings — ask sales."),
    dict(name="Marki Microwave", kind="manufacturer",
         url="https://www.markimicrowave.com", space_url="",
         form="https://www.markimicrowave.com/company/contact.aspx",
         cats={"mixer", "amplifier", "filter", "coupler", "divider"},
         quals=["hi-rel screening on request"],
         note="High-performance MMIC mixers, multipliers and passives to mmWave. "
              "Not QMLV; request hi-rel/space screening for flight builds."),
    dict(name="Mercury Systems", kind="manufacturer",
         url="https://www.mrcy.com",
         space_url="https://www.mrcy.com/microelectronics",
         form="https://www.mrcy.com/company/contact-us",
         cats={"data_converter", "ic"},
         quals=["rad-tolerant microelectronics", "screening/SiP"],
         note="Rad-tolerant RF & mixed-signal microelectronics, SiP and custom "
              "packaging; DMEA-trusted assembly and screening."),
    dict(name="Narda-MITEQ (L3Harris)", kind="manufacturer",
         url="https://nardamiteq.com", space_url="",
         form="https://nardamiteq.com/en/contact",
         cats={"amplifier", "mixer", "synthesizer", "detector", "coupler",
               "isolator", "switch"},
         quals=["hi-rel / space builds to spec"],
         note="RF/µW components and integrated assemblies (LNAs, mixers, "
              "synthesizers, detectors); space/hi-rel builds to source control."),
    dict(name="K&L Microwave", kind="manufacturer",
         url="https://www.klmicrowave.com", space_url="",
         form="https://www.klmicrowave.com/contact/",
         cats={"filter"},
         quals=["mil/space screening on request"],
         note="Cavity, LC, ceramic and suspended-substrate filters; military "
              "and space-screened variants available (Dover/API group)."),
    dict(name="DiTom Microwave", kind="manufacturer",
         url="https://www.ditom.com", space_url="",
         form="https://www.ditom.com/contact/",
         cats={"isolator", "circulator"},
         quals=["hi-rel / space screening on request"],
         note="Coaxial and drop-in isolators/circulators to ~40 GHz; screened "
              "hi-rel and space variants to customer flow."),
    dict(name="MECA Electronics", kind="manufacturer",
         url="https://www.e-meca.com", space_url="",
         form="https://www.e-meca.com/rf-microwave-contact-us/",
         cats={"isolator", "circulator", "coupler", "divider", "attenuator"},
         quals=["Space-Qualified series", "made in USA"],
         note="Passive RF (isolators, circulators, couplers, dividers, "
              "attenuators, terminations) with a dedicated space-qualified line."),
    dict(name="Q-Tech", kind="manufacturer",
         url="https://q-tech.com",
         space_url="https://q-tech.com/market-segments/high-reliability-space/",
         form="https://q-tech.com/contact/",
         cats={"oscillator", "clock"},
         quals=["MIL-PRF-55310 Class S/B", "AS9100", "TID to ~1 MRad(Si)"],
         note="Leading US space crystal-oscillator house: OCXO, TCXO, MCXO, "
              "VCXO, SAW; B+ small-form space clocks with a class-B fast path."),
    dict(name="Frequency Electronics (FEI)", kind="manufacturer",
         url="https://www.freqelec.com",
         space_url="https://www.freqelec.com/space-components/",
         form="https://www.freqelec.com/contact-us/",
         cats={"oscillator", "clock"},
         quals=["space frequency-control heritage"],
         note="Space timing & frequency generation: OCXOs, master clocks and "
              "rubidium/atomic references for satellites."),
    dict(name="Bliley Technologies", kind="manufacturer",
         url="https://bliley.com",
         space_url="https://bliley.com/markets/space/",
         form="https://bliley.com/contact/",
         cats={"oscillator"},
         quals=["NewSpace/space screening"],
         note="Low-phase-noise OCXOs/XOs for space and NewSpace; rad-tolerant "
              "options and short-lead NewSpace flows."),

    # ---- distributors & screening houses --------------------------------
    dict(name="Richardson RFPD (Arrow)", kind="distributor",
         url="https://www.richardsonrfpd.com",
         space_url="https://shop.richardsonrfpd.com/ProductContent/Application/Aerospace__and__Defense",
         email="rfpdsales@richardsonrfpd.com",
         form="https://www.richardsonrfpd.com/contact-us",
         cats={ALL},
         quals=["QPL/MIL-STD", "COTS upscreening", "rad-hard screening",
                "hermetic options"],
         note="RF/µW specialist distributor (more RF engineers than any global "
              "distributor). A&D line with QPL parts plus COTS upscreening, "
              "hermetic packaging and rad-hard screening services."),
    dict(name="Micross Components", kind="screening",
         url="https://www.micross.com",
         space_url="https://www.micross.com/components-and-services/hi-rel-ics-components/qml/smd-5962",
         form="https://www.micross.com/contact/",
         cats={ALL},
         quals=["QML/SMD (1,100+ DLA/DSCC)", "die, upscreen, assembly & test"],
         note="Hi-rel/space distributor and microelectronics services: QML/SMD "
              "catalog, bare die, upscreening, assembly and test (Integra, "
              "SemiDice). Good when you need screened or die-level parts."),
    dict(name="Mouser Electronics", kind="distributor",
         url="https://www.mouser.com",
         space_url="https://www.mouser.com/applications/aerospace-defense/",
         form="https://www.mouser.com/newsroom/contact-us/",
         cats={ALL},
         quals=["broadline; space/hi-rel lines where offered"],
         note="Broadline distributor; some space-grade/QMLV parts are catalog-"
              "orderable. Fast for eval/COTS and online quoting."),
    dict(name="Digi-Key", kind="distributor",
         url="https://www.digikey.com",
         space_url="https://www.digikey.com/en/supplier-centers",
         form="https://www.digikey.com/en/contact",
         cats={ALL},
         quals=["broadline; space/hi-rel lines where offered"],
         note="Broadline distributor with aerospace/defense supplier centers; "
              "online quote and strong small-quantity availability."),
    dict(name="Arrow Electronics", kind="distributor",
         url="https://www.arrow.com", space_url="",
         form="https://www.arrow.com/en/support",
         cats={ALL},
         quals=["broadline; franchised A&D lines"],
         note="Global broadline distributor (parent of Richardson RFPD); "
              "franchised aerospace/defense lines and program support."),

    # ---- marketplaces / search ------------------------------------------
    dict(name="everythingRF", kind="marketplace",
         url="https://www.everythingrf.com",
         space_url="https://www.everythingrf.com/space",
         form="https://www.everythingrf.com/rfq",
         cats={ALL},
         quals=["parametric search + vendor directory"],
         note="RF/µW parametric search across vendors with a space section; "
              "routes RFQs to the manufacturers."),
    dict(name="SATNow", kind="marketplace",
         url="https://www.satnow.com",
         space_url="https://www.satnow.com",
         form="https://www.satnow.com/rfq",
         cats={ALL},
         quals=["satellite/space marketplace + directory"],
         note="Satellite/space-focused component marketplace and vendor "
              "directory with RFQ routing."),

    # ---- qualification authorities / reference --------------------------
    dict(name="DLA Land & Maritime (VQ)", kind="authority",
         url="https://landandmaritimeapps.dla.mil",
         space_url="https://landandmaritimeapps.dla.mil/programs/smcr/",
         cats={ALL}, quals=["QML/QPL & SMD (5962) source of supply"],
         note="Check a part's qualification and approved sources: QML-38535, "
              "QPL and Standardized Microcircuit Drawings (5962 SMDs)."),
    dict(name="NASA NEPP / GSFC parts", kind="authority",
         url="https://nepp.nasa.gov", space_url="https://nepp.nasa.gov",
         cats={ALL}, quals=["radiation & reliability data"],
         note="NASA Electronic Parts and Packaging program: radiation test "
              "reports, derating and EEE parts guidance."),
    dict(name="ESA ESCC / EPPL", kind="authority",
         url="https://escies.org", space_url="https://escies.org",
         cats={ALL}, quals=["ESCC QPL & EPPL"],
         note="European space component qualification: ESCC Qualified Parts "
              "List and the European Preferred Parts List."),
]

_KIND_RANK = {"manufacturer": 0, "distributor": 1, "screening": 1,
              "marketplace": 2, "authority": 3}


def _serves(entry, category):
    cats = entry["cats"]
    return ALL in cats or (category in cats if category else True)


def suggest(category, space=True, freq_ghz=None):
    """Ranked suppliers for a category. Matching manufacturers first, then RF
    specialist / hi-rel distributors and broadline distributors, then
    marketplaces, then (space only) qualification authorities.

    `freq_ghz` is accepted for future band-aware ranking; not used yet."""
    matches = [e for e in _SUPPLIERS if _serves(e, category)]
    if not space:
        matches = [e for e in matches if e["kind"] != "authority"]

    def key(e):
        specific = 0 if (category and category in e["cats"]) else 1  # explicit cat first
        return (_KIND_RANK.get(e["kind"], 9), specific, e["name"].lower())

    ranked = sorted(matches, key=key)
    out = []
    for e in ranked:
        contact = (e.get("email") or ("quote form" if e.get("form") else "")
                   or e.get("url", ""))
        out.append({
            "name": e["name"], "kind": e["kind"],
            "url": e.get("space_url") or e["url"],
            "home": e["url"],
            "cats": ("all RF/µW" if ALL in e["cats"]
                     else ", ".join(sorted(e["cats"]))),
            "quals": "; ".join(e.get("quals", [])),
            "contact": contact,
            "note": e["note"],
            "_entry": e,
        })
    return out


def draft_context(entry, query=None):
    """Turn a supplier entry (either a raw _SUPPLIERS dict or a suggest() row)
    into the vendor dict rfq.draft expects: name, url, rfq_email, rfq_url, quals.
    """
    e = entry.get("_entry", entry)
    return {
        "name": e["name"],
        "url": e.get("space_url") or e.get("url", ""),
        "rfq_email": e.get("email", ""),
        "rfq_url": e.get("form") or e.get("space_url") or e.get("url", ""),
        "quals": e.get("quals", []),
        "kind": e.get("kind", ""),
    }
