"""From-scratch web-search fallback (SearXNG backend).

When the curated databases return no strong match, this module runs a plain web
search and returns a ranked list of *links* — clearly-labeled, unverified
candidates the engineer can open, not parts the tool claims to have vetted.

Backend: a self-hosted SearXNG instance (no API keys, no third-party quota). Set
its base URL with RFPARTS_SEARXNG_URL (default http://localhost:8888); the
instance must have the JSON output format enabled. The SearchBackend interface
is deliberately small so a different backend (Google CSE, Tavily, ...) can be
dropped in without touching the caller.

Results are de-duplicated by normalized URL and ranked by domain trust (known RF
manufacturers / distributors / everythingRF first) and by whether the hit looks
like an S-parameter / Touchstone file — which ties into the sNp indicator. A
dedicated query variant hunts specifically for Touchstone files.

Nothing here raises: a missing or unreachable backend yields an empty list plus
a log line.
"""
import os
import re
from urllib.parse import quote_plus, urlparse

import requests

from . import fetch
from .registry import synonyms

DEFAULT_SEARXNG = "http://localhost:8888"
TIMEOUT = int(os.environ.get("RFPARTS_WEB_TIMEOUT", "15") or "15")

# Domain -> trust score. Higher sorts first. Substring match on the host.
_RF_MANUFACTURERS = (
    "minicircuits.com", "analog.com", "qorvo.com", "skyworksinc.com", "macom.com",
    "markimicrowave.com", "custommmic.com", "psemi.com", "nxp.com", "infineon.com",
    "mercurysystems.com", "narda-miteq.com", "krytar.com", "ditom.com",
    "lownoisefactory.com", "pasternack.com", "fairviewmicrowave.com", "jfwindustries.com",
    "svmicrowave.com", "rlcelectronics.com",
)
_DISTRIBUTORS = ("digikey.com", "mouser.com", "richardsonrfpd.com", "rfmw.com", "arrow.com")
_AGGREGATORS = ("everythingrf.com", "octopart.com", "findchips.com")

_TRUST = {}
for _d in _RF_MANUFACTURERS:
    _TRUST[_d] = 5
for _d in _DISTRIBUTORS:
    _TRUST[_d] = 4
for _d in _AGGREGATORS:
    _TRUST[_d] = 3

_SNP_HINT = re.compile(r"\.s\d{1,2}p\b|touchstone|s-?paramet|snp\b", re.I)
_LOW_TRUST = re.compile(r"(reddit|forum|facebook|pinterest|youtube|wikipedia)\.", re.I)


def _domain(url):
    try:
        host = urlparse(url).netloc.lower()
    except ValueError:
        return ""
    return host[4:] if host.startswith("www.") else host


def _normalize_url(url):
    try:
        p = urlparse(url.strip())
    except (ValueError, AttributeError):
        return ""
    return f"{p.scheme.lower()}://{p.netloc.lower()}{p.path.rstrip('/')}"


def _trust(host):
    for dom, score in _TRUST.items():
        if host == dom or host.endswith("." + dom) or dom in host:
            return score
    if _LOW_TRUST.search(host or ""):
        return -2
    return 0


class SearchBackend:
    """Interface: search(query, n) -> [{'title','url','snippet','source'}]."""

    def search(self, query, n=10):  # pragma: no cover - interface
        raise NotImplementedError


class SearxngBackend(SearchBackend):
    """Query a self-hosted SearXNG instance via its JSON output."""

    def __init__(self, base_url=None, getter=None):
        self.base = (base_url or os.environ.get("RFPARTS_SEARXNG_URL")
                     or DEFAULT_SEARXNG).rstrip("/")
        # getter(url) -> parsed json dict; injectable for tests.
        self._get = getter or self._http_get

    def _http_get(self, url):
        r = requests.get(url, headers={"User-Agent": fetch.UA,
                                       "Accept": "application/json"}, timeout=TIMEOUT)
        if r.status_code >= 400:
            fetch.log(f"searxng HTTP {r.status_code}")
            return None
        try:
            return r.json()
        except ValueError:
            fetch.log("searxng: response was not JSON (is format=json enabled?)")
            return None

    def search(self, query, n=10):
        url = f"{self.base}/search?q={quote_plus(query)}&format=json&safesearch=0"
        try:
            payload = self._get(url)
        except requests.RequestException as exc:
            fetch.log(f"searxng unreachable: {type(exc).__name__}")
            return []
        return self.parse_results(payload)[:n]

    @staticmethod
    def parse_results(payload):
        if not isinstance(payload, dict):
            return []
        out = []
        for row in payload.get("results", []) or []:
            if not isinstance(row, dict):
                continue
            url = row.get("url")
            if not url:
                continue
            out.append({
                "title": row.get("title") or url,
                "url": url,
                "snippet": row.get("content") or "",
                "source": row.get("engine") or "",
            })
        return out


def _query_variants(spec, query=None):
    """Yield (query_string, is_snp_focused) variants from an explicit query or spec."""
    if query:
        base = query.strip()
    else:
        parts = []
        cat = spec.get("category")
        if cat:
            syn = synonyms(cat)
            parts.append(syn[0] if syn else cat)
        if spec.get("freq_ghz"):
            lo, hi = spec["freq_ghz"]
            parts.append(f"{lo:g}-{hi:g} GHz")
        if spec.get("impedance_ohm"):
            parts.append(f"{spec['impedance_ohm']:g} ohm")
        if spec.get("connector"):
            parts.append(str(spec["connector"]))
        for tok in spec.get("other", []) or []:
            parts.append(str(tok))
        base = " ".join(parts).strip()
    if not base:
        return []
    return [(f"{base} datasheet", False),
            (f"{base} s-parameters touchstone", True)]


def web_fallback(spec, backend=None, limit=None, query=None, cancel=None):
    """Run the web-search fallback and return ranked, de-duplicated link candidates.

    Each candidate: {_web: True, title, url, snippet, source (domain), snp (bool),
    vendor (domain), score}. Returns [] on any failure or when nothing is found.
    """
    if limit is None:
        try:
            limit = int(os.environ.get("RFPARTS_WEB_RESULTS", "12"))
        except ValueError:
            limit = 12
    if backend is None:
        backend = SearxngBackend()

    variants = _query_variants(spec, query)
    if not variants:
        return []

    by_url = {}
    for q, is_snp in variants:
        if cancel is not None and cancel.is_set():
            break
        try:
            rows = backend.search(q, n=limit)
        except Exception:  # noqa: BLE001 - a backend hiccup must not sink the run
            rows = []
        for row in rows:
            key = _normalize_url(row.get("url", ""))
            if not key:
                continue
            snp = is_snp or bool(_SNP_HINT.search(
                f"{row.get('url', '')} {row.get('snippet', '')}"))
            existing = by_url.get(key)
            if existing is None:
                host = _domain(row.get("url", ""))
                by_url[key] = {
                    "_web": True,
                    "title": row.get("title") or row.get("url"),
                    "url": row.get("url"),
                    "snippet": row.get("snippet", ""),
                    "source": host,
                    "vendor": host,
                    "snp": snp,
                    "score": _trust(host) + (1 if snp else 0),
                }
            elif snp and not existing["snp"]:
                existing["snp"] = True
                existing["score"] += 1

    results = sorted(by_url.values(), key=lambda c: (-c["score"], c["source"]))
    return results[:limit]
