r"""rfparts_space.py — find HI-REL / SPACE-QUALIFIED parts across many categories.

Refined pass. Space/hi-rel parts live at (a) space-focused marketplaces that let
you filter by "space qualified" via URL, and (b) manufacturers/distributors whose
lines are rad-hard / MIL-PRF-38534 Class K / QML-V. This debug probes those
sources for space/hi-rel parts in many categories and filters OUT non-devices
(catalog links, MIL-STD/MIL-PRF/ESCC standards, brochures, manufacturer landings).

What's new vs the first version:
  * URL-level pre-filtering: SATNow facet URLs (e.g. amplifiers + stype="Low
    Noise Amplifier" for LNAs, stype="Power Amplifier" for PAs, variable
    attenuators + stype="Digital"), so the site returns the right subset.
  * Corrected SATNow slugs (mixers=microwave-rf-mixers, attenuators=
    microwave-rf-fixed-attenuators, couplers=couplers, ...).
  * Non-device filter: drops "Catalog Products (N)", MIL-STD/MIL-PRF/MIL-C/ESCC/
    QML/SMD standards, brochures/reports, and bare manufacturer names. SATNow
    items are kept only when the link is a real /products/ page.
  * Fairview, Pasternack and Teledyne added directly as sources.
  * Optional shallow follow (--follow N) turns a manufacturer's category links
    into actual parts.

Gentle by design: polite, robots-obeying, cached fetch; capped pages; product
pages not fetched unless --follow. Keep caps modest so no site is overloaded.

Output: rfparts_space_log.txt + rfparts_space_data.json (send the JSON back).

Usage:
  python rfparts_space.py
  python rfparts_space.py --categories lna phase_shifter switch
  python rfparts_space.py --sources satnow teledyne_e2v pasternack fairview
  python rfparts_space.py --follow 4         # follow manufacturer category links
  python rfparts_space.py --list-sources
  python rfparts_space.py --self-test
"""
from __future__ import annotations

import argparse
import hashlib
import html
import json
import os
import pathlib
import random
import re
import sys
import tempfile
import time
from collections import defaultdict
from urllib.parse import quote, quote_plus, urljoin, urlparse

try:
    import requests
except Exception as exc:  # noqa: BLE001
    print(f"this tool needs the 'requests' package: {type(exc).__name__}: {exc}",
          file=sys.stderr)
    sys.exit(2)

PROJECT_ROOT = pathlib.Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


# =========================================================================
# gentle, browser-like fetcher (self-contained — does NOT hammer sites)
# =========================================================================
# Politeness measures, since these sites bot-limit aggressive clients:
#   * a real browser User-Agent + Accept headers (no brotli — we don't depend on it)
#   * a per-host delay with random jitter between requests
#   * retry-with-backoff on 403/429/503/network errors (a browser UA usually
#     clears a first 403), then give up quietly
#   * an on-disk cache so re-runs don't re-hit the site at all
#   * a hard global cap on total requests
#   * NEVER raises — a bad response/timeout returns None instead of crashing
BROWSER_HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"),
    "Accept": ("text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,"
               "image/webp,image/apng,*/*;q=0.8"),
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate",   # no 'br' — brotli may not be installed
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document", "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none", "Sec-Fetch-User": "?1",
}


class Fetcher:
    def __init__(self, delay=2.0, jitter=1.5, timeout=25, retries=2,
                 max_fetches=150, cache_dir=None, use_cache=True, sink=None):
        self.session = requests.Session()
        self.session.headers.update(BROWSER_HEADERS)
        self.delay, self.jitter = delay, jitter
        self.timeout, self.retries = timeout, retries
        self.max_fetches, self.used = max_fetches, 0
        self.use_cache = use_cache
        self.cache_dir = pathlib.Path(cache_dir or
                                      (pathlib.Path(tempfile.gettempdir()) / "rfparts_space_cache"))
        try:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            self.use_cache = False
        self.last_by_host = {}
        self.sink = sink or (lambda *a: None)

    def budget_left(self):
        return max(0, self.max_fetches - self.used)

    def _cache_path(self, url):
        return self.cache_dir / (hashlib.sha1(url.encode("utf-8")).hexdigest() + ".html")

    def get(self, url):
        """Fetch a URL gently; return text or None. Never raises."""
        if self.use_cache:
            cp = self._cache_path(url)
            try:
                if cp.exists():
                    return cp.read_text("utf-8", errors="replace")
            except Exception:
                pass
        if self.used >= self.max_fetches:
            self.sink(f"      (global fetch cap {self.max_fetches} reached; skipping {short(url, 60)})")
            return None
        host = urlparse(url).netloc
        # per-host spacing with jitter
        wait = self.delay + random.uniform(0, self.jitter) - (time.time() - self.last_by_host.get(host, 0))
        if wait > 0:
            time.sleep(wait)
        text = None
        for attempt in range(self.retries + 1):
            try:
                r = self.session.get(url, timeout=self.timeout)
                self.last_by_host[host] = time.time()
                self.used += 1
                if r.status_code == 200 and r.text:
                    text = r.text
                    break
                if r.status_code in (403, 429, 503) and attempt < self.retries:
                    time.sleep((attempt + 1) * 3 + random.uniform(0, 1.5))
                    continue
                self.sink(f"      HTTP {r.status_code} for {short(url, 70)}")
                break
            except Exception as e:  # noqa: BLE001
                self.last_by_host[host] = time.time()
                if attempt < self.retries:
                    time.sleep((attempt + 1) * 2 + random.uniform(0, 1.0))
                    continue
                self.sink(f"      fetch error ({type(e).__name__}) for {short(url, 60)}")
                break
        if text and self.use_cache:
            try:
                self._cache_path(url).write_text(text, "utf-8")
            except Exception:
                pass
        return text


# Module-level fetcher; configured in main().
FETCH = Fetcher()


# =========================================================================
# space-qualification signal taxonomy
# =========================================================================
SPACE_LEVEL = re.compile(
    r"\bclass\s*[kvy]\b|\bqml\s*-?\s*[vy]\b|\bqmlv\b|\bjans\b|\bjansr\b|"
    r"space[-\s]?(?:level|grade|qualified|qualification|flight|heritage)|"
    r"flight[-\s]?(?:qualified|proven|heritage)|\bclass\s*s\b|\bs-?level\b|"
    r"rad(?:iation)?[-\s]?(?:hard|tolerant)(?:ened)?|\bqml-?v\b|\d+\s*krad", re.I)
HIREL = re.compile(
    r"\bhi-?rel\b|high[-\s]reliability|mil-?prf-?3853[45]|mil-?std-?883|"
    r"mil-?prf-?55310|mil-?prf-?19500|\bclass\s*[hgq]\b|\bqml\b|\bjantxv?\b|"
    r"screen(?:ed|ing)|up-?screen(?:ed|ing)?|burn-?in|hermetic(?:ally)?|\bTID\b|"
    r"\bSEE\b|single[-\s]event|leadless\s+hermetic", re.I)


def classify(text):
    blob = text or ""
    m = SPACE_LEVEL.search(blob)
    if m:
        return "space", m.group(0)
    h = HIREL.search(blob)
    if h:
        return "hi_rel", h.group(0)
    return "none", None


# =========================================================================
# NON-DEVICE filter — drop catalogs, standards, docs, manufacturer landings
# =========================================================================
# Standards / specs / quality docs — never a purchasable device.
STANDARDS_RX = re.compile(
    r"\bMIL-?STD-?\d|\bMIL-?PRF-?\d|\bMIL-?DTL-?\d|\bMIL-?C-?\d|\bMIL-?M-?\d|"
    r"\bMIL-?S-?\d|\bMIL-?T-?\d|\bMIL-?E-?\d|\bESCC\b|\bECSS\b|\bSMD\s*5962\b|"
    r"\b5962-?\d|\bDSCC\b|\bEEE-?INST\b|\bJESD\b|\bASTM\b|\bAEC-?Q\b|\bQML-?\d|"
    r"\bMIL-?PRF\b|\bMIL-?STD\b", re.I)
# Pages / links that are not a single part.
NON_DEVICE_RX = re.compile(
    r"\bcatalog\b|products?\s*\(\s*\d|\breport\b|responsib|brochure|white\s*paper|"
    r"\boverview\b|capabilit|\bsupplier\b|service\s+provider|\bscanning\b|"
    r"integration|secure\s+files|\bdirectory\b|manufacturers?\b|\bnews\b|\bblog\b|"
    r"webinar|\bvideo\b|datasheet|application\s+note|\bapp\s+note\b|training|"
    r"resources?\b|\bprofile\b|\bcompany\b|\babout\b|\bcontact\b|\bhome\b|\blogin\b|"
    r"\bquote\b|\bcompare\b|\bdownload\b|\bterms\b|privacy|cookie|sitemap|careers|"
    r"\bquality\b|certificat|\bfaq\b|\bcart\b|\bregister\b|subscribe|newsletter|"
    r"how\s+to\s+buy|where\s+to\s+buy|\bsupport\b", re.I)

_NAV_WORDS = ("login", "sign in", "signin", "view all", "see all", "read more",
              "learn more", "add to", "back to", "next", "previous")


def looks_like_part(text):
    if not text or not (3 <= len(text) <= 80):
        return False
    low = text.lower()
    if any(w in low for w in _NAV_WORDS):
        return False
    return bool(re.search(r"[A-Za-z]", text) and re.search(r"\d", text))


_MFR_PART_RX = re.compile(r"^(.{2,60}?)\s+[-–—]\s+([A-Za-z0-9][A-Za-z0-9\-\.\/\+ ]{2,40})$")


def parse_mfr_part(title):
    """'Mini Circuits - CMA-545G1+' -> ('Mini Circuits', 'CMA-545G1+'), else None."""
    m = _MFR_PART_RX.match(title or "")
    if not m:
        return None
    mfr, part = m.group(1).strip(), m.group(2).strip()
    if STANDARDS_RX.search(part) or not re.search(r"[A-Za-z]", part) or not re.search(r"\d", part):
        return None
    return mfr, part


_COMPANY_RX = re.compile(
    r"\b(inc|llc|ltd|limited|corp|corporation|gmbh|co|company|technolog(?:y|ies)|"
    r"electronics|systems|associates|industries|semiconductors?|microwave|"
    r"microcircuits?|labs?|monolithics?|solutions|group|s\.?a\.?|ag)\.?\s*$", re.I)


def is_device(title):
    """True if the title looks like a real part (not a standard/catalog/doc/company)."""
    t = (title or "").strip()
    if not t or STANDARDS_RX.search(t) or NON_DEVICE_RX.search(t):
        return False
    if _COMPANY_RX.search(t) and not parse_mfr_part(t):
        return False                      # bare company name (e.g. "…HiRel Electronics")
    if parse_mfr_part(t):
        return True
    return looks_like_part(t)


def is_product_url(url):
    u = (url or "").lower()
    if not u or u.startswith("javascript") or u.startswith("mailto") or u.endswith(".pdf"):
        return False
    return any(k in u for k in ("/products/", "/product/", "/product-detail",
                                "/part/", "/item/", "-category.aspx", "/detail/",
                                "-p.aspx"))


# =========================================================================
# SOURCES
# =========================================================================
def _facet(value):
    return "%3B" + quote_plus(str(value)) + "%3B"   # ;Value; (SATNow/everythingRF facet)


# category -> list of (slug, facet_param|None, facet_value|None). Tried in order.
SATNOW = {
    "lna":            [("microwave-rf-amplifiers", "stype", "Low Noise Amplifier")],
    "amplifier":      [("microwave-rf-amplifiers", None, None)],
    "power_amplifier":[("microwave-rf-amplifiers", "stype", "Power Amplifier"),
                       ("microwave-rf-amplifiers", "stype", "High Power Amplifier")],
    "phase_shifter":  [("analog-phase-shifters", None, None),
                       ("digital-phase-shifters", None, None)],
    "attenuator":     [("microwave-rf-fixed-attenuators", None, None),
                       ("microwave-rf-variable-attenuators", None, None)],
    "switch":         [("microwave-rf-switches", None, None), ("rf-switches", None, None),
                       ("switches", None, None)],
    "filter":         [("rf-filters", None, None)],
    "mixer":          [("microwave-rf-mixers", None, None)],
    "limiter":        [("microwave-rf-limiters", None, None), ("limiters", None, None),
                       ("rf-limiters", None, None)],
    "coupler":        [("couplers", None, None), ("directional-couplers", None, None)],
    "divider":        [("power-dividers-combiners", None, None),
                       ("rf-power-dividers-splitters", None, None), ("splitters-combiners", None, None)],
    "isolator":       [("isolators", None, None), ("isolators-circulators", None, None),
                       ("rf-isolators", None, None)],
    "circulator":     [("circulators", None, None), ("isolators-circulators", None, None)],
    "oscillator":     [("oscillators", None, None)],
    "multiplier":     [("microwave-rf-frequency-multipliers", None, None),
                       ("frequency-multipliers", None, None)],
}

MARKETPLACES = [
    {"key": "satnow", "name": "SATNow (Space & Satellite marketplace)", "domain": "satnow.com",
     "kind": "satnow", "browse": "https://www.satnow.com/search/microwave-rf-amplifiers"},
    {"key": "everythingrf", "name": "everythingRF (Space-Qualified filter)", "domain": "everythingrf.com",
     "kind": "everythingrf",
     "template": ("https://www.everythingrf.com/search/{slug}/filters"
                  "?page={page}&country=global&sgrade=%3BSpace+Qualified%3B"),
     "slugs": {"lna": "low-noise-amplifiers", "amplifier": "microwave-rf-amplifiers",
               "phase_shifter": "phase-shifters", "filter": "rf-filters",
               "switch": "rf-switches", "mixer": "rf-mixers", "attenuator": "rf-attenuators"},
     "browse": "https://www.everythingrf.com/browse/space-qualified-components"},
]

DISTRIBUTORS = [
    # Pasternack "Enhanced" = screened / hi-rel grade. The listing is URL-filtered
    # by Category + a per-category <Rf…99relgrade>=Enhanced param, so every part
    # returned is hi-rel/space-screened. (Params taken from Pasternack's own menu.)
    {"key": "pasternack", "name": "Pasternack (Enhanced/hi-rel grade)", "domain": "pasternack.com",
     "mode": "pasternack", "grade": "hi_rel",
     "cats": {
        "lna": [("Low Noise Amplifiers", "Rfacamln99relgrade")],
        "amplifier": [("Broadband Amplifiers", "Rfacambb99relgrade"),
                      ("Gain Block Amplifiers", "Rfacamgb99relgrade"),
                      ("Bi Directional Amplifiers", "Rfacambd99relgrade")],
        "power_amplifier": [("Power Amplifiers", "Rfacampa99relgrade")],
        "phase_shifter": [("Phase Shifters and Trimmers", "Rfpsph99relgrade")],
        "attenuator": [("Programmable Attenuators", "Rfacatpr99relgrade"),
                       ("Voltage Variable Attenuators", "Rfacatvv99relgrade")],
        "switch": [("PIN Diode Switches", "Rfacswpinstd99relgrade"),
                   ("High Isolation Switches", "Rfacswpinhstd99relgrade"),
                   ("Electromechanical Relay Switches", "Rfacswelm99relgrade")],
        "mixer": [("Mixers", "Rfacmx99relgrade")],
        "limiter": [("Limiting Amplifiers", "Rfacamlim99relgrade")],
        "divider": [("Frequency Dividers", "Rfacdv99relgrade")],
        "oscillator": [("Phase Locked Oscillators", "Rfacospl99relgrade"),
                       ("Voltage Control Oscillators", "Rfacosvo99relgrade"),
                       ("Reference Oscillators", "Rfacosro99relgrade"),
                       ("Temperature Compensated Crystal Oscillators", "Rfacostcxo99relgrade")],
     },
     "note": "Enhanced = screened/hi-rel grade (results are URL-filtered to Enhanced)"},
    # Fairview (Infinite Electronics, Algolia): /category/<group>/<subcat>.html.
    # Grade isn't a simple URL param here, so parts are listed and grade is
    # classified from the page / flagged for verification (SATNow or datasheet).
    {"key": "fairview", "name": "Fairview Microwave", "domain": "fairviewmicrowave.com",
     "mode": "fairview",
     "cats": {
        "lna": "rf-amplifiers/low-noise-rf-amplifiers",
        "power_amplifier": "rf-amplifiers/power-amplifiers",
        "amplifier": "rf-amplifiers/gain-block-amplifiers",
        "limiter": "rf-amplifiers/limiting-amplifiers",
        "phase_shifter": "phase-shifters",
        "attenuator": "attenuators/fixed-attenuators",
        "switch": "rf-switches/pin-diode-switches",
        "mixer": "rf-mixers-multipliers/rf-mixers",
     },
     "note": "category pages (Algolia); grade classified from page / verify on SATNow"},
]

MANUFACTURERS = [
    {"key": "teledyne_e2v", "name": "Teledyne e2v HiRel", "base": "https://www.teledynedefenseelectronics.com/",
     "landing": ["https://www.teledynedefenseelectronics.com/e2vhrel/products/Pages/Space.aspx",
                 "https://www.teledynedefenseelectronics.com/e2vhrel/products/Pages/RF-and-Microwave.aspx"],
     "note": "LNAs, PAs, DVGAs, digital step attenuators, limiters, mixers, PLLs, switches — MIL-PRF-38534 Class K"},
    {"key": "caes", "name": "CAES (Cobham Advanced Electronic Solutions)", "base": "https://caes.com/",
     "landing": ["https://caes.com/products/rf-microwave"], "note": "largest US rad-hard analog/RF provider"},
    {"key": "arralis", "name": "Arralis", "base": "https://arralis.com/",
     "landing": ["https://arralis.com/products/"], "note": "space-qualified Ka/E-band MMICs: phase shifters, LNAs, PAs, mixers"},
    {"key": "micross", "name": "Micross Hi-Rel RF Solutions", "base": "https://www.micross.com/",
     "landing": ["https://www.micross.com/components-and-services/hi-rel-rf-solutions"],
     "note": "hi-rel RF SMT semiconductors, MMIC die, MCMs; leadless hermetic, MIL-screened"},
    {"key": "macom", "name": "MACOM Aerospace & Defense", "base": "https://www.macom.com/",
     "landing": ["https://www.macom.com/products/rf-microwave-mmwave/amplifiers/rf-power-amplifiers/aerospace-and-defense"],
     "note": "A&D RF/microwave; space-screened options on many MMICs"},
    {"key": "qorvo", "name": "Qorvo Defense & Aerospace", "base": "https://www.qorvo.com/",
     "landing": ["https://www.qorvo.com/products/space", "https://www.qorvo.com/products/aerospace-defense"],
     "note": "space/defense MMIC LNAs, PAs, switches, phase shifters, core chips"},
    {"key": "adi", "name": "Analog Devices — Space", "base": "https://www.analog.com/",
     "landing": ["https://www.analog.com/en/product-category/space-products.html"],
     "note": "space-grade (rad-tolerant/-hardened) RF and mixed-signal, QML options"},
    {"key": "criteria", "name": "Criteria Labs", "base": "https://www.criterialabs.com/",
     "landing": ["https://www.criterialabs.com/products/"],
     "note": "up-screening house: commercial/COTS RF ICs to space grade (QML-equivalent)"},
    {"key": "minicircuits_space", "name": "Mini-Circuits — Space Upscreening", "base": "https://www.minicircuits.com/",
     "landing": ["https://www.minicircuits.com/ads/space-upscreening.html"],
     "note": "upscreens the majority of its catalog in-house (LTCC/ceramic especially)"},
    {"key": "pmi", "name": "Planar Monolithics Industries (PMI)", "base": "https://www.pmi-rf.com/",
     "landing": ["https://www.pmi-rf.com/"], "note": "hi-rel/space phase shifters, limiters, switches, amplifiers"},
    {"key": "aethercomm", "name": "Aethercomm", "base": "https://aethercomm.com/",
     "landing": ["https://aethercomm.com/products/"], "note": "hi-rel/space SSPAs and LNAs"},
    {"key": "narda_miteq", "name": "Narda-MITEQ", "base": "https://nardamiteq.com/",
     "landing": ["https://nardamiteq.com/products.php"], "note": "space-qualified amplifiers, LNAs (MITEQ heritage)"},
]

SPACE_MFR_HINTS = ("teledyne", "e2v", "caes", "cobham", "arralis", "micross", "qorvo",
                   "analog devices", "macom", "m/a-com", "criteria", "mini circuits",
                   "mini-circuits", "planar monolithics", "pmi", "aethercomm", "narda",
                   "miteq", "mercury", "northrop", "erzia", "united monolithic",
                   "cml", "microchip", "renesas", "skyworks", "infineon", "kyocera",
                   "crane", "stellant", "nuvotronics", "raltron", "rakon", "wenzel",
                   "morion", "q-tech", "quartzlock", "greenray")


# =========================================================================
# helpers
# =========================================================================
class Tee:
    def __init__(self, path, max_line=4000):
        self.fh = open(path, "w", encoding="utf-8")
        self.max_line = max_line

    def __call__(self, msg=""):
        line = str(msg)
        try:
            print(line)
        except Exception:
            print(line.encode("ascii", "replace").decode("ascii"))
        self.fh.write((line[: self.max_line] + " …[trunc]" if len(line) > self.max_line
                       else line) + "\n")
        self.fh.flush()

    def close(self):
        try:
            self.fh.close()
        except Exception:
            pass


def rule(sink, title, ch="="):
    sink(""); sink(ch * 78); sink(title); sink(ch * 78)


def short(v, n=140):
    s = "" if v is None else str(v)
    s = re.sub(r"\s+", " ", s).strip()
    return s if len(s) <= n else s[:n] + "…"


_A_RX = re.compile(r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', re.I | re.S)
_TAG_RX = re.compile(r"<[^>]+>")


def extract_anchors(html_text, base_url):
    """(title, url) for every anchor with visible text (deduped by title)."""
    out, seen = [], set()
    for href, inner in _A_RX.findall(html_text or ""):
        text = html.unescape(re.sub(r"\s+", " ", _TAG_RX.sub(" ", inner)).strip())
        if not text or len(text) > 90:
            continue
        try:
            url = urljoin(base_url, href)
        except Exception:
            url = None
        key = (text.lower(), url)
        if key in seen:
            continue
        seen.add(key)
        out.append({"title": text, "url": url})
        if len(out) >= 800:
            break
    return out


def guess_manufacturer(text):
    low = (text or "").lower()
    for m in SPACE_MFR_HINTS:
        if m in low:
            return m
    return None


# =========================================================================
# probes
# =========================================================================
def probe_satnow(cat, args, sink):
    """SATNow is a space marketplace; keep only real /products/ links."""
    for slug, fparam, fval in SATNOW.get(cat, []):
        if fparam:
            url0 = (f"https://www.satnow.com/search/{slug}/filters"
                    f"?page=1&country=global&{fparam}={_facet(fval)}")
            page_tmpl = (f"https://www.satnow.com/search/{slug}/filters"
                         f"?page={{page}}&country=global&{fparam}={_facet(fval)}")
        else:
            url0 = f"https://www.satnow.com/search/{slug}?page=1"
            page_tmpl = f"https://www.satnow.com/search/{slug}?page={{page}}"
        items = []
        for page in range(1, args.max_pages + 1):
            html_text = FETCH.get(page_tmpl.format(page=page))
            if not html_text:
                if page == 1:
                    sink(f"    {cat:<15} [{slug}] no content (blocked/unreachable) -> {url0}")
                break
            page_items = [it for it in extract_anchors(html_text, url0)
                          if is_product_url(it["url"]) and is_device(it["title"])]
            for it in page_items:
                mp = parse_mfr_part(it["title"])
                it["manufacturer"] = mp[0] if mp else guess_manufacturer(it["title"])
                it["part"] = mp[1] if mp else it["title"]
                it["tier"], it["signal"] = "space", "SATNow space DB"
            items.extend(page_items)
            if len(page_items) < 5:
                break
        if items:
            uniq = {}
            for it in items:
                uniq.setdefault((it.get("part") or it["title"]).lower(), it)
            hits = list(uniq.values())
            sink(f"    {cat:<15} {len(hits):>3} devices   {url0}")
            return {"slug": slug, "facet": (fparam, fval), "url": url0,
                    "count": len(hits), "items": hits[: args.max_items]}
    sink(f"    {cat:<15}   0 devices (tried {len(SATNOW.get(cat, []))} slug(s))")
    return {"slug": None, "count": 0, "items": []}


def probe_everythingrf(cat, src, args, sink):
    slug = src["slugs"].get(cat)
    if not slug:
        return {"count": 0, "items": []}
    url = src["template"].format(slug=slug, page=1)
    html_text = FETCH.get(url)
    if not html_text:
        sink(f"    {cat:<15} [{slug}] blocked/unreachable (open manually) -> {url}")
        return {"url": url, "count": 0, "items": [], "blocked": True}
    items = [it for it in extract_anchors(html_text, url)
             if is_device(it["title"]) and is_product_url(it["url"])]
    for it in items:
        it["tier"], it["signal"] = "space", "everythingRF space filter"
        mp = parse_mfr_part(it["title"])
        it["manufacturer"] = mp[0] if mp else guess_manufacturer(it["title"])
    sink(f"    {cat:<15} {len(items):>3} devices   {url}")
    return {"url": url, "count": len(items), "items": items[: args.max_items]}


def _distributor_keep(it, domain):
    """Keep real product links from a distributor listing (drop nav/category)."""
    if not is_device(it["title"]):
        return False
    u = (it.get("url") or "").lower()
    if not u or u.startswith("javascript") or u.startswith("mailto") or "#" in u:
        return False
    if not _same_domain(u, domain):
        return False
    if any(bad in u for bad in ("nsearch.aspx", "-category.aspx", "/category/",
                                "/nsearch", "/search")):
        return False
    return True


def probe_distributor(cat, src, args, sink):
    domain = src["domain"]
    if src["mode"] == "pasternack":
        specs = src["cats"].get(cat, [])
        if not specs:
            sink(f"    {cat:<15} (not offered at Enhanced grade)")
            return {"count": 0, "items": []}
        items, used = [], []
        for catname, relgrade in specs:
            url = (f"https://www.pasternack.com/nsearch.aspx?Category={quote(catname)}"
                   f"&{relgrade}=Enhanced&view_type=grid")
            html_text = FETCH.get(url)
            if not html_text:
                sink(f"    {cat:<15} [{catname}] blocked/unreachable -> {url}")
                continue
            used.append(url)
            for it in extract_anchors(html_text, url):
                if not _distributor_keep(it, domain):
                    continue
                mp = parse_mfr_part(it["title"])
                it["tier"], it["signal"] = "hi_rel", "Pasternack Enhanced grade"
                it["manufacturer"], it["part"] = "Pasternack", (mp[1] if mp else it["title"])
                items.append(it)
        uniq = {}
        for i in items:
            uniq.setdefault((i.get("part") or i["title"]).lower(), i)
        hits = list(uniq.values())
        sink(f"    {cat:<15} {len(hits):>3} Enhanced (hi-rel) devices   {used[0] if used else '(none)'}")
        return {"urls": used, "count": len(hits), "items": hits[: args.max_items]}

    # Fairview (Algolia category path)
    path = src["cats"].get(cat)
    if not path:
        sink(f"    {cat:<15} (no known Fairview category path)")
        return {"count": 0, "items": []}
    url = (f"https://www.fairviewmicrowave.com/category/{path}.html"
           f"?hitsPerPage=96&indexName=fm_product_en_prod&page=0")
    html_text = FETCH.get(url)
    if not html_text:
        sink(f"    {cat:<15} blocked/unreachable -> {url}")
        return {"url": url, "count": 0, "items": [], "blocked": True}
    page_sig = "space" if SPACE_LEVEL.search(html_text) else (
        "hi_rel" if HIREL.search(html_text) else None)
    items = []
    for it in extract_anchors(html_text, url):
        if not _distributor_keep(it, domain):
            continue
        t, s = classify(it["title"])
        it["tier"] = t if t != "none" else (page_sig or "unverified")
        it["signal"] = s or (f"on {page_sig} page" if page_sig else "Fairview category (verify grade)")
        it["manufacturer"] = "Fairview"
        items.append(it)
    uniq = {}
    for i in items:
        uniq.setdefault(i["title"].lower(), i)
    hits = list(uniq.values())
    graded = sum(1 for i in hits if i["tier"] in ("space", "hi_rel"))
    sink(f"    {cat:<15} {len(hits):>3} devices ({graded} with explicit grade)   {url}")
    return {"url": url, "count": len(hits), "items": hits[: args.max_items]}


# Known homepages for space/hi-rel manufacturers (used to turn a manufacturer
# NAME discovered on SATNow into its own site). Substring match on the SATNow
# manufacturer name (lowercased). Extend as new names show up in the logs.
MFR_SITES = {
    "teledyne": "teledynedefenseelectronics.com", "e2v": "teledynedefenseelectronics.com",
    "qorvo": "qorvo.com", "analog devices": "analog.com", "macom": "macom.com",
    "m/a-com": "macom.com", "mercury": "mercurysystems.com", "micross": "micross.com",
    "narda": "nardamiteq.com", "miteq": "nardamiteq.com", "caes": "caes.com",
    "cobham": "caes.com", "arralis": "arralis.com", "criteria": "criterialabs.com",
    "mini circuits": "minicircuits.com", "mini-circuits": "minicircuits.com",
    "cml": "cmlmicro.com", "kyocera": "kyocera-avx.com", "avx": "kyocera-avx.com",
    "crane": "craneae.com", "nuvotronics": "cubic.com", "raltron": "raltron.com",
    "rakon": "rakon.com", "wenzel": "wenzel.com", "morion": "morion.com.ru",
    "q-tech": "q-tech.com", "quartzlock": "quartzlock.com", "greenray": "greenrayindustries.com",
    "united monolithic": "ums-rf.com", "ums": "ums-rf.com", "erzia": "erzia.com",
    "stellant": "stellantsystems.com", "northrop": "northropgrumman.com",
    "microchip": "microchip.com", "skyworks": "skyworksinc.com", "psemi": "psemi.com",
    "guerrilla": "guerrilla-rf.com", "marki": "markimicrowave.com", "pmi": "pmi-rf.com",
    "planar monolithics": "pmi-rf.com", "aethercomm": "aethercomm.com",
    "infineon": "infineon.com", "renesas": "renesas.com", "spectrum control": "api-tech.com",
    "api ": "api-tech.com", "cobham": "caes.com", "wi2wi": "wi2wi.com",
    "axtal": "axtal.com", "aspen": "aspenelectronicsinc.com", "raytheon": "raytheon.com",
    "l3": "l3harris.com", "ducommun": "ducommun.com", "anaren": "ttmtech.com",
}

# Keywords used to spot category links on a manufacturer homepage.
CAT_KEYWORDS = {
    "lna": ("low noise", "low-noise", "lna", "amplifier"),
    "amplifier": ("amplifier", "amplifiers"),
    "power_amplifier": ("power amplifier", "power-amplifier", "hpa", "solid state power"),
    "phase_shifter": ("phase shifter", "phase-shifter", "phase shift"),
    "attenuator": ("attenuator",), "switch": ("switch", "switches"),
    "filter": ("filter", "filters"), "mixer": ("mixer", "mixers", "converter"),
    "limiter": ("limiter",), "coupler": ("coupler", "hybrid", "directional"),
    "divider": ("divider", "splitter", "combiner"),
    "isolator": ("isolator",), "circulator": ("circulator",),
    "oscillator": ("oscillator", "vco", "dro", "ocxo", "tcxo"),
    "multiplier": ("multiplier",),
}



def _same_domain(url, domain):
    try:
        host = urlparse(url).netloc.lower()
    except Exception:
        return False
    return host.endswith(domain)


def resolve_domain(mfr_name):
    low = (mfr_name or "").lower()
    for key, dom in MFR_SITES.items():
        if key in low:
            return dom
    return None


def discover_manufacturers_from_satnow(payload):
    """From the SATNow results: {category: [manufacturer names]} and a union set."""
    per_cat = defaultdict(list)
    seen = defaultdict(set)
    for mp in payload["marketplaces"]:
        if "satnow" not in mp.get("domain", ""):
            continue
        for cat, blk in mp["by_category"].items():
            for it in blk.get("items", []):
                mfr = it.get("manufacturer")
                if mfr and mfr.lower() not in seen[cat]:
                    seen[cat].add(mfr.lower())
                    per_cat[cat].append(mfr)
    union = {}
    for cat, mfrs in per_cat.items():
        for m in mfrs:
            union.setdefault(m.lower(), m)
    return per_cat, list(union.values())


def crawl_manufacturer_site(name, categories, args, sink, seed_urls=None):
    """Politely enumerate a manufacturer's OWN site for parts in each category.

    seed_urls: explicit landing/product pages (curated manufacturers). Otherwise
    the homepage is fetched once and category links are discovered from it. Every
    Each fetch is capped per manufacturer and by the global fetch cap.
    """
    domain = resolve_domain(name)
    result = {"manufacturer": name, "domain": domain, "by_category": {},
              "fetches": 0, "resolved": bool(domain or seed_urls)}
    if not domain and not seed_urls:
        sink(f"    {short(name, 34):<36} no known site — add to MFR_SITES / visit via SATNow")
        return result
    home = seed_urls[0] if seed_urls else f"https://www.{domain}/"
    sink(f"    {short(name, 34):<36} {domain or urlparse(home).netloc}")

    # Discover candidate category pages from the homepage (one fetch), unless we
    # were handed explicit seeds.
    homepage_links = []
    if not seed_urls:
        if FETCH.budget_left() <= 0:
            sink("      (fetch cap reached)")
            return result
        hp = FETCH.get(home); result["fetches"] += 1
        if hp:
            homepage_links = extract_anchors(hp, home)

    per_mfr_fetches = 0
    for cat in categories:
        if per_mfr_fetches >= args.pages_per_mfr or FETCH.budget_left() <= 0:
            break
        kw = CAT_KEYWORDS.get(cat, (cat,))
        scan = []
        if seed_urls:
            scan = list(seed_urls)
        else:
            for a in homepage_links:
                u, t = a.get("url"), (a.get("title") or "")
                if u and _same_domain(u, domain) and any(
                        k in (u + " " + t).lower() for k in kw):
                    scan.append(u)
        # de-dup, cap per category
        seen, uscan = set(), []
        for u in scan:
            if u not in seen:
                seen.add(u); uscan.append(u)
        parts = []
        for u in uscan[: args.pages_per_mfr]:
            if per_mfr_fetches >= args.pages_per_mfr or FETCH.budget_left() <= 0:
                break
            html_text = FETCH.get(u); result["fetches"] += 1; per_mfr_fetches += 1
            if not html_text:
                continue
            sig = "space" if SPACE_LEVEL.search(html_text) else (
                "hi_rel" if HIREL.search(html_text) else "none")
            for it in extract_anchors(html_text, u):
                if is_device(it["title"]) and is_product_url(it["url"]):
                    t, s = classify(it["title"])
                    it["tier"] = t if t != "none" else sig
                    it["signal"] = s or f"on {sig} page"
                    it["manufacturer"] = name
                    parts.append(it)
        if parts:
            uniq = {}
            for p in parts:
                uniq.setdefault(p["title"].lower(), p)
            hits = list(uniq.values())
            result["by_category"][cat] = hits[: args.max_items]
            sink(f"        {cat:<14} {len(hits):>3} device link(s)")
    return result


def print_sources(sink):
    rule(sink, "CURATED HI-REL / SPACE-QUALIFIED SOURCES (open directly)")
    sink("  Space-focused marketplaces (space-qualified filtering by URL):")
    for m in MARKETPLACES:
        sink(f"    - {m['name']}: {m.get('browse', m['domain'])}")
    sink("  Commercial distributors (filter to MIL/space parts):")
    for d in DISTRIBUTORS:
        sink(f"    - {d['name']}: https://www.{d['domain']}/")
    sink("  Manufacturers whose lines are largely rad-hard / space / hi-rel:")
    for m in MANUFACTURERS:
        sink(f"    - {m['name']}: {m['base']}")
        sink(f"        {short(m['note'], 96)}")
    sink("  Datasheet signals (strongest→weakest space): MIL-PRF-38534 Class K ·")
    sink("    MIL-PRF-38535 Class V/QML-V · Class Y · MIL-PRF-19500 JANS · 'space")
    sink("    level/grade/flight' · TID/krad, SEE, rad-hard.  Hi-rel: Class H/G/Q,")
    sink("    MIL-STD-883, JANTXV, hermetic, screened, burn-in.")


# =========================================================================
# self-test
# =========================================================================
def self_test(sink):
    rule(sink, "SELF-TEST (offline)")
    checks = [
        ("Mini Circuits - CMA-545G1+", True), ("Qorvo - TGA2701", True),
        ("CL-1410 U-Low Noise LNA", True), ("TDLNA2050SEP", True),
        ("Catalog Products (727)", False), ("MIL-STD-883", False),
        ("MIL-PRF-38534", False), ("ESCC-22900", False), ("QML/SMD 5962", False),
        ("Corporate Social Responsibility Report", False), ("3D Scanning", False),
        ("Teledyne e2v HiRel Electronics", False),  # bare manufacturer, no part
    ]
    ok = True
    for title, want in checks:
        got = is_device(title)
        flag = "ok " if got == want else "BAD"
        ok = ok and got == want
        sink(f"  {flag} is_device={got!s:<5} want={want!s:<5} {title}")
    # URL product-detection
    assert is_product_url("https://www.satnow.com/products/microwave-rf-amplifiers/mini-circuits/100-2-cma-545g1")
    assert not is_product_url("javascript:void(0)")
    # facet URL
    u = f"https://www.satnow.com/search/microwave-rf-amplifiers/filters?page=1&country=global&stype={_facet('Low Noise Amplifier')}"
    sink(f"  LNA facet URL: {u}")
    assert "stype=%3BLow+Noise+Amplifier%3B" in u
    assert classify("MIL-PRF-38534 Class K")[0] == "space"
    assert classify("DC-20 GHz amplifier")[0] == "none"
    sink("  all checks passed." if ok else "  SOME CHECKS FAILED (see BAD lines).")
    print_sources(sink)
    sink("\nSELF-TEST complete.")


# =========================================================================
# main
# =========================================================================
def main(argv=None):
    ap = argparse.ArgumentParser(description="Find hi-rel/space-qualified parts across space-specific sources.")
    ap.add_argument("--categories", nargs="+", default=None)
    ap.add_argument("--sources", nargs="+", default=None,
                    help="restrict to source keys (satnow, everythingrf, pasternack, fairview, "
                         "teledyne_e2v, caes, arralis, micross, macom, qorvo, adi, criteria, ...)")
    ap.add_argument("--max-pages", type=int, default=2, help="marketplace listing pages per category")
    ap.add_argument("--max-items", type=int, default=80)
    ap.add_argument("--max-mfrs", type=int, default=12,
                    help="max manufacturers (from SATNow) to crawl on their own sites (default 12)")
    ap.add_argument("--pages-per-mfr", type=int, default=3,
                    help="max page fetches per manufacturer site (default 3)")
    ap.add_argument("--max-fetches", type=int, default=150,
                    help="global hard cap on total network fetches (default 150)")
    ap.add_argument("--delay", type=float, default=2.0,
                    help="base seconds between requests to the same host (default 2.0)")
    ap.add_argument("--jitter", type=float, default=1.5,
                    help="extra random 0..J seconds added to each delay (default 1.5)")
    ap.add_argument("--timeout", type=int, default=25, help="per-request timeout seconds")
    ap.add_argument("--no-cache", action="store_true", help="don't read/write the on-disk page cache")
    ap.add_argument("--refresh", action="store_true", help="ignore existing cache for this run (re-fetch)")
    ap.add_argument("--no-crawl", action="store_true",
                    help="discovery only: list manufacturers from SATNow, don't visit their sites")
    ap.add_argument("--list-sources", action="store_true")
    ap.add_argument("--log", default="rfparts_space_log.txt")
    ap.add_argument("--json", default="rfparts_space_data.json")
    ap.add_argument("--self-test", action="store_true")
    args = ap.parse_args(argv)

    sink = Tee(args.log)
    # Configure the gentle browser-like fetcher.
    FETCH.delay = args.delay
    FETCH.jitter = args.jitter
    FETCH.timeout = args.timeout
    FETCH.max_fetches = args.max_fetches
    FETCH.use_cache = not args.no_cache
    FETCH.sink = sink
    if args.refresh:
        FETCH.use_cache = False   # don't read cache; still won't write if --no-cache
        if not args.no_cache:
            FETCH.use_cache = True
            try:
                for f in FETCH.cache_dir.glob("*.html"):
                    f.unlink()
            except Exception:
                pass
    rule(sink, "rfparts SPACE / HI-REL source sweep (refined)")
    sink("Gentle mode: browser headers, per-host delay+jitter, retry/backoff, "
         "on-disk cache, capped. One bad site can't crash the run.")
    sink(f"fetcher: delay={FETCH.delay}s +0..{FETCH.jitter}s jitter, timeout={FETCH.timeout}s, "
         f"cache={'on' if FETCH.use_cache else 'off'} at {FETCH.cache_dir}")

    if args.self_test:
        self_test(sink); sink.close()
        print(f"\nself-test log: {args.log}"); return 0
    if args.list_sources:
        print_sources(sink); sink.close(); return 0

    categories = args.categories or list(SATNOW)
    want = set(s.lower() for s in args.sources) if args.sources else None
    sink(f"categories: {', '.join(categories)}")
    sink(f"caps: max-pages={args.max_pages}  max-mfrs={args.max_mfrs}  "
         f"pages/mfr={args.pages_per_mfr}  global max-fetches={args.max_fetches}")

    payload = {"meta": {"categories": categories}, "marketplaces": [],
               "distributors": [], "manufacturers": []}

    for src in MARKETPLACES:
        if want and src["key"] not in want:
            continue
        rule(sink, f"MARKETPLACE: {src['name']}", ch="-")
        block = {"source": src["name"], "domain": src["domain"], "by_category": {}}
        for cat in categories:
            if src["kind"] == "satnow":
                block["by_category"][cat] = probe_satnow(cat, args, sink)
            else:
                block["by_category"][cat] = probe_everythingrf(cat, src, args, sink)
        payload["marketplaces"].append(block)

    for src in DISTRIBUTORS:
        if want and src["key"] not in want:
            continue
        rule(sink, f"DISTRIBUTOR: {src['name']}  ({src['note']})", ch="-")
        block = {"source": src["name"], "domain": src["domain"], "by_category": {}}
        for cat in categories:
            block["by_category"][cat] = probe_distributor(cat, src, args, sink)
        payload["distributors"].append(block)

    # ---- discover manufacturers from SATNow, then visit their OWN sites ----
    per_cat_mfrs, union_mfrs = discover_manufacturers_from_satnow(payload)
    rule(sink, "MANUFACTURERS DISCOVERED ON SATNow (per category)")
    for cat in categories:
        ms = per_cat_mfrs.get(cat, [])
        if ms:
            sink(f"  {cat}: {', '.join(ms)}")
    sink(f"  -> {len(union_mfrs)} distinct manufacturers across all categories")

    payload["manufacturer_discovery"] = {"per_category": per_cat_mfrs, "union": union_mfrs}

    if not args.no_crawl:
        rule(sink, "MANUFACTURER SITES (go to the source for the full line)", ch="-")
        sink("  Visiting discovered manufacturers' own sites (capped & polite)…")
        # Map a resolved domain -> curated landing seeds (better than a blind
        # homepage scan) so a discovered manufacturer that we also curate uses
        # its known product pages.
        curated_seeds = {}
        for m in MANUFACTURERS:
            dom = resolve_domain(m["name"]) or urlparse(m["base"]).netloc
            curated_seeds.setdefault(dom, m.get("landing"))

        worklist, seen_dom = [], set()
        # 1) SATNow-discovered manufacturers FIRST (your priority).
        for name in union_mfrs:
            dom = resolve_domain(name)
            if not dom:
                worklist.append((name, None))          # reported as "no known site"
                continue
            if dom in seen_dom:
                continue
            seen_dom.add(dom)
            worklist.append((name, curated_seeds.get(dom)))
        # 2) Then core curated space houses not already covered (SATNow may miss them).
        for m in MANUFACTURERS:
            dom = resolve_domain(m["name"]) or urlparse(m["base"]).netloc
            if dom in seen_dom:
                continue
            seen_dom.add(dom)
            worklist.append((m["name"], m.get("landing")))

        crawled = 0
        for name, seeds in worklist:
            if crawled >= args.max_mfrs or FETCH.budget_left() <= 0:
                sink(f"  (stopping: {'max-mfrs' if crawled>=args.max_mfrs else 'fetch-cap'} reached; "
                     f"{FETCH.used}/{FETCH.max_fetches} fetches used)")
                break
            res = crawl_manufacturer_site(name, categories, args, sink, seed_urls=seeds)
            payload["manufacturers"].append(res)
            if res["resolved"]:
                crawled += 1
        sink(f"  crawled {crawled} manufacturer site(s); {FETCH.used}/{FETCH.max_fetches} total fetches used")
    else:
        sink("\n(--no-crawl) Skipped visiting manufacturer sites; discovery list above.")

    # ---- aggregate ----
    rule(sink, "SPACE / HI-REL DEVICES FOUND (by category)")
    by_cat = defaultdict(list)
    for mp in payload["marketplaces"]:
        for cat, blk in mp["by_category"].items():
            for it in blk.get("items", []):
                by_cat[cat].append(("SATNow:" + mp["source"], it))
    for dist in payload["distributors"]:
        for cat, blk in dist["by_category"].items():
            for it in blk.get("items", []):
                by_cat[cat].append((dist["source"], it))
    mfr_dev = 0
    for m in payload["manufacturers"]:
        for cat, items in m.get("by_category", {}).items():
            for it in items:
                by_cat[cat].append((m["manufacturer"] + " (own site)", it))
                mfr_dev += 1
    grand = 0
    for cat in sorted(by_cat):
        rows = by_cat[cat]
        grand += len(rows)
        sink(f"  {cat}: {len(rows)}")
        for srcname, it in rows[:18]:
            name = it.get("part") or it.get("title")
            sink(f"    [{it['tier']:<6}] {short(name, 36):<38} {it.get('manufacturer') or srcname}")
    sink(f"\n  total device rows: {grand}   (of which {mfr_dev} from manufacturer sites)")
    sink(f"  network fetches used: {FETCH.used}/{FETCH.max_fetches}")
    if grand == 0:
        sink("  (Nothing parsed — use --list-sources and open the URLs by hand.)")

    print_sources(sink)
    try:
        pathlib.Path(args.json).write_text(
            json.dumps(payload, indent=1, ensure_ascii=False, default=str), encoding="utf-8")
        sink(f"\nstructured results -> {args.json}  (send this back)")
    except Exception as exc:  # noqa: BLE001
        sink(f"\ncould not write JSON: {type(exc).__name__}: {exc}")
    sink.close()
    print(f"\nlogs: {args.log}  +  {args.json}")
    return 0


if __name__ == "__main__":
    sys.exit(main())