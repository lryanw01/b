"""Offline self-checks: URL filter, spec extraction regexes, evaluation, ranking.

No network required. Run with:  pytest -q   (or:  python tests/test_rfparts.py)
"""
from rfparts import extract, rank
from rfparts.discover import _url_ok
from rfparts.spec import _canon_category, _parse_range


# --- category canonicalization / range parsing ---------------------------
def test_canon_category():
    assert _canon_category("LNA") == "lna"
    assert _canon_category("low noise amplifier") == "lna"
    assert _canon_category("pad") == "attenuator"
    assert _canon_category("Attenuator") == "attenuator"


def test_parse_range():
    assert _parse_range("4-8") == [4.0, 8.0]
    assert _parse_range("8 4") == [4.0, 8.0]
    assert _parse_range("DC-18") == [0.0, 18.0]
    assert _parse_range("") is None


# --- URL filter ----------------------------------------------------------
def test_url_filter():
    toks = ["attenuator", "atten", "pad"]
    assert _url_ok("https://x.com/product/2082-6241-cryo-attenuator/", toks, "attenuator")
    assert not _url_ok("https://x.com/about-us/", toks, "attenuator")          # junk
    assert not _url_ok("https://x.com/products/attenuators/", toks, "attenuator")  # listing
    assert not _url_ok("https://x.com/product/cryo-isolator-4-8/", toks, "attenuator")  # wrong type
    assert _url_ok(
        "https://q.com/product/dc-to-18-ghz-10-db-attenuator-qmc-10blk-sma/", toks, "attenuator")


# --- spec extraction regexes ---------------------------------------------
def test_extract_freq_and_gain():
    text = ("Low Noise Amplifier. Frequency: 4 - 8 GHz. Typical gain 32 dB. "
            "Noise temperature 4 K. SMA connectors. Lead time 6 weeks.")
    specs = _mine(text)
    assert specs["freq_ghz"] == [4.0, 8.0]
    assert specs["gain_db"] == 32.0
    assert specs["noise_k"] == 4.0
    assert specs["connector"] == "SMA"
    assert specs["lead_weeks"] == 6.0


def test_extract_dc_and_stock():
    text = "DC to 18 GHz fixed attenuator, bulkhead SMA. In stock. $145.00"
    specs = _mine(text)
    assert specs["freq_ghz"] == [0.0, 18.0]
    assert specs["bulkhead"] is True
    assert specs["lead_weeks"] == 0.0
    assert specs["price_usd"] == 145.0


def _mine(text):
    """Run the regex miners directly on a text blob (bypasses the network)."""
    specs = {}
    fg = extract._freq_ghz(text)
    if fg:
        specs["freq_ghz"] = fg
    g = extract.GAIN.search(text)
    if g:
        specs["gain_db"] = float(g.group(1))
    nk = extract.NOISE_K.search(text)
    if nk:
        specs["noise_k"] = float(nk.group(1))
    if extract.CRYO.search(text):
        specs["cryo"] = True
    conn = extract.CONNECTOR.search(text)
    if conn:
        specs["connector"] = conn.group(1).upper().replace(" ", "")
    if extract.BULKHEAD.search(text):
        specs["bulkhead"] = True
    lw = extract._lead_weeks(text)
    if lw is not None:
        specs["lead_weeks"] = lw
    pr = extract.PRICE.search(text)
    if pr:
        specs["price_usd"] = float(pr.group(1).replace(",", ""))
    return specs


# --- evaluation / tiering ------------------------------------------------
SPEC = {"category": "lna", "freq_ghz": [4, 8], "temp_k": 4,
        "gain_db_min": 30, "noise_k_max": 5, "connector": "SMA"}


def test_evaluate_full_fit():
    c = {"title": "cryo LNA", "url": "u1",
         "specs": {"freq_ghz": [4, 8], "cryo": True, "gain_db": 32,
                   "noise_k": 4, "connector": "SMA"}}
    rank.evaluate(c, SPEC)
    assert c["miss"] == 0 and c["unknown"] == 0
    assert rank.tier(c) == "A"


def test_evaluate_unknown_is_B():
    c = {"title": "LNA", "url": "u2", "specs": {"freq_ghz": [4, 8], "cryo": True}}
    rank.evaluate(c, SPEC)
    assert c["miss"] == 0 and c["unknown"] > 0
    assert rank.tier(c) == "B"


def test_evaluate_miss_is_C():
    c = {"title": "LNA", "url": "u3",
         "specs": {"freq_ghz": [6, 8], "cryo": True, "gain_db": 32, "noise_k": 4, "connector": "SMA"}}
    rank.evaluate(c, SPEC)  # 6-8 doesn't cover 4-8 -> freq miss
    assert c["criteria"]["freq"] == "miss"
    assert rank.tier(c) == "C"


# --- ranking order -------------------------------------------------------
def test_rank_order():
    cands = [
        {"url": "b", "title": "cryo LNA B", "vendor": "V",
         "specs": {"freq_ghz": [4, 8], "cryo": True, "gain_db": 32, "noise_k": 4,
                   "connector": "SMA", "price_usd": 900}},
        {"url": "a", "title": "cryo LNA A", "vendor": "V",
         "specs": {"freq_ghz": [4, 8], "cryo": True, "gain_db": 32, "noise_k": 4,
                   "connector": "SMA", "price_usd": 500}},
        {"url": "u", "title": "LNA unknown", "vendor": "V",
         "specs": {"freq_ghz": [4, 8], "cryo": True}},
        {"url": "err", "title": "404", "vendor": "V", "specs": {"_error": True}},
    ]
    r = rank.rank(cands, SPEC)
    assert [c["url"] for c in r] == ["a", "b", "u"]  # A(cheaper), A(pricier), then B; error dropped


if __name__ == "__main__":
    import sys
    import traceback

    failed = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"ok   {name}")
            except Exception:
                failed += 1
                print(f"FAIL {name}")
                traceback.print_exc()
    sys.exit(1 if failed else 0)
