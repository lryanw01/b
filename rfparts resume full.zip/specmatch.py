"""specmatch — one place that decides what a vendor's spec label means.

WHY THIS EXISTS
---------------
Every source words its specs differently, and each ingest had its own private
lookup table that only matched what somebody had thought to type in:

    everythingRF   exact-match dict on the lowercased label. "Switching Speed"
                   worked; "Switching Speed (Max)" silently produced nothing.
    MACOM          regex list against specName.
    Marki          another regex list against table headers.

Anything unlisted was dropped without a word, so a spec could be present in the
source, stored nowhere, and invisible in the audit -- the failure mode looks
identical to "the vendor never published it".

This module normalises a label and resolves it against ONE canonical vocabulary,
in three escalating passes:

    1. exact match on the normalised label
    2. alias match after qualifiers/units are stripped
       ("Switching Speed (Max), ns" -> "switching speed")
    3. token-subset match, so "Typical Insertion Loss at 10 GHz" still resolves
       to insertion_loss_db via the {insertion, loss} token set

Pass 3 is deliberately conservative: it requires every token of a known alias to
be present, so "return loss" never matches "insertion loss", and single-token
aliases are excluded from fuzzy matching entirely (a bare "loss" or "power" is
too ambiguous to guess from).

Nothing here converts values -- callers keep their own unit handling. This only
answers "which spec is this label talking about, and what kind of value is it".
"""
from __future__ import annotations

import re

# ---------------------------------------------------------------- vocabulary
# canonical key -> (value kind, [alias phrases])
#
# kind is what the CALLER should do with the value:
#   "freq"     a frequency or frequency range
#   "num"      a plain number in the spec's canonical unit
#   "time_ns"  a time that must be normalised to nanoseconds
#   "power"    an output power that may be in W or dBm
#   "text"     an enumeration or free text
SPEC_VOCAB: dict[str, tuple[str, list[str]]] = {
    "freq_ghz": ("freq", [
        "frequency", "frequency range", "operating frequency", "freq",
        "rf frequency", "frequency band range", "passband", "pass band",
        "operating frequency range", "bandwidth range"]),
    "freq_min": ("freq", ["min frequency", "frequency min", "start frequency",
                          "lower frequency", "f low", "fmin"]),
    "freq_max": ("freq", ["max frequency", "frequency max", "stop frequency",
                          "upper frequency", "f high", "fmax"]),
    "gain_db": ("num", ["gain", "small signal gain", "ss gain", "linear gain",
                        "gain typ", "amplifier gain"]),
    "nf_db": ("num", ["noise figure", "nf", "noise", "noise figure db"]),
    "oip3_dbm": ("num", ["oip3", "ip3", "output ip3", "output third order",
                         "third order intercept", "output intercept",
                         "toi", "output toi"]),
    "iip3_dbm": ("num", ["iip3", "input ip3", "input third order",
                         "input intercept"]),
    "p1db_dbm": ("num", ["p1db", "1 db compression", "output p1db",
                         "input p1db", "compression point",
                         "1db compression point", "op1db"]),
    "psat_dbm": ("power", ["psat", "saturated power", "saturated output power",
                           "output power", "pout", "peak output power",
                           "rf output power", "power output", "p out"]),
    "power_w": ("num", ["power handling", "input power handling",
                        "cw power handling", "average power"]),
    "isolation_db": ("num", ["isolation", "port isolation", "channel isolation",
                             "rf isolation", "on off isolation"]),
    "insertion_loss_db": ("num", ["insertion loss", "il", "loss",
                                  "insertion loss typ", "on state loss"]),
    "return_loss_db": ("num", ["return loss", "rl"]),
    "input_return_loss_db": ("num", ["input return loss", "in return loss"]),
    "output_return_loss_db": ("num", ["output return loss", "out return loss"]),
    "attenuation_db": ("num", ["attenuation", "attenuation range",
                               "attenuation step", "step size"]),
    "conversion_loss_db": ("num", ["conversion loss", "conversion gain"]),
    "vswr": ("num", ["vswr", "swr", "voltage standing wave ratio"]),
    "impedance_ohm": ("num", ["impedance", "nominal impedance",
                              "characteristic impedance", "z0"]),
    "directivity_db": ("num", ["directivity"]),
    "coupling_db": ("num", ["coupling", "coupling factor", "coupling value"]),
    "phase_balance_deg": ("num", ["phase balance", "phase error",
                                  "phase imbalance"]),
    "amplitude_balance_db": ("num", ["amplitude balance", "amplitude imbalance",
                                     "amplitude unbalance"]),
    "efficiency_pct": ("num", ["efficiency", "pae", "power added efficiency",
                               "drain efficiency"]),
    "supply_v": ("num", ["supply voltage", "bias voltage", "vdd", "vcc",
                         "operating voltage", "voltage supply", "vsupply"]),
    "current_ma": ("num", ["supply current", "current consumption", "idd",
                           "icc", "quiescent current", "bias current"]),
    "switching_time_ns": ("time_ns", [
        "switching speed", "switching time", "switch speed", "switch time",
        "rise time", "fall time", "rise fall time", "ton", "toff",
        "t on", "t off", "on time", "off time", "settling time",
        "video switching speed", "rf switching speed"]),
    "data_rate_gbps": ("num", ["data rate", "max data rate", "bit rate"]),
    "tid_krad": ("num", ["tid", "total ionizing dose", "total dose",
                         "radiation tolerance", "rad tolerance"]),
    "sel_mev": ("num", ["sel", "single event latchup", "let threshold",
                        "single event effects"]),
    "temp_min_c": ("num", ["min operating temperature", "temperature min",
                           "min temperature"]),
    "temp_max_c": ("num", ["max operating temperature", "temperature max",
                           "max temperature"]),
    # --- enumerations / text -------------------------------------------------
    "package": ("text", ["package", "package type", "package category",
                         "package style", "case", "case style", "outline",
                         "package outline"]),
    "connector": ("text", ["connector", "connector type", "interface",
                           "connectors"]),
    # "number of throws" is deliberately absent: it is a COUNT ("4"), and letting
    # it resolve here overwrote the configuration enum ("SP4T") with a bare digit.
    "configuration": ("text", ["configuration", "config", "switch configuration",
                               "throw configuration", "pole throw", "switch type",
                               "port configuration"]),
    "mount_type": ("text", ["mount", "mounting", "mount type", "mounting type",
                            "form", "form factor"]),
    "technology": ("text", ["technology", "process", "process technology",
                            "semiconductor process", "die technology"]),
    "subtype": ("text", ["type", "device type", "product type"]),
    "pulsed_cw": ("text", ["pulsed cw", "pulsed or cw", "operation mode",
                           "duty"]),
    "industry_application": ("text", ["industry application", "application",
                                      "applications", "end application",
                                      "market"]),
    "waveguide": ("text", ["waveguide", "waveguide size", "waveguide band"]),
    "modulation": ("text", ["modulation", "modulation type"]),
    "frequency_band": ("text", ["frequency band", "band", "rf band"]),
}

# Words that qualify a measurement without changing WHICH spec it is. Stripping
# them is what lets "Switching Speed (Max)" and "Typical Gain @ 10 GHz" resolve.
_QUALIFIERS = {
    "max", "maximum", "min", "minimum", "typ", "typical", "nom", "nominal",
    "avg", "average", "peak", "worst", "case", "guaranteed", "spec", "value",
    "range", "at", "@", "over", "across", "per", "vs", "versus", "up", "to",
    "and", "or", "the", "of", "for", "with", "in", "on", "a", "an",
    "measured", "test", "tested", "condition", "conditions", "note", "notes",
    "db", "dbm", "dbc", "ghz", "mhz", "khz", "hz", "ns", "us", "ms", "ps",
    "ohm", "ohms", "volt", "volts", "v", "ma", "amp", "amps", "w", "watt",
    "watts", "mw", "dbw", "deg", "degree", "degrees", "c", "celsius", "pct",
    "percent", "krad", "mev", "gbps", "mbps", "sec", "second", "seconds",
}
_PAREN = re.compile(r"\([^)]*\)|\[[^\]]*\]|\{[^}]*\}")
_NONWORD = re.compile(r"[^a-z0-9]+")


def normalize_label(label) -> str:
    """A vendor label reduced to comparable words.

    'Switching Speed (Max), ns' -> 'switching speed'
    'Typical Insertion Loss @ 10 GHz' -> 'insertion loss'
    """
    s = str(label or "").lower()
    s = _PAREN.sub(" ", s)              # drop parenthetical qualifiers
    s = s.split(",")[0] if "," in s and len(s.split(",")[0]) > 2 else s
    s = _NONWORD.sub(" ", s)
    toks = [t for t in s.split() if t and t not in _QUALIFIERS]
    return " ".join(toks)


def _token_set(s) -> frozenset:
    return frozenset(normalize_label(s).split())


# Precomputed lookup tables.
_EXACT: dict[str, tuple[str, str]] = {}
_TOKENS: list[tuple[frozenset, str, str]] = []
for _key, (_kind, _aliases) in SPEC_VOCAB.items():
    for _a in list(_aliases) + [_key.replace("_", " ")]:
        _norm = normalize_label(_a)
        if _norm:
            _EXACT.setdefault(_norm, (_key, _kind))
        _ts = _token_set(_a)
        # Single-token aliases are excluded from fuzzy matching: a bare "loss" or
        # "power" would swallow half the vocabulary.
        if len(_ts) >= 2:
            _TOKENS.append((_ts, _key, _kind))
# Longest token sets first, so "input return loss" wins over "return loss".
_TOKENS.sort(key=lambda t: -len(t[0]))


def resolve(label, allow_fuzzy=True):
    """(canonical_key, kind) for a vendor spec label, or (None, None).

    Pass `allow_fuzzy=False` for sources whose labels are already clean and where
    a wrong guess is worse than a miss."""
    norm = normalize_label(label)
    if not norm:
        return None, None
    hit = _EXACT.get(norm)
    if hit:
        return hit
    if not allow_fuzzy:
        return None, None
    toks = frozenset(norm.split())
    if len(toks) < 2:
        return None, None
    for ts, key, kind in _TOKENS:
        if ts <= toks:                  # every alias token present
            return key, kind
    return None, None


def resolve_key(label, allow_fuzzy=True):
    return resolve(label, allow_fuzzy=allow_fuzzy)[0]


# ------------------------------------------------------ switch throw config
# Switch topology as stated in prose or an enum: SPDT, SP4T, DPDT, transfer.
# Normalised to the SPnT / DPnT form so filtering and sorting are consistent.
_WORD_NUM = {"single": 1, "one": 1, "double": 2, "two": 2, "dual": 2,
             "triple": 3, "three": 3, "quad": 4, "four": 4, "five": 5,
             "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
             "eleven": 11, "twelve": 12, "sixteen": 16}
# Poles and throws are written as a letter for 1-4 and a digit above that, and
# the two halves mix freely: SPDT, SP4T, DPDT, DP3T, 1P4T, SP-4T. The first
# version of this only accepted a DIGIT for the throw count, so it matched SP4T
# and missed SPDT and DPDT entirely -- the two most common switches there are.
_LETTER_NUM = {"s": 1, "d": 2, "t": 3, "q": 4}
_THROW_COMPACT = re.compile(
    r"\b([sdtq]|[1-9]\d?)\s*[-_ ]?\s*p\s*[-_ ]?\s*([sdtq]|[1-9]\d?)\s*[-_ ]?\s*t\b",
    re.I)
_THROW_WORDS = re.compile(
    r"\b(single|one|double|two|dual|triple|three|quad|four)\s*[- ]?\s*pole\b"
    r"[\s,]*(?:\w+\s+){0,2}?(single|one|double|two|dual|triple|three|quad|four|"
    r"five|six|seven|eight|nine|ten|eleven|twelve|sixteen)\s*[- ]?\s*throw\b",
    re.I)


def _pole_str(n):
    return {1: "SP", 2: "DP", 3: "3P", 4: "4P"}.get(n, f"{n}P")


def _throw_str(n):
    # Industry convention: 1 throw is ST, 2 is DT, 3 and up are numbered.
    return {1: "ST", 2: "DT"}.get(n, f"{n}T")


def _num_from(token):
    tok = str(token).lower()
    if tok in _LETTER_NUM:
        return _LETTER_NUM[tok]
    try:
        return int(tok)
    except ValueError:
        return None


def parse_throw_config(text):
    """Canonical switch topology from prose or an enum value.

    SPDT, SP4T, SP-4T, 1P4T, sp4t, DPDT, 'single pole four throw' all resolve to
    the SPST / SPDT / SP4T / DPDT form. Returns None when nothing switch-like is
    stated, so a value is never invented for a part that is not a switch."""
    s = str(text or "")
    if not s:
        return None
    for m in _THROW_COMPACT.finditer(s):
        poles = _num_from(m.group(1))
        throws = _num_from(m.group(2))
        if poles and throws and 1 <= poles <= 8 and 1 <= throws <= 32:
            return _pole_str(poles) + _throw_str(throws)
    m = _THROW_WORDS.search(s)
    if m:
        poles = _WORD_NUM.get(m.group(1).lower())
        throws = _WORD_NUM.get(m.group(2).lower())
        if poles and throws:
            return _pole_str(poles) + _throw_str(throws)
    if re.search(r"\btransfer\s*switch\b", s, re.I):
        return "transfer"
    return None
