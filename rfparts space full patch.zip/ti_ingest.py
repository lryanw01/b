"""Ingest the Texas Instruments Space Products Guide (.pdf) into partdb.

Reads the LOCAL guide PDF -- no network. The guide's parametric tables are dense
and vary page to page, so this adapter is deliberately conservative: it harvests
every space part *number* (the reliable signal) plus the section it appears
under, and classifies its space pedigree from the TI suffix. It does NOT invent
parametrics it can't map cleanly.

TI space suffixes -> pedigree:
    -SP  / QML-SP   radiation-hardened, QMLV / class V     -> space_qualified
    -SEP            space enhanced plastic                 -> space_grade
    -EP  -HB -HT    enhanced/hi-rel companion              -> space_grade

Per part:
    parts row   mpn / vendor="Texas Instruments" / category (from section) /
                product_url=ti.com/product/<base> / description=section + pedigree
    specs       space, space_variant, ti_suffix (text)
    evidence    ti-space-products-guide (+9 qualified / +7 grade)

Run:
    python -m rfparts.ti_ingest "C:\\path\\slyt532l.pdf" --dry-run
"""
from __future__ import annotations

import argparse
import re
import warnings
from collections import Counter
from pathlib import Path

import pdfplumber

try:
    from .partdb import SpecRow, upsert_part, put_specs, put_evidence
except ImportError:
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from rfparts.partdb import (                        # type: ignore
        SpecRow, upsert_part, put_specs, put_evidence)

warnings.filterwarnings("ignore")
VENDOR = "Texas Instruments"

# base part + space suffix, e.g. TPS7H4011-SP, ADC12DJ5200-SEP, ADC128S102QML-SP
_PN = re.compile(
    r"\b([A-Z]{2,6}\d[A-Z0-9]*?)(QML)?-(SP|SEP|EP|HB|HT|SPHT|HR|HIREL)\b")

_SECTION_CAT = [
    ("analog-to-digital", "data_converter"), ("adc", "data_converter"),
    ("digital-to-analog", "data_converter"), ("dac", "data_converter"),
    ("data converter", "data_converter"),
    ("power management", "power"), ("power-management", "power"),
    ("regulator", "power"), ("converter dc", "power"), ("reference", "power"),
    ("amplifier", "amplifier"), ("op amp", "amplifier"), ("op-amp", "amplifier"),
    ("clock", "clock"), ("timing", "clock"),
    ("interface", "interface"), ("transceiver", "interface"),
    ("rs-485", "interface"), ("lvds", "interface"), ("isolation", "interface"),
    ("pll", "synthesizer"), ("synthesizer", "synthesizer"),
    ("oscillator", "oscillator"),
    ("logic", "ic"), ("fpga", "ic"), ("processor", "ic"), ("memory", "ic"),
    ("sensor", "sensor"), ("temperature", "sensor"),
]


def _variant(suffix, qml):
    s = suffix.upper()
    if s == "SP" or qml:
        return "space_qualified", f"TI -{s}{' QML' if qml else ''} (rad-hard/QMLV)"
    if s in ("HIREL", "HR"):
        return "space_qualified", "TI hi-rel"
    return "space_grade", f"TI -{s} (space-grade companion)"


def _category(section):
    s = section.lower()
    for needle, canon in _SECTION_CAT:
        if needle in s:
            return canon
    return "ic"


def parse_pdf(path):
    with pdfplumber.open(str(path)) as pdf:
        for page in pdf.pages:
            text = page.extract_text() or ""
            first = text.split("\n", 1)[0][:80]
            for m in _PN.finditer(text):
                base, qml, suffix = m.group(1), bool(m.group(2)), m.group(3)
                mpn = f"{base}{'QML' if qml else ''}-{suffix}"
                variant, reason = _variant(suffix, qml)
                yield {"mpn": mpn, "base": base, "suffix": suffix,
                       "category": _category(first), "section": first,
                       "variant": variant, "reason": reason}


def _write(rec):
    url = f"https://www.ti.com/product/{rec['base']}"
    pid = upsert_part(mpn=rec["mpn"], vendor=VENDOR, category=rec["category"],
                      subcategory="", product_url=url,
                      description=f"TI space {rec['section']}".strip()[:200])
    rows = [
        SpecRow(key="ti_suffix", value_text=rec["suffix"], method="catalog",
                confidence=0.9, source_url=url, snippet=rec["reason"][:120]),
        SpecRow(key="space", value_text="qualified", method="catalog",
                confidence=0.9, source_url=url, snippet=rec["reason"][:120]),
        SpecRow(key="space_variant", value_text=rec["variant"], method="catalog",
                confidence=0.9, source_url=url, snippet=rec["reason"][:120]),
    ]
    put_specs(pid, rows)
    if rec["variant"] == "space_qualified":
        put_evidence(pid, [("ti-space-products-guide-qualified", 9.0, url,
                            rec["reason"])])
    else:
        put_evidence(pid, [("ti-space-products-guide-grade", 7.0, url, rec["reason"])])
    return pid


def ingest(path, dry_run=False, verbose=False):
    path = Path(path)
    if not path.is_file():
        raise SystemExit(f"file not found: {path}")
    best = {}
    for rec in parse_pdf(path):
        key = rec["mpn"].upper()
        prev = best.get(key)
        if prev is None or (prev["variant"] == "space_grade"
                            and rec["variant"] == "space_qualified"):
            best[key] = rec
    counts = Counter()
    for rec in best.values():
        counts["parts"] += 1
        counts[rec["variant"]] += 1
        if verbose:
            print(f"  {rec['mpn']:<22} {rec['category']:<14} {rec['variant']}")
        if not dry_run:
            _write(rec)
    return dict(counts)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file", help="TI Space Products Guide .pdf")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args(argv)
    c = ingest(Path(args.file), args.dry_run, args.verbose)
    print("\n=== TI space products guide ingest "
          + ("(dry run) ===" if args.dry_run else "===")
          + f"\n  parts             {c.get('parts', 0)}"
          + f"\n    space_qualified {c.get('space_qualified', 0)}"
          + f"\n    space_grade     {c.get('space_grade', 0)}")
    if args.dry_run:
        print("  (nothing written -- drop --dry-run to commit)")


if __name__ == "__main__":
    main()
