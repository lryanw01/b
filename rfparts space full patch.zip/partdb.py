"""Persistent part/spec database — the destination for mined datasheets.

SQLite (WAL) under $RFPARTS_HOME/parts.db. Everything the ephemeral-datasheet
pipeline learns lands here with provenance; the PDFs themselves are discarded
and survive only as a sha256 row in `documents`.

Design rules:
  * Specs are EAV rows with a (min, typ, max) numeric triple + unit + method +
    confidence + source URL + snippet — never a bare number with no origin.
  * DigiKey-derived data is NEVER written here (API UA sec 5.1); the DigiKey
    adapter remains an in-memory overlay at ranking time.
  * parser_version gates staleness exactly like specstore.py did.

Public API (all thread-safe; one connection per thread):
    db()                          -> sqlite3.Connection (per-thread)
    upsert_part(fields)           -> part_id
    put_specs(part_id, specs)     -> None      specs: list[SpecRow]
    put_document(sha, url, part_id, nbytes, pages) -> None
    document_seen(sha)            -> bool
    put_evidence(part_id, rows)   -> None
    put_vendor_fact(domain, **kw) -> None
    vendor_facts(domain)          -> dict
    query_candidates(category=None, f_lo=None, f_hi=None, limit=200)
                                  -> list[candidate dicts] (rank.py-shaped)
    frontier_push / frontier_pop / frontier_mark — crawl queue persistence
"""
from __future__ import annotations

import json
import os
import pathlib
import re
import sqlite3
import threading
import time
from dataclasses import dataclass, field

from . import pedigree

PARSER_VERSION = 1

DATA = pathlib.Path(os.environ.get("RFPARTS_HOME", pathlib.Path.home() / ".rfparts"))

DB_PATH = DATA / "parts.db"

_LOCAL = threading.local()

_SCHEMA = """
CREATE TABLE IF NOT EXISTS parts(
  id INTEGER PRIMARY KEY,
  mpn TEXT NOT NULL,
  mpn_norm TEXT NOT NULL,
  vendor TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL DEFAULT '',
  subcategory TEXT NOT NULL DEFAULT '',
  product_url TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '',
  first_seen REAL NOT NULL,
  last_seen REAL NOT NULL,
  UNIQUE(mpn_norm, vendor)
);
CREATE INDEX IF NOT EXISTS idx_parts_cat ON parts(category);

CREATE TABLE IF NOT EXISTS specs(
  part_id INTEGER NOT NULL REFERENCES parts(id) ON DELETE CASCADE,
  key TEXT NOT NULL,
  value_min REAL, value_typ REAL, value_max REAL,
  value_text TEXT,
  unit TEXT NOT NULL DEFAULT '',
  method TEXT NOT NULL DEFAULT '',
  confidence REAL NOT NULL DEFAULT 0.5,
  source_url TEXT NOT NULL DEFAULT '',
  snippet TEXT NOT NULL DEFAULT '',
  parser_version INTEGER NOT NULL,
  extracted_at REAL NOT NULL,
  PRIMARY KEY(part_id, key, source_url)
);

CREATE TABLE IF NOT EXISTS documents(
  sha256 TEXT PRIMARY KEY,
  url TEXT NOT NULL,
  part_id INTEGER REFERENCES parts(id) ON DELETE SET NULL,
  bytes_len INTEGER NOT NULL DEFAULT 0,
  pages_parsed INTEGER NOT NULL DEFAULT 0,
  parser_version INTEGER NOT NULL,
  parsed_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS qual_evidence(
  part_id INTEGER NOT NULL REFERENCES parts(id) ON DELETE CASCADE,
  signal TEXT NOT NULL,
  weight REAL NOT NULL,
  source_url TEXT NOT NULL DEFAULT '',
  snippet TEXT NOT NULL DEFAULT '',
  found_at REAL NOT NULL,
  PRIMARY KEY(part_id, signal, source_url)
);

CREATE TABLE IF NOT EXISTS vendors(
  domain TEXT PRIMARY KEY,
  name TEXT NOT NULL DEFAULT '',
  hirel_program INTEGER NOT NULL DEFAULT 0,
  facts TEXT NOT NULL DEFAULT '{}',
  updated_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS url_templates(
  domain TEXT NOT NULL,
  n_segments INTEGER NOT NULL,
  prefix TEXT NOT NULL,
  hits INTEGER NOT NULL DEFAULT 1,
  updated_at REAL NOT NULL,
  PRIMARY KEY(domain, n_segments, prefix)
);

CREATE TABLE IF NOT EXISTS frontier(
  url TEXT PRIMARY KEY,
  priority REAL NOT NULL,
  depth INTEGER NOT NULL,
  domain TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',   -- pending | done | error | skipped
  added_at REAL NOT NULL,
  fetched_at REAL
);
CREATE INDEX IF NOT EXISTS idx_frontier_status ON frontier(status, priority);
"""


@dataclass
class SpecRow:
    """One extracted spec value with full provenance."""
    key: str
    value_min: float | None = None
    value_typ: float | None = None
    value_max: float | None = None
    value_text: str | None = None
    unit: str = ""
    method: str = "regex"          # table | regex | page | catalog
    confidence: float = 0.5
    source_url: str = ""
    snippet: str = ""


def db() -> sqlite3.Connection:
    """Per-thread connection; creates schema on first use."""
    conn = getattr(_LOCAL, "conn", None)
    if conn is not None:
        return conn
    DATA.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript(_SCHEMA)
    _LOCAL.conn = conn
    return conn


def _norm_mpn(mpn: str) -> str:
    return re.sub(r"\s+", "", str(mpn or "")).upper()


def upsert_part(*, mpn, vendor="", category="", subcategory="",
                product_url="", description="") -> int:
    now = time.time()
    conn = db()
    with conn:
        conn.execute(
            """INSERT INTO parts(mpn, mpn_norm, vendor, category, subcategory,
                                 product_url, description, first_seen, last_seen)
               VALUES(?,?,?,?,?,?,?,?,?)
               ON CONFLICT(mpn_norm, vendor) DO UPDATE SET
                 last_seen=excluded.last_seen,
                 category=CASE WHEN excluded.category!='' THEN excluded.category ELSE parts.category END,
                 subcategory=CASE WHEN excluded.subcategory!='' THEN excluded.subcategory ELSE parts.subcategory END,
                 product_url=CASE WHEN excluded.product_url!='' THEN excluded.product_url ELSE parts.product_url END,
                 description=CASE WHEN excluded.description!='' THEN excluded.description ELSE parts.description END
            """,
            (mpn, _norm_mpn(mpn), vendor, category, subcategory,
             product_url, description, now, now))
        row = conn.execute("SELECT id FROM parts WHERE mpn_norm=? AND vendor=?",
                           (_norm_mpn(mpn), vendor)).fetchone()
    return row["id"]


def put_specs(part_id: int, rows: list[SpecRow]) -> None:
    now = time.time()
    conn = db()
    with conn:
        for r in rows:
            conn.execute(
                """INSERT INTO specs(part_id, key, value_min, value_typ, value_max,
                                     value_text, unit, method, confidence,
                                     source_url, snippet, parser_version, extracted_at)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(part_id, key, source_url) DO UPDATE SET
                     value_min=excluded.value_min, value_typ=excluded.value_typ,
                     value_max=excluded.value_max, value_text=excluded.value_text,
                     unit=excluded.unit, method=excluded.method,
                     confidence=excluded.confidence, snippet=excluded.snippet,
                     parser_version=excluded.parser_version,
                     extracted_at=excluded.extracted_at""",
                (part_id, r.key, r.value_min, r.value_typ, r.value_max,
                 r.value_text, r.unit, r.method, r.confidence,
                 r.source_url, r.snippet[:300], PARSER_VERSION, now))


def document_seen(sha256: str) -> bool:
    row = db().execute(
        "SELECT parser_version FROM documents WHERE sha256=?", (sha256,)).fetchone()
    return bool(row) and row["parser_version"] >= PARSER_VERSION


def put_document(sha256, url, part_id, bytes_len, pages_parsed) -> None:
    conn = db()
    with conn:
        conn.execute(
            """INSERT OR REPLACE INTO documents
               (sha256, url, part_id, bytes_len, pages_parsed, parser_version, parsed_at)
               VALUES(?,?,?,?,?,?,?)""",
            (sha256, url, part_id, bytes_len, pages_parsed,
             PARSER_VERSION, time.time()))


def put_evidence(part_id: int, rows) -> None:
    """rows: iterable of (signal, weight, source_url, snippet)."""
    conn = db()
    with conn:
        for signal, weight, source_url, snippet in rows:
            conn.execute(
                """INSERT OR REPLACE INTO qual_evidence
                   (part_id, signal, weight, source_url, snippet, found_at)
                   VALUES(?,?,?,?,?,?)""",
                (part_id, signal, weight, source_url, snippet[:300], time.time()))


def put_vendor_fact(domain: str, *, name="", hirel_program=None, **facts) -> None:
    conn = db()
    row = conn.execute("SELECT facts, hirel_program, name FROM vendors WHERE domain=?",
                       (domain,)).fetchone()
    merged = json.loads(row["facts"]) if row else {}
    merged.update(facts)
    hr = int(hirel_program) if hirel_program is not None else (row["hirel_program"] if row else 0)
    nm = name or (row["name"] if row else "")
    with conn:
        conn.execute(
            """INSERT OR REPLACE INTO vendors(domain, name, hirel_program, facts, updated_at)
               VALUES(?,?,?,?,?)""",
            (domain, nm, hr, json.dumps(merged), time.time()))


def vendor_facts(domain: str) -> dict:
    row = db().execute("SELECT * FROM vendors WHERE domain=?", (domain,)).fetchone()
    if not row:
        return {}
    out = json.loads(row["facts"])
    out["hirel_program"] = bool(row["hirel_program"])
    out["name"] = row["name"]
    return out


# --- frontier ---------------------------------------------------------------

def frontier_push(url, priority, depth, domain, requeue=False) -> bool:
    """Add a URL if never seen; returns True when newly queued.

    requeue=True additionally revives an EXISTING row: back to 'pending' at at
    least the given priority. Seed sources need this — a plain INSERT OR
    IGNORE meant a re-seeded listing whose row was already 'done' from an
    earlier run silently re-queued nothing, so its children never got the
    priority-inherited re-expansion. The fetch layer caches the page, so a
    revived listing costs ~no network.
    """
    conn = db()
    with conn:
        cur = conn.execute(
            """INSERT OR IGNORE INTO frontier(url, priority, depth, domain, status, added_at)
               VALUES(?,?,?,?, 'pending', ?)""",
            (url, priority, depth, domain, time.time()))
        if cur.rowcount == 1:
            return True
        if requeue:
            conn.execute(
                "UPDATE frontier SET status='pending', priority=MAX(priority, ?) "
                "WHERE url=?", (priority, url))
        else:
            # A re-push at higher priority must WIN on a pending row. INSERT OR
            # IGNORE alone silently discarded the new score, so children pushed
            # at 6.5 by old code stayed at 6.5 forever no matter how many
            # priority-19 re-expansions their parent listing produced.
            conn.execute(
                "UPDATE frontier SET priority=? WHERE url=? AND "
                "status='pending' AND priority < ?", (priority, url, priority))
    return cur.rowcount == 1


def frontier_boost_tokens(tokens, delta=3.0, cap=25.0) -> int:
    """Raise every pending row whose URL contains any of `tokens` by `delta`
    (bounded by cap). Drift-recovery: when a crawl wanders off-category, the
    on-category remainder of the frontier gets pulled forward."""
    toks = [t for t in tokens if t][:8]
    if not toks:
        return 0
    conn = db()
    where = " OR ".join("url LIKE ?" for _ in toks)
    args = [f"%{t}%" for t in toks]
    with conn:
        cur = conn.execute(
            f"UPDATE frontier SET priority=MIN(priority + ?, ?) "
            f"WHERE status='pending' AND ({where})",
            [delta, cap] + args)
    return cur.rowcount


def frontier_boost(domain, path_substr, priority) -> int:
    """Raise pending rows of a domain whose URL contains path_substr to at
    least `priority`. Repairs rows queued before priority inheritance existed.
    Returns the number of rows updated."""
    conn = db()
    with conn:
        cur = conn.execute(
            "UPDATE frontier SET priority=? WHERE domain=? AND status='pending' "
            "AND url LIKE ? AND priority < ?",
            (priority, domain, f"%{path_substr}%", priority))
    return cur.rowcount


_BAND_KEY = re.compile(r"^(.+)@(\d+(?:\.\d+)?)-(\d+(?:\.\d+)?)GHz$")


def frontier_pop(domain_budget: dict[str, int] | None = None,
                 default_budget: int = 1, avoid_domains=(),
                 skip_url_tokens=()):
    """Highest-priority pending URL whose domain still has budget, or None.

    A domain absent from `domain_budget` gets `default_budget`, so manually or
    sitemap-seeded domains are crawlable (previously they read as 0 = skipped,
    which made externally seeded frontiers dead on arrival).
    """
    conn = db()
    # Scan in chunks until an eligible row is found or the frontier is truly
    # exhausted. A fixed LIMIT 50 window interacted badly with the off-category
    # skip filter: once the top-50 was all off-category rows (skipped but left
    # pending), pop returned None and the crawl exited in seconds while
    # hundreds of eligible rows sat just below the window.
    fallback = None
    offset = 0
    while offset < 5000:
        rows = conn.execute(
            "SELECT url, priority, depth, domain FROM frontier "
            "WHERE status='pending' ORDER BY priority DESC "
            "LIMIT 200 OFFSET ?", (offset,)).fetchall()
        if not rows:
            break
        offset += len(rows)
        for row in rows:
            if (domain_budget is not None
                    and domain_budget.get(row["domain"], default_budget) <= 0):
                continue
            low = row["url"].lower()
            # Off-category URLs stay PENDING (a future search for that
            # category will want them) — just never popped for this one.
            if any(t in low for t in skip_url_tokens):
                continue
            if row["domain"] in avoid_domains:
                fallback = fallback or dict(row)   # round-robin: prefer change
                continue
            return dict(row)
    return fallback


def frontier_mark(url: str, status: str) -> None:
    conn = db()
    with conn:
        conn.execute("UPDATE frontier SET status=?, fetched_at=? WHERE url=?",
                     (status, time.time(), url))


# --- read side: rank.py-shaped candidates -----------------------------------

# specs.key -> candidate specs field expected by rank.py / gui.py.
_KEY_MAP = {
    "gain_db": ("gain_db", "min"),
    "nf_db": ("noise_nf_db", "max"),
    "p1db_dbm": ("p1db_dbm", "min"),
    "oip3_dbm": ("oip3_dbm", "min"),
    "insertion_loss_db": ("insertion_loss_db", "max"),
    "isolation_db": ("isolation_db", "min"),
    "vswr": ("vswr", "max"),
    "attenuation_db": ("attenuation_db", "typ"),
    "power_w": ("power_w", "min"),
    "psat_dbm": ("psat_dbm", "min"),
    "conversion_loss_db": ("conversion_loss_db", "max"),
    "no_of_ways": ("no_of_ways", "typ"),
    "ports": ("ports", "typ"),
    # space-semiconductor radiation specs (ADI/TI catalogs), surfaced so the
    # datasheet-style results grid can show and colour them.
    "tid_krad": ("tid_krad", "typ"),
    "sel_mev": ("sel_mev", "typ"),
}


def _pick(row, pref):
    """Guarantee-first value pick: pref column, then typ, then whatever exists."""
    order = {"min": ("value_min", "value_typ", "value_max"),
             "max": ("value_max", "value_typ", "value_min"),
             "typ": ("value_typ", "value_max", "value_min")}[pref]
    for col in order:
        if row[col] is not None:
            return row[col]
    return None


def query_candidates(category=None, f_lo=None, f_hi=None, limit=200):
    """Return stored parts as candidate dicts in the shape rank.py expects."""
    conn = db()
    q = "SELECT * FROM parts"
    args = []
    if category:
        q += " WHERE category=?"
        args.append(category)
    q += " ORDER BY last_seen DESC LIMIT ?"
    args.append(limit * 3)          # over-fetch; freq filter is in Python
    out = []
    for p in conn.execute(q, args):
        specs = {}
        conf = {}
        banded = {}                       # base key -> [(lo, hi, row), ...]
        for s in conn.execute("SELECT * FROM specs WHERE part_id=?", (p["id"],)):
            key = s["key"]
            if key == "freq_ghz" and s["value_min"] is not None and s["value_max"] is not None:
                specs["freq_ghz"] = (s["value_min"], s["value_max"])
                continue
            bm = _BAND_KEY.match(key)
            if bm:
                banded.setdefault(bm.group(1), []).append(
                    (float(bm.group(2)), float(bm.group(3)), dict(s)))
                continue
            mapped = _KEY_MAP.get(key)
            if mapped:
                out_key, pref = mapped
                val = _pick(s, pref)
                if val is not None and s["confidence"] >= conf.get(out_key, 0):
                    specs[out_key] = val
                    conf[out_key] = s["confidence"]
            elif s["value_text"] and key in ("connector", "mount_type",
                                            "technology", "space",
                                            "space_variant", "package",
                                            "qual_level", "ti_suffix",
                                            "orderable", "source_category"):
                # "space" MUST be in this passthrough list. It was written to
                # the specs table by the qualification engine but filtered out
                # here on read, so every crawled part surfaced with no space
                # value at all — the GUI's space column showed "?" no matter
                # how much qualification evidence had been found and stored.
                specs[key] = s["value_text"]
        # Band-conditioned specs: choose the band matching the REQUESTED
        # frequency (best overlap; full coverage preferred). With no requested
        # band, use the worst case across bands so ranking never flatters.
        for base, rows_b in banded.items():
            mapped = _KEY_MAP.get(base)
            if not mapped:
                continue
            out_key, pref = mapped
            chosen = None
            if f_lo is not None and f_hi is not None:
                def _fit(b):
                    lo, hi, _r = b
                    overlap = max(0.0, min(hi, f_hi) - max(lo, f_lo))
                    covers = lo <= f_lo and hi >= f_hi
                    return (1 if covers else 0, overlap)
                best = max(rows_b, key=_fit)
                if _fit(best)[1] > 0:
                    chosen = best[2]
            if chosen is None:
                vals = [(_pick(r, pref), r) for _lo, _hi, r in rows_b]
                vals = [(v, r) for v, r in vals if v is not None]
                if not vals:
                    continue
                worst = max if pref == "max" else min
                chosen = worst(vals, key=lambda x: x[0])[1]
            val = _pick(chosen, pref)
            if val is not None:
                specs[out_key] = val
                specs[out_key + "_band"] = chosen["key"].split("@", 1)[-1] \
                    if "@" in chosen["key"] else ""
        fg = specs.get("freq_ghz")
        if f_lo is not None and f_hi is not None:
            if not fg or fg[0] > f_lo + 1e-9 or fg[1] < f_hi - 1e-9:
                continue
        ev = conn.execute(
            "SELECT signal, weight, snippet FROM qual_evidence WHERE part_id=?",
            (p["id"],)).fetchall()
        cand = {
            "vendor": p["vendor"], "model": p["mpn"], "url": p["product_url"],
            "category": p["category"] or None,
            "subcategory": p["subcategory"] or None,
            "title": p["mpn"], "description": p["description"] or "", "specs": specs,
            "source": "partdb",
            "qual_evidence": [dict(r) for r in ev],
            "qual_summary": ", ".join(
                f"{r['signal']} {'+' if r['weight'] >= 0 else ''}{r['weight']:g}"
                for r in ev[:6]),
        }
        out.append(cand)
        if len(out) >= limit:
            break
    return out


def distinct_vendors():
    """Sorted distinct, non-empty vendor names present in the parts table.
    Lets the GUI build its vendor picker from the actual dataset."""
    return [r["vendor"] for r in db().execute(
        "SELECT DISTINCT vendor FROM parts WHERE vendor != '' "
        "ORDER BY vendor COLLATE NOCASE").fetchall()]


def candidate_by_mpn(mpn, vendor=""):
    """One rank-ready candidate for a specific part, regardless of category —
    used by the live-stream path, which previously looked the part up through
    a category-filtered query and silently missed any part whose derived
    category differed from the search's."""
    conn = db()
    row = conn.execute(
        "SELECT category FROM parts WHERE mpn_norm=?" +
        (" AND vendor=?" if vendor else ""),
        ((_norm_mpn(mpn), vendor) if vendor else (_norm_mpn(mpn),))).fetchone()
    if not row:
        return None
    for c in query_candidates(category=row["category"] or None, limit=400):
        if _norm_mpn(c.get("model")) == _norm_mpn(mpn):
            return c
    return None


# --- SATNow cross-reference -------------------------------------------------
# Space qualification belongs to the PART, not to the page it was found on:
# if an MPN appears anywhere in SATNow's space parts database, the same part
# discovered on the manufacturer's own site is space qualified too.

def mpn_in_satnow(mpn) -> bool:
    """True when this MPN exists among parts sourced from satnow.com."""
    row = db().execute(
        "SELECT 1 FROM parts WHERE mpn_norm=? AND product_url LIKE '%satnow.com%' "
        "LIMIT 1", (_norm_mpn(mpn),)).fetchone()
    return row is not None

def apply_satnow_crosslink(mpn, source_url) -> int:
    """A part was just ingested FROM satnow: upgrade every same-MPN part from
    other vendors to qualified, with cross-reference evidence. Returns count."""
    conn = db()
    upgraded = 0
    for row in conn.execute(
            "SELECT id FROM parts WHERE mpn_norm=? AND product_url NOT LIKE "
            "'%satnow.com%'", (_norm_mpn(mpn),)):
        put_specs(row["id"], [SpecRow(
            key="space", value_text="qualified", method="evidence",
            confidence=0.9, source_url=source_url,
            snippet="cross-listed in SATNow space parts database")])
        put_evidence(row["id"], [("satnow-cross-listed", 8.0, source_url,
                                  "same MPN listed in SATNow space database")])
        upgraded += 1
    return upgraded


# --- learned product-URL templates ------------------------------------------
# A confirmed product page teaches the shape of that site's product URLs
# ((n_segments, static_prefix)); seeds.urls_matching_templates then pulls the
# whole catalog branch out of the sitemap on later runs, so discovery improves
# every time the crawler runs instead of restarting from keyword scoring.

def save_template(domain, template) -> None:
    if not template:
        return
    n_seg, prefix = template
    conn = db()
    with conn:
        conn.execute(
            """INSERT INTO url_templates(domain, n_segments, prefix, hits, updated_at)
               VALUES(?,?,?,1,?)
               ON CONFLICT(domain, n_segments, prefix) DO UPDATE SET
                 hits = hits + 1, updated_at = excluded.updated_at""",
            (domain, n_seg, prefix, time.time()))


def get_templates(domain, min_hits=3):
    """Templates confirmed by at least min_hits distinct product pages."""
    rows = db().execute(
        "SELECT n_segments, prefix FROM url_templates "
        "WHERE domain=? AND hits>=?", (domain, min_hits)).fetchall()
    return {(r["n_segments"], r["prefix"]) for r in rows}


# --- dataset maintenance: cross-catalog dedupe ------------------------------
# The same manufacturer part can arrive from several catalogs (everythingRF, an
# ADI/TI/Qorvo sheet, ...). merge_duplicates() collapses parts sharing a loose
# part-number key, KEEPING THE ROW WITH THE MOST SPECS and folding the others'
# specs and evidence into it, so richer wins and nothing is lost.

def _loose_key(mpn: str) -> str:
    """Cross-catalog part key: alphanumerics only, uppercase, trailing '+' kept
    (Mini-Circuits RoHS). 'XYZ-100' == 'XYZ 100' == 'xyz100'."""
    s = str(mpn or "").upper().replace("+", "\u0001")
    s = re.sub(r"[^A-Z0-9]", "", s).replace("\u0001", "+")
    return s


def _spec_count(conn, part_id):
    return conn.execute("SELECT COUNT(*) AS n FROM specs WHERE part_id=?",
                        (part_id,)).fetchone()["n"]


def _is_qualified(conn, part_id):
    row = conn.execute(
        "SELECT value_text FROM specs WHERE part_id=? AND key='space_variant'",
        (part_id,)).fetchone()
    return bool(row) and row["value_text"] == "space_qualified"


def merge_duplicates(progress=None) -> dict:
    """Collapse parts sharing a loose MPN key; return {'groups','deleted'}.

    Duplicates are matched vendor-agnostically on the alphanumeric part number
    (so the same part from everythingRF and a manufacturer sheet collapse).
    Winner = most specs, then space-qualified over grade, then longer
    description, then a real category. Losers' specs/evidence are copied onto the
    winner (their distinct source_url keeps provenance and avoids clobbering),
    then the loser rows are deleted (ON DELETE CASCADE clears the copied specs).
    """
    conn = db()
    buckets: dict[str, list[int]] = {}
    for r in conn.execute("SELECT id, mpn FROM parts"):
        buckets.setdefault(_loose_key(r["mpn"]), []).append(r["id"])
    merged = deleted = 0
    for key, ids in buckets.items():
        if not key or len(ids) < 2:
            continue
        rank = []
        for pid in ids:
            p = conn.execute("SELECT * FROM parts WHERE id=?", (pid,)).fetchone()
            rank.append((_spec_count(conn, pid), _is_qualified(conn, pid),
                         len(p["description"] or ""), bool(p["category"]), pid))
        rank.sort(reverse=True)
        winner = rank[0][4]
        losers = [pid for *_r, pid in rank[1:]]
        merged += 1
        with conn:
            for lid in losers:
                lp = conn.execute("SELECT * FROM parts WHERE id=?", (lid,)).fetchone()
                wp = conn.execute("SELECT * FROM parts WHERE id=?", (winner,)).fetchone()
                fills = {c: lp[c] for c in ("category", "subcategory",
                                            "product_url", "description")
                         if not wp[c] and lp[c]}
                if fills:
                    sets = ", ".join(f"{c}=?" for c in fills)
                    conn.execute(f"UPDATE parts SET {sets} WHERE id=?",
                                 (*fills.values(), winner))
                conn.execute(
                    """INSERT OR IGNORE INTO specs
                       SELECT ?, key, value_min, value_typ, value_max, value_text,
                              unit, method, confidence, source_url, snippet,
                              parser_version, extracted_at
                       FROM specs WHERE part_id=?""", (winner, lid))
                conn.execute(
                    """INSERT OR IGNORE INTO qual_evidence
                       SELECT ?, signal, weight, source_url, snippet, found_at
                       FROM qual_evidence WHERE part_id=?""", (winner, lid))
                conn.execute("DELETE FROM parts WHERE id=?", (lid,))
                deleted += 1
        if progress:
            progress(f"merged {key} ({len(losers)} duplicate)")
    return {"groups": merged, "deleted": deleted}


def dataset_stats() -> dict:
    """Counts for the GUI status line after a rebuild."""
    conn = db()
    parts = conn.execute("SELECT COUNT(*) AS n FROM parts").fetchone()["n"]
    qual = conn.execute(
        "SELECT COUNT(DISTINCT part_id) AS n FROM specs "
        "WHERE key='space_variant' AND value_text='space_qualified'").fetchone()["n"]
    grade = conn.execute(
        "SELECT COUNT(DISTINCT part_id) AS n FROM specs "
        "WHERE key='space_variant' AND value_text='space_grade'").fetchone()["n"]
    vendors = conn.execute(
        "SELECT COUNT(DISTINCT vendor) AS n FROM parts WHERE vendor!=''").fetchone()["n"]
    return {"parts": parts, "qualified": qual, "grade": grade, "vendors": vendors}


# --- part families: a base part number and its pedigree variants -------------
# Distinct from merge_duplicates (which collapses the *same* part). A family
# groups parts that share a base part number but differ by pedigree/screening —
# e.g. TPS7H4011-SP (space-qualified) and TPS7H4011-SEP (space-grade). These
# stay separate rows; family grouping just lets you see a part alongside its
# qualified/graded siblings.

def family_key(mpn) -> str:
    """Base part-number key shared by a part and its pedigree variants."""
    return pedigree.family_base(mpn)


def _part_pedigree(conn, part_id) -> str:
    specs = {}
    for r in conn.execute(
            "SELECT key, value_text FROM specs WHERE part_id=? "
            "AND key IN ('space','space_variant')", (part_id,)):
        specs[r["key"]] = r["value_text"]
    return pedigree.normalize(specs)


def family_members(part_id, include_self=False):
    """Sibling parts sharing the selected part's base number, strongest pedigree
    first. Each item: id, mpn, vendor, category, pedigree, pedigree_label, url."""
    conn = db()
    row = conn.execute("SELECT id, mpn FROM parts WHERE id=?", (part_id,)).fetchone()
    if not row:
        return []
    key = family_key(row["mpn"])
    if not key:
        return []
    out = []
    for r in conn.execute("SELECT id, mpn, vendor, category, product_url, "
                          "description FROM parts"):
        if r["id"] == part_id and not include_self:
            continue
        if family_key(r["mpn"]) != key:
            continue
        ped = _part_pedigree(conn, r["id"])
        out.append({
            "id": r["id"], "mpn": r["mpn"], "vendor": r["vendor"],
            "category": r["category"], "url": r["product_url"],
            "description": r["description"],
            "pedigree": ped, "pedigree_label": pedigree.label(ped),
            "is_self": r["id"] == part_id,
        })
    out.sort(key=lambda m: (pedigree.rank_of(m["pedigree"]), str(m["mpn"])))
    return out


def _family_buckets(conn):
    buckets = {}
    for r in conn.execute("SELECT id, mpn FROM parts"):
        k = family_key(r["mpn"])
        if k:
            buckets.setdefault(k, []).append(r["id"])
    return buckets


def family_stats() -> dict:
    """Counts of multi-member families and how many span >1 pedigree level."""
    conn = db()
    buckets = _family_buckets(conn)
    multi = {k: ids for k, ids in buckets.items() if len(ids) > 1}
    multi_pedigree = 0
    for ids in multi.values():
        peds = {_part_pedigree(conn, pid) for pid in ids}
        if len(peds) > 1:
            multi_pedigree += 1
    return {"families": len(multi),
            "parts_in_families": sum(len(v) for v in multi.values()),
            "multi_pedigree_families": multi_pedigree}


# --- dataset health ---------------------------------------------------------
# Coverage-oriented snapshot: where is the data thick or thin? Everything is a
# straight read over partdb so it stays fast and honest.

# Which specs to report coverage on, PER CATEGORY. Keys are canonical DB spec
# keys (what the ingesters store); labels are for display. RF parametrics are
# only listed for the categories where they're meaningful, so a spec's coverage
# % is measured against the parts it actually applies to — not diluted by every
# other category. The universal set (package + radiation) is appended to every
# category, and categories not listed here fall back to frequency + universal.
_FREQ = ("frequency", "freq_ghz")
_UNIVERSAL_COVERAGE = [("package", "package"), ("TID", "tid_krad"),
                       ("SEL", "sel_mev")]
_CATEGORY_COVERAGE = {
    "amplifier":     [_FREQ, ("gain", "gain_db"), ("NF", "nf_db"),
                      ("P1dB", "p1db_dbm"), ("OIP3", "oip3_dbm"), ("Psat", "psat_dbm")],
    "mixer":         [_FREQ, ("conversion loss", "conversion_loss_db"),
                      ("isolation", "isolation_db"), ("P1dB", "p1db_dbm"),
                      ("OIP3", "oip3_dbm")],
    "attenuator":    [_FREQ, ("attenuation", "attenuation_db"), ("power", "power_w")],
    "filter":        [_FREQ, ("insertion loss", "insertion_loss_db")],
    "switch":        [_FREQ, ("isolation", "isolation_db"),
                      ("insertion loss", "insertion_loss_db"), ("P1dB", "p1db_dbm")],
    "coupler":       [_FREQ, ("isolation", "isolation_db"),
                      ("insertion loss", "insertion_loss_db")],
    "divider":       [_FREQ, ("isolation", "isolation_db"),
                      ("insertion loss", "insertion_loss_db")],
    "phase_shifter": [_FREQ, ("insertion loss", "insertion_loss_db")],
    "limiter":       [_FREQ, ("insertion loss", "insertion_loss_db"),
                      ("power", "power_w")],
    "isolator":      [_FREQ, ("insertion loss", "insertion_loss_db"),
                      ("isolation", "isolation_db")],
    "circulator":    [_FREQ, ("insertion loss", "insertion_loss_db"),
                      ("isolation", "isolation_db")],
    "detector":      [_FREQ],
    "synthesizer":   [_FREQ],
    "oscillator":    [_FREQ],
    "beamformer":    [_FREQ, ("gain", "gain_db")],
    "transceiver":   [_FREQ],
    # non-RF space ICs — RF parametrics don't apply; radiation & package matter
    "data_converter": [], "power": [], "clock": [], "interface": [],
    "sensor": [], "ic": [],
}
_ALL_COVERAGE_KEYS = sorted(
    {key for specs in _CATEGORY_COVERAGE.values() for _l, key in specs}
    | {k for _l, k in _UNIVERSAL_COVERAGE} | {_FREQ[1]})


def _coverage_specs_for(category):
    """Ordered (label, db_key) coverage specs for a category with the universal
    set appended. Unlisted categories fall back to frequency + universal."""
    base = _CATEGORY_COVERAGE.get(category)
    if base is None:
        base = [_FREQ]
    out, seen = [], set()
    for lbl, key in list(base) + _UNIVERSAL_COVERAGE:
        if key not in seen:
            seen.add(key)
            out.append((lbl, key))
    return out


def dataset_health() -> dict:
    """Structured health snapshot: totals, category mix, pedigree distribution,
    category-aware spec coverage, radiation coverage, family & duplicate stats."""
    conn = db()
    parts = conn.execute("SELECT COUNT(*) AS n FROM parts").fetchone()["n"]
    vendors = conn.execute(
        "SELECT COUNT(DISTINCT vendor) AS n FROM parts WHERE vendor!=''").fetchone()["n"]

    sizes = [(r["category"], r["n"]) for r in conn.execute(
        "SELECT category, COUNT(*) AS n FROM parts GROUP BY category ORDER BY n DESC")]
    by_category = [(c or "(uncategorized)", n) for c, n in sizes]

    # pedigree distribution (normalized, one bucket per part)
    dist = {k: 0 for k in pedigree.LADDER}
    pmap = {}
    for r in conn.execute("SELECT part_id, key, value_text FROM specs "
                          "WHERE key IN ('space','space_variant')"):
        pmap.setdefault(r["part_id"], {})[r["key"]] = r["value_text"]
    for pid_row in conn.execute("SELECT id FROM parts"):
        ped = pedigree.normalize(pmap.get(pid_row["id"], {}))
        dist[ped] = dist.get(ped, 0) + 1

    # category-aware coverage: count parts-with-spec WITHIN each category, so the
    # % denominator is the parts the spec applies to.
    qmarks = ",".join("?" * len(_ALL_COVERAGE_KEYS))
    pair_counts = {}
    for r in conn.execute(
            f"SELECT p.category AS cat, s.key AS key, "
            f"COUNT(DISTINCT s.part_id) AS n FROM specs s "
            f"JOIN parts p ON p.id = s.part_id WHERE s.key IN ({qmarks}) "
            f"GROUP BY p.category, s.key", _ALL_COVERAGE_KEYS):
        pair_counts[(r["cat"], r["key"])] = r["n"]
    category_coverage = []
    for cat, size in sizes:
        rows = []
        for lbl, key in _coverage_specs_for(cat):
            n = pair_counts.get((cat, key), 0)
            rows.append((lbl, n, round(100.0 * n / size, 1) if size else 0.0))
        category_coverage.append({"category": cat or "(uncategorized)",
                                  "count": size, "specs": rows})

    rad_parts = conn.execute(
        "SELECT COUNT(DISTINCT part_id) AS n FROM specs "
        "WHERE key IN ('tid_krad','sel_mev')").fetchone()["n"]

    # remaining exact-duplicate collisions (loose key)
    dup_buckets = {}
    for r in conn.execute("SELECT id, mpn FROM parts"):
        dup_buckets.setdefault(_loose_key(r["mpn"]), []).append(r["id"])
    dup_groups = sum(1 for ids in dup_buckets.values() if len(ids) > 1)

    return {
        "parts": parts,
        "vendors": vendors,
        "by_category": by_category,
        "pedigree": dist,
        "pedigree_labels": {k: pedigree.label(k) for k in pedigree.LADDER},
        "category_coverage": category_coverage,
        "radiation_parts": rad_parts,
        "radiation_pct": round(100.0 * rad_parts / parts, 1) if parts else 0.0,
        "families": family_stats(),
        "duplicate_groups": dup_groups,
    }


def family_by_mpn(mpn, include_self=True):
    """Resolve an MPN (exact / case-insensitive / loose) and return its family."""
    conn = db()
    row = (conn.execute("SELECT id FROM parts WHERE mpn=?", (mpn,)).fetchone()
           or conn.execute("SELECT id FROM parts WHERE UPPER(mpn)=UPPER(?)",
                           (mpn,)).fetchone())
    pid = row["id"] if row else None
    if pid is None:
        target = _loose_key(mpn)
        for r in conn.execute("SELECT id, mpn FROM parts"):
            if _loose_key(r["mpn"]) == target:
                pid = r["id"]
                break
    return family_members(pid, include_self=include_self) if pid else []
