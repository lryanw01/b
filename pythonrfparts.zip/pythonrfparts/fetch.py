"""Polite, cached HTTP fetch.

Design choices (deliberate, for use on managed/corporate machines):
  * Honest User-Agent that identifies the tool and a contact — no browser spoofing.
  * robots.txt is fetched and *obeyed*; disallowed URLs are skipped, not forced.
  * Per-domain politeness delay: DEFAULT_DELAY, raised to robots Crawl-delay when
    the site declares one (so we go fast where allowed, slow where asked).
  * SQLite cache with TTL so re-runs don't re-hit vendors (text AND binary).
  * Smart retry: only transient failures (timeouts, connection errors, 429, 5xx)
    are retried, honoring Retry-After; 4xx (403/404/...) fail immediately instead
    of burning a full timeout on a site that already said no.
  * Pure `requests` — no headless browser, no JS execution, no anti-bot evasion.

Verbose logging goes to stderr by default. A GUI (or anything without a visible
stderr) can set LOG_SINK to a callable to capture log lines instead.
"""
import sqlite3
import threading
import time
import urllib.robotparser
from urllib.parse import urlparse

import requests

from .registry import DATA
from . import timing

CACHE_DB = DATA / "cache.db"
TTL = 7 * 86400          # successful pages cached 7 days
FAIL_TTL = 3600          # failures cached 1 hour
DEFAULT_DELAY = 0.5      # seconds between requests to the same domain (unless robots asks for more)
TIMEOUT = 20
MAX_RETRIES = 3
RETRY_STATUS = {429, 500, 502, 503, 504}
VERBOSE = False
LOG_SINK = None          # optional callable(msg); used instead of stderr when set

# Honest, identifying User-Agent. Change the contact to yours before deploying.
UA = "rfparts/0.1 (+https://example.invalid/rfparts; component-sourcing bot)"
HEADERS = {"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9"}

_local = threading.local()
_domain_lock = threading.Lock()
_domain_last = {}        # domain -> last request time
_robots_lock = threading.Lock()
_robots = {}             # domain -> (RobotFileParser, crawl_delay)


def log(msg):
    if not VERBOSE:
        return
    if LOG_SINK is not None:
        LOG_SINK(msg)
    else:
        import sys

        print(msg, file=sys.stderr)


def _db():
    if not hasattr(_local, "db"):
        _local.db = sqlite3.connect(CACHE_DB)
        _local.db.execute(
            "CREATE TABLE IF NOT EXISTS pages "
            "(url TEXT PRIMARY KEY, ts REAL, ok INT, body BLOB)")
    return _local.db


def _cached(url, ttl, binary=False):
    row = _db().execute(
        "SELECT ts, ok, body FROM pages WHERE url=?", (url,)).fetchone()
    if row and time.time() - row[0] < (ttl if row[1] else FAIL_TTL):
        if not row[1]:
            return None, True
        return (row[2] if binary else row[2].decode("utf-8", "replace")), True
    return None, False


def _store(url, body, binary=False):
    if body is None:
        blob, ok = b"", 0
    else:
        blob, ok = (body if binary else body.encode()), 1
    _db().execute(
        "INSERT OR REPLACE INTO pages VALUES (?,?,?,?)",
        (url, time.time(), ok, blob))
    _db().commit()


def _robot(url):
    domain = urlparse(url).netloc
    with _robots_lock:
        if domain not in _robots:
            rp = urllib.robotparser.RobotFileParser()
            robots_url = f"{urlparse(url).scheme}://{domain}/robots.txt"
            delay = DEFAULT_DELAY
            try:
                r = requests.get(robots_url, headers=HEADERS, timeout=TIMEOUT)
                if r.status_code == 200:
                    rp.parse(r.text.splitlines())
                    cd = rp.crawl_delay(UA)
                    if cd:
                        delay = max(delay, float(cd))
                else:
                    rp = None
            except requests.RequestException:
                rp = None
            _robots[domain] = (rp, delay)
        return _robots[domain]


def allowed(url):
    rp, _ = _robot(url)
    return True if rp is None else rp.can_fetch(UA, url)


def _polite(url):
    rp, delay = _robot(url)
    domain = urlparse(url).netloc
    with _domain_lock:
        wait = _domain_last.get(domain, 0) + delay - time.time()
        _domain_last[domain] = max(time.time(), _domain_last.get(domain, 0) + delay)
    if wait > 0:
        time.sleep(wait)


def _retry_after(resp, fallback):
    ra = resp.headers.get("Retry-After")
    if ra:
        try:
            return max(0.0, float(ra))
        except ValueError:
            pass
    return fallback


def _request(url):
    _polite(url)
    return requests.get(url, headers=HEADERS, timeout=TIMEOUT)


def get(url, ttl=TTL, binary=False):
    """Fetch a URL politely. Returns text (or bytes if binary), or None.

    Skips (returns None) if robots.txt disallows it. Successes and failures are
    cached (binary included). Transient failures are retried; 4xx are not.
    """
    if not allowed(url):
        log(f"robots-disallow {url}")
        return None
    body, hit = _cached(url, ttl, binary)
    if hit:
        return body
    timing.note_request(urlparse(url).netloc)
    _t0 = time.perf_counter()
    body = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            r = _request(url)
        except requests.Timeout:
            log(f"timeout ({attempt}) {url}")
            continue
        except requests.RequestException as e:
            log(f"fetch fail {url}: {type(e).__name__}")
            break
        if r.status_code in RETRY_STATUS and attempt < MAX_RETRIES:
            wait = _retry_after(r, DEFAULT_DELAY * attempt)
            log(f"retry {r.status_code} ({attempt}) {url} in {wait:g}s")
            time.sleep(wait)
            continue
        if r.status_code >= 400:
            log(f"fetch fail {url}: HTTP {r.status_code}")
            break
        body = r.content if binary else r.text
        break
    timing.record("http_fetch", time.perf_counter() - _t0,
                  label=f"GET {url[:90]}")
    _store(url, body, binary)
    return body

def get_bytes(url, ttl=TTL):
    return get(url, ttl=ttl,binary=True)