"""Draft a plain-text RFQ (request-for-quote) email for a vendor.

This only *drafts* text — it does not send anything, open a mail client, or
touch the network. You paste it into your own email tooling.
"""


def _req_line(spec):
    bits = []
    if spec.get("category"):
        bits.append(spec["category"])
    if spec.get("freq_ghz"):
        bits.append(f"{spec['freq_ghz'][0]:g}–{spec['freq_ghz'][1]:g} GHz")
    if spec.get("temp_k") is not None:
        bits.append(f"operating at {spec['temp_k']:g} K")
    if spec.get("gain_db_min") is not None:
        bits.append(f"gain ≥ {spec['gain_db_min']:g} dB")
    if spec.get("noise_k_max") is not None:
        bits.append(f"noise temp ≤ {spec['noise_k_max']:g} K")
    if spec.get("attenuation_db") is not None:
        bits.append(f"{spec['attenuation_db']:g} dB attenuation")
    if spec.get("package"):
        bits.append(f"{spec['package']} package")
    if spec.get("connector"):
        bits.append(f"{spec['connector']} connectors")
    if spec.get("mount"):
        bits.append(spec["mount"])
    for o in spec.get("other", []):
        bits.append(o)
    return ", ".join(bits) if bits else "the part described below"


def draft(vendor, parts, spec, requester="[your name]", org="[your organization]"):
    """Return (to_address, subject, body) for an RFQ to `vendor` about `parts`."""
    to = vendor.get("rfq_email") or f"(no email on file — use web form at {vendor['url']})"
    subject = f"RFQ: {spec.get('category', 'RF component')} " + (
        f"{spec['freq_ghz'][0]:g}-{spec['freq_ghz'][1]:g} GHz" if spec.get("freq_ghz") else "")
    lines = [
        f"Hello {vendor['name']} sales team,",
        "",
        f"We are sourcing a {_req_line(spec)} and would like a quote and lead time.",
        "",
        "Parts of interest from your catalog:",
    ]
    if parts:
        for p in parts:
            price = p.get("specs", {}).get("price_usd")
            price_s = f" (listed ${price:,.0f})" if isinstance(price, (int, float)) else ""
            lines.append(f"  - {p.get('title', p['url'])}{price_s}")
            lines.append(f"    {p['url']}")
    else:
        lines.append("  - (open to your recommendation for the requirement above)")

    ask = ["Please include unit price at qty 1 and 10, lead time,"]
    if spec.get("space"):
        # Lane's domain: make the qualification ask explicit for space builds.
        ask.append("and qualification status — MIL-PRF-38534 Class K/H or QML flow,")
        ask.append("available screening/upscreening, hermeticity, and any radiation")
        ask.append("(TID/SEE) data or heritage.")
    else:
        ask.append("RoHS/qualification status, and any datasheet not already on your site.")

    lines += [""] + [" ".join(ask)] + [
        "",
        "Thank you,",
        f"{requester}",
        f"{org}",
    ]
    return to, subject.strip(), "\n".join(lines)
