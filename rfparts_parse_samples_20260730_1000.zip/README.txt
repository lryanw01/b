rfparts parse sample bundle
===========================
generated 2026-07-30 10:00:30

One folder per vendor. In each folder:

  NN_<something>.html        the exact source bytes our parser was given
  NN_<something>_excerpt.csv for spreadsheets: header + units + a few data rows,
                             with the part-number column as its RAW FORMULA
                             (it is =HYPERLINK(...), and reading it wrongly
                             yields blank part numbers)
  NN_..._parsed.txt          readable parse report: tables found, header ->
                             spec-key mapping, columns that were IGNORED, each
                             parsed value beside the cell it came from, and every
                             rejected row with its reason
  NN_..._parsed.json         the same report, machine-readable
  part_<PN>.html             for Marki/Skyworks, one part's own page, where the
                             specs actually live
  parts.json                 the part dicts the pipeline emits, specs included

Only 3 sample(s) per vendor: enough to show a parsing fault, small
enough to send. Cached pages were reused where available, so this usually costs
no requests.

environment.txt records versions, resolved paths, per-vendor counts, and anything
that could not be sampled and why.
