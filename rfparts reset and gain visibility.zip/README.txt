rfparts — Reset actually resetting, and gain made visible in the log
===================================================================
2 files. Drop into rfparts/.  Run: python -m rfparts.selfcheck


1. RESET LEFT EVERYTHING IN PLACE — FOUND IT
--------------------------------------------
"reset only the vendors ticked above" defaulted to TRUE.

So ticking Reset with, say, ADI ticked deleted ONLY the ADI rows and left
everythingRF, MACOM, Qorvo and the rest untouched -- which is exactly what you
saw in the vendor panel. If you ticked Reset with NO vendors, it did wipe
everything; the behaviour changed depending on a checkbox that was on by default
and easy to miss.

Fixed three ways:

  * The default is now FALSE. Reset means reset. Narrowing it is opt-in, and the
    checkbox is relabelled "narrow the reset to only the vendors ticked above
    (default: reset EVERYTHING)".

  * The confirmation now states the actual consequence, with counts read from the
    database before anything is deleted:

        Delete parts, scrape state, cached pages and downloaded datasheets for
        the WHOLE dataset

        all 11437 part(s) will be deleted.

    or, if you narrow it:

        ONLY: Analog Devices
        1201 part(s) will be deleted and 10236 part(s) from other vendors will
        be KEPT.

  * The vendor panel now refreshes THE MOMENT the reset completes, instead of
    waiting for its 1-second timer. Previously the re-ingest had already begun
    repopulating the counts by the time the panel next drew, so the reset looked
    like it had done nothing even when it worked. The log also gets an explicit
    line:

        RESET DONE | 1201 part(s) deleted, 0 scrape-log row(s), 0 cached page(s)


2. ADI GAIN — THE PIPELINE IS CORRECT, SO HERE IS HOW TO SEE IT
---------------------------------------------------------------
I re-inspected both ADI sources end to end and the extraction is working:

    ADIParametricSearchAmplifiers.xlsx   "Gain typ" -> gain_db
    ADIParametricSearchLNA+PA.xlsx       "Gain typ" -> gain_db, 335 of 418 rows
                                         populated, all 335 extracted
    ADIParametricSearchMixers.xlsx       "Conversion Gain" -> conversion_gain_db
    the other six sheets                 have NO gain column at all
    adi_space_portfolio_*.xlsx           has NO gain column at all

Measured in the database after a real rebuild: 377 gain_db rows, stored as
value_typ with unit dB, e.g. ADL6346B = 40.0 dB. The picker's candidate builder
returns it for 316 of 400 amplifier candidates, and the live table renders it as
"40.0 dB".

So the likely reason you saw none is (1) above: the reset spared your old ADI
rows, which were written before the gain fix, and resume then skipped re-reading
the sheets.

To make this answerable from the log instead of by hunting in the UI, every
rebuild now ends with:

    RF spec coverage by vendor (after this run)
      vendor                parts   freq   gain     NF   P1dB   OIP3   Psat
      Analog Devices         1201   1027    377    382    317    374     59

If gain reads 0 there after a rebuild, the ingest genuinely did not run; if it
reads 377, the data is in the database and the question moves to the query or the
column being looked at.

Do note the honest ceiling: only three of the nine parametric sheets carry a gain
column, and the space portfolio carries none, so roughly a third of ADI parts will
never have gain from these sources. The space portfolio's job is qualification
level, TID/SEL, package material and the datasheet URL -- not RF parametrics. The
39 genuine RF amplifiers in it get their gain by merging with the parametric
exports, which is why ingesting BOTH matters.


SUGGESTED SEQUENCE
------------------
    1. python -m rfparts.selfcheck
    2. Rebuild, tick RESET, leave "narrow the reset" UNTICKED, confirm the count
       in the dialog looks like your whole dataset
    3. tick ADI and set the ADI parametric folder, and point the sources folder at
       the one holding adi_space_portfolio_*.xlsx so BOTH ADI inputs are read
    4. read the coverage table at the end of the log


NOT TESTED HERE
---------------
No Tk: the confirmation text, the relabelled checkbox and the immediate panel
refresh are verified by AST and by driving rebuild() directly (the reset event
fires with the right counts and the dataset really does go to 0), not by eye.
