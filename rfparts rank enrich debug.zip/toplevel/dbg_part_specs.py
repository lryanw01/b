"""dbg_part_specs.py — where did THIS part's numbers come from?

    python dbg_part_specs.py HMC8038
    python dbg_part_specs.py HMC8038 --sources
    python dbg_part_specs.py HMC8038 ADRF5040 --key freq_ghz

Prints, for one part:

  1. every spec row in the database, with the source URL, method and confidence
     that produced it, so a wrong number can be attributed to a specific source
     rather than guessed at
  2. what each key resolves to after the confidence contest, which is what the
     grid and the ranker actually see
  3. with --sources, the RAW value in each source file that mentions the part --
     the ADI workbook cell, the everythingRF attribute, the Qorvo table cell --
     alongside the conversion applied to it

WHY
    A frequency can be wrong in three different places and they need different
    fixes: the source states something unexpected, the parser mis-scales it, or a
    stale row from an older parser is still winning the confidence contest. The
    database alone cannot tell them apart, so this shows the stored rows and the
    source values side by side.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

try:
    from pythonrfparts import partdb
except Exception as e:                                   # pragma: no cover
    sys.exit(f"Could not import the package: {e}\n"
             "Run this from the folder that contains pythonrfparts/.")


def _loose(s):
    return re.sub(r"[^A-Z0-9]", "", str(s or "").upper())


def show_db(mpn):
    conn = partdb.db()
    rows = conn.execute(
        "SELECT id, mpn, vendor, category, subcategory, description, product_url "
        "FROM parts WHERE upper(mpn)=? OR upper(mpn) LIKE ?",
        (mpn.upper(), f"%{mpn.upper()}%")).fetchall()
    if not rows:
        print(f"  no part in the database matching {mpn!r}")
        return []
    for r in rows:
        print(f"\n  {'=' * 66}")
        print(f"  {r['mpn']}   vendor={r['vendor']}   category={r['category']}"
              f"/{r['subcategory'] or '-'}")
        print(f"  {r['description'][:96]}")
        print(f"  {r['product_url'][:96]}")
        specs = conn.execute(
            "SELECT key, value_min, value_typ, value_max, unit, method, "
            "confidence, source_url, snippet FROM specs WHERE part_id=? "
            "ORDER BY key, confidence DESC", (r["id"],)).fetchall()
        print(f"\n  {len(specs)} stored spec row(s):")
        print(f"    {'key':<20} {'min':>10} {'typ':>10} {'max':>10} {'unit':<6} "
              f"{'conf':>5}  method / source")
        for s in specs:
            def f(v):
                return "" if v is None else f"{v:g}"
            print(f"    {s['key']:<20} {f(s['value_min']):>10} "
                  f"{f(s['value_typ']):>10} {f(s['value_max']):>10} "
                  f"{(s['unit'] or ''):<6} {s['confidence']:>5.2f}  "
                  f"{s['method'] or '?'} / {(s['source_url'] or '')[:42]}")
            if s["snippet"]:
                print(f"      snippet: {str(s['snippet'])[:88]}")
        # What the UI actually sees, after the confidence contest.
        cands = [c for c in partdb.query_candidates(limit=100000)
                 if _loose(c.get("model")) == _loose(r["mpn"])]
        if cands:
            resolved = cands[0].get("specs") or {}
            print(f"\n  resolved for the grid/ranker ({len(resolved)} key(s)):")
            for k in sorted(resolved):
                print(f"    {k:<24} {resolved[k]}")
            fg = resolved.get("freq_ghz")
            if isinstance(fg, (tuple, list)) and len(fg) == 2:
                lo, hi = fg
                verdict = "looks sane"
                if hi > 300:
                    verdict = "!! above 300 GHz -- almost certainly a unit error"
                elif lo > 0 and hi / lo > 1000:
                    verdict = "!! spans >3 decades -- almost certainly a unit error"
                print(f"\n  frequency band {lo} - {hi} GHz  -> {verdict}")
                if hi > 300:
                    print(f"     if the source said MHz, the right band is "
                          f"{lo / 1000:g} - {hi / 1000:g} GHz")
        else:
            print("\n  ! the part is in `parts` but query_candidates does not "
                  "return it\n    (a category filter or the frequency filter is "
                  "excluding it)")
    return [r["mpn"] for r in rows]


_FREQ_HDR = re.compile(r"freq|bandwidth|cutoff", re.I)


def scan_adi(mpn, adi_dir=None):
    """Raw cells for this part in any ADI parametric workbook."""
    try:
        import openpyxl
    except ImportError:
        print("    (openpyxl not installed; cannot read the ADI workbooks)")
        return
    try:
        from pythonrfparts import adi_parametric_ingest as adi
    except Exception as e:
        print(f"    (could not import adi_parametric_ingest: {e})")
        return
    roots = [Path(adi_dir)] if adi_dir else []
    roots += [Path.home() / "Downloads" / "rfparts",
              Path(partdb.DATA).parent]
    books = []
    for root in roots:
        if root.is_dir():
            books += [f for f in root.rglob("*.xlsx")
                      if not f.name.startswith("~$")]
    books = list(dict.fromkeys(books))[:12]
    if not books:
        print("    no .xlsx found to check")
        return
    target = _loose(mpn)
    for b in books:
        try:
            wb = openpyxl.load_workbook(str(b), read_only=True, data_only=False)
        except Exception as e:
            print(f"    {b.name}: could not open ({type(e).__name__})")
            continue
        sheet = ("Web Display" if "Web Display" in wb.sheetnames
                 else wb.sheetnames[-1])
        ws = wb[sheet]
        rows = list(ws.iter_rows(values_only=True))
        wb.close()
        if not rows:
            continue
        # find the header row and the part row
        hdr_i = 0
        for i, row in enumerate(rows[:12]):
            if row and any(isinstance(c, str) and "part" in c.lower()
                           for c in row if c):
                hdr_i = i
                break
        headers = [str(c or "") for c in rows[hdr_i]]
        for row in rows[hdr_i + 1:]:
            joined = " ".join(str(c) for c in row if c)
            if target and target in _loose(joined):
                print(f"\n    {b.name} [{sheet}] row match:")
                for h, v in zip(headers, row):
                    if v is None or not _FREQ_HDR.search(h):
                        continue
                    scale = adi.freq_unit_from_header(h)
                    conv = adi._freq_to_ghz(v, scale)
                    print(f"      {h[:44]:<44} raw={v!r:<14} "
                          f"header-unit-scale={scale} -> {conv} GHz")
                break


def scan_erf(mpn, erf_dir=None):
    """The everythingRF attributes for this part, from the saved pages."""
    try:
        from pythonrfparts import erf_space_ingest as esi
    except Exception as e:
        print(f"    (could not import erf_space_ingest: {e})")
        return
    roots = [Path(erf_dir)] if erf_dir else []
    try:
        from pythonrfparts.paths import EVERYTHING_RF, SOURCES_ROOT
        roots += [Path(EVERYTHING_RF), Path(SOURCES_ROOT)]
    except Exception:
        pass
    pages = []
    for root in roots:
        if root.is_dir():
            pages += list(root.rglob("*.htm*"))
    pages = list(dict.fromkeys(pages))
    if not pages:
        print("    no saved everythingRF pages found")
        return
    target = _loose(mpn)
    hits = 0
    for f in pages:
        try:
            text = f.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if target not in _loose(text):
            continue
        for part in esi.parse_page(text, f.parent.name):
            if _loose(part.get("mpn")) != target:
                continue
            hits += 1
            print(f"\n    {f.name} (folder {f.parent.name}):")
            for r in part.get("spec_rows") or []:
                if not _FREQ_HDR.search(r.key):
                    continue
                print(f"      {r.key:<18} min={r.value_min} typ={r.value_typ} "
                      f"max={r.value_max} unit={r.unit!r} "
                      f"method={r.method} conf={r.confidence}")
                if r.snippet:
                    print(f"        snippet: {str(r.snippet)[:80]}")
            break
        if hits >= 3:
            break
    if not hits:
        print(f"    {len(pages)} page(s) searched; {mpn} not found in any")


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("mpn", nargs="+")
    ap.add_argument("--sources", action="store_true",
                    help="also read the source files and show the raw values")
    ap.add_argument("--adi-dir", default=None)
    ap.add_argument("--erf-dir", default=None)
    ap.add_argument("--key", default=None,
                    help="only show this spec key in the stored rows")
    args = ap.parse_args(argv)

    print(f"database: {partdb.DB_PATH}")
    for mpn in args.mpn:
        print(f"\n{'#' * 70}\n#  {mpn}\n{'#' * 70}")
        show_db(mpn)
        if args.sources:
            print(f"\n  --- raw values in the ADI workbooks ---")
            scan_adi(mpn, args.adi_dir)
            print(f"\n  --- raw values in the saved everythingRF pages ---")
            scan_erf(mpn, args.erf_dir)
    print("\nReading this: if a stored row's source_url points at a file whose RAW")
    print("value is right, the parser mis-scaled it. If the raw value is already")
    print("odd, the source says so. If an old row with high confidence is winning")
    print("over a newer correct one, the fix is to re-parse that source (bump its")
    print("PARSER_VERSION or touch the file) so the stale row is replaced.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
