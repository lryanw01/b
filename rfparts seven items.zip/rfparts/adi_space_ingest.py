"""Ingest the ADI space portfolio spreadsheet.

This is a different file from the ADI *parametric* exports, and far richer for
qualification purposes. We were reading exactly one column out of nineteen -- the
part number -- and guessing datasheet URLs that analog.com then answered with
HTTP 403. Column 18 contains the real URL.

WHAT THE SHEET ACTUALLY HOLDS  (verified against adi_space_portfolio_*.xlsx)

    row 3 is the header row; data starts at row 4

     0  Generic Part Number          AD1671S
     1  Description
     2  Orderable Material Number    AD16710703D   (several rows per generic part)
     3  Category                     PRECISION A/D CONVERTERS
     4  Sub-Category
     5  Space Qualification Level    ASD Model (MIL-PRF-38535 Class V)
     6  Operating Temperature        -55°C to 125°C
     7  Production Radiation Hardness
     8  TID Threshold (kRad)         100 (non-RHA)
     9  TID Report
    10  SEL Threshold (MeV*cm2/mg)
    11  SEE Report
    12  Displacement Damage (TNID)
    13  Displacement Damage Report
    14  Package                      28-Lead Side-Brazed Ceramic
    15  Package Material             Ceramic/Metal
    16  Lead Finish                  SnPb
    17  ADI POD No.
    18  Datasheet URL                https://www.analog.com/...

Columns 5, 8, 10 and 15 are the ones that matter most and were entirely absent
from the database: the QML level drives pedigree, TID/SEL are the radiation data
the health report has been reporting as ~0% coverage, and "Ceramic/Metal" is
direct hermeticity evidence.

MULTIPLE ROWS PER PART.  Each orderable material number gets its own row, and
they differ: an Engineering Model row carries "n/a - Engineering Model" and no
radiation data, while the flight row carries Class V and a TID threshold. Rows are
collapsed per generic part number, keeping the STRONGEST qualification level and
the best-populated radiation figures, so an engineering-model row can never
downgrade the flight part.

    python -m rfparts.adi_space_ingest "Sources/newSources" --dry-run --verbose
"""
from __future__ import annotations

import argparse
import re
from collections import Counter
from pathlib import Path

try:
    from .partdb import SpecRow, upsert_part, put_specs, put_evidence
except ImportError:                                     # loose-script fallback
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from rfparts.partdb import (                          # type: ignore
        SpecRow, upsert_part, put_specs, put_evidence)

VENDOR = "Analog Devices"
HEADER_HINT = "generic part number"

# ADI's own category strings -> pipeline categories. Their space portfolio is
# mostly non-RF precision silicon, so most of it is correctly NOT an RF category.
_CATEGORY_MAP = [
    ("a/d converter", "data_converter"), ("d/a converter", "data_converter"),
    ("adc", "data_converter"), ("dac", "data_converter"),
    ("amplifier", "amplifier"), ("op amp", "amplifier"),
    ("instrumentation amp", "amplifier"),
    ("comparator", "interface"),
    ("voltage reference", "power"), ("regulator", "power"),
    ("power management", "power"), ("switching regulator", "power"),
    ("interface", "interface"), ("transceiver", "transceiver"),
    ("rs-485", "interface"), ("rs-232", "interface"),
    ("clock", "clock"), ("timing", "clock"), ("oscillator", "oscillator"),
    ("mixer", "mixer"), ("multiplier", "multiplier"),
    ("switch", "switch"), ("attenuator", "attenuator"),
    ("sensor", "sensor"), ("temperature", "sensor"),
    ("supervisory", "power"), ("multiplexer", "switch"),
    ("rf", "amplifier"),
]

# Qualification level -> (pedigree-ish tier, weight). Ordered strongest first so
# collapsing rows keeps the best one.
_QUAL_TIERS = [
    (r"class\s*v|qml-?v|38535\s*class\s*v", "qualified", 10.0,
     "MIL-PRF-38535 Class V / QML-V"),
    (r"class\s*k|38534\s*class\s*k", "qualified", 10.0,
     "MIL-PRF-38534 Class K"),
    (r"\bjans\b", "qualified", 10.0, "MIL-PRF-19500 JANS"),
    (r"escc|esa\s*qpl", "qualified", 10.0, "ESCC / ESA QPL"),
    (r"class\s*q|qml-?q", "hi_rel", 7.0, "MIL-PRF-38535 Class Q / QML-Q"),
    (r"class\s*h|38534\s*class\s*h", "hi_rel", 7.0, "MIL-PRF-38534 Class H"),
    (r"jantxv|jantx", "hi_rel", 6.5, "JANTX(V)"),
    (r"asd\s*model", "qualified", 9.0, "ADI ASD (aerospace) model"),
    (r"mil-std-883", "hi_rel", 6.0, "MIL-STD-883 screened"),
    (r"engineering\s*model|^n/a", "", 0.0, "engineering model (not flight)"),
]
_NA = {"", "n/a", "na", "none", "not performed", "not applicable", "-", "tbd"}


def _clean(v):
    s = "" if v is None else str(v).replace("\n", " ").strip()
    return "" if s.lower() in _NA else s


def _num(v):
    """First number in a cell. '100 (non-RHA)' -> 100.0"""
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    m = re.search(r"-?\d+(?:\.\d+)?", str(v).replace(",", ""))
    return float(m.group(0)) if m else None


def _category_for(cat, subcat=""):
    blob = f"{cat} {subcat}".lower()
    for needle, mapped in _CATEGORY_MAP:
        if needle in blob:
            return mapped
    return "ic"


def _qual_for(text):
    """(tier, weight, label) for a Space Qualification Level cell."""
    low = (text or "").lower()
    for pat, tier, weight, label in _QUAL_TIERS:
        if re.search(pat, low):
            return tier, weight, label
    return "", 0.0, ""


_TEMP = re.compile(r"(-?\d+)\s*°?\s*C\s*(?:to|\.\.|–|-)\s*\+?(-?\d+)\s*°?\s*C",
                   re.I)


def find_workbooks(path):
    path = Path(path)
    if path.is_file():
        return [path]
    hits = []
    for pat in ("*space_portfolio*.xlsx", "*space*portfolio*.xlsx",
                "*Space*Qualified*.xlsx"):
        hits += [p for p in path.rglob(pat) if not p.name.startswith("~$")]
    return sorted(set(hits))


def parse_workbook(path, verbose=False, progress=None):
    """Collapse the sheet to one record per GENERIC part number."""
    import openpyxl
    say = progress or (lambda m: None)
    wb = openpyxl.load_workbook(str(path), read_only=True, data_only=True)
    ws = wb[wb.sheetnames[0]]
    rows = [list(r) for r in ws.iter_rows(values_only=True)]
    wb.close()

    header_row = None
    for i, r in enumerate(rows[:20]):
        if any(HEADER_HINT in str(c or "").lower() for c in r):
            header_row = i
            break
    if header_row is None:
        say(f"      {path.name}: no 'Generic Part Number' header found")
        return {}
    headers = [str(c or "").replace("\n", " ").strip() for c in rows[header_row]]

    def col(*needles, exact=None):
        for i, h in enumerate(headers):
            hl = h.lower()
            if exact and hl == exact:
                return i
            if not exact and all(n in hl for n in needles):
                return i
        return None

    ix = {
        "pn": col("generic part number"),
        "desc": col(exact="description"),
        "orderable": col("orderable"),
        "cat": col(exact="category"),
        "subcat": col("sub-category") or col("sub category"),
        "qual": col("qualification level"),
        "temp": col("temperature"),
        "rha": col("radiation hardness"),
        "tid": col("tid threshold"),
        "sel": col("sel threshold"),
        "tnid": col("displacement damage"),
        "package": col(exact="package"),
        "pkg_mat": col("package material"),
        "lead": col("lead finish"),
        "ds": col("datasheet url"),
    }
    if verbose:
        say(f"      {path.name}: header row {header_row + 1}, "
            f"{len(headers)} column(s)")
        for k, i in ix.items():
            say(f"        {k:<10} -> col {i}"
                + (f"  '{headers[i]}'" if i is not None else "  (absent)"))
    if ix["pn"] is None:
        return {}

    def cell(r, key):
        i = ix.get(key)
        return _clean(r[i]) if i is not None and i < len(r) else ""

    merged = {}
    orderables = {}
    for r in rows[header_row + 1:]:
        if not r:
            continue
        pn = cell(r, "pn")
        if not pn or len(pn) < 3:
            continue
        tier, weight, label = _qual_for(cell(r, "qual"))
        rec = merged.get(pn)
        if rec is None:
            rec = merged[pn] = {
                "mpn": pn, "vendor": VENDOR, "description": cell(r, "desc"),
                "adi_category": cell(r, "cat"), "adi_subcategory": cell(r, "subcat"),
                "qual_text": "", "qual_tier": "", "qual_weight": 0.0,
                "qual_label": "", "specs": {}, "datasheet_url": cell(r, "ds"),
                "rows": 0,
            }
            rec["category"] = _category_for(rec["adi_category"],
                                            rec["adi_subcategory"])
        rec["rows"] += 1
        orderables.setdefault(pn, []).append(cell(r, "orderable"))

        # Keep the STRONGEST qualification across the orderable rows: an
        # engineering-model row must never downgrade the flight part.
        if weight > rec["qual_weight"]:
            rec["qual_weight"] = weight
            rec["qual_tier"] = tier
            rec["qual_label"] = label
            rec["qual_text"] = cell(r, "qual")

        s = rec["specs"]
        tid = _num(cell(r, "tid"))
        if tid is not None:
            s["tid_krad"] = max(tid, s.get("tid_krad", 0.0))
        sel = _num(cell(r, "sel"))
        if sel is not None:
            s["sel_mev"] = max(sel, s.get("sel_mev", 0.0))
        tnid = _num(cell(r, "tnid"))
        if tnid is not None:
            s["tnid"] = max(tnid, s.get("tnid", 0.0))
        tm = _TEMP.search(cell(r, "temp"))
        if tm:
            s.setdefault("temp_min_c", float(tm.group(1)))
            s.setdefault("temp_max_c", float(tm.group(2)))
        for key, src in (("package", "package"), ("package_material", "pkg_mat"),
                         ("lead_finish", "lead"),
                         ("radiation_hardness", "rha")):
            v = cell(r, src)
            if v and key not in s:
                s[key] = v
        if not rec["datasheet_url"]:
            rec["datasheet_url"] = cell(r, "ds")
    for pn, rec in merged.items():
        ords = [o for o in orderables.get(pn, []) if o]
        if ords:
            rec["orderables"] = sorted(set(ords))
    return merged


def _write(rec):
    pid = upsert_part(mpn=rec["mpn"], vendor=VENDOR,
                      category=rec.get("category", "ic"),
                      subcategory="", product_url=rec.get("datasheet_url", ""),
                      description=rec.get("description", "")[:200])
    url = rec.get("datasheet_url", "")
    rows = []

    def add(key, **kw):
        rows.append(SpecRow(key=key, method="catalog", confidence=0.95,
                            source_url=url, snippet="ADI space portfolio", **kw))

    s = rec.get("specs", {})
    for key in ("tid_krad", "sel_mev", "tnid", "temp_min_c", "temp_max_c"):
        if key in s:
            add(key, value_typ=float(s[key]),
                unit={"tid_krad": "krad", "sel_mev": "MeV*cm2/mg"}.get(key, "C"))
    for key in ("package", "package_material", "lead_finish",
                "radiation_hardness"):
        if key in s:
            add(key, value_text=str(s[key])[:100])
    if rec.get("adi_category"):
        add("vendor_category", value_text=rec["adi_category"][:100])
    if rec.get("orderables"):
        add("orderable_parts", value_text=", ".join(rec["orderables"])[:200])
    if rec.get("qual_text"):
        add("space_qual_level", value_text=rec["qual_text"][:120])
    # Hermetic construction is stated outright by "Ceramic/Metal", and the
    # classifier and pedigree both key off it.
    mat = str(s.get("package_material", "")).lower()
    if "ceramic" in mat or "metal" in mat:
        add("hermetic", value_text="yes")
    if rec.get("qual_tier"):
        add("space", value_text="qualified")
        add("space_variant", value_text=(
            "space_qualified" if rec["qual_tier"] == "qualified"
            else "space_grade"))
    if url:
        add("datasheet_url", value_text=url[:200])
    if rows:
        put_specs(pid, rows)

    ev = []
    if rec.get("qual_tier") == "qualified":
        ev.append(("adi-space-portfolio-qualified", rec.get("qual_weight", 9.0),
                   url, rec.get("qual_label", "ADI space portfolio")))
    elif rec.get("qual_tier") == "hi_rel":
        ev.append(("adi-space-portfolio-hirel", rec.get("qual_weight", 7.0),
                   url, rec.get("qual_label", "ADI space portfolio")))
    else:
        ev.append(("adi-space-portfolio-listing", 3.0, url,
                   rec.get("qual_text", "listed in the ADI space portfolio")))
    if s.get("tid_krad") or s.get("sel_mev"):
        ev.append(("radiation-characterized", 4.0, url,
                   f"TID {s.get('tid_krad', '-')} krad, "
                   f"SEL {s.get('sel_mev', '-')} MeV*cm2/mg"))
    put_evidence(pid, ev)
    return pid


def ingest(path, dry_run=False, verbose=False, progress=None, categories=None,
           part=None, cancel=None):
    say = progress or print
    allowed = [c for c in (categories or []) if c]
    files = find_workbooks(path)
    if not files:
        say(f"    no ADI space portfolio workbook found under {path}")
        return {"parts": 0}
    counts = Counter()
    for f in files:
        say(f"    {f.name}")
        merged = parse_workbook(f, verbose=verbose, progress=say)
        say(f"      {len(merged)} generic part(s) from "
            f"{sum(r['rows'] for r in merged.values())} orderable row(s)")
        for pn, rec in merged.items():
            if allowed and rec.get("category") not in allowed:
                counts["filtered_out"] += 1
                continue
            counts["parts"] += 1
            counts[f"tier:{rec.get('qual_tier') or 'listed'}"] += 1
            if rec["specs"].get("tid_krad"):
                counts["with_tid"] += 1
            if rec["specs"].get("sel_mev"):
                counts["with_sel"] += 1
            if verbose:
                say(f"        {pn:<16} {rec.get('category',''):<14} "
                    f"{rec.get('qual_tier') or '-':<10} "
                    f"TID={rec['specs'].get('tid_krad','-')} "
                    f"pkg={rec['specs'].get('package_material','-')}")
            if part:
                part({"vendor": VENDOR, "mpn": pn,
                      "category": rec.get("category", ""), "subcategory": "",
                      "specs": dict(rec["specs"]),
                      "space": ("space_qualified"
                                if rec.get("qual_tier") == "qualified"
                                else ("space_grade" if rec.get("qual_tier")
                                      else "")),
                      "url": rec.get("datasheet_url", ""),
                      "source": f"ADI space portfolio ({f.name})",
                      "datasheet_url": rec.get("datasheet_url", "")})
            if not dry_run:
                _write(rec)
    return dict(counts)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("path", help="the .xlsx, or a folder containing it")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args(argv)
    c = ingest(Path(args.path), args.dry_run, args.verbose)
    print(f"\n=== ADI space portfolio {'(dry run) ' if args.dry_run else ''}===")
    for k in sorted(c):
        print(f"  {k:<22} {c[k]}")


if __name__ == "__main__":
    main()
