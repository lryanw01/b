rfparts — the seven items
=========================
10 files: 1 new, 9 modified. Drop into rfparts/. Run: python -m rfparts.selfcheck


1. EVERYTHINGRF STILL RE-PARSING WITHOUT A RESET
------------------------------------------------
The checkpoint filename is a hash of the source path, so ANY change to the path
STRING -- with no change to the actual folder -- produces a new key and a fresh
parse. On Windows that happens constantly: C:\Users\... and c:\users\... are the
same directory but hash differently, and a folder picker, a typed path and a saved
setting can each give a different case.

_resume_state_path now normalises with os.path.normcase + normpath (lowercases and
canonicalises separators on Windows, no-op on Linux) and lowercases the glob.
Verified: "/tmp/erfsim" + "EverythingRFSpaceQual*", "/tmp/erfsim/" +
"everythingrfspacequal*", and "/tmp/./erfsim" now all resolve to ONE checkpoint.

The resume decision is also printed now, because this was undiagnosable from
outside:
    RESUME STATE | resume=on dry_run=False
    RESUME STATE | parent=C:\...\Sources
    RESUME STATE | glob='EverythingRFSpaceQual'
    RESUME STATE | checkpoint=...\Data\cache\everythingrf_abd217cc.json (exists=True)
    RESUME STATE | source_complete=True completed_files=586 page_count=586
    RESUME STATE | ! checkpoint was written for a DIFFERENT parent: ...
If it still re-parses, that block says why in one line.


2. PARSE INSPECTOR NOW GOES BY VENDOR
-------------------------------------
A Vendor dropdown filters the source list, and sources are grouped by vendor with
counts. CLI:  --list  shows the grouping;  --vendor adi  inspects that group.


3. PARSE INSPECTOR NOW INCLUDES LOCAL FILES
-------------------------------------------
It previously saw only the vendor page cache, so the two sources that produce the
most rows could not be inspected at all. It now also lists everythingRF HTML and
the ADI workbooks, and .xlsx files get a spreadsheet report: which columns were
recognised, which were IGNORED, and every parsed value beside the cell it came
from -- including whether a value came from the sheet or from the description
fallback.

    python -m rfparts.parse_debug --list
    python -m rfparts.parse_debug --vendor adi
    python -m rfparts.parse_debug "Sources/ADIParametrics/...Mixers.xlsx"


4. ADI PARTS WITH NO SPECS
--------------------------
Not a parser bug -- ADI's own export has the literal string 'None' in every
parametric column for about 15% of rows. But the DESCRIPTION still states the
range: "1GHz to 22GHz, 15W, GaN Power Amplifier".

specs_from_description() now recovers frequency, output power (converting W to
dBm), gain and NF from the description, but ONLY where the sheet gave nothing --
a real column value is never overwritten, and the inspector labels which is which.

    parts with no RF spec at all:  158  ->  42
    ADPA1112AEHZ   freq 1-22 GHz, psat 41.8 dBm   (from "1GHz to 22GHz, 15W")
    ADTR1104       freq 8-12 GHz, psat 39.5 dBm
    HMC8191        freq 6-26.5 GHz

The remaining 42 genuinely have neither columns nor a usable description.


5. "CURRENT DATABASE BY VENDOR" IS SCROLLABLE
---------------------------------------------
Canvas + scrollbar, with mouse-wheel scrolling bound only while the pointer is
over the panel so it cannot steal the wheel from the parts table.


6. SPACE CLASSIFICATION BY SOURCE
---------------------------------
Root cause: classify_file() sent EVERY .xlsx to the legacy adi adapter, and that
adapter stamps space_variant on every row -- so the entire ADI parametric
catalogue was being reported as space qualified.

    ADIParametricSearch*.xlsx     -> adi_parametric   (NO space classification)
    adi_space_portfolio*.xlsx     -> adi_space        (qualified / grade)
    other ADI .xlsx               -> adi              (legacy)

adi_parametric_ingest also now refuses to write space, space_variant or erf_grade
at all, so the routing cannot regress silently.

everythingRF was already correct and is unchanged: folder name containing
"spacequal" -> space_qualified, otherwise containing "space" -> space_grade. So
EverythingRFSpaceQual* and EverythingRFSpaceGrade* classify from the folder.

One thing that LOOKS like a leak but is not: nine parametric mixers do carry
space_variant. They are ADH1015S, ADH1048AS, ADH1081S ... -- note the S suffix.
They appear in BOTH files, so they take RF specs from the parametric export and
qualification from the space portfolio. That is the correct merge, and each one
carries both evidence signals to prove it.


7. INSERTION LOSS COUNTS AS NF FOR PASSIVES
-------------------------------------------
For a passive lossy network at ambient, noise figure in dB equals insertion loss
in dB. A filter quoting only insertion loss therefore DOES have a known noise
figure; it just was not labelled one, so "NF below 3 dB" rejected every passive in
the dataset as "NF couldn't be verified".

    partdb.PASSIVE_CATEGORIES   filter, switch, attenuator, coupler, divider,
                                balun, phase_shifter, limiter, isolator,
                                circulator, equalizer, bias_tee, termination,
                                diplexer, transformer
    partdb.effective_nf(category, specs) -> (value, source_key)
    rank.evaluate    an nf_db requirement is satisfied by insertion_loss_db
                     (and conversion_loss_db) on a passive part
    gui              the NF column shows "1.4 (IL)" so the number is never
                     mistaken for a measured NF
    health           the coverage row reads "NF / insertion loss"

Verified: filter with insertion_loss 1.4 -> effective_nf (1.4, insertion_loss_db);
amplifier with insertion_loss 1.0 -> (None, None), correctly NOT treated as NF;
rank now reports nf='met' instead of 'unknown'.


VERIFICATION
------------
    selfcheck                              all checks passed
    resume key across 3 path spellings     one checkpoint
    erf resume run 2                       source_skipped=1
    ADI description fallback               158 -> 42 without RF specs
    routing                                parametric != space portfolio
    space counts                           178 qualified / 1 grade, all from
                                           the portfolio
    passive NF                             met, not unknown

Not exercised here: no Tk, so the scrollable panel and the NF column are verified
by construction and by the value-formatting logic, not by eye.
