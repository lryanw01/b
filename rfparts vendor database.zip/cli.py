"""rfparts command-line interface — LOCAL space-qualified parts finder.

Subcommands:
  search   query the local dataset for a category + criteria, rank, report
  ingest   (re)build the dataset from local catalogs (everythingRF + sheets/PDFs)
  report   re-render the last saved results as markdown
  rfq      draft an RFQ email for a given vendor from the last results
  vendors  list vendors present in the dataset
  gui      launch the desktop GUI

Everything is offline. There is NO web discovery, crawling, or live datasheet
extraction: parts come from partdb, which is populated by the ingest command
(and the GUI's "Rebuild dataset" button) from catalogs already on disk.
"""
import argparse
import json
import re
import sys

from . import rank, registry, rfq, spec, partdb, space_dataset
from .registry import DATA, load_vendors, vendors_for

RESULTS = DATA / "results.json"
DB_CANDIDATE_LIMIT = 20000


def _force_utf8():
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def _norm_vendor(value):
    return re.sub(r"[^a-z0-9]", "", str(value or "").lower())


def _mpn_of(candidate):
    """Best-effort manufacturer part number for a candidate (title fallback)."""
    for tok in re.findall(r"[A-Za-z0-9][A-Za-z0-9._/\-]*\+?", candidate.get("title", "")):
        if any(c.isalpha() for c in tok) and any(c.isdigit() for c in tok) and len(tok) >= 3:
            return tok
    return ""


# --- dataset read -----------------------------------------------------------
def _partdb_candidates(query):
    """Stored parts as ranked-ready candidates."""
    fg = query.get("freq_ghz") or (None, None)
    try:
        cands = partdb.query_candidates(
            category=query.get("category"), f_lo=fg[0], f_hi=fg[1],
            limit=DB_CANDIDATE_LIMIT)
    except Exception:
        return []
    exclude = {_norm_vendor(v) for v in (query.get("exclude_vendors") or [])}
    out = []
    for c in cands:
        c.setdefault("category", query.get("category"))
        if exclude and _norm_vendor(c.get("vendor")) in exclude:
            continue
        out.append(c)
    return out


def db_vendors():
    try:
        return partdb.distinct_vendors()
    except Exception:
        return []


def vendor_choices():
    """Registry + dataset vendor names for the GUI picker (folded by norm)."""
    reg = [v["name"] for v in load_vendors()]
    by_norm = {_norm_vendor(n): n for n in reg}
    out = list(reg)
    for n in db_vendors():
        if not n:
            continue
        key = _norm_vendor(n)
        if key not in by_norm:
            by_norm[key] = n
            out.append(n)
    return sorted(out, key=str.lower)


def _subcategory_filter(cands, query):
    """Drop candidates that clearly belong to a sibling subcategory (kept from
    the original pipeline; trusts the stored subcategory, then free-text)."""
    cat = query.get("category")
    sub = query.get("subcategory")
    if not (cat and sub):
        return cands, 0
    if cat == "divider":
        m = re.match(r"(\d+)\s*way$", sub)
        if m:
            req = int(m.group(1))
            kept, dropped = [], 0
            for c in cands:
                w = rank._ways(c)
                if w and w != req:
                    dropped += 1
                else:
                    kept.append(c)
            return kept, dropped
    own = [t.lower() for t in (query.get("subcategory_terms") or [])
           or registry.subcategory_terms(cat, sub)]
    excl = registry.subcategory_exclusion_terms(cat, sub)
    valid_keys = {k for k, _lbl, _syns in registry.subcategories(cat)}
    kept, dropped = [], 0
    for c in cands:
        cs = c.get("subcategory")
        if cs and cs != sub and cs in valid_keys and sub in valid_keys:
            dropped += 1
            continue
        if not excl:
            kept.append(c)
            continue
        blob = f"{c.get('title', '')} {c.get('description', '')}".lower()
        if any(t in blob for t in own):
            kept.append(c)
            continue
        if cat == "amplifier":
            model = _mpn_of(c) or c.get("title", "")
            if registry.amp_subcat_conflict(sub, model, c.get("specs", {})):
                dropped += 1
                continue
        if any(t in blob for t in excl):
            dropped += 1
        else:
            kept.append(c)
    return kept, dropped


def run_search(query, progress=None, cancel=None, tick=None, on_result=None):
    """Local dataset search: pull stored parts, filter, rank. Returns (ranked,
    errors). `tick`/`on_result` are accepted for GUI compatibility but the local
    query is instant so there's nothing to stream."""
    def emit(m):
        if progress:
            progress(m)

    space_note = " (space-qualified only)" if query.get("space") else ""
    emit(f"searching local dataset for {query.get('category')}{space_note} ...")
    cands = _partdb_candidates(query)
    if not cands:
        emit("no stored parts in that category — run Rebuild dataset / `rfparts ingest`")
        return [], []
    cands, sub_dropped = _subcategory_filter(cands, query)
    if sub_dropped:
        emit(f"filtered {sub_dropped} part(s) in a different {query.get('subcategory')} sibling")
    ranked = rank.rank(cands, query)
    emit(f"done — {len(ranked)} ranked option(s)")
    if on_result:
        for c in ranked:
            on_result(c)
    return ranked, []


def web_fallback(query, ranked, cancel=None):
    """No web fallback in the offline build (kept so callers don't break)."""
    return []


def persist(query, ranked, errors):
    RESULTS.write_text(
        json.dumps({"spec": query, "results": ranked, "errors": errors}, indent=1),
        encoding="utf-8")
    md = rank.markdown(ranked, query, errors)
    (DATA / "results.md").write_text(md, encoding="utf-8")
    return md


# --- commands ---------------------------------------------------------------
def cmd_search(args):
    query = spec.build(args)
    if not query.get("category"):
        print("error: category is required for search", file=sys.stderr)
        return 2
    query["local_only"] = True
    ranked, errors = run_search(query, progress=lambda m: print(m, file=sys.stderr))
    persist(query, ranked, errors)
    print(rank.markdown(ranked[: args.top], query, errors if args.show_errors else None))
    print(f"\nfull report: {DATA / 'results.md'}  ({len(ranked)} ranked)", file=sys.stderr)
    return 0


def _resolve_vendors(arg):
    """--vendors all | qorvo marki | (absent) -> []"""
    if not arg:
        return []
    if len(arg) == 1 and arg[0].lower() in ("all", "*"):
        return list(space_dataset.CATALOG_VENDORS)
    out, bad = [], []
    for v in arg:
        v = v.lower()
        if v in space_dataset.CATALOG_VENDORS:
            out.append(v)
        else:
            bad.append(v)
    if bad:
        print(f"unknown vendor(s): {', '.join(bad)}; known: "
              f"{', '.join(space_dataset.CATALOG_VENDORS)}", file=sys.stderr)
    return out


def cmd_ingest(args):
    files = args.file or []
    vendors = _resolve_vendors(args.vendors)
    if not (files or args.dir or args.erf or vendors):
        print("nothing to ingest: pass catalog files, --dir, --erf and/or "
              "--vendors", file=sys.stderr)
        return 2
    limits = {}
    if args.qorvo_ids:
        limits["qorvo_ids"] = args.qorvo_ids
    if args.max_products:
        limits["skyworks_products"] = args.max_products
        limits["marki_products"] = args.max_products
    if args.marki_forms:
        limits["marki_forms"] = args.marki_forms
    summary = space_dataset.rebuild(
        erf_parent=args.erf, source_files=files, source_dir=args.dir,
        dedupe=not args.no_dedupe, progress=lambda m: print(m, file=sys.stderr),
        vendors=vendors, vendor_rate=args.rate, vendor_limits=limits,
        download_datasheets=not args.no_datasheets,
        download_limit=args.download_limit, adi_dir=args.adi_dir,
        use_cache=not args.no_cache)
    if summary["errors"]:
        print("\nwarnings:", file=sys.stderr)
        for e in summary["errors"]:
            print(f"  - {e}", file=sys.stderr)
    s = summary["stats"]
    print(f"dataset: {s['parts']} parts | {s['qualified']} qualified | "
          f"{s['grade']} grade | {s['vendors']} vendors")
    return 0


def _load_results():
    if not RESULTS.exists():
        print("no saved results — run `rfparts search` first", file=sys.stderr)
        return None
    return json.loads(RESULTS.read_text(encoding="utf-8"))


def cmd_report(args):
    data = _load_results()
    if not data:
        return 1
    results = data["results"][: args.top] if args.top else data["results"]
    print(rank.markdown(results, data["spec"], data.get("errors")))
    return 0


def cmd_rfq(args):
    data = _load_results()
    if not data:
        return 1
    vendors = {v["name"]: v for v in load_vendors()}
    vendor = vendors.get(args.vendor) or {"name": args.vendor, "url": "", "rfq_email": ""}
    parts = [c for c in data["results"] if c.get("vendor") == vendor["name"]][: args.parts]
    to, subject, body = rfq.draft(vendor, parts, data["spec"])
    print(f"To: {to}\nSubject: {subject}\n\n{body}")
    return 0


def cmd_vendors(args):
    for name in vendor_choices():
        print(name)
    return 0


def _resolve_part(mpn):
    """Find a part id by exact, case-insensitive, then loose MPN match."""
    conn = partdb.db()
    row = conn.execute("SELECT id FROM parts WHERE mpn=?", (mpn,)).fetchone()
    if row:
        return row["id"]
    row = conn.execute("SELECT id FROM parts WHERE UPPER(mpn)=UPPER(?)", (mpn,)).fetchone()
    if row:
        return row["id"]
    target = partdb._loose_key(mpn)
    for r in conn.execute("SELECT id, mpn FROM parts"):
        if partdb._loose_key(r["mpn"]) == target:
            return r["id"]
    return None


def cmd_family(args):
    pid = _resolve_part(args.mpn)
    if pid is None:
        print(f"no part matching '{args.mpn}' in the dataset", file=sys.stderr)
        return 1
    members = partdb.family_members(pid, include_self=True)
    if len(members) <= 1:
        print(f"{args.mpn}: no pedigree variants found "
              f"(base '{partdb.family_key(args.mpn)}')")
        return 0
    print(f"Family '{partdb.family_key(args.mpn)}' — {len(members)} variant(s), "
          f"strongest pedigree first:\n")
    for m in members:
        star = " *" if m["is_self"] else "  "
        print(f"{star} {m['mpn']:<20} {m['pedigree_label']:<16} {m['vendor']:<22} "
              f"{m['url'] or ''}")
    return 0


def cmd_health(args):
    h = partdb.dataset_health()
    print(f"Dataset health\n{'=' * 52}")
    print(f"  parts: {h['parts']}    vendors: {h['vendors']}    "
          f"duplicate groups remaining: {h['duplicate_groups']}")
    print(f"\n  Pedigree distribution (informational, not scored):")
    for k in partdb.pedigree.LADDER:
        n = h["pedigree"].get(k, 0)
        pct = (100.0 * n / h["parts"]) if h["parts"] else 0.0
        print(f"    {h['pedigree_labels'][k]:<16} {n:>5}  {pct:4.1f}%")
    print(f"\n  Categories:")
    for cat, n in h["by_category"][: args.top]:
        print(f"    {cat:<20} {n:>5}")
    print(f"\n  Spec coverage by category  (% of parts in that category "
          f"carrying a value):")
    shown = {c for c, _n in h["by_category"][: args.top]}
    for cc in h["category_coverage"]:
        if cc["category"] not in shown:
            continue
        print(f"    {cc['category']} ({cc['count']})")
        for lbl, n, pct in cc["specs"]:
            bar = "#" * int(pct / 5)
            print(f"      {lbl:<16} {n:>5}  {pct:5.1f}%  {bar}")
    print(f"\n  Radiation data (TID/SEL): {h['radiation_parts']} parts "
          f"({h['radiation_pct']}%)")
    f = h["families"]
    print(f"\n  Families: {f['families']} base parts with variants "
          f"({f['parts_in_families']} parts); "
          f"{f['multi_pedigree_families']} span >1 pedigree level")
    return 0


def cmd_gui(args):
    try:
        from . import gui
    except Exception as e:
        print(f"could not start GUI: {e}", file=sys.stderr)
        print("This Python may lack tkinter. Use the CLI, or enable tkinter.",
              file=sys.stderr)
        return 1
    return gui.main()


def build_parser():
    p = argparse.ArgumentParser(prog="rfparts",
                                description="Local space-qualified parts finder")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("search", help="search the local dataset and rank options")
    s.add_argument("category", help="canonical category, e.g. amplifier, filter, data_converter")
    s.add_argument("--freq", help="passband in GHz, e.g. '4-8' or 'DC-18'")
    s.add_argument("--gain-db-min", dest="gain_db_min", type=float)
    s.add_argument("--noise-k-max", dest="noise_k_max", type=float)
    s.add_argument("--attenuation-db", dest="attenuation_db", type=float)
    s.add_argument("--impedance")
    s.add_argument("--ports", type=int)
    s.add_argument("--connector")
    s.add_argument("--package", help="connectorized, smt, die, flange")
    s.add_argument("--space", action="store_true",
                   help="require space qualification (space-qualified/grade only)")
    s.add_argument("--exclude", nargs="+", help="vendor names to skip")
    s.add_argument("--prefer", nargs="+", help="vendor names to try first")
    s.add_argument("--other", nargs="+")
    s.add_argument("--top", type=int, default=15)
    s.add_argument("--show-errors", action="store_true")
    s.set_defaults(func=cmd_search)

    i = sub.add_parser("ingest",
                       help="(re)build the dataset from local catalogs and/or "
                            "live vendor catalogues")
    i.add_argument("file", nargs="*", help="catalog files (.xlsx/.pdf) to ingest")
    i.add_argument("--erf", help="parent folder of the EverythingRFSpace* subfolders")
    i.add_argument("--dir", help="folder to scan for catalog files")
    i.add_argument("--no-dedupe", action="store_true", help="skip the dedupe pass")
    i.add_argument("--vendors", nargs="*", metavar="V",
                   help="vendor catalogues to walk: "
                        + " ".join(space_dataset.CATALOG_VENDORS)
                        + ", or 'all'")
    i.add_argument("--rate", type=float, default=1.0,
                   help="seconds between requests to the same host (default 1)")
    i.add_argument("--qorvo-ids", type=int, default=0,
                   help="how many Qorvo categoryIDs to probe (0 = the full range)")
    i.add_argument("--max-products", type=int, default=0,
                   help="cap per-part page visits for Skyworks/Marki")
    i.add_argument("--marki-forms", nargs="*",
                   help="connectorized surface-mount bare-die waveguide")
    i.add_argument("--adi-dir",
                   help="folder of ADIParametricSearch*.xlsx (ADI is not scraped)")
    i.add_argument("--no-datasheets", action="store_true",
                   help="record datasheet URLs but do not download the files")
    i.add_argument("--download-limit", type=int, default=0,
                   help="max datasheet files to download this run")
    i.add_argument("--no-cache", action="store_true",
                   help="ignore the on-disk page cache")
    i.set_defaults(func=cmd_ingest)

    r = sub.add_parser("report", help="re-render last saved results")
    r.add_argument("--top", type=int, default=0)
    r.set_defaults(func=cmd_report)

    q = sub.add_parser("rfq", help="draft an RFQ email for a vendor")
    q.add_argument("vendor")
    q.add_argument("--parts", type=int, default=5)
    q.set_defaults(func=cmd_rfq)

    v = sub.add_parser("vendors", help="list vendors in the dataset")
    v.set_defaults(func=cmd_vendors)

    fam = sub.add_parser("family", help="show a part's pedigree variants (base-PN family)")
    fam.add_argument("mpn", help="a manufacturer part number in the dataset")
    fam.set_defaults(func=cmd_family)

    hz = sub.add_parser("health", help="dataset coverage / pedigree / family report")
    hz.add_argument("--top", type=int, default=15, help="how many categories to list")
    hz.set_defaults(func=cmd_health)

    g = sub.add_parser("gui", help="launch the desktop GUI")
    g.set_defaults(func=cmd_gui)
    return p


def main(argv=None):
    _force_utf8()
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
