rfparts -- vendor catalogue database build
==========================================
Six files: 2 new, 4 modified. Drop them into rfparts/ over the existing ones.

  NEW       vendor_catalogs.py         walks Qorvo, MACOM, Skyworks, Marki;
                                       downloads datasheets; writes partdb rows
  NEW       adi_parametric_ingest.py   ADI parametric .xlsx -> partdb
  MODIFIED  registry.py                +11 categories the vendor catalogues use
  MODIFIED  space_dataset.py           rebuild() gains vendor selection
  MODIFIED  cli.py                     ingest --vendors ...
  MODIFIED  gui.py                     vendor checkboxes in Rebuild dataset

QUICK START
  GUI :  Rebuild dataset...  ->  tick vendors  ->  Rebuild
  CLI :  python -m rfparts.cli ingest --vendors adi --adi-dir "C:\...\ADIParametrics"
         python -m rfparts.cli ingest --vendors all --rate 1.0 --max-products 200
         python -m rfparts.cli ingest --vendors qorvo marki --qorvo-ids 60
         python -m rfparts.cli health

HOW EACH VENDOR IS REACHED (established by probing the live sites)
  ADI       NOT scraped. analog.com returns HTTP 403 to scripts on every
            datasheet URL and on the product-category pages. Your parametric
            exports carry more than a crawl would: 1044 parts, 878 with a
            frequency range, plus NF / gain / OIP3 / P1dB / price / lifecycle.
            Point --adi-dir at the folder of ADIParametricSearch*.xlsx.
            Part numbers are =HYPERLINK() formulas, so the workbook is read with
            data_only=False -- with data_only=True that column reads as empty.
  QORVO     product-list?categoryID=caNNNN renders PARAMETRIC TABLES, and each
            row carries the part number, the opaque datasheet id and the family's
            spec columns. So frequency/gain/NF/OIP3 come free with enumeration.
            The /products/<family>/<sub> pages are marketing pages with no table.
  MACOM     Parts live at /products/product-detail/<PN>. Other last path
            segments are filter facets (200_V, SWITCHES-SP3T) and are rejected.
            Datasheets: cdn.macom.com/datasheets/<PN>.pdf
  SKYWORKS  /en/Products -> categories -> /en/Products/<Category>/<PN>. The
            datasheet document number is opaque (SKY58281-11_205951B_PS.pdf), so
            each product page is opened to find its PDF, preferring a filename
            that names the part and never a catalogue.
  MARKI     /products/<form>/<category>/?page=N -- PAGED, so every page is
            walked until one yields nothing new. Their per-part PDFs are Chrome
            print renderings (producer=Skia/PDF, no text layer, unreadable), so
            the /datasheet/ PAGE is the source; its pipe-separated spec tables
            are parsed header-first, which is what gets gain 15.1 dB rather than
            the max-frequency column.

POLITENESS
  One rate limit per host, robots.txt per host WITH a timeout (urllib's parser
  has none and will hang forever on a host that goes quiet), every page cached on
  disk so a re-run costs nothing, and downloads rotate between vendors so no one
  host sees a burst. A host whose robots.txt cannot be read is skipped, not
  crawled anyway.

WHAT IS NOT TESTED
  Live fetching could not be exercised where this was built (no outbound
  network). Every parser was verified against real captured HTML and your real
  spreadsheets; the walkers were driven end to end against a simulated network.
  Start with --qorvo-ids 20 --max-products 50 and read the terminal output before
  a full run.
