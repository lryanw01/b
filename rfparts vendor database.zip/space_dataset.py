"""Build/refresh the space-qualified parts dataset from LOCAL catalogs.

One place that knows how to turn the catalogs on disk into partdb rows, then
dedupe. Everything is offline: it only reads files you already downloaded.

Sources understood:
  * everythingRF saved listing folders  -> erf_space_ingest  (EverythingRFSpace*)
  * ADI space portfolio .xlsx            -> adi_ingest
  * Qorvo defense/aerospace .pdf         -> qorvo_ingest
  * TI Space Products Guide .pdf         -> ti_ingest

Adding another catalog later = drop a new ``*_ingest`` module with an
``ingest(path, dry_run, verbose)`` and add one line to ``_ADAPTERS``.

Public API (used by the GUI "Rebuild dataset" button and the CLI `ingest`):
    rebuild(erf_parent=None, source_files=(), source_dir=None,
            dedupe=True, progress=None) -> summary dict
    scan_dir(folder) -> list[(path, kind)]
"""
from __future__ import annotations

import traceback
from pathlib import Path

try:
    from . import (adi_ingest, qorvo_ingest, ti_ingest, erf_space_ingest,
                   partdb, vendor_catalogs)
except ImportError:                                    # loose-script fallback
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from rfparts import (adi_ingest, qorvo_ingest, ti_ingest,   # type: ignore
                         erf_space_ingest, partdb, vendor_catalogs)

# Vendors whose live catalogues can be walked (see vendor_catalogs). Selectable
# so a refresh can target one vendor instead of re-walking everything.
CATALOG_VENDORS = vendor_catalogs.ALL_VENDORS

# kind -> (module, human label)
_ADAPTERS = {
    "adi": (adi_ingest, "ADI space portfolio"),
    "qorvo": (qorvo_ingest, "Qorvo defense/aerospace brochure"),
    "ti": (ti_ingest, "TI Space Products Guide"),
}


def classify_file(path: Path) -> str | None:
    """Best-effort adapter kind for a file, from its name/extension."""
    name = path.name.lower()
    ext = path.suffix.lower()
    if ext in (".xlsx", ".xlsm", ".csv") and "adi" in name:
        return "adi"
    if ext in (".xlsx", ".xlsm", ".csv"):
        return "adi"          # only ADI ships an xlsx today
    if ext == ".pdf" and "qorvo" in name:
        return "qorvo"
    if ext == ".pdf" and ("slyt" in name or name.startswith("ti") or "space-products" in name
                          or "space_products" in name):
        return "ti"
    if ext == ".pdf":
        return None           # unknown PDF -> let the caller decide
    return None


def scan_dir(folder) -> list[tuple[Path, str | None]]:
    """Every ingestable file under `folder` (one level), with its guessed kind."""
    folder = Path(folder)
    out = []
    if not folder.is_dir():
        return out
    for p in sorted(folder.iterdir()):
        if p.is_file() and p.suffix.lower() in (".pdf", ".xlsx", ".xlsm", ".csv"):
            out.append((p, classify_file(p)))
    return out


def _run(kind, path, progress) -> dict:
    module, label = _ADAPTERS[kind]
    progress(f"ingesting {label}: {Path(path).name} ...")
    counts = module.ingest(Path(path), dry_run=False, verbose=False)
    progress(f"  {label}: {counts.get('parts', 0)} parts "
             f"({counts.get('space_qualified', 0)} qualified, "
             f"{counts.get('space_grade', 0)} grade)")
    return counts


def rebuild(erf_parent=None, source_files=(), source_dir=None,
            erf_glob="EverythingRFSpace*", dedupe=True, progress=None,
            vendors=None, vendor_rate=1.0, vendor_limits=None,
            download_datasheets=True, download_limit=0, adi_dir=None,
            use_cache=True) -> dict:
    """Ingest everything selected into partdb, then dedupe.

    Local sources (unchanged):
      erf_parent   folder holding the EverythingRFSpace* listing subfolders
      source_files explicit catalog files (kind auto-detected by name)
      source_dir   a folder to scan for catalog files
      dedupe       run partdb.merge_duplicates() at the end (richest specs win)

    Live vendor catalogues (new):
      vendors      subset of CATALOG_VENDORS to walk, e.g. ['qorvo','marki'].
                   None or [] walks none, so existing callers behave as before.
      vendor_rate  seconds between requests to the SAME host
      vendor_limits e.g. {'qorvo_ids': 40, 'marki_products': 200}
      adi_dir      folder of ADIParametricSearch*.xlsx (ADI is never scraped)
      use_cache    reuse pages already downloaded into partdb.DATA/vendor_cache
    """
    def emit(m):
        if progress:
            progress(m)

    summary = {"sources": [], "errors": [], "parts_ingested": 0}

    files: list[tuple[Path, str | None]] = [(Path(f), classify_file(Path(f)))
                                            for f in source_files]
    if source_dir:
        files += scan_dir(source_dir)

    # everythingRF first (it carries the real manufacturer part numbers that
    # ADI/TI/Qorvo rows later dedupe against).
    if erf_parent:
        try:
            emit(f"ingesting everythingRF space folders under {erf_parent} ...")
            c = erf_space_ingest.ingest(Path(erf_parent), erf_glob,
                                        dry_run=False, verbose=False)
            n = c.get("parts", 0)
            summary["parts_ingested"] += n
            summary["sources"].append(("everythingRF", n, c))
            emit(f"  everythingRF: {n} parts "
                 f"({c.get('space_qualified', 0)} qualified, "
                 f"{c.get('space_grade', 0)} grade)")
        except Exception as e:                          # keep going on one bad source
            summary["errors"].append(f"everythingRF: {e}")
            emit(f"  everythingRF FAILED: {e}")
            traceback.print_exc()

    for path, kind in files:
        if kind not in _ADAPTERS:
            summary["errors"].append(f"unrecognized source: {path.name}")
            emit(f"  skipped (unrecognized): {path.name}")
            continue
        try:
            c = _run(kind, path, emit)
            summary["parts_ingested"] += c.get("parts", 0)
            summary["sources"].append((kind, c.get("parts", 0), c))
        except Exception as e:
            summary["errors"].append(f"{path.name}: {e}")
            emit(f"  {path.name} FAILED: {e}")
            traceback.print_exc()

    # --- live vendor catalogues -------------------------------------------
    if vendors:
        emit("")
        try:
            vsum = vendor_catalogs.ingest(
                vendors=vendors, rate=vendor_rate, progress=emit,
                limits=vendor_limits, download=download_datasheets,
                download_limit=download_limit, adi_dir=adi_dir,
                use_cache=use_cache)
            summary["vendors"] = vsum
            for v, info in vsum.get("per_vendor", {}).items():
                n = info.get("parts", 0)
                summary["parts_ingested"] += n
                summary["sources"].append((f"vendor:{v}", n, info))
            summary["errors"].extend(vsum.get("errors", []))
        except Exception as e:
            summary["errors"].append(f"vendor catalogs: {e}")
            emit(f"  vendor catalogs FAILED: {e}")
            traceback.print_exc()

    if dedupe:
        emit("de-duplicating (keeping the richest copy of each part) ...")
        d = partdb.merge_duplicates(progress=None)
        summary["dedupe"] = d
        emit(f"  merged {d['groups']} duplicate group(s), removed {d['deleted']} row(s)")

    summary["stats"] = partdb.dataset_stats()
    s = summary["stats"]
    emit(f"dataset now: {s['parts']} parts, {s['qualified']} space-qualified, "
         f"{s['grade']} space-grade, {s['vendors']} vendors")
    return summary
