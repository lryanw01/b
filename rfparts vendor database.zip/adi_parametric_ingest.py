"""Ingest ADI parametric-search exports (.xlsx) into partdb.

Analog Devices refuses scripted access to analog.com (every datasheet URL returns
HTTP 403, and the product-category pages 403 as well), so there is no polite way
to crawl them. There is no need to: their parametric search exports exactly the
table we want, and one export per product family covers the whole RF catalogue.

    Downloads/ADIParametrics/
        ADIParametricSearchAmplifiers.xlsx
        ADIParametricSearchLNA+PA.xlsx
        ADIParametricSearchMixers.xlsx
        ... etc

WORKBOOK SHAPE (verified against the real exports)
    sheet 'Cover'            row 1  Product Type -> the category
    sheet 'Web Display'      row 1  column headers
                             row 2  units row  (Hz, dB, dBm, dBc/Hz ...)
                             row 3+ one part per row
    Part Number is an Excel formula, NOT a plain value:
        =HYPERLINK("https://www.analog.com/en/ADL6346B#details", "ADL6346B")
    so the workbook must be read with data_only=False and the formula parsed --
    with data_only=True that column comes back empty and every row looks blank.
    The formula conveniently carries the product URL as well as the part number.

Frequencies are in Hz in these exports (1500000000), so they are scaled to GHz.

Run standalone:
    python -m rfparts.adi_parametric_ingest "C:\\path\\ADIParametrics" --dry-run
"""
from __future__ import annotations

import argparse
import re
from collections import Counter
from pathlib import Path

try:
    from .partdb import SpecRow, upsert_part, put_specs, put_evidence
except ImportError:                                     # loose-script fallback
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from rfparts.partdb import (                          # type: ignore
        SpecRow, upsert_part, put_specs, put_evidence)

VENDOR = "Analog Devices"
DATASHEET_TPL = ("https://www.analog.com/media/en/technical-documentation/"
                 "data-sheets/{pn}.pdf")

# 'Product Type' from the Cover sheet -> canonical pipeline category.
_PRODUCT_TYPE_CAT = [
    ("low-noise amplifier", "amplifier"), ("power amplifier", "amplifier"),
    ("rf amplifier", "amplifier"), ("amplifier", "amplifier"),
    ("attenuator", "attenuator"),
    ("beamformer", "beamformer"), ("vector modulator", "beamformer"),
    ("mixer", "mixer"),
    ("modulator", "modulator"), ("demodulator", "modulator"),
    ("phase shifter", "phase_shifter"),
    ("switch", "switch"),
    ("tunable filter", "filter"), ("filter", "filter"),
    ("detector", "detector"),
    ("synthesizer", "synthesizer"), ("pll", "synthesizer"),
]

# Per-row 'type' column (e.g. 'RF Amp Type') that refines the category.
_ROW_TYPE_SUB = [
    ("low noise", ("amplifier", "lna")), ("lna", ("amplifier", "lna")),
    ("power amplifier", ("amplifier", "pa")),
    ("gain block", ("amplifier", "buffer")),
    ("driver", ("amplifier", "driver")),
    ("variable gain", ("amplifier", "vga")),
    ("distributed", ("amplifier", "")),
]

# Column header (lowercased, fuzzy) -> (partdb spec key, unit, how to read).
# 'range' means the header names a min/max pair handled separately.
_COL_SPECS = [
    (r"frequency response min|freq(uency)? min|min frequency", "freq_min", "GHz"),
    (r"frequency response max|freq(uency)? max|max frequency", "freq_max", "GHz"),
    (r"noise figure", "nf_db", "dB"),
    (r"^oip3|oip3 typ", "oip3_dbm", "dBm"),
    (r"op1db|p1db|output p1db", "p1db_dbm", "dBm"),
    (r"^gain( typ)?$|gain typ|small signal gain", "gain_db", "dB"),
    (r"isolation", "isolation_db", "dB"),
    (r"insertion loss", "insertion_loss_db", "dB"),
    (r"conversion loss|conversion gain", "conversion_loss_db", "dB"),
    (r"attenuation range|attenuation", "attenuation_db", "dB"),
    (r"output power|psat|pout", "psat_dbm", "dBm"),
    (r"1ku list price|price", "price_usd", "USD"),
]
_HYPERLINK = re.compile(r'HYPERLINK\(\s*"([^"]+)"\s*,\s*"([^"]+)"\s*\)', re.I)
_TEMP = re.compile(r"(-?\d+)\s*(?:to|\.\.|–|-)\s*\+?(-?\d+)\s*°?\s*C", re.I)


def _num(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    m = re.search(r"-?\d+(?:\.\d+)?", str(v).replace(",", ""))
    return float(m.group(0)) if m else None


def _category_for(product_type):
    low = (product_type or "").lower()
    for needle, cat in _PRODUCT_TYPE_CAT:
        if needle in low:
            return cat
    return "ic"


def _refine(category, row_type):
    low = (row_type or "").lower()
    for needle, (cat, sub) in _ROW_TYPE_SUB:
        if needle in low:
            return cat, sub
    return category, ""


def _hz_to_ghz(v):
    """These exports give frequency in Hz (1500000000 = 1.5 GHz)."""
    n = _num(v)
    if n is None:
        return None
    if n > 1e6:                     # Hz
        return n / 1e9
    if n > 1e3:                     # MHz, just in case
        return n / 1e3
    return n                        # already GHz


def parse_workbook(path, verbose=False):
    """Yield one dict per part row."""
    import openpyxl
    path = Path(path)
    # data_only=False is essential: the part number is a HYPERLINK formula.
    wb = openpyxl.load_workbook(str(path), read_only=True, data_only=False)

    product_type = ""
    if "Cover" in wb.sheetnames:
        for row in wb["Cover"].iter_rows(max_row=12, values_only=True):
            cells = [str(c) for c in row if c is not None]
            if len(cells) >= 2 and "product type" in cells[0].lower():
                product_type = cells[1]
                break
    sheet = ("Web Display" if "Web Display" in wb.sheetnames
             else wb.sheetnames[-1])
    ws = wb[sheet]
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    if not rows:
        return
    headers = [str(h or "").strip() for h in rows[0]]
    # row index 1 is usually the units row; detect it rather than assume
    body_from = 1
    if len(rows) > 1:
        second = [str(c or "") for c in rows[1]]
        if sum(1 for c in second if c and len(c) <= 12) >= 3 and \
                not any(_HYPERLINK.search(c) for c in second):
            body_from = 2
    category = _category_for(product_type)
    if verbose:
        print(f"      product type '{product_type}' -> category '{category}'; "
              f"{len(headers)} column(s), data starts at row {body_from + 1}")

    # map columns
    col_map, type_col = {}, None
    for i, h in enumerate(headers):
        hl = h.lower()
        if "type" in hl and i > 0 and not col_map.get(i):
            type_col = type_col if type_col is not None else i
        for pat, key, unit in _COL_SPECS:
            if re.search(pat, hl):
                col_map[i] = (key, unit)
                break
        if "temperature" in hl:
            col_map[i] = ("temp_range", "C")
        elif "lifecycle" in hl:
            col_map[i] = ("lifecycle", "")
        elif hl.startswith("description"):
            col_map[i] = ("description", "")

    for r in rows[body_from:]:
        if not r:
            continue
        cell0 = str(r[0]) if r[0] is not None else ""
        m = _HYPERLINK.search(cell0)
        if m:
            product_url, pn = m.group(1), m.group(2).strip()
        else:
            pn, product_url = cell0.strip(), ""
        if not pn or len(pn) < 3:
            continue
        rec = {"mpn": pn, "product_url": product_url, "category": category,
               "subcategory": "", "description": "", "specs": {},
               "source_family": product_type}
        row_type = (str(r[type_col]) if type_col is not None
                    and type_col < len(r) and r[type_col] is not None else "")
        rec["category"], rec["subcategory"] = _refine(category, row_type)
        for i, (key, unit) in col_map.items():
            if i >= len(r) or r[i] is None:
                continue
            val = r[i]
            if key == "description":
                rec["description"] = str(val)[:200]
            elif key == "temp_range":
                tm = _TEMP.search(str(val))
                if tm:
                    rec["specs"]["temp_min_c"] = (float(tm.group(1)), "C")
                    rec["specs"]["temp_max_c"] = (float(tm.group(2)), "C")
            elif key == "lifecycle":
                rec["specs"]["lifecycle"] = (str(val)[:60], "")
            elif key in ("freq_min", "freq_max"):
                g = _hz_to_ghz(val)
                if g is not None:
                    rec["specs"][key] = (g, "GHz")
            else:
                n = _num(val)
                if n is not None:
                    rec["specs"][key] = (n, unit)
        yield rec


def _write(rec):
    pn = rec["mpn"]
    ds = DATASHEET_TPL.format(pn=pn.lower())
    pid = upsert_part(mpn=pn, vendor=VENDOR, category=rec["category"],
                      subcategory=rec.get("subcategory", ""),
                      product_url=rec.get("product_url") or ds,
                      description=rec.get("description", "")[:200])
    rows = []
    s = rec["specs"]
    lo, hi = s.get("freq_min"), s.get("freq_max")
    if lo or hi:
        a = (lo or hi)[0]
        b = (hi or lo)[0]
        rows.append(SpecRow(key="freq_ghz", value_min=min(a, b),
                            value_max=max(a, b), unit="GHz", method="catalog",
                            confidence=0.9, source_url=rec.get("product_url", ""),
                            snippet="ADI parametric export"))
    for key, (val, unit) in s.items():
        if key in ("freq_min", "freq_max"):
            continue
        if isinstance(val, str):
            rows.append(SpecRow(key=key, value_text=val, unit=unit,
                                method="catalog", confidence=0.9,
                                source_url=rec.get("product_url", "")))
        else:
            rows.append(SpecRow(key=key, value_typ=val, unit=unit,
                                method="catalog", confidence=0.9,
                                source_url=rec.get("product_url", "")))
    rows.append(SpecRow(key="datasheet_url", value_text=ds, method="catalog",
                        confidence=0.9, source_url=rec.get("product_url", "")))
    put_specs(pid, rows)
    put_evidence(pid, [("adi-parametric-export", 3.0,
                        rec.get("product_url", ""),
                        f"ADI {rec.get('source_family', '')} parametric export")])
    return pid


def ingest(path, dry_run=False, verbose=False, progress=None):
    """`path` may be one .xlsx or a folder of them."""
    def emit(m):
        (progress or print)(m)

    path = Path(path)
    files = ([path] if path.is_file()
             else sorted(p for p in path.glob("*.xlsx")
                         if not p.name.startswith("~$")))
    if not files:
        raise SystemExit(f"no .xlsx found at {path}")
    counts = Counter()
    seen = set()
    for f in files:
        emit(f"    {f.name}")
        n = 0
        for rec in parse_workbook(f, verbose=verbose):
            key = rec["mpn"].upper()
            if key in seen:
                counts["duplicate_rows"] += 1
                continue
            seen.add(key)
            n += 1
            counts["parts"] += 1
            counts[f"cat:{rec['category']}"] += 1
            if verbose:
                sp = ", ".join(f"{k}={v[0]}" for k, v in
                               list(rec["specs"].items())[:4])
                emit(f"        {rec['mpn']:<18} {rec['category']:<12} {sp}")
            if not dry_run:
                _write(rec)
        emit(f"      -> {n} part(s)")
    return dict(counts)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("path", help="an ADI parametric .xlsx, or a folder of them")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args(argv)
    c = ingest(Path(args.path), args.dry_run, args.verbose)
    print(f"\n=== ADI parametric ingest {'(dry run) ' if args.dry_run else ''}===")
    print(f"  parts           {c.get('parts', 0)}")
    print(f"  duplicate rows  {c.get('duplicate_rows', 0)}")
    for k, v in sorted(c.items()):
        if k.startswith("cat:"):
            print(f"    {k[4:]:<14} {v}")


if __name__ == "__main__":
    main()
