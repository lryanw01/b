rfparts — ADI space portfolio: classification and category fixes
===============================================================
3 files, all modified. Drop into rfparts/.  Run: python -m rfparts.selfcheck

Both things you reported were real, and they had different causes.


1. PARTS ON THE PORTFOLIO NOT MARKED SPACE QUALIFIED
----------------------------------------------------
FIVE of the fourteen distinct "Space Qualification Level" values in your file
matched none of my patterns, so 95 orderable rows were stored with NO space
classification at all despite being in the portfolio:

    24 + 6  MIL-PRF-38535 Class Level S (and "with Exceptions")
    42      Commercial Space Low (CSL)
    11      Commercial Space High (CSH)
    10      MIL-PRF-38535 Class Level B
     2      NASA/EEE-INST-002

Class Level S was the bad one. My pattern was `class\s*v`, which cannot match
"Class Level S" -- and QML Class S is the HIGHEST space level, not a lesser one.
Now handled, along with:
    Class S / QML-S            -> space_qualified (weight 10)
    NASA/EEE-INST-002          -> space_qualified (9.5)
    Commercial Space High/Low  -> space_grade (6.0 / 5.0)  ADI's own space grades
    Class Level B              -> space_grade (4.0)  military, not space
    n/a - Engineering Model    -> still unclassified, correctly

Result on your file: every one of the 233 generic parts is now classified.
    before   178 qualified,  1 grade   (54 parts unclassified)
    after    200 qualified, 33 grade   (0 unclassified)


2. "AMPLIFIERS" WITH NO GAIN / NF / P1dB / OIP3
-----------------------------------------------
Two separate things here, and neither is a parse failure.

(a) THE PORTFOLIO HAS NO SUCH COLUMNS. Not one of its 233 parts carries gain, NF,
    OIP3 or P1dB, because the file does not contain those columns -- it holds
    qualification level, TID, SEL, temperature, package, package material, lead
    finish and a datasheet URL. There is nothing there to extract.

(b) MOST OF THOSE "AMPLIFIERS" ARE NOT RF AMPLIFIERS. Of the 102 parts we filed as
    RF `amplifier`, ADI's own Category column says:

        57  PRECISION AMPLIFIERS     <- op-amps
        39  RF AMPLIFIERS
         6  RF DETECTORS

    My category map listed ("amplifier", "amplifier") before the specific entries,
    and "PRECISION AMPLIFIERS" contains "amplifier" -- so 57 precision op-amps
    were filed as RF amplifiers, and the coverage report then demanded RF gain,
    noise figure, OIP3 and P1dB from parts that can never have any of them. That
    is what you were looking at.

    Fixed by ordering the map specific-first and adding a real category:
        PRECISION / OPERATIONAL / INSTRUMENTATION AMPLIFIERS -> op_amp
        RF DETECTORS                                         -> detector
        BEAMFORMERS / VECTOR MODULATORS                      -> beamformer
    `op_amp` is registered in registry.py ("Op-amps / precision amplifiers") and
    given an explicitly NON-RF coverage list in partdb, so it is never asked for
    RF specs again.

    After: 57 op_amp, 39 amplifier, 6 detector.

(c) THE 39 GENUINE RF AMPLIFIERS DO GET THEIR SPECS -- from the merge. 76 of the
    233 portfolio parts appear in the ADI parametric exports under the same part
    number, so ingesting both sources gives the space part its RF parametrics and
    its qualification. Measured: 33 of the 39 RF amplifiers now carry
    gain/NF/OIP3/P1dB.

    The remaining 6: five (ADH311S, ADH499S, ADL8141, ADL8142-2, HMC8413) are not
    in the parametric exports at all, so there is no source for their RF specs.
    The sixth, ADH-APH634S, IS in the exports but with only frequency and package
    -- its parametric row is one of the empty ones. Its description gives
    "81 GHz to 86 GHz, Medium Power Amplifier", which the description fallback
    already picks up as a frequency range.

    So after this patch there is no remaining ADI gap that a parser change can
    close: what is missing is missing from ADI's own files.


RE-INGEST NEEDED
----------------
Both fixes change how rows are written, so existing rows keep their old category
and classification until re-ingested:

    python -m rfparts.cli ingest --vendors adi --adi-dir "<your ADIParametrics>"
    python -m rfparts.cli ingest --dir "<folder holding adi_space_portfolio>"

or Rebuild with RESET ticked for ADI only. Then the audit should report ADI cleanly.


NOT TESTED HERE
---------------
Verified against your actual adi_space_portfolio_2026-07-28.xlsx and the nine
ADIParametrics workbooks, driven through the real rebuild path. No Tk, nothing
GUI-side changed.
