"""rfparts_save_pages.py — save listing/table pages from YOUR OWN browser.

One script for both sources that need a real browser:

    everythingRF   paginated listings behind a Cloudflare check
    Qorvo          parametric tables built client-side by a Next.js app, so a
                   plain HTTP fetch returns an app shell with no rows in it

WHAT THIS IS
    You drive Chrome. You clear any human check yourself. This attaches to that
    same real session over CDP and automates the tedious part: wait for the page
    to render, save the HTML, advance (click "Next" for everythingRF, go to the
    next table URL for Qorvo), repeat.

WHAT THIS IS NOT
    No headless/stealth browser, no TLS or UA fingerprint spoofing, no attempt to
    solve or bypass a challenge. If a challenge appears it STOPS and hands control
    back to you. Any clearance cookie in play is one you earned as a human in your
    own profile. Requests stay human-paced and supervised.

SETUP (once)
    pip install playwright

    Launch Chrome with a debug port and a dedicated profile:

      Windows
        "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe" ^
            --remote-debugging-port=9222 --user-data-dir="%USERPROFILE%\\rfparts-chrome"

      macOS
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \\
            --remote-debugging-port=9222 --user-data-dir="$HOME/rfparts-chrome"

      Linux
        google-chrome --remote-debugging-port=9222 --user-data-dir="$HOME/rfparts-chrome"

USAGE
    python rfparts_save_pages.py --source qorvo
    python rfparts_save_pages.py --source erf --url "https://www.everythingrf.com/..."
    python rfparts_save_pages.py --source both --url "https://www.everythingrf.com/..."

    Qorvo needs no --url: the six parametric-table URLs are built in.

WHERE IT SAVES
    Qorvo -> <Sources>/QorvoParametric/<slug>.html
    ERF   -> <Sources>/EverythingRFSpaceQual/<folder>/page_NNN.html

    Both are exactly where the rebuild looks, so "Rebuild dataset" picks the
    pages up with no extra configuration.
"""
from __future__ import annotations

import argparse
import hashlib
import os
import random
import re
import sys
import time
import urllib.parse
from pathlib import Path

try:
    from playwright.sync_api import sync_playwright
except ImportError:
    sys.exit("Playwright not installed. Run:  pip install playwright")

# ---------------------------------------------------------------- destinations
def _sources_root():
    """Where the pipeline looks for local sources."""
    env = os.environ.get("RFPARTS_SOURCES", "").strip()
    if env:
        return Path(env)
    here = Path(__file__).resolve().parent
    for cand in (here / "Sources", here.parent / "Sources"):
        if cand.is_dir():
            return cand
    return here / "Sources"


# The six Qorvo parametric tables. Path-based URLs on the rebuilt (Vercel) site;
# the old /products/product-list?categoryID=N scheme 404s everywhere.
#
# robots.txt (checked 2026-08-04) disallows /products/c/, /products/i/,
# /products/s/, /products/sc/, /products/sca/ and /products/ai/. None of these
# URLs sit under those prefixes -- "/products/s/" does not match
# "/products/switches/", because the trailing slash is part of the rule.
QORVO_TABLES = [
    ("amplifiers-lnas-gain-blocks",
     "https://www.qorvo.com/products/amplifiers/lnas-gain-blocks/parametric-table"),
    ("amplifiers-power-amplifiers",
     "https://www.qorvo.com/products/amplifiers/power-amplifiers/parametric-table"),
    ("amplifiers-variable-gain-amplifiers",
     "https://www.qorvo.com/products/amplifiers/variable-gain-amplifiers/parametric-table"),
    ("switches-rf-switches",
     "https://www.qorvo.com/products/switches/rf-switches/parametric-table"),
    ("frequency-converters-mixers",
     "https://www.qorvo.com/products/frequency-converters/mixers/parametric-table"),
    ("frequency-converters-upconverters-downconverters",
     "https://www.qorvo.com/products/frequency-converters/upconverters-downconverters/parametric-table"),
]

CF_MARKERS = ("cf-browser-verification", "cf_chl_", "checking your browser",
              "just a moment", "turnstile", "__cf_chl", "attention required")

NEXT_SELECTORS = (
    'a[rel="next"]',
    'a[aria-label*="Next" i]',
    'a[title*="Next" i]',
    'li.next:not(.disabled) a',
    'a.next:not(.disabled)',
    '.pagination a.next',
)

# The grid only exists once the app has rendered. Saving before this appears is
# the whole failure mode we are working around, so it is waited for explicitly
# rather than trusting a fixed sleep.
QORVO_ROW_SELECTOR = "div.row.grid-row"
QORVO_READY_SELECTORS = ("div.table-body div.row.grid-row",
                         "div.table-head div.head-cell")


def looks_like_challenge(html: str) -> bool:
    low = html.lower()
    return any(m in low for m in CF_MARKERS) and len(html) < 30000


def sig(html: str) -> str:
    return hashlib.md5(html[:4000].encode("utf-8", "replace")).hexdigest()


def human_pause(base):
    time.sleep(base + random.uniform(0.4, 2.0))


def attach(p, endpoint):
    try:
        browser = p.chromium.connect_over_cdp(endpoint)
    except Exception as e:
        sys.exit(f"Could not attach to Chrome at {endpoint}: {e}\n"
                 "Launch Chrome with --remote-debugging-port=9222 first "
                 "(see the header of this file).")
    if not browser.contexts or not browser.contexts[0].pages:
        sys.exit("No open tab found. Open any page in that Chrome window first.")
    return browser, browser.contexts[0].pages[0]


def _wait_settled(page, timeout=20000):
    try:
        page.wait_for_load_state("networkidle", timeout=timeout)
    except Exception:
        pass          # some pages never fully idle; use what has rendered


def _clear_challenge(page, label):
    html = page.content()
    if looks_like_challenge(html):
        input(f"\n[{label}] human check detected. Clear it in the browser, "
              f"then press Enter here... ")
        _wait_settled(page)
        html = page.content()
    return html


# ---------------------------------------------------------------- Qorvo
def save_qorvo(page, out_root, delay, only=None, overwrite=False):
    out = Path(out_root) / "QorvoParametric"
    out.mkdir(parents=True, exist_ok=True)
    targets = [(s, u) for s, u in QORVO_TABLES
               if not only or any(o.lower() in s for o in only)]
    print(f"\n=== Qorvo: {len(targets)} parametric table(s) -> {out} ===")
    saved = skipped = empty = 0
    for i, (slug, url) in enumerate(targets, 1):
        dest = out / f"{slug}.html"
        if dest.exists() and not overwrite:
            print(f"[{i}/{len(targets)}] {slug}: already saved "
                  f"({dest.stat().st_size:,} bytes) -- use --overwrite to refresh")
            skipped += 1
            continue
        print(f"[{i}/{len(targets)}] {url}")
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=60000)
        except Exception as e:
            print(f"    ! navigation failed: {type(e).__name__}: {e}")
            continue
        _wait_settled(page)
        _clear_challenge(page, slug)
        # Wait for the grid itself, not just for the network to quiet down.
        ready = False
        for sel in QORVO_READY_SELECTORS:
            try:
                page.wait_for_selector(sel, timeout=25000)
                ready = True
                break
            except Exception:
                continue
        if not ready:
            print("    ! the parametric grid never appeared. The page may need a "
                  "moment more, or its markup changed.")
        # Rows can arrive in batches; wait until the count stops growing.
        last = -1
        for _ in range(12):
            try:
                n = page.locator(QORVO_ROW_SELECTOR).count()
            except Exception:
                n = 0
            if n and n == last:
                break
            last = n
            time.sleep(1.0)
        html = page.content()
        rows = html.count('class="row grid-row"')
        if not rows:
            empty += 1
            print(f"    ! saved nothing useful: 0 grid rows in {len(html):,} "
                  f"bytes. Not writing the file.")
            continue
        dest.write_text(html, encoding="utf-8")
        saved += 1
        print(f"    saved {dest.name}  ({len(html):,} bytes, {rows} row(s))")
        human_pause(delay)
    print(f"\nQorvo: {saved} saved, {skipped} already present, {empty} empty")
    return saved


# ---------------------------------------------------------------- everythingRF
def save_erf(page, out_root, delay, start_url=None, folder="EverythingRFSpaceQual",
             subfolder=None, max_pages=1000, next_sel=None, overwrite=False):
    out = Path(out_root) / folder / (subfolder or "saved")
    out.mkdir(parents=True, exist_ok=True)
    print(f"\n=== everythingRF -> {out} ===")
    if start_url:
        print(f"navigating to {start_url}")
        try:
            page.goto(start_url, wait_until="domcontentloaded", timeout=60000)
        except Exception as e:
            print(f"! navigation failed: {type(e).__name__}: {e}")
            return 0
    else:
        print(f"using the tab already open: {page.url}")

    existing = sorted(out.glob("page_*.html"))
    start_at = 1
    if existing and not overwrite:
        start_at = len(existing) + 1
        print(f"{len(existing)} page(s) already saved here; continuing at "
              f"page_{start_at:03d} (use --overwrite to start over)")

    last, saved = None, 0
    for i in range(start_at, max_pages + 1):
        _wait_settled(page)
        html = _clear_challenge(page, f"page {i}")
        this = sig(html)
        if this == last:
            print(f"[{i}] page did not change after Next -- stopping.")
            break
        last = this
        boxes = html.count('class="product-box"')
        dest = out / f"page_{i:03d}.html"
        dest.write_text(html, encoding="utf-8")
        saved += 1
        print(f"[{i}] saved {dest.name}  ({len(html):,} bytes, {boxes} "
              f"product box(es))  {page.url[:70]}")
        if boxes == 0:
            print("    ! no product boxes on this page; the listing may have "
                  "ended or the markup changed.")
        nxt = None
        if next_sel:
            nxt = page.query_selector(next_sel)
        else:
            for sel in NEXT_SELECTORS:
                el = page.query_selector(sel)
                if el and el.is_visible():
                    nxt = el
                    break
            if nxt is None:
                try:
                    cand = page.get_by_role("link", name="Next", exact=False).first
                    if cand and cand.count() and cand.is_visible():
                        nxt = cand
                except Exception:
                    pass
        if not nxt:
            print(f"[{i}] no Next link found -- end of listing (or pass "
                  f"--next-selector).")
            break
        try:
            nxt.click()
        except Exception as e:
            print(f"[{i}] could not click Next ({type(e).__name__}) -- stopping.")
            break
        human_pause(delay)
    print(f"\neverythingRF: {saved} page(s) saved into {out}")
    return saved


def main(argv=None):
    ap = argparse.ArgumentParser(
        description=__doc__.split("\n")[0],
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--source", choices=("erf", "qorvo", "both"), default="both",
                    help="which source to refresh (default both)")
    ap.add_argument("--out", default=None,
                    help="Sources root (default: RFPARTS_SOURCES, else "
                         "./Sources next to this file)")
    ap.add_argument("--url", default=None,
                    help="everythingRF starting listing URL; omit to use the "
                         "tab already open")
    ap.add_argument("--erf-folder", default="EverythingRFSpaceQual",
                    help="top folder for ERF pages (SpaceQual => qualified)")
    ap.add_argument("--erf-subfolder", default=None,
                    help="subfolder name, e.g. EverythingRFSpaceSwitches")
    ap.add_argument("--max-pages", type=int, default=1000)
    ap.add_argument("--only", nargs="*",
                    help="Qorvo: only tables whose slug contains these, "
                         "e.g. --only switches mixers")
    ap.add_argument("--next-selector", default=None)
    ap.add_argument("--endpoint", default="http://localhost:9222")
    ap.add_argument("--delay", type=float, default=3.0,
                    help="base seconds between pages (jitter added)")
    ap.add_argument("--overwrite", action="store_true",
                    help="re-save pages that already exist")
    args = ap.parse_args(argv)

    out_root = Path(args.out) if args.out else _sources_root()
    out_root.mkdir(parents=True, exist_ok=True)
    print(f"sources root: {out_root}")

    if args.source in ("erf", "both") and not args.url:
        print("note: no --url given for everythingRF, so the tab you already "
              "have open will be used as page 1.")

    with sync_playwright() as p:
        browser, page = attach(p, args.endpoint)
        print(f"attached to Chrome: {page.url[:80]}")
        total = 0
        if args.source in ("qorvo", "both"):
            total += save_qorvo(page, out_root, args.delay, only=args.only,
                                overwrite=args.overwrite)
        if args.source in ("erf", "both"):
            total += save_erf(page, out_root, args.delay, start_url=args.url,
                              folder=args.erf_folder,
                              subfolder=args.erf_subfolder,
                              max_pages=args.max_pages,
                              next_sel=args.next_selector,
                              overwrite=args.overwrite)
    print(f"\ndone: {total} page(s) saved.")
    print("Next: Rebuild dataset (Resume is fine -- unchanged files are skipped).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
