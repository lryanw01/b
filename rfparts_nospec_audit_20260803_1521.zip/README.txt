Missing-spec audit
==================

One folder PER SOURCE, then per audited part -- because 'Analog
Devices' covers two different inputs (the parametric exports and the
space-qualified product list) whose gaps mean different things:
  ADI-Parametrics/ ADI-space-qualified-product-list/ MACOM/ Marki/
  EverythingRF/ Qorvo/ Skyworks/ Mini-Circuits/

Inside each part folder:
  source_<name>            the file the part was parsed from (for a
                           spreadsheet, the header plus that part's row)
  parsed.txt               what the parser extracts from it today
  verdict.txt              per missing spec: STALE ROW / PARSER GAP /
                           NOT IN SOURCE, with the source text quoted

summary.txt  verdict totals and what each one means
findings.csv one row per (part, missing spec) for sorting

Only a few parts per vendor, chosen most-incomplete-first. Nothing was
written to the database.
