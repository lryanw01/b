"""enum_census.py — what values are actually in the metadata fields?

    python enum_census.py
    python enum_census.py --top 20
    python enum_census.py --field package --top 40
    python enum_census.py --csv enums.csv

Counts the distinct values of every enumerated field in the database and prints
the most common ones per field, with a rough tally of the long tail.

WHY
    Fields like interface, package and mount type accumulate a vendor's exact
    wording -- "SMT", "Surface Mount", "surface-mount", "SMD" are four spellings
    of one thing. Each spelling is a separate dropdown entry and a separate
    filter value, so a search for one silently excludes the others. You cannot
    decide what to fold together without first seeing what is there, and the
    long tail is usually where the duplicates hide.

    The suggestions at the end are candidates, not decisions: folding SMT and
    die together would be wrong (they are genuinely different things), while
    folding "Surface Mount" into "SMT" is obviously right. The script separates
    the two cases by only proposing folds within a family it knows about, and
    flagging everything else as "review".
"""
from __future__ import annotations

import argparse
import csv
import re
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

try:
    from pythonrfparts import partdb
except Exception as e:                                   # pragma: no cover
    sys.exit(f"Could not import the package: {e}\n"
             "Run this from the folder that contains pythonrfparts/.")

# Columns on the parts table plus spec keys that hold text rather than numbers.
PART_COLUMNS = ["vendor", "category", "subcategory"]
TEXT_SPEC_KEYS = [
    "package", "package_size", "connector", "mount_type", "technology",
    "configuration", "switch_type", "throw_config", "subtype", "space",
    "space_variant", "pulsed_cw", "industry_application", "product_status",
    "lifecycle", "qual_level", "orderable", "source_category", "waveguide",
    "modulation", "device_type", "erf_grade", "availability",
]

# Families the script is confident about. Each maps a canonical value to the
# spellings that mean the same thing. Deliberately conservative: mounting style
# and package body are NOT merged, because "SMT" describes how a part attaches
# and "QFN" describes what it is -- a part is both, and collapsing them loses
# information you cannot get back.
FOLD_FAMILIES = {
    "mount_type": {
        "SMT": ["smt", "smd", "surface mount", "surface-mount", "surfacemount",
                "surface mount technology", "smt/smd", "reflow"],
        "connectorized": ["connectorized", "connectorised", "coaxial",
                          "coax", "connector", "sma connectorized"],
        "die": ["die", "bare die", "chip", "chip and wire", "mmic die",
                "bare-die", "unpackaged"],
        "waveguide": ["waveguide", "wg"],
        "drop-in": ["drop in", "drop-in", "dropin"],
        "flange": ["flange", "flanged", "bolt down", "bolt-down"],
        "through-hole": ["through hole", "through-hole", "thru hole", "tht",
                         "pth", "leaded"],
        "module": ["module", "brick", "assembly"],
    },
    "connector": {
        "SMA": ["sma", "sma female", "sma male", "sma (f)", "sma (m)"],
        "2.92mm": ["2.92mm", "2.92 mm", "k connector", "k-connector", "3.5mm",
                   "3.5 mm"],
        "2.4mm": ["2.4mm", "2.4 mm"],
        "1.85mm": ["1.85mm", "1.85 mm", "v connector"],
        "N": ["n", "n type", "n-type", "type n"],
        "TNC": ["tnc"], "BNC": ["bnc"], "SSMA": ["ssma"], "SMP": ["smp"],
        "solder": ["solder", "solder pin", "solder lug", "pins"],
    },
    "space": {
        "qualified": ["qualified", "space qualified", "space-qualified",
                      "spacequalified", "yes", "true", "space"],
        "hi_rel": ["hi rel", "hi-rel", "hirel", "high reliability",
                   "high-reliability", "space grade", "space-grade"],
        "no": ["no", "false", "commercial", "none"],
    },
    "pulsed_cw": {
        "CW": ["cw", "continuous wave", "continuous"],
        "pulsed": ["pulsed", "pulse"],
        "both": ["pulsed/cw", "cw/pulsed", "both", "cw and pulsed"],
    },
}


def norm(v):
    return re.sub(r"\s+", " ", str(v or "").strip().lower())


def canonical_for(field, value):
    """The canonical spelling for a value, or None if the script is not sure."""
    fam = FOLD_FAMILIES.get(field)
    if not fam:
        return None
    n = norm(value)
    if not n:
        return None
    for canon, spellings in fam.items():
        if n == norm(canon) or n in [norm(s) for s in spellings]:
            return canon
    return None


def census_part_columns(conn, columns):
    out = {}
    for col in columns:
        try:
            rows = conn.execute(
                f"SELECT {col} AS v, COUNT(*) AS n FROM parts "
                f"WHERE {col} IS NOT NULL AND {col} != '' "
                f"GROUP BY {col} ORDER BY n DESC").fetchall()
        except Exception as e:
            print(f"  ! could not read parts.{col}: {e}")
            continue
        out[col] = Counter({r["v"]: r["n"] for r in rows})
    return out


def census_spec_keys(conn, keys):
    out = {}
    for key in keys:
        try:
            rows = conn.execute(
                "SELECT value_text AS v, COUNT(*) AS n FROM specs "
                "WHERE key=? AND value_text IS NOT NULL AND value_text != '' "
                "GROUP BY value_text ORDER BY n DESC", (key,)).fetchall()
        except Exception as e:
            print(f"  ! could not read specs[{key}]: {e}")
            continue
        if rows:
            out[key] = Counter({r["v"]: r["n"] for r in rows})
    return out


def report(field, counts, top, writer=None):
    total = sum(counts.values())
    distinct = len(counts)
    print(f"\n{'=' * 70}")
    print(f"  {field}   {total} value(s) across {distinct} distinct spelling(s)")
    print(f"{'=' * 70}")
    shown = counts.most_common(top)
    width = max((len(str(v)) for v, _ in shown), default=10)
    width = min(max(width, 12), 46)
    folds = {}
    for value, n in shown:
        canon = canonical_for(field, value)
        mark = ""
        if canon and norm(canon) != norm(value):
            mark = f"  -> fold into {canon!r}"
            folds.setdefault(canon, []).append((value, n))
        print(f"    {n:>7}  {str(value)[:46]:<{width}}{mark}")
        if writer:
            writer.writerow([field, value, n, canon or ""])
    tail = distinct - len(shown)
    if tail > 0:
        tail_n = total - sum(n for _v, n in shown)
        print(f"    {tail_n:>7}  ... {tail} more distinct value(s) in the tail")
        if writer:
            for value, n in counts.most_common()[top:]:
                writer.writerow([field, value, n, canonical_for(field, value) or ""])
    if folds:
        saved = sum(n for lst in folds.values() for _v, n in lst)
        print(f"\n    folding the marked spellings would collapse "
              f"{sum(len(v) for v in folds.values())} entries "
              f"({saved} rows) into {len(folds)} canonical value(s)")
    elif field in FOLD_FAMILIES:
        print("\n    nothing in the top values needs folding")
    else:
        print("\n    no fold rules for this field -- review the list above and "
              "tell me\n    which spellings mean the same thing")


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--top", type=int, default=10,
                    help="values to show per field (default 10)")
    ap.add_argument("--field", default=None,
                    help="only this field")
    ap.add_argument("--csv", default=None,
                    help="also write every value and count to this CSV")
    ap.add_argument("--min-distinct", type=int, default=2,
                    help="skip fields with fewer distinct values than this")
    args = ap.parse_args(argv)

    conn = partdb.db()
    print(f"database: {partdb.DB_PATH}")

    everything = {}
    everything.update(census_part_columns(conn, PART_COLUMNS))
    everything.update(census_spec_keys(conn, TEXT_SPEC_KEYS))
    # anything else in specs that is predominantly text and looks enumerated
    try:
        extra = conn.execute(
            "SELECT key, COUNT(DISTINCT value_text) AS d, COUNT(*) AS n "
            "FROM specs WHERE value_text IS NOT NULL AND value_text != '' "
            "GROUP BY key HAVING d BETWEEN 2 AND 400 ORDER BY n DESC").fetchall()
    except Exception:
        extra = []
    for r in extra:
        if r["key"] in everything or r["key"] in TEXT_SPEC_KEYS:
            continue
        rows = conn.execute(
            "SELECT value_text AS v, COUNT(*) AS n FROM specs WHERE key=? "
            "GROUP BY value_text ORDER BY n DESC", (r["key"],)).fetchall()
        everything[r["key"]] = Counter({x["v"]: x["n"] for x in rows})

    fields = ([args.field] if args.field
              else sorted(everything, key=lambda k: -sum(everything[k].values())))
    writer = fh = None
    if args.csv:
        fh = open(args.csv, "w", newline="", encoding="utf-8")
        writer = csv.writer(fh)
        writer.writerow(["field", "value", "count", "suggested_canonical"])

    shown_any = False
    for f in fields:
        counts = everything.get(f)
        if not counts:
            print(f"\n  {f}: no values stored")
            continue
        if len(counts) < args.min_distinct:
            continue
        report(f, counts, args.top, writer)
        shown_any = True
    if fh:
        fh.close()
        print(f"\nfull value list written to {args.csv}")
    if not shown_any:
        print("\nnothing to report -- is the database populated?")

    print("\n" + "=" * 70)
    print("  WHAT IS WORTH FOLDING, AND WHAT IS NOT")
    print("=" * 70)
    print("""
  Worth folding (same fact, different spelling):
    mount_type   SMT / SMD / Surface Mount / surface-mount -> one value
    connector    SMA / SMA Female / SMA (F)                -> SMA
                 3.5mm / 2.92mm / K connector              -> one value, they
                                                              intermate
    space        Space Qualified / space-qualified / Yes   -> qualified
    pulsed_cw    CW / Continuous Wave                      -> CW

  NOT worth folding (genuinely different facts):
    die into SMT      a bare die is not surface mount -- it has no package and
                      needs chip-and-wire assembly. Merging them would let a
                      die-only part answer an SMT search.
    package into      "QFN" is the body, "SMT" is how it attaches. A part is
    mount_type        both; collapsing them loses one axis of search.
    package_size      a dimension, not an enum -- leave it alone.

  Judgement call, your domain:
    connectorized vs module        often the same part described two ways
    hi_rel vs space qualified      distinct qualification levels, but vendors
                                   use them loosely -- keeping them apart is
                                   safer, and the space_variant field already
                                   records the finer grade
""")
    return 0


if __name__ == "__main__":
    sys.exit(main())
