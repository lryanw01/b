"""Build/refresh the space-qualified parts dataset from LOCAL catalogs.

One place that knows how to turn the catalogs on disk into partdb rows, then
dedupe. Everything is offline: it only reads files you already downloaded.

Sources understood:
  * everythingRF saved listing folders  -> erf_space_ingest  (EverythingRFSpace*)
  * ADI space portfolio .xlsx            -> adi_ingest
  * Qorvo defense/aerospace .pdf         -> qorvo_ingest
  * TI Space Products Guide .pdf         -> ti_ingest

Adding another catalog later = drop a new ``*_ingest`` module with an
``ingest(path, dry_run, verbose)`` and add one line to ``_ADAPTERS``.

Public API (used by the GUI "Rebuild dataset" button and the CLI `ingest`):
    rebuild(erf_parent=None, source_files=(), source_dir=None,
            dedupe=True, progress=None) -> summary dict
    scan_dir(folder) -> list[(path, kind)]
"""
from __future__ import annotations

import re
import time
import traceback
from pathlib import Path
from .paths import (EVERYTHING_RF, NEW_SOURCES, ADI_PARAMETRICS,
                    EXPORT_DIR, QORVO_PAGES)

try:
    from . import (adi_ingest, qorvo_ingest, ti_ingest, erf_space_ingest,
                   minicircuits_ingest,
                   partdb, vendor_catalogs, adi_parametric_ingest,
                   adi_space_ingest)
except ImportError:                                    # loose-script fallback
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from rfparts import (adi_ingest, qorvo_ingest, ti_ingest,   # type: ignore
                         minicircuits_ingest,
                         erf_space_ingest, partdb, vendor_catalogs,
                         adi_parametric_ingest, adi_space_ingest)

# Vendors whose live catalogues can be walked (see vendor_catalogs). Selectable
# so a refresh can target one vendor instead of re-walking everything.
CATALOG_VENDORS = vendor_catalogs.ALL_VENDORS

# What each source is CAPABLE of providing, declared rather than inferred.
#
# "Why is there no gain from the space portfolio?" is not answerable by looking at
# the dataset: an empty column looks identical whether the parser failed or the
# source never had the data. Verified against the real files -- the ADI space
# portfolio has 19 columns and not one of them is gain, NF, P1dB, OIP3 or Psat;
# the word "Gain" appears 5 times in the entire workbook, all inside description
# prose. So the honest answer is printed at the end of every rebuild instead of
# being re-investigated.
SOURCE_CAPABILITIES = {
    "ADI space portfolio": {
        "provides": ["space_qual_level", "tid_krad", "sel_mev", "tnid",
                     "temp_min_c", "temp_max_c", "package", "package_material",
                     "lead_finish", "datasheet_url", "freq_ghz (from the "
                     "description, ~117 of 234 parts)"],
        "cannot_provide": ["gain_db", "nf_db", "p1db_dbm", "oip3_dbm",
                           "psat_dbm"],
        "note": "19 columns, none parametric. RF numbers for its 39 genuine RF "
                "amplifiers arrive by merging with the ADI parametric exports on "
                "the same part number.",
    },
    "ADI parametric exports": {
        "provides": ["freq_ghz", "gain_db (Amplifiers + LNA/PA sheets only)",
                     "nf_db", "oip3_dbm", "iip3_dbm", "p1db_dbm", "psat_dbm",
                     "conversion_gain_db", "package", "price_usd", "lifecycle",
                     "temp_min_c", "temp_max_c"],
        "cannot_provide": ["tid_krad", "sel_mev", "space_qual_level"],
        "note": "3 of 9 sheets carry a gain column; the other 6 have none. "
                "Commercial catalogue, so it never sets a space classification.",
    },
    "everythingRF": {
        "provides": ["freq_ghz", "gain_db", "nf_db", "p1db_dbm", "oip3_dbm",
                     "psat_dbm (derived from Output Power in W)", "power_w",
                     "insertion_loss_db", "isolation_db", "package",
                     "space_variant (from the folder name)"],
        "cannot_provide": ["tid_krad", "sel_mev"],
        "note": "Listing cards vary by part: many state only frequency and type.",
    },
    "MACOM": {
        "provides": ["freq_ghz", "gain_db", "psat_dbm", "p1db_dbm", "oip3_dbm",
                     "supply_v", "current_ma", "efficiency_pct",
                     "datasheet_url"],
        "cannot_provide": ["tid_krad", "sel_mev", "space_qual_level"],
        "note": "From the data-part JSON embedded in each listing row.",
    },
    "Qorvo": {
        "provides": ["freq_ghz", "gain_db", "nf_db", "p1db_dbm", "oip3_dbm",
                     "insertion_loss_db", "isolation_db", "attenuation_db",
                     "package", "datasheet_url"],
        "cannot_provide": ["tid_krad", "sel_mev", "space_qual_level"],
        "note": "Whichever columns that category's parametric table happens to "
                "carry.",
    },
    "Marki Microwave": {
        "provides": ["freq_ghz", "gain_db", "nf_db", "p1db_dbm", "oip3_dbm",
                     "isolation_db", "conversion_loss_db", "supply_v",
                     "current_ma", "absmax_*"],
        "cannot_provide": ["tid_krad", "sel_mev", "space_qual_level"],
        "note": "Specs come from the /datasheet/ page, not the listing, so the "
                "per-part pass must complete.",
    },
    "Skyworks": {
        "provides": ["datasheet_url", "package"],
        "cannot_provide": ["gain_db", "nf_db", "p1db_dbm", "oip3_dbm",
                           "tid_krad", "sel_mev"],
        "note": "Listings carry no parametrics; the numbers are only in the PDF.",
    },
}


def capability_report(sources=None):
    """Lines describing what each source can and cannot supply."""
    out = ["Source capabilities (what each input can actually provide)"]
    for name, cap in SOURCE_CAPABILITIES.items():
        if sources and not any(s.lower() in name.lower() for s in sources):
            continue
        out.append(f"  {name}")
        out.append(f"    provides : {', '.join(cap['provides'])}")
        out.append(f"    CANNOT   : {', '.join(cap['cannot_provide'])}")
        out.append(f"    note     : {cap['note']}")
    return out

# kind -> (module, human label)
_ADAPTERS = {
    "adi": (adi_ingest, "ADI catalog sheet"),
    "adi_space": (adi_space_ingest, "ADI space portfolio "
                                    "(qual level, TID/SEL, package material)"),
    "adi_parametric": (adi_parametric_ingest, "ADI parametric search export"),
    "qorvo": (qorvo_ingest, "Qorvo defense/aerospace brochure"),
    "ti": (ti_ingest, "TI Space Products Guide"),
    "minicircuits": (minicircuits_ingest, "Mini-Circuits catalogue JSON"),
}


def classify_file(path: Path) -> str | None:
    """Best-effort adapter kind for a file, from its name/extension."""
    name = path.name.lower()
    ext = path.suffix.lower()
    if ext in (".xlsx", ".xlsm", ".csv"):
        # The ADI SPACE PORTFOLIO carries qualification level, TID/SEL
        # thresholds, package material and a real datasheet URL. Sending it to
        # the generic adi adapter read the part number and discarded the other
        # eighteen columns.
        if "space_portfolio" in name or "space portfolio" in name or \
                ("space" in name and "adi" in name):
            return "adi_space"
        if "parametricsearch" in name.replace(" ", "") or "parametric" in name:
            return "adi_parametric"
        return "adi"          # legacy ADI catalog sheets
    if ext == ".json" and "minicircuit" in name:
        return "minicircuits"
    if ext == ".pdf" and "qorvo" in name:
        return "qorvo"
    if ext == ".pdf" and ("slyt" in name or name.startswith("ti") or "space-products" in name
                          or "space_products" in name):
        return "ti"
    if ext == ".pdf":
        return None           # unknown PDF -> let the caller decide
    return None


def scan_dir(folder) -> list[tuple[Path, str | None]]:
    """Every ingestable file under `folder` (one level), with its guessed kind."""
    folder = Path(folder)
    out = []
    if not folder.is_dir():
        return out
    for p in sorted(folder.rglob("*")):
        if p.is_file() and p.suffix.lower() in (".pdf", ".xlsx", ".xlsm", ".csv"):
            out.append((p, classify_file(p)))
    return out


def _existing_spec_values(part_id):
    """{key: value} already stored for a part, for reporting what enrichment
    changes rather than just how many rows it wrote."""
    out = {}
    try:
        for r in partdb.db().execute(
                "SELECT key, value_text, value_typ FROM specs WHERE part_id=?",
                (part_id,)):
            out[r["key"]] = (r["value_text"] if r["value_text"] is not None
                             else r["value_typ"])
    except Exception:
        pass
    return out


def _cancelled(cancel):
    """True when the caller has asked to stop.

    `cancel` is a threading.Event from the GUI but a plain callable from the CLI,
    and assuming one shape breaks the other -- calling an Event raised "'Event'
    object is not callable" and killed the whole datasheet-mining step. The rest
    of the codebase already tests for .is_set() first; this matches it so there is
    one convention rather than two."""
    try:
        if cancel is None:
            return False
        return bool(cancel.is_set() if hasattr(cancel, "is_set") else cancel())
    except Exception:
        return False


def _file_checkpoint_path():
    from .paths import CACHE_DIR
    return Path(CACHE_DIR) / "file_sources.json"


def _file_fingerprint(path):
    """Content hash + size for a catalog file, so an unchanged file is skipped.

    The everythingRF ingest has always had a checkpoint; the FILE-based ingests
    (Qorvo brochure, ADI xlsx, TI guide) had none at all -- `ingest(path,
    dry_run, verbose)` takes no resume argument -- so every rebuild re-parsed
    them in full regardless of the Resume checkbox. Hashing the file is enough:
    these are single documents, so there is no partial-progress problem to model,
    only "has this file changed since we last read it".
    """
    import hashlib
    p = Path(path)
    h = hashlib.sha1()
    try:
        st = p.stat()
        with p.open("rb") as fh:
            while True:
                chunk = fh.read(1 << 20)
                if not chunk:
                    break
                h.update(chunk)
    except OSError:
        return None
    return f"{st.st_size}:{h.hexdigest()[:16]}"


def _load_file_checkpoints():
    fp = _file_checkpoint_path()
    if fp.is_file():
        try:
            import json as _json
            data = _json.loads(fp.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}
    return {}


def _save_file_checkpoint(key, fingerprint, parts):
    fp = _file_checkpoint_path()
    try:
        import json as _json
        data = _load_file_checkpoints()
        data[key] = {"fingerprint": fingerprint, "parts": int(parts or 0),
                     "at": time.strftime("%Y-%m-%dT%H:%M:%S")}
        fp.parent.mkdir(parents=True, exist_ok=True)
        fp.write_text(_json.dumps(data, indent=1), encoding="utf-8")
        return True
    except Exception as e:
        # Never swallow this. A checkpoint that fails to persist looks exactly
        # like "resume does not work", which is the bug being fixed here.
        print(f"  ! could not save file-source checkpoint: "
              f"{type(e).__name__}: {e}")
        return False


def _run(kind, path, progress, part=None, categories=None, cancel=None,
         resume=False) -> dict:
    import inspect
    module, label = _ADAPTERS[kind]
    ckey = f"{kind}|{Path(path).name}"
    # The fingerprint covers the FILE. It must also cover the PARSER, or a parser
    # improvement can never reach an unchanged source: the ADI frequency-unit fix
    # was invisible for exactly that reason -- the workbook was untouched, the
    # checkpoint matched, the stale values stayed.
    pver = getattr(module, "PARSER_VERSION", 1)
    fp = _file_fingerprint(path) if resume else None
    fingerprint = f"{fp}|p{pver}" if fp else None
    if resume and fingerprint:
        prev = _load_file_checkpoints().get(ckey)
        if isinstance(prev, dict) and prev.get("fingerprint") != fingerprint \
                and str(prev.get("fingerprint", "")).split("|p")[0] == str(fp):
            progress(f"  parser for {label} has changed since this file was last "
                     f"read; re-parsing it once")
        if isinstance(prev, dict) and prev.get("fingerprint") == fingerprint:
            progress(f"SKIP unchanged source: {label}: {Path(path).name} "
                     f"({prev.get('parts', 0)} part(s) last time) -- Reset to "
                     f"force a re-parse")
            return {"parts": 0, "source_skipped": 1}
    progress(f"ingesting {label}: {Path(path).name} ...")
    kwargs = {"dry_run": False, "verbose": False}
    # Older adapters take only (path, dry_run, verbose); the newer ones also
    # report parts to the live table and honour the category filter. Pass what
    # each actually accepts rather than assuming a common signature.
    try:
        accepted = inspect.signature(module.ingest).parameters
    except (TypeError, ValueError):
        accepted = {}
    if "progress" in accepted:
        kwargs["progress"] = progress
    if "part" in accepted and part is not None:
        kwargs["part"] = part
    if "categories" in accepted and categories:
        kwargs["categories"] = categories
    if "cancel" in accepted and cancel is not None:
        kwargs["cancel"] = cancel
    counts = module.ingest(Path(path), **kwargs)
    progress(f"  {label}: {counts.get('parts', 0)} parts "
             f"({counts.get('space_qualified', 0)} qualified, "
             f"{counts.get('space_grade', 0)} grade)")
    if resume and fingerprint:
        _save_file_checkpoint(ckey, fingerprint, counts.get("parts", 0))
    return counts


# ---------------------------------------------------------------- sources
# One id per SOURCE, which is what a rebuild actually re-runs. Vendors were the
# wrong unit: a Qorvo part can arrive from the everythingRF pages, the aerospace
# brochure or the parametric tables, and "re-run Qorvo" cannot say which of those
# to touch. Re-running a source leaves every other source's parts alone.
SOURCES = {
    "everythingrf":   "everythingRF saved listing pages",
    "qorvo_pages":    "Qorvo parametric tables (saved pages)",
    "minicircuits":   "Mini-Circuits catalogue JSON",
    "adi_parametric": "ADI parametric search export",
    "adi_space":      "ADI space portfolio",
    "adi":            "ADI catalog sheet",
    "qorvo":          "Qorvo defence/aerospace brochure",
    "ti":             "TI Space Products Guide",
    "macom":          "MACOM website catalogue",
    "marki":          "Marki Microwave website catalogue",
    "skyworks":       "Skyworks website catalogue",
    "datasheets":     "local datasheet enrichment",
    # Parse a vendor's datasheet folder directly, rather than only using
    # datasheets to fill blanks behind a catalogue. Selecting one walks
    # Data/datasheets/<vendor>/ and mines every file into the dataset, so a
    # part whose catalogue listing says little still arrives with specs.
    "ds_minicircuits": "Mini-Circuits datasheet folder",
    "ds_marki":        "Marki Microwave datasheet folder",
    "ds_macom":        "MACOM datasheet folder",
    "ds_adi":          "Analog Devices datasheet folder",
}

# source key -> (folder name under the datasheet library, vendor to file under)
# Analog Devices was missing: fetch_missing_datasheets.py writes ADI (and the
# Hittite parts folded into it) to Analog-Devices/, which is one of the larger
# folders on disk, so leaving it out of the picker made it unreachable.
DATASHEET_SOURCES = {
    "ds_minicircuits": ("Mini-Circuits", "Mini-Circuits"),
    "ds_marki":        ("Marki-Microwave", "Marki Microwave"),
    "ds_macom":        ("MACOM", "MACOM"),
    # Qorvo removed: the Qorvo material is parametric tables, not datasheets,
    # so the folder does not exist and the checkbox could only ever report
    # "no folder".
    "ds_adi":          ("Analog-Devices", "Analog Devices"),
}

# Which live vendor walk each catalogue source maps to.
_SOURCE_VENDOR = {"macom": "macom", "marki": "marki", "skyworks": "skyworks"}


# What a datasheet CALLS the part, in the words vendors actually print. Checked
# before the spec rules because it is direct evidence: a cable states "Coaxial
# Cable" on every page, and has no gain, no conversion loss and no way count to
# infer from, so spec rules alone left every cable uncategorized.
# Two tiers. A STRONG phrase names the part outright and can be trusted
# anywhere in the text; a WEAK one is a bare noun that also turns up in prose
# about something else, and is only believed when nothing strong matched.
#
# The bare nouns caused real damage: SMA88 is an amplifier whose description
# says "thin film HYBRID design", and MAAP-011341 is an amplifier with a
# "DETECTOR Voltage" pin. Both were filed as passives.
_TITLE_STRONG = [
    ("cable", r"coaxial\s+cable|cable\s+assembl|hand[\s-]?flex|"
              r"interconnect\s+cable|semi[\s-]?rigid\s+cable"),
    ("amplifier", r"low\s+noise\s+amplifier|power\s+amplifier|"
                  r"cascadable\s+amplifier|gain\s+block|\bLNA\b|"
                  r"driver\s+amplifier|limiting\s+amplifier|"
                  r"variable\s+gain\s+amplifier|\bamplifier\b"),
    ("divider", r"power\s+split|power\s+divid|splitter\s*/?\s*combiner|"
                r"wilkinson|\d+\s*way\s+(?:power\s+)?(?:split|divid|combin)"),
    ("coupler", r"directional\s+coupler|dual\s+directional|"
                r"\d+\s*d[Bb]\s+coupler|hybrid\s+coupler|"
                r"90\s*\u00b0?\s*hybrid|180\s*\u00b0?\s*hybrid|"
                r"quadrature\s+hybrid"),
    ("filter", r"band\s*pass\s+filter|low\s*pass\s+filter|"
               r"high\s*pass\s+filter|band\s*stop\s+filter|"
               r"notch\s+filter|\bdiplexer\b|\bduplexer\b|"
               r"tunable\s+filter"),
    ("mixer", r"\bmixer\b|upconverter|downconverter|image\s+reject"),
    ("switch", r"\bSP\d+T\b|\bSPDT\b|\bDPDT\b|transfer\s+switch|"
               r"\bRF\s+switch\b|reflective\s+switch|"
               r"non[\s-]?reflective\s+switch"),
    ("attenuator", r"\battenuator\b|voltage\s+variable\s+attenuat|"
                   r"digital\s+step\s+attenuat"),
    ("phase_shifter", r"phase\s+shifter|vector\s+modulator"),
    ("multiplier", r"frequency\s+multiplier|frequency\s+doubler|"
                   r"active\s+doubler|\btripler\b"),
    ("oscillator", r"\bVCO\b|voltage\s+controlled\s+oscillator|"
                   r"\bsynthesizer\b|crystal\s+oscillator"),
    ("transformer", r"\btransformer\b|\bbalun\b|impedance\s+transform"),
    ("termination", r"\btermination\b|\bterminator\b|dummy\s+load"),
    ("adapter", r"\badapter\b|between\s+series"),
    ("equalizer", r"gain\s+equali|\bequalizer\b"),
    ("limiter", r"\blimiter\b"),
    ("detector", r"power\s+detector|log\s+detector|\bSDLVA\b|"
                 r"detector\s+diode|successive\s+detection"),
    ("dc_block", r"\bDC\s+block\b"),
    ("bias_tee", r"\bbias\s+tee\b"),
]
_TITLE_WEAK = [
    ("coupler", r"\bcoupler\b"),
    ("filter", r"\bfilter\b"),
    ("switch", r"\bswitch\b"),
    ("detector", r"\bdetector\b"),
    ("oscillator", r"\boscillator\b"),
    ("divider", r"\bcombiner\b|\bdivider\b|\bsplitter\b"),
]
_TITLE_STRONG = [(c, re.compile(p, re.I)) for c, p in _TITLE_STRONG]
_TITLE_WEAK = [(c, re.compile(p, re.I)) for c, p in _TITLE_WEAK]


def _category_from_title(title):
    """The category a datasheet names for itself, or ''.

    Strong phrases win wherever they appear; among several, the one appearing
    EARLIEST, since a datasheet names its own part before it mentions anything
    it connects to.
    """
    text = str(title or "")
    if not text:
        return ""
    hits = []
    for cat, rx in _TITLE_STRONG:
        m = rx.search(text)
        if m:
            hits.append((m.start(), cat))
    if hits:
        return min(hits)[1]
    for cat, rx in _TITLE_WEAK:
        m = rx.search(text)
        if m:
            hits.append((m.start(), cat))
    return min(hits)[1] if hits else ""


def _classify_from_specs(rows, mpn="", title=""):
    """(category, subcategory) inferred from the specs a datasheet yielded.

    Only what the specs actually imply. A way count means a divider and names
    its subcategory; a conversion loss means a mixer; a throw config means a
    switch. Where nothing is implied the category is left empty rather than
    guessed, because a wrong category makes a part answer searches it should
    not."""
    got = {}
    for r in rows:
        v = r.value_text if r.value_text is not None else r.value_typ
        got[r.key] = v
    ways = got.get("ways")
    cat, sub = _category_from_title(title), ""
    if cat:
        if cat == "divider" and ways:
            try:
                n = int(float(ways))
                if 2 <= n <= 64:
                    sub = f"{n}-way"
            except (TypeError, ValueError):
                pass
        elif cat == "switch" and got.get("throw_config"):
            sub = str(got["throw_config"])
        return cat, sub
    if got.get("throw_config"):
        cat = "switch"
        sub = str(got["throw_config"])
    elif got.get("conversion_loss_db") is not None:
        cat = "mixer"
    elif got.get("coupling_db") is not None or got.get("directivity_db") is not None:
        cat = "coupler"
    elif got.get("phase_range_deg") is not None:
        cat = "phase_shifter"
    elif got.get("attenuation_db") is not None:
        cat = "attenuator"
    elif got.get("gain_db") is not None:
        cat = "amplifier"
    elif got.get("rejection_db") is not None or got.get("center_freq_ghz"):
        cat = "filter"
    if ways:
        try:
            n = int(float(ways))
            if 2 <= n <= 64:
                cat = cat or "divider"
                if cat == "divider":
                    sub = f"{n}-way"
        except (TypeError, ValueError):
            pass
    return cat, sub


def ingest_datasheet_folder(src_key, progress=None, cancel=None,
                            limit=None, part=None, event=None,
                            every=15) -> dict:
    """Mine every datasheet in one vendor's folder straight into the dataset.

    Distinct from the `datasheets` enrichment source, which only visits parts
    that are ALREADY in the database. This one starts from the files: a
    datasheet whose part was never catalogued still becomes a part, with the
    filename as its MPN, which is how the folder came to be named in the first
    place.
    """
    emit = progress or (lambda m: None)
    # dsmine is imported inside the enrichment block rather than at module
    # level, so it has to be imported here too -- relying on it being a global
    # made this fail with a NameError the caller's except clause then swallowed.
    try:
        from . import dsmine
    except ImportError:
        import dsmine
    folder, vendor = DATASHEET_SOURCES[src_key]
    counts = {"files": 0, "parsed": 0, "parts": 0, "specs": 0, "skipped": 0}
    # default_roots() is deduped, but belt and braces: a vendor folder can
    # still be reached twice if two roots are genuinely different directories
    # that both contain it. Counting a file twice inflates the total, the
    # progress line and the ETA, and re-parses work already done.
    roots, seen_root = [], set()
    for r in dsmine.default_roots():
        d = Path(r) / folder
        if not d.is_dir():
            continue
        try:
            key = str(d.resolve()).casefold()
        except OSError:
            key = str(d).casefold()
        if key in seen_root:
            continue
        seen_root.add(key)
        roots.append(d)
    if not roots:
        emit(f"  {vendor}: no folder named {folder!r} under the datasheet "
             f"library")
        return counts
    files, seen_file = [], set()
    for r in roots:
        for f in sorted(r.rglob("*")):
            if not (f.is_file() and f.suffix.lower() in (".pdf", ".html",
                                                         ".htm", ".txt")):
                continue
            try:
                fk = str(f.resolve()).casefold()
            except OSError:
                fk = str(f).casefold()
            if fk in seen_file:
                continue
            seen_file.add(fk)
            files.append(f)
    if limit:
        files = files[:limit]
    emit(f"  {vendor}: {len(files)} datasheet(s) in {folder}")
    cache, disk_cache = {}, dsmine.load_cache()
    stats = {}
    started = time.time()
    err_groups, err_first = {}, {}
    # 16k files at a few hundred milliseconds each is over an hour, and the old
    # 250-file interval meant the first sign of life arrived minutes in -- which
    # read as a hang. Report often, and send each part UP so the build window
    # fills as it goes rather than all at once at the end.
    for i, f in enumerate(files, 1):
        if _cancelled(cancel):
            emit(f"  stop requested at {i}/{len(files)}; parsed work is cached, "
                 f"so resuming is quick")
            break
        counts["files"] += 1
        mpn = f.stem
        index = {dsmine._loose(mpn): f}
        try:
            rows = dsmine.mine_part(mpn, index, cache, disk_cache=disk_cache,
                                    stats=stats)
        except Exception as e:
            # A 60-character snippet with no traceback makes a failure
            # countable but not fixable -- 153 errors could be one bug or a
            # hundred and there was no way to tell. Group them by cause here,
            # and write full tracebacks to a file beside the library.
            counts["errors"] = counts.get("errors", 0) + 1
            import traceback as _tb
            tb = _tb.extract_tb(e.__traceback__)
            frame = tb[-1] if tb else None
            sig = (f"{type(e).__name__} at "
                   f"{Path(frame.filename).name}:{frame.lineno}"
                   if frame else type(e).__name__)
            err_groups[sig] = err_groups.get(sig, 0) + 1
            if sig not in err_first:
                err_first[sig] = (mpn, "".join(_tb.format_exception(
                    type(e), e, e.__traceback__)))
                emit(f"    ! {sig}: {str(e)[:70]}   (first seen on {mpn})")
            continue
        if not rows:
            counts["skipped"] += 1
        else:
                # A part created from a datasheet had no category and therefore no
            # subcategory, so a 2-way splitter never showed as 2-way anywhere.
            # Both are derived from what was mined.
            cat, sub = _classify_from_specs(
                rows, mpn, getattr(dsmine.mine_part, "last_title", ""))
            pid = partdb.upsert_part(mpn=mpn, vendor=vendor, category=cat,
                                     subcategory=sub, description="")
            partdb.put_specs(pid, rows)
            partdb.put_evidence(pid, [("datasheet-folder", 1.0, str(f),
                                       f"parsed from {folder}")])
            counts["parts"] += 1
            counts["specs"] += len(rows)
            if part:
                # The shape the build window expects: mpn, vendor and the specs
                # as {key: value}. Sent per part, so the table grows live.
                try:
                    # How many distinct values each spec carries, so the
                    # build window can show "2.4 dB (3 values)" -- a worst-case
                    # number alone hides that the part was measured over three
                    # bands, which is the thing worth seeing while it runs.
                    # NOT named `counts`: that is the walker's running tally
                    # of files and parts, and shadowing it here broke the very
                    # next iteration with a KeyError on 'files'.
                    import json as _json
                    band_counts = {}
                    for r in rows:
                        if not r.key.endswith("_bands"):
                            continue
                        try:
                            band_counts[r.key[:-6]] = len(_json.loads(
                                r.value_text or "[]"))
                        except Exception:
                            pass
                    part({"mpn": mpn, "vendor": vendor, "category": cat,
                          "subcategory": sub,
                          "source": f"datasheet:{folder}",
                          "specs": {r.key: (r.value_text
                                            if r.value_text is not None
                                            else r.value_typ)
                                    for r in rows},
                          "spec_counts": band_counts,
                          "datasheet_file": str(f)})
                except Exception:
                    pass
        if event and (i % every == 0 or i == len(files)):
            try:
                event({"type": "datasheet", "vendor": vendor,
                       "detail": f"{i}/{len(files)}  {mpn}", "url": ""})
            except Exception:
                pass
        if i % every == 0 or i == len(files):
            el = time.time() - started
            rate = i / max(1e-9, el)
            left = (len(files) - i) / max(1e-9, rate)
            eta = (f"{left:.0f}s" if left < 90 else
                   f"{left / 60:.0f}m" if left < 5400 else f"{left / 3600:.1f}h")
            emit(f"    {i}/{len(files)}  {counts['parts']} part(s), "
                 f"{counts['specs']} spec row(s), {counts['skipped']} empty"
                 + (f", {counts['errors']} error(s)" if counts.get("errors")
                    else "")
                 + f"   {rate:.1f}/s  eta {eta}")
        if i % 200 == 0:
            dsmine.save_cache(disk_cache)
    dsmine.save_cache(disk_cache)
    if err_groups:
        emit(f"  {counts.get('errors', 0)} error(s) in "
             f"{len(err_groups)} distinct cause(s):")
        for sig, n in sorted(err_groups.items(), key=lambda kv: -kv[1]):
            emit(f"      {n:>5} x  {sig}   (e.g. {err_first[sig][0]})")
        log = Path(list(dsmine.default_roots())[0]) / "_parse_errors.log" \
            if dsmine.default_roots() else Path("_parse_errors.log")
        try:
            log.write_text(
                "\n\n".join(f"{'=' * 70}\n{sig}   x{err_groups[sig]}   "
                             f"first: {mpn0}\n{tb}"
                             for sig, (mpn0, tb) in err_first.items()),
                encoding="utf-8")
            emit(f"      full tracebacks: {log}")
        except OSError as e:
            emit(f"      (could not write the error log: {e})")
    emit(f"  {vendor}: {counts['parts']} part(s) from {counts['files']} file(s), "
         f"{counts['specs']} spec row(s)"
         + (f", {counts['skipped']} yielded nothing" if counts["skipped"] else ""))
    return counts


def _wanted(sources, key):
    """Is this source selected? An empty/None selection means everything."""
    if not sources:
        return True
    return key in set(sources)


def rebuild(erf_parent=None, source_files=(), source_dir=None,
            erf_glob="EverythingRFSpace*", dedupe=True, progress=None,
            vendors=None, vendor_rate=1.0, vendor_limits=None,
            download_datasheets=True, download_limit=0, adi_dir=None,
            use_cache=True, categories=None, reset=False,
            resume=True, reset_vendors_only=False, part=None, event=None,
            cancel=None, mine_datasheets=True, qorvo_pages=None,
            sources=None) -> dict:
    """Ingest everything selected into partdb, then dedupe.

    Local sources (unchanged):
      erf_parent   folder holding the EverythingRFSpace* listing subfolders
      source_files explicit catalog files (kind auto-detected by name)
      source_dir   a folder to scan for catalog files
      dedupe       run partdb.merge_duplicates() at the end (richest specs win)

    Live vendor catalogues (new):
      vendors      subset of CATALOG_VENDORS to walk, e.g. ['qorvo','marki'].
                   None or [] walks none, so existing callers behave as before.
      vendor_rate  seconds between requests to the SAME host
      vendor_limits e.g. {'qorvo_ids': 40, 'marki_products': 200}
      adi_dir      folder of ADIParametricSearch*.xlsx (ADI is never scraped)
      use_cache    reuse pages already downloaded into partdb.DATA/vendor_cache
    """
    def emit(m):
        if progress:
            progress(m)

    summary = {"sources": [], "errors": [], "parts_ingested": 0}
    if reset:
        # The GUI/CLI pass vendor KEYS ('adi'), but parts are stored under
        # display NAMES ('Analog Devices'). Without translating, a scoped reset
        # matched nothing and silently deleted zero rows.
        scope = None
        if reset_vendors_only and vendors:
            scope = []
            for v in vendors:
                scope.append(v)
                name = vendor_catalogs.VENDORS.get(v, {}).get("name")
                if name and name not in scope:
                    scope.append(name)
        emit("RESET dataset | deleting parts, scrape state and caches"
             + (f" for {', '.join(scope)}" if scope else " (everything)"))
        removed = partdb.reset_dataset(vendors=scope, clear_cache=True,
                                       progress=emit)
        summary["reset"] = removed
        emit(f"RESET DONE | {removed['parts']} part(s) deleted, "
             f"{removed['scrape_log']} scrape-log row(s), "
             f"{removed['cache_files']} cached page(s), "
             f"{removed['datasheet_files']} datasheet file(s)")
        if event:
            try:
                event({"type": "reset", **removed})
            except Exception:
                pass
        # Resume state is meaningless immediately after a reset.
        resume = False

    files: list[tuple[Path, str | None]] = [(Path(f), classify_file(Path(f)))
                                            for f in source_files]
    if source_dir:
        files += scan_dir(source_dir)
    # The Mini-Circuits catalogue JSON lives in Sources and no caller passes it
    # explicitly, so pick it up wherever it is. Without this the adapter is
    # registered and never invoked -- which is the state catalog.py was already
    # in, and the reason no Mini-Circuits part ever reached the dataset.
    try:
        from .paths import SOURCES_ROOT
        for root in (Path(SOURCES_ROOT), Path(NEW_SOURCES)):
            if not root.is_dir():
                continue
            for f in sorted(root.rglob("*minicircuit*.json")):
                # files holds (path, kind) pairs, not bare paths.
                if not any(Path(p0) == f for p0, _k in files):
                    files.append((f, "minicircuits"))
    except Exception as e:
        emit(f"  (could not look for the Mini-Circuits JSON: {e})")

    # everythingRF first (it carries the real manufacturer part numbers that
    # ADI/TI/Qorvo rows later dedupe against).
    if erf_parent and _wanted(sources, "everythingrf"):
        try:
            erf_path = Path(erf_parent)
            ingest_parent, ingest_glob = erf_path, erf_glob
            if erf_path.is_dir() and erf_path.name.lower().startswith("everythingrfspace"):
                ingest_parent, ingest_glob = erf_path.parent, erf_path.name
            emit(f"ingesting everythingRF space folders under {ingest_parent} ...")
            c = erf_space_ingest.ingest(
                ingest_parent, ingest_glob, dry_run=False, verbose=False,
                resume=bool(resume), progress=emit, part=part, cancel=cancel)
            n = c.get("parts", 0)
            summary["parts_ingested"] += n
            summary["sources"].append(("everythingRF", n, c))
            emit(f"  everythingRF: {n} parts "
                 f"({c.get('space_qualified', 0)} qualified, "
                 f"{c.get('space_grade', 0)} grade)")
        except Exception as e:                          # keep going on one bad source
            summary["errors"].append(f"everythingRF: {e}")
            emit(f"  everythingRF FAILED: {e}")
            traceback.print_exc()

    # Every HTML catalog under newSources is a trusted space source. Folder
    # names containing SpaceQual are qualified; names containing Space (but not
    # SpaceQual) are grade; all other newSources folders default to qualified.
    if source_dir:
        html_root = Path(source_dir)
        if html_root.is_dir() and any(html_root.rglob("*.htm*")):
            try:
                emit(f"ingesting trusted space HTML folders under {html_root} ...")
                c = erf_space_ingest.ingest(
                    html_root, "*", dry_run=False, verbose=False,
                    default_variant="space_qualified",
                    resume=bool(resume), progress=emit, part=part,
                    cancel=cancel)
                n = c.get("parts", 0)
                summary["parts_ingested"] += n
                summary["sources"].append(("newSources-html", n, c))
                emit(f"  newSources HTML: {n} parts "
                     f"({c.get('space_qualified', 0)} qualified, "
                     f"{c.get('space_grade', 0)} grade)")
            except Exception as e:
                summary["errors"].append(f"newSources HTML: {e}")
                emit(f"  newSources HTML FAILED: {e}")
                traceback.print_exc()

    for path, kind in files:
        # A file whose source was not selected is left entirely alone: not
        # re-read, and its parts untouched.
        if kind and not _wanted(sources, kind):
            continue
        if kind not in _ADAPTERS:
            summary["errors"].append(f"unrecognized source: {path.name}")
            emit(f"  skipped (unrecognized): {path.name}")
            continue
        try:
            c = _run(kind, path, emit, part=part, resume=bool(resume),
                             categories=categories, cancel=cancel)
            summary["parts_ingested"] += c.get("parts", 0)
            summary["sources"].append((kind, c.get("parts", 0), c))
        except Exception as e:
            summary["errors"].append(f"{path.name}: {e}")
            emit(f"  {path.name} FAILED: {e}")
            traceback.print_exc()

    # --- live vendor catalogues -------------------------------------------
    # Sources map onto the live vendor walks. Selecting sources that include no
    # live catalogue skips the crawl entirely, rather than defaulting to walking
    # every vendor -- which is the behaviour that made "re-run one thing" scrape
    # everything.
    if sources:
        vendors = [v for k, v in _SOURCE_VENDOR.items() if k in set(sources)]
    if vendors:
        emit("")
        try:
            vsum = vendor_catalogs.ingest(
                vendors=vendors, rate=vendor_rate, progress=emit,
                limits=vendor_limits, download=download_datasheets,
                download_limit=download_limit, adi_dir=adi_dir,
                use_cache=use_cache, categories=categories,
                resume=bool(resume), part=part, event=event, cancel=cancel)
            summary["vendors"] = vsum
            for v, info in vsum.get("per_vendor", {}).items():
                n = info.get("parts", 0)
                summary["parts_ingested"] += n
                summary["sources"].append((f"vendor:{v}", n, info))
            summary["errors"].extend(vsum.get("errors", []))
        except Exception as e:
            summary["errors"].append(f"vendor catalogs: {e}")
            emit(f"  vendor catalogs FAILED: {e}")
            traceback.print_exc()

    for line in capability_report():
        emit(line)
    emit("")

    # A short coverage report per vendor, so a missing spec is visible here rather
    # than being discovered later in the picker.
    try:
        conn = partdb.db()
        emit("")
        emit("RF spec coverage by vendor (after this run)")
        emit(f"  {'vendor':<20} {'parts':>6} {'freq':>6} {'gain':>6} {'NF':>6} "
             f"{'P1dB':>6} {'OIP3':>6} {'Psat':>6}")
        for row in conn.execute(
                "SELECT vendor, COUNT(*) n FROM parts GROUP BY vendor "
                "ORDER BY n DESC").fetchall():
            v = row["vendor"] or "(blank)"
            cells = []
            for key in ("freq_ghz", "gain_db", "nf_db", "p1db_dbm",
                        "oip3_dbm", "psat_dbm"):
                cells.append(conn.execute(
                    "SELECT COUNT(DISTINCT s.part_id) n FROM specs s "
                    "JOIN parts p ON p.id = s.part_id "
                    "WHERE p.vendor=? AND s.key=?",
                    (row["vendor"], key)).fetchone()["n"])
            emit(f"  {v[:20]:<20} {row['n']:>6} "
                 + " ".join(f"{c:>6}" for c in cells))
        emit("")
    except Exception as e:
        emit(f"  (coverage report unavailable: {e})")

    # ---- Qorvo parametric tables saved from a browser ------------------------
    # Qorvo's tables are rendered client-side, so they cannot be fetched; they are
    # saved by rfparts_save_pages.py and parsed here. Written through the same
    # write_records() path as a live catalog walk, which matters for conflicts:
    # catalog specs carry confidence 0.8-0.9 while everythingRF writes 0.75, so
    # where both sources state a spec the VENDOR's own figure wins, and where only
    # one states it the value is simply added. put_specs keys on
    # (part_id, key, source_url), so nothing is overwritten -- the two sources
    # union, they do not compete.
    if qorvo_pages is not False and _wanted(sources, "qorvo_pages"):
        qdir = Path(qorvo_pages) if qorvo_pages else QORVO_PAGES
        if qdir.is_dir() and any(qdir.rglob("*.htm*")):
            try:
                emit(f"ingesting saved Qorvo parametric tables from {qdir} ...")
                recs = vendor_catalogs.qorvo_from_folder(qdir, say=emit)
                if recs:
                    written = vendor_catalogs.write_records(
                        recs, emit, source_signal="qorvo-parametric")
                    n = written if isinstance(written, int) else len(recs)
                    summary["parts_ingested"] += n
                    summary["sources"].append(("qorvo-parametric", n,
                                               {"parts": n}))
                    emit(f"  Qorvo parametric: {n} part(s) written")
            except Exception as e:
                summary["errors"].append(f"qorvo parametric: {e}")
                emit(f"  Qorvo parametric FAILED: {e}")
                traceback.print_exc()
        elif qorvo_pages:
            emit(f"  (no saved Qorvo pages under {qdir}; run "
                 f"rfparts_save_pages.py --source qorvo)")

    # ---- fill blanks from the datasheets already on disk ---------------------
    # Catalog listings only tabulate the handful of specs a vendor chose to put
    # in its comparison table. Everything else -- switching speed above all -- is
    # in the datasheet, and nothing in the rebuild path used to open one.
    # Datasheet FOLDERS, before enrichment: parts created here then benefit
    # from the same enrichment pass as everything else.
    for _sk in DATASHEET_SOURCES:
        if not _wanted(sources, _sk):
            continue
        if sources and _sk not in set(sources):
            continue
        emit("")
        try:
            summary.setdefault("datasheet_folders", {})[_sk] = \
                ingest_datasheet_folder(_sk, progress=emit, cancel=cancel,
                                        part=part, event=event)
        except Exception as e:
            import traceback as _tb
            emit(f"  ! {_sk} failed: {type(e).__name__}: {e}")
            _tb.print_exc()

    if mine_datasheets and _wanted(sources, "datasheets"):
        emit("mining local datasheets for specs the listings did not carry ...")
        try:
            from . import dsmine
            conn = partdb.db()
            rows = conn.execute("SELECT id, mpn FROM parts").fetchall()
            index = dsmine.build_index(say=emit)
            if index:
                disk_cache = dsmine.load_cache()
                emit(f"  {len(disk_cache)} datasheet(s) already parsed in a "
                     f"previous run will be reused")
                # Only parts that actually HAVE a datasheet are worth visiting.
                # Checking that first turns a walk over every row in the database
                # into a walk over the few thousand that can yield anything.
                have = [r for r in rows if dsmine.has_datasheet(r["mpn"], index)]
                # Only enrich a part whose datasheet has not already been applied
                # to it. Re-mining a part that was enriched from the same
                # unchanged file on a previous run cannot produce a different
                # answer, so it is pure cost -- and on a 4000-datasheet library
                # that cost was the whole enrichment pass, every rebuild.
                done_map = disk_cache.get("__applied__")
                if not isinstance(done_map, dict):
                    done_map = {}
                todo = []
                for r in have:
                    fkey = dsmine.part_file_key(r["mpn"], index)
                    if fkey and done_map.get(str(r["id"])) == fkey:
                        continue
                    todo.append((r, fkey))
                emit(f"  {len(have)} of {len(rows)} part(s) have a local "
                     f"datasheet; {len(have) - len(todo)} already enriched from "
                     f"the same file, {len(todo)} to do")
                cache, filled, added = {}, 0, 0
                mstats = {"parsed": 0, "reused": 0}
                started = time.time()
                for i, (r, fkey) in enumerate(todo, 1):
                    if _cancelled(cancel):
                        emit("  stop requested; leaving datasheet mining "
                             "(progress is recorded, so resuming is quick)")
                        break
                    mined = dsmine.mine_part(r["mpn"], index, cache,
                                             disk_cache=disk_cache,
                                             stats=mstats)
                    if mined:
                        # Say what was actually found, per part. "N parts
                        # enriched" gives no way to tell a useful pass from one
                        # that filled thousands of fields with nonsense, and this
                        # is the step most likely to introduce a wrong number.
                        before = _existing_spec_values(r["id"])
                        notes = []
                        for row in mined:
                            val = (row.value_text if row.value_text is not None
                                   else row.value_typ)
                            unit = f" {row.unit}" if row.unit else ""
                            old_val = before.get(row.key)
                            if old_val is None:
                                notes.append(f"+{row.key}={val}{unit}")
                            elif str(old_val) != str(val):
                                notes.append(f"~{row.key}={val}{unit} "
                                             f"(had {old_val})")
                            else:
                                notes.append(f"={row.key}")
                        partdb.put_specs(r["id"], mined)
                        filled += 1
                        added += len(mined)
                        if notes:
                            emit(f"    {r['mpn']:<22} "
                                 + ", ".join(notes[:8])
                                 + (f" (+{len(notes) - 8} more)"
                                    if len(notes) > 8 else ""))
                    # Record it either way: a datasheet that yields nothing is
                    # still a question already answered.
                    if fkey:
                        done_map[str(r["id"])] = fkey
                    if i % 250 == 0:
                        rate = i / max(1e-6, time.time() - started)
                        eta = (len(todo) - i) / max(1e-6, rate)
                        emit(f"  {i}/{len(todo)} checked, {filled} enriched, "
                             f"{mstats['parsed']} parsed / "
                             f"{mstats['reused']} reused, eta {eta:.0f}s")
                        disk_cache["__applied__"] = done_map
                        dsmine.save_cache(disk_cache)
                disk_cache["__applied__"] = done_map
                dsmine.save_cache(disk_cache)
                emit(f"  datasheets: {mstats['parsed']} parsed, "
                     f"{mstats['reused']} reused from cache")
                emit(f"  datasheet mining: {filled} part(s) gained "
                     f"{added} spec row(s) (stored at low confidence, so any "
                     f"catalog value still wins)")
                summary["datasheet_mining"] = {"parts": filled, "rows": added,
                                               "indexed": len(index)}
        except Exception as e:
            emit(f"  (datasheet mining unavailable: {e})")
            summary["errors"].append(f"datasheet mining: {e}")

    if dedupe:
        emit("de-duplicating (keeping the richest copy of each part) ...")
        d = partdb.merge_duplicates(progress=None)
        summary["dedupe"] = d
        emit(f"  merged {d['groups']} duplicate group(s), removed {d['deleted']} row(s)")

    summary["stats"] = partdb.dataset_stats()
    s = summary["stats"]
    emit(f"dataset now: {s['parts']} parts, {s['qualified']} space-qualified, "
         f"{s['grade']} space-grade, {s['vendors']} vendors")
    exported = partdb.export_parts_json(EXPORT_DIR)
    summary["json_export"] = exported
    emit(f"normalized JSON export: {exported['parts']} parts -> {exported['folder']}")
    return summary
