"""Central project paths for RF Parts sources, database, caches, and exports."""
from __future__ import annotations
import os
from pathlib import Path

PACKAGE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = PACKAGE_DIR.parent
SOURCES_ROOT = Path(os.environ.get("RFPARTS_SOURCES", PROJECT_ROOT / "Sources")).expanduser()
DATA_ROOT = Path(os.environ.get("RFPARTS_HOME", PROJECT_ROOT / "Data")).expanduser()
DATABASE_DIR = DATA_ROOT / "database"
CACHE_DIR = DATA_ROOT / "cache"
EXPORT_DIR = DATA_ROOT / "parts_json"
ADI_PARAMETRICS = SOURCES_ROOT / "ADIParametrics"
EVERYTHING_RF = SOURCES_ROOT / "EverythingRFSpaceQual"
NEW_SOURCES = SOURCES_ROOT / "newSources"

for folder in (DATA_ROOT, DATABASE_DIR, CACHE_DIR, EXPORT_DIR):
    folder.mkdir(parents=True, exist_ok=True)
