rfparts — parse sample bundle moved to the dialog's action row
=============================================================
12 files. Drop into rfparts/.  Run first:  python -m rfparts.selfcheck


WHERE THE BUTTON IS NOW
-----------------------
Rebuild dataset dialog, bottom action row, left of Cancel and Rebuild:

    [ Create parse sample bundle… ]  PNs per source [2]  [x] cached pages only
                                                        [ Cancel ] [ Rebuild ]

It is a peer action, not a rebuild option: it samples a couple of part numbers per
source, writes nothing to the database, and does not require a scrape. Pressing it
never starts a rebuild.

REMOVED from the build-progress window. You were right that it should not be an
option mid-scrape -- offering it there implied you had to be scraping to get one.

CLI unchanged:  python -m rfparts.cli samples --offline


A BUG I FOUND WHILE MOVING IT
-----------------------------
The dialog section I added last round NEVER EXISTED in your copy. The patch
anchored on

    btns = ttk.Frame(frm)

while your file says

    btns = ttk.Frame(self, padding=(10, 8))

so the widgets were never created -- including self.sample_n -- while
_make_sample_bundle, which reads them, was. Nothing complained: the module
imports, compiles, and passes the dangling-name scan, because self.sample_n is an
ATTRIBUTE, not a name. It would have raised AttributeError the first time you
pressed the button, exactly like the part_cb crash.

That is the third anchor miss on this project, so selfcheck now scans for it:

    unassigned_attributes()  -- reports `self.X.<something>` where nothing in the
                                class ever assigns self.X

It only flags attributes USED AS OBJECTS (self.sample_n.get()), so callbacks
(command=self.destroy), dataclass fields and class constants stay quiet. Verified
both ways: clean on the real tree, and deleting the one line
`self.sample_n = tk.StringVar(...)` produces

    gui.py:2048 RebuildDialog.self.sample_n is used as an object but never
    assigned in the class

selfcheck now has three scans, one per failure mode this project has actually hit:
    module imports + cross-layer signatures   (missing paths.py, reset_dataset)
    dangling names                            (part_cb, _stopped, url in walkers)
    unassigned attributes                     (this one)


ALSO IN THIS ZIP
----------------
Everything from the previous two rounds, unchanged and still verified:
the bundle itself (folder per vendor, source bytes + parse reports + parts.json,
spreadsheet excerpts keeping the raw =HYPERLINK formula, offline by default),
the everythingRF resume path-normalisation, the ADI description fallback
(158 -> 42 parts without RF specs), space classification routed by source,
insertion-loss-as-NF for passives, the vendor-scoped health windows, the
scrollable vendor panel, and the parse inspector by vendor including local files.


NOT TESTED HERE
---------------
No Tk, so the button's position on the action row is verified by pack order and by
AST assertions that the handler and its two variables exist -- not by eye.
