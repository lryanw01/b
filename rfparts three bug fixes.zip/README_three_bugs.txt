rfparts — fixes for the three problems you hit
=============================================
4 files, all modified. Drop into rfparts/ over the existing ones.

Run this first; it now catches all three classes of fault:
    python -m rfparts.selfcheck


1. RESET: "name 'part_cb' is not defined"
-----------------------------------------
erf_space_ingest.ingest() USED part_cb (line 840) and _stopped (line 850) but
DEFINED neither. My previous patch anchored on

    def emit(message):

while your file actually says

    def emit(message: str) -> None:

so the two helper definitions were never inserted, while the call sites that
depend on them were. The module still imported and still compiled -- it only blew
up when that branch ran, which is why it survived until you pressed Reset.

Both helpers are now defined at the top of ingest(). part_cb is a deliberate
alias: `part` is rebound as a loop variable further down, so using the parameter
name directly would have shadowed the callback.

AND, so this cannot happen a fourth time, selfcheck now does a scope walk over
every shipped module and fails on any name that is read but never bound. It found
three more live instances of exactly this fault in my own earlier patches:

    vendor_catalogs.py:625  walk_macom()    resume.mark(url, ...)   -> loop var is `u`
    vendor_catalogs.py:722  walk_skyworks() resume.mark(url, ...)   -> loop var is `u`
    vendor_catalogs.py:930  walk_marki()    resume.mark(url, ...)   -> `url` unbound

The first two would have raised NameError on the first successful MACOM or
Skyworks walk that produced parts. The third raised UnboundLocalError whenever a
category filter skipped every Marki category. All fixed and regression-tested.
(The checker's first version had the very bug it detects -- it used Path without
importing it. Fixed too.)


2. MARKI PRODUCED NO SPECS
--------------------------
The parser was fine: run it against your ADM-10699PSM HTML on its own and it
returns 15 specs (gain 15.1 dB, NF 2.3 dB, OIP3 24 dBm, P1dB 12.5 dBm, isolation
21 dB, 2-20 GHz). The PIPELINE was wrong.

walk_marki streams parts to the database in batches of 15 DURING ENUMERATION
(flush() at the listing stage). The /datasheet/ pages -- the only place Marki
specs exist -- are not read until afterwards. So every Marki row was committed
with an empty spec set, and the specs parsed later were then blocked from being
written by the streamed_keys guard that stops double-writing.

Records are now re-emitted as UPDATES after the datasheet pass:
flush(update=True), and stream_records() bypasses streamed_keys when update=True.
upsert_part + put_specs are idempotent, so the specs simply fill in.

Verified end to end: the DB row for ADM-10699PSM now carries 15 spec rows,
including freq_ghz 2.0-20.0, gain_db 15.1, nf_db 2.3, oip3_dbm 24.

Also fixed in walk_marki: my earlier edit had left the per-category reporting
nested inside `if resume:` at the wrong indentation level, so with resume off you
got no per-category log line at all, and a duplicate resume.mark() at form level
referenced whatever page happened to be last.


3. ADI PARAMETRICS WERE PARSED, BUT MOST COLUMNS WERE DISCARDED
---------------------------------------------------------------
Every row parsed and every row had *some* specs, which is why it looked like it
worked. But the column map only recognised about half the sheet. Silently dropped
across the nine workbooks:

    Package              (unmapped in EIGHT of nine sheets -- no package data
                          reached the database at all)
    Package Area, Package Height, Availability
    IIP3 typ             (mixers and switches -- the pattern was ^oip3, so IIP3
                          never matched)
    IP-0.1 dB typ        switch compression
    Switching Speed typ
    Bandwidth -3 dB
    Max Average RF Power
    Return Loss Typ
    Residual Phase Noise typ
    Frequency Response IF min/max     mixer IF range -- gone entirely
    Frequency Response LO min/max     mixer LO range -- gone entirely
    Specified at Frequency
    Phase Adjust / Phase Shifter Resolution
    Frequency Cuttoff Range           (their typo, now matched)
    RF Amp Type / Attenuator Type / RF Mixer Type / Configuration / Filter Type
                                      the vendor's own classification

All nine workbooks now map every column. The IF/LO patterns are ordered BEFORE
the generic RF ones on purpose: a mixer sheet carries "Frequency Response IF min"
alongside "Frequency Response min", and matching the generic pattern first would
swallow the qualified ones.

A SIGN BUG worth knowing about. ADI's mixer column is "Conversion Gain" in dB
with a meaningful sign: +10 for an active mixer, -10 for a passive one (i.e. 10 dB
of loss). It was being filed straight into conversion_loss_db, so a passive mixer
recorded -10 dB of "loss" -- which passes any "loss below N dB" filter you would
ever write. Now stored as conversion_gain_db with the sign intact, and when the
gain is negative a positive conversion_loss_db is derived alongside it. Verified:
ADH1015S gain=+10 loss=none; ADH1048AS gain=-10 loss=10. The same ambiguity
existed in the vendor walkers and is fixed there too.

Coverage after the fix (1044 ADI parts):
    temp_min/max 1004   freq_ghz 878   device_type 852   price 775
    package 480   nf 382   gain 375   oip3 374   p1db 317
    package_height 282  package_area 278  availability 255  iip3 241


REGRESSION RUN (simulated network, your real HTML and spreadsheets)
------------------------------------------------------------------
    run 1  resume on                    5 parts, 3 with specs, no errors
    run 2  resume on, same sources       0 parts  (all work correctly skipped)
    run 3  categories=[attenuator]       1 part,  1 with specs, no errors
    DB: Marki 15 spec rows, Qorvo 6, MACOM 2, Skyworks 1
    reset + re-ingest ADI: 1044 parts, no errors

Still not exercised here: no Tk and no live network. The GUI is unchanged by this
patch. If Marki still comes back specless on your machine, run
    python -m rfparts.parse_debug <the cached datasheet page> --vendor marki
and send me that report -- it prints the pipe-table column mapping and every
parsed value beside the raw cell it came from.
