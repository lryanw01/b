"""Extract text from product pages / datasheets and mine RF specs with regex.

`page_text()` returns (visible_text, datasheet_pdf_url_or_None).
`pdf_text()` pulls text from the linked datasheet (first few pages).
`extract_specs()` returns a mined specs dict. Catalog candidates ("_catalog")
start from the structured specs the catalog loader already mapped (in "_specs")
and only fill gaps from their text blob — no network. Datasheet PDF parsing is
the slow, GIL-holding step; set RFPARTS_PDF=0 to skip it.

Mini-Circuits port counts are never guessed or fetched live here: they come only
from the standalone S-parameter cache (see minicircuits_cache), which a separate
root-level scanner maintains. This module only reads that cache.
"""
import io
import os
import re
import time
from urllib.parse import urljoin

from bs4 import BeautifulSoup

from . import fetch, minicircuits_cache, timing
from re import error
from .registry import PARAM_SPECS

PARSE_PDF = os.environ.get("RFPARTS_PDF", "1") != "0"

# Precompiled regexes for the optional parametric specs (NF, P1dB, OIP3, ...).
_PARAM_PATTERNS = {
    key: [re.compile(p, re.I) for p in meta["patterns"]]
    for key, meta in PARAM_SPECS.items()
}

# --- spec-mining patterns -------------------------------------------------
FREQ = re.compile(r"(\d+(?:\.\d+)?)\s*(?:GHz)?\s*(?:-|–|—|to)\s*(\d+(?:\.\d+)?)\s*GHz", re.I)
FREQ_DC = re.compile(r"\bDC\s*(?:-|–|—|to)\s*(\d+(?:\.\d+)?)\s*GHz", re.I)
FREQ_MHZ = re.compile(r"(\d+(?:\.\d+)?)\s*(?:MHz)?\s*(?:-|–|—|to)\s*(\d+(?:\.\d+)?)\s*MHz", re.I)
FREQ_DC_MHZ = re.compile(r"\bDC\s*(?:-|–|—|to)\s*(\d+(?:\.\d+)?)\s*MHz", re.I)
GAIN = re.compile(r"gain[^.\n\r]{0,60}?(\d{1,2}(?:\.\d+)?)\s*dB", re.I)
NOISE_K = re.compile(r"noise\s+temp\w*[^.\n\r]{0,40}?(\d+(?:\.\d+)?)\s*K", re.I)
NOISE_NF = re.compile(r"noise\s+figure[^.\n\r]{0,40}?(\d+(?:\.\d+)?)\s*dB", re.I)
ATTEN = re.compile(r"(\d{1,2}(?:\.\d+)?)\s*dB\b", re.I)

# --- attenuation mining (attenuator-type categories only) -----------------
# Historically the ATTEN regex above was defined but never called, so the
# 'atten' criterion was always unknown. These are used, in priority order, only
# for attenuator categories (a bare 'N dB' or a '-NN' model suffix is meaningful
# for a pad but noise for an amplifier, e.g. the '103' in 'PGA-103+').
ATTEN_LABELED = re.compile(
    r"attenuat(?:ion|or)[^.\n\r]{0,25}?(\d{1,3}(?:\.\d+)?)\s*dB", re.I)
ATTEN_NAME_DB = re.compile(r"\b(\d{1,3}(?:\.\d+)?)\s*dB\b", re.I)
ATTEN_MODEL_SUFFIX = re.compile(r"[-_](\d{1,3})(?:dB)?(?=[-_+]|$)", re.I)
ATTEN_CATEGORIES = {"attenuator"}

# --- physical dimension mining (L x W x H in inches / mm / cm) -------------
_DIM_UNIT = r"(?:in\b|inch(?:es)?|\"|mm|cm)"
DIM_LWH_EACH = re.compile(
    r"(\d+(?:\.\d+)?)\s*" + _DIM_UNIT + r"\s*[x\u00d7]\s*"
    r"(\d+(?:\.\d+)?)\s*" + _DIM_UNIT + r"\s*[x\u00d7]\s*"
    r"(\d+(?:\.\d+)?)\s*(" + _DIM_UNIT + r")", re.I)
DIM_LWH = re.compile(
    r"(\d+(?:\.\d+)?)\s*[x\u00d7]\s*(\d+(?:\.\d+)?)\s*[x\u00d7]\s*"
    r"(\d+(?:\.\d+)?)\s*(" + _DIM_UNIT + r")", re.I)
DIM_LW_EACH = re.compile(
    r"(\d+(?:\.\d+)?)\s*" + _DIM_UNIT + r"\s*[x\u00d7]\s*"
    r"(\d+(?:\.\d+)?)\s*(" + _DIM_UNIT + r")", re.I)
DIM_LW = re.compile(
    r"(\d+(?:\.\d+)?)\s*[x\u00d7]\s*(\d+(?:\.\d+)?)\s*(" + _DIM_UNIT + r")", re.I)
IMPEDANCE = re.compile(r"\b(33|50|75|90|100|300)\s*(?:Ω|ohm|ohms)\b", re.I)
PRICE = re.compile(r"\$\s?([\d,]{1,9}(?:\.\d{2})?)")
CRYO = re.compile(r"cryogenic|cryo\b|\b4\s?K\b|milli-?kelvin|\bmK\b", re.I)
CONNECTOR = re.compile(
    r"\b(SMA|2\.92\s?mm|2\.4\s?mm|1\.85\s?mm|K[-\s]?connector|N[-\s]?type|"
    r"SMP|SMPM|TNC|BNC|GPO|G3PO)\b", re.I)
BULKHEAD = re.compile(r"bulkhead|feed-?through|hermetic", re.I)
LEAD = re.compile(
    r"lead\s*time[^.\n\r]{0,25}?(\d+)(?:\s*[-–]\s*(\d+))?\s*(day|week|month)", re.I)
IN_STOCK = re.compile(r"\bin stock\b|ready to ship|ships (?:today|same day)|available now", re.I)
ERROR_TITLE = re.compile(
    r"page not found|\b404\b|\b403\b|access denied|forbidden|error", re.I)
PN_IMP_PREFIX = re.compile(r"\b(50|75|33|90|100)S", re.I)
PN_IMP_SUFFIX = re.compile(r"[-_](50|75|33)(?=\D|$)")
THROWS = re.compile(r"\bSP(\d{1,2}|S|D)T\b", re.I)
NWAY = re.compile(r"\b(\d{1,2})[-\s]?way\b", re.I)
NPORT = re.compile(r"\b(\d{1,2})[-\s]?ports?\b", re.I)
ONE_P_N_T = re.compile(r"\b1P(\d{1,2})T\b", re.I)
DPDT = re.compile(r"\bDPDT\b", re.I)
CHANNELS = re.compile(r"\b(\d{1,2})[-\s]?channels?\b", re.I)

# --- package / interface patterns (surface-mount vs connectorized) --------
DIE = re.compile(r"\bbare[-\s]?die\b|\bdie[-\s]?form\b|\bMMIC die\b|wire[-\s]?bond(?:able)?", re.I)
SMT = re.compile(
    r"surface[-\s]?mount|\bSMT\b|drop[-\s]?in|\bQFN\b|\bLGA\b|land[-\s]?grid|"
    r"land[-\s]?pattern|solderable|reflow|castellat", re.I)
CONNECTORIZED = re.compile(
    r"connectori[sz]ed|coaxial (?:module|package|assembly)|"
    r"(?:SMA|N[-\s]?type|2\.92\s?mm) (?:in|out|input|output|female|male|connector)", re.I)
# A STRONGER connectorized signal: the part itself is called connectorized /
# coaxial, or a connector is named as the part's own I/O. Deliberately excludes
# bare "SMA connectors" / "SMA male" phrasing, which shows up when a datasheet
# merely describes an evaluation board or a connector *option* for an otherwise
# surface-mount module. Used to stop those mentions flipping SMT modules.
STRONG_CONNECTORIZED = re.compile(
    r"connectori[sz]ed|coaxial\s+(?:module|package|assembly|component|connector)|"
    r"(?:SMA|N[-\s]?type|2\.92\s?mm|2\.4\s?mm|1\.85\s?mm|BNC|TNC|SMP|SMPM|GPO|G3PO)"
    r"\s*(?:input|output|in/out|i/o|port)\b", re.I)
FLANGE = re.compile(r"flange[-\s]?mount|\bflange\b", re.I)

# --- space / hi-rel qualification signals ---------------------------------
SPACE_QUAL = re.compile(
    r"space[-\s]?(?:qualified|qualification|grade|graded|level|flight|rated|ready)|"
    r"flight[-\s]?(?:qualified|proven|heritage)|qualified for space|"
    r"space[-\s]?heritage|for space applications|"
    r"rad(?:iation)?[-\s]?hard(?:ened|ness)?|ESCC|ECSS|NASA[-\s]?EEE|"
    r"MIL-PRF-38534|MIL-PRF-38535|QMLV|QML[-\s]?V", re.I)
HIREL = re.compile(
    r"hi-?rel\b|high[-\s]?reliability|MIL-PRF-3853[45]|MIL-STD-883|MIL-STD-750|"
    r"\bclass\s?[KHS]\b|\bQML\b|QMLH|screen(?:ed|ing)|upscreen|"
    r"rad(?:iation)?[-\s]?tolerant|\bTID\b|\bSEE\b|single[-\s]?event|"
    r"hermetic(?:ally)?|space[-\s]?grade", re.I)


def page_text(url):
    """Return product-focused visible text and a datasheet URL.

    Navigation, headers, footers, sidebars, and related-product carousels are
    removed before mining. This prevents topology phrases from unrelated menu
    items (for example, "8-way") from being mistaken for the current part.
    """
    html = fetch.get(url)
    if not html:
        return "", None
    soup = BeautifulSoup(html, "html.parser")

    # Save PDF links before pruning the document.
    pdf = None
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if href.lower().endswith(".pdf") and re.search(r"datasheet|spec|data-sheet", href, re.I):
            pdf = urljoin(url, href)
            break
    if pdf is None:
        for a in soup.find_all("a", href=True):
            if a["href"].lower().endswith(".pdf"):
                pdf = urljoin(url, a["href"])
                break

    for tag in soup(["script", "style", "noscript", "nav", "header", "footer", "aside"]):
        tag.decompose()
    for selector in (
        ".related", ".related-products", ".upsells", ".cross-sells",
        ".woocommerce-breadcrumb", ".sidebar", ".menu", "#menu",
        "[class*='related-product']", "[class*='product-category']",
    ):
        for tag in soup.select(selector):
            tag.decompose()

    # Prefer the actual product/article container when one exists.
    root = None
    for selector in (
        "main", "article.product", ".single-product-main-image + div",
        ".product", ".entry-content", "#main", "article",
    ):
        root = soup.select_one(selector)
        if root is not None and len(root.get_text(" ", strip=True)) >= 80:
            break
    if root is None:
        root = soup
    text = root.get_text(" ", strip=True)
    return text, pdf


def pdf_text(url, max_pages=4):
    with timing.span("pdf_total"):
        data = fetch.get(url, binary=True)
        if not data:
            return ""
        try:
            import pdfplumber

            parts = []
            with timing.span("pdf_parse_cpu"):
                with pdfplumber.open(io.BytesIO(data)) as pdf:
                    for page in pdf.pages[:max_pages]:
                        parts.append(page.extract_text() or "")
            return "\n".join(parts)
        except Exception:
            return ""


def _lead_weeks(text):
    m = LEAD.search(text)
    if m:
        lo = int(m.group(1))
        unit = m.group(3).lower()
        mult = {"day": 1 / 7, "week": 1, "month": 4.3}[unit]
        return round(lo * mult, 1)
    if IN_STOCK.search(text):
        return 0.0
    return None


def _freq_ghz(text):
    m = FREQ.search(text)
    if m:
        return [float(m.group(1)), float(m.group(2))]
    m = FREQ_DC.search(text)
    if m:
        return [0.0, float(m.group(1))]
    m = FREQ_MHZ.search(text)
    if m:
        return [float(m.group(1)) / 1000, float(m.group(2)) / 1000]
    m = FREQ_DC_MHZ.search(text)
    if m:
        return [0.0, float(m.group(1)) / 1000]
    return None


def _impedance_ohm(text, name="", vendor=""):
    """Characteristic impedance in ohms. Prefers an explicit unit in text,
    then whitelisted part-number patterns (JFW '<Z>S...', trailing '-75')."""
    m = IMPEDANCE.search(text)
    if m:
        return float(m.group(1))
    nm = str(name).upper()
    vendor_name = str(vendor).lower()
    # JFW model numbers encode impedance as the leading 50/75 before the family
    # letters (50S..., 50P..., 75PA..., 50PD..., etc.). Titles often contain
    # text before the model, so search for the model token instead of matching
    # only at character zero.
    if "jfw" in vendor_name:
        m = re.search(r"(?<!\d)(50|75)(?=[A-Z]{1,4}[-\d])", nm)
        if m:
            return float(m.group(1))
    m = PN_IMP_PREFIX.search(nm)
    if m:
        return float(m.group(1))
    m = PN_IMP_SUFFIX.search(nm)
    if m:
        return float(m.group(1))
    return None


def _mount_type(text, has_connector):
    if DIE.search(text):
        return "die"
    if SMT.search(text):
        return "smt"
    if CONNECTORIZED.search(text) or has_connector:
        return "connectorized"
    if FLANGE.search(text):
        return "flange"
    return "unknown"


def _space_signal(text):
    if SPACE_QUAL.search(text):
        return "qualified"
    if HIREL.search(text):
        return "hi_rel"
    return "none"


def _throws(tok):
    return {"S": 1, "D": 2}.get(tok.upper(), int(tok) if tok.isdigit() else None)


def _infer_category(name, category=""):
    """Repair broad/misclassified sitemap categories from the product title."""
    t = str(name).lower()
    for key, canon in (
        ("attenuator", "attenuator"), ("termination", "termination"),
        ("terminator", "termination"), ("power divider", "divider"),
        ("power splitter", "divider"), ("combiner", "divider"),
        ("coupler", "coupler"), ("circulator", "circulator"),
        ("isolator", "isolator"), ("mixer", "mixer"),
        ("amplifier", "amplifier"), ("filter", "filter"),
        ("dc block", "dc_block"), ("switch", "switch"),
    ):
        if key in t:
            return canon
    return str(category).lower()


def _ports(text, category="", name=""):
    """Return physical RF-port count using product-local text only.

    Explicit port counts and switch topologies win. "N-way" is interpreted as
    N+1 only for dividers/combiners or when the nearby text explicitly names a
    divider/splitter/combiner, avoiding menu and unrelated-product false hits.
    """
    local = f"{name} {text}"
    cat = _infer_category(name or text[:200], category)

    m = NPORT.search(local)
    if m:
        return int(m.group(1))
    if DPDT.search(local):
        return 4
    m = ONE_P_N_T.search(local)
    if m:
        return int(m.group(1)) + 1
    m = THROWS.search(local)
    if m:
        t = _throws(m.group(1))
        if t:
            return t + 1

    if cat == "divider":
        m = NWAY.search(local)
        if m:
            return int(m.group(1)) + 1

    if CHANNELS.search(local):
        return None
    return {
        "termination": 1, "attenuator": 2, "dc_block": 2, "filter": 2,
        "amplifier": 2, "lna": 2, "isolator": 2, "circulator": 3,
        "mixer": 3, "coupler": 4,
    }.get(cat)


def _attenuation_db(name, text, category):
    """Attenuation in dB for attenuator-type parts, or None.

    Priority: an explicitly labeled value ('10 dB attenuation') anywhere, then a
    bare 'N dB' in the compact product name, then a trailing model-number suffix
    ('PE7003-10' -> 10). Only runs for attenuator categories so a stray dB figure
    (return loss, VSWR spec, an amplifier's '-103' family number) isn't mistaken
    for attenuation.
    """
    if category not in ATTEN_CATEGORIES:
        return None
    m = ATTEN_LABELED.search(text) or ATTEN_LABELED.search(name)
    if m:
        try:
            return float(m.group(1))
        except (TypeError, ValueError):
            pass
    m = ATTEN_NAME_DB.search(name)   # name is compact + low-noise
    if m:
        try:
            return float(m.group(1))
        except (TypeError, ValueError):
            pass
    m = ATTEN_MODEL_SUFFIX.search(name)
    if m:
        try:
            v = float(m.group(1))
            if 0 <= v <= 120:        # a sane attenuation range in dB
                return v
        except (TypeError, ValueError):
            pass
    return None


def _norm_unit(u):
    u = (u or "").strip().lower()
    if u in ('"', "in", "inch", "inches"):
        return "in"
    return u  # mm or cm


def _dimensions(name, text):
    """Best-effort physical size as {l, w, h?, unit, raw}, or None.

    Tries, in order: L x W x H with a unit after each number, L x W x H with one
    trailing unit, then the two-dimensional variants. The compact product name is
    searched before the noisier page text. Single lone measurements are not
    stored (too easily a connector diameter / center-pin length).
    """
    for src in (name, text):
        if not src:
            continue
        m = DIM_LWH_EACH.search(src) or DIM_LWH.search(src)
        if m:
            unit = _norm_unit(m.group(4))
            return {"l": float(m.group(1)), "w": float(m.group(2)),
                    "h": float(m.group(3)), "unit": unit,
                    "raw": re.sub(r"\s+", " ", m.group(0)).strip()}
        m = DIM_LW_EACH.search(src) or DIM_LW.search(src)
        if m:
            unit = _norm_unit(m.group(3))
            return {"l": float(m.group(1)), "w": float(m.group(2)),
                    "unit": unit,
                    "raw": re.sub(r"\s+", " ", m.group(0)).strip()}
    return None


def _mine_text(text, name, specs, category="", vendor=""):
    """Fill any specs not already present by mining `text` (+ `name`)."""
    if "freq_ghz" not in specs:
        # Product titles are compact and far less noisy than full page text.
        fg = _freq_ghz(name) or _freq_ghz(text)
        if fg:
            specs["freq_ghz"] = fg
    if "gain_db" not in specs:
        g = GAIN.search(text)
        if g:
            specs["gain_db"] = float(g.group(1))
    if "noise_k" not in specs:
        nk = NOISE_K.search(text)
        if nk:
            specs["noise_k"] = float(nk.group(1))
    if "cryo" not in specs and CRYO.search(text):
        specs["cryo"] = True
    if "attenuation_db" not in specs:
        att = _attenuation_db(name, text, category)
        if att is not None:
            specs["attenuation_db"] = att
    if "dimensions" not in specs:
        dims = _dimensions(name, text)
        if dims:
            specs["dimensions"] = dims
    # Optional parametric specs (noise figure, P1dB, OIP3, isolation, ...): only
    # mine ones not already provided as structured specs (e.g. Mini-Circuits
    # specs or DigiKey mapped parameters).
    for key, patterns in _PARAM_PATTERNS.items():
        if key in specs and specs[key] is not None:
            continue
        meta = PARAM_SPECS[key]
        # Most parametric specs have one fixed unit (dB, dBm, W) so the captured
        # number is the value. Some do not: switching speed is quoted in ns, us
        # or ms, and storing the bare number would make 2 ms look faster than
        # 50 ns. When the spec declares unit_group, that group is normalised
        # through unit_scale into the spec's canonical unit.
        ugroup = meta.get("unit_group")
        uscale = meta.get("unit_scale") or {}
        for pat in patterns:
            m = pat.search(text)
            if not m:
                continue
            try:
                value = float(m.group(1))
            except (TypeError, ValueError):
                continue
            if ugroup:
                try:
                    unit = (m.group(ugroup) or "").strip().lower()
                except (IndexError, error):
                    unit = ""
                factor = uscale.get(unit)
                if factor is None:
                    continue        # unknown/absent unit: refuse to guess
                value *= factor
            specs[key] = value
            break
    if "connector" not in specs:
        conn = CONNECTOR.search(text)
        if conn:
            specs["connector"] = conn.group(1).upper().replace(" ", "")
    if "bulkhead" not in specs and BULKHEAD.search(text):
        specs["bulkhead"] = True
    if "lead_weeks" not in specs:
        lw = _lead_weeks(text)
        if lw is not None:
            specs["lead_weeks"] = lw
    if "price_usd" not in specs:
        pr = PRICE.search(text)
        if pr:
            try:
                specs["price_usd"] = float(pr.group(1).replace(",", ""))
            except ValueError:
                pass
    if "impedance_ohm" not in specs:
        # Prefer the title/model before page text, which may contain related
        # products with a different impedance.
        z = _impedance_ohm(name, name, vendor) or _impedance_ohm(text, name, vendor)
        if z is not None:
            specs["impedance_ohm"] = z
    if "ports" not in specs:
        p = _ports(text, category, name)
        if p is not None:
            specs["ports"] = p
    if "mount_type" not in specs:
        specs["mount_type"] = _mount_type(text, "connector" in specs)
    if "space" not in specs:
        # Space / hi-rel wording appears in the product title as often as the body
        # (e.g. "…, Space Qualified" or an "-S" / "MIL" grade suffix), so scan both.
        sig = _space_signal(f"{name}\n{text}")
        if sig != "none":
            specs["space"] = sig
    return specs


def extract_specs(candidate):
    """Return a mined specs dict. Catalog candidates start from prebuilt
    structured specs; live candidates fetch the page (+ datasheet)."""
    name = candidate.get("title", "")
    category = candidate.get("category", "")
    vendor = candidate.get("vendor", "")
    if candidate.get("_catalog"):
        _t0 = time.perf_counter()
        specs = dict(candidate.get("_specs") or {})
        text = candidate.get("text", "")
        if not specs and not text:
            return {"_error": True}
        specs = _mine_text(text, name, specs, category, vendor)
        # Mini-Circuits discovery is catalog-based, but the RF port count and its
        # S-parameter provenance must come only from the standalone background
        # scanner cache — never from a catalog/topology guess and never from a
        # live network request. Drop any guessed fields, then overlay the cache.
        if vendor == "Mini-Circuits":
            for key in ("ports", "ports_source", "sparams_url", "sparams_filename"):
                specs.pop(key, None)
            cached = minicircuits_cache.cached_for(candidate)
            for key, value in cached.items():
                if value is not None:
                    specs[key] = value
            # Guard against evaluation-board / connector-option text flipping a
            # surface-mount module to "connectorized". Only keep connectorized
            # when the catalog interface field said so, or the text explicitly
            # calls the PART connectorized/coaxial or names a connector as its own
            # I/O (STRONG_CONNECTORIZED) — not a bare "SMA connectors" mention.
            if specs.get("mount_type") == "connectorized":
                catalog_mount = (candidate.get("_specs") or {}).get("mount_type")
                strong = bool(STRONG_CONNECTORIZED.search(text)) or \
                    bool(STRONG_CONNECTORIZED.search(name))
                if catalog_mount != "connectorized" and not strong:
                    specs["mount_type"] = "smt"
            # Most Mini-Circuits parts that aren't explicitly connectorized (or
            # die/flange) are surface-mount; default the leftover "unknown" mounts.
            if specs.get("mount_type") in (None, "", "unknown"):
                specs["mount_type"] = "smt"
        timing.record("extract_catalog", time.perf_counter() - _t0, vendor=vendor)
        return specs

    _t0 = time.perf_counter()
    with timing.span("page_text"):
        text, pdf = page_text(candidate["url"])
    if not text or (ERROR_TITLE.search(name) and len(text) < 200):
        timing.record("extract_live", time.perf_counter() - _t0, vendor=vendor,
                      label=f"{vendor} ERROR {candidate['url'][:70]}")
        return {"_error": True}
    if pdf and PARSE_PDF and not fetch.cancelled():
        text = text + "\n" + pdf_text(pdf)
    specs = _mine_text(text, name, {}, category, vendor)
    if pdf:
        specs["datasheet"] = pdf
    timing.record("extract_live", time.perf_counter() - _t0, vendor=vendor,
                  label=f"{vendor} {'+pdf ' if (pdf and PARSE_PDF) else ''}{candidate['url'][:70]}")
    return specs
