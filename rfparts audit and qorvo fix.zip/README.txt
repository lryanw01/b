rfparts — Qorvo categories, everythingRF resume, and the missing-spec audit
==========================================================================
7 files: 1 new, 6 modified. Drop into rfparts/.
Run first:  python -m rfparts.selfcheck


1. (NOT CHANGED) everythingRF qualified/grade
---------------------------------------------
You were right and I was wrong. EverythingRFSpaceAmps IS a grade folder, and
EverythingRFSpaceQualAmplifiers would be qualified. The leaf-folder rule is
correct. Untouched.


2. QORVO CATEGORIES — FIXED
---------------------------
Every Qorvo part was filed as "ic". The section titles are not
"<h2>Name (21)</h2>"; a real page says

    <h3 class="pst-header-title">Digital Step Attenuators
        <span class="pst-header-amount">(21)</span></h3>

The count sits in a NESTED span, so my [^<] run stopped before it and the pattern
matched nothing, leaving every section unnamed. Now keyed on
class="pst-header-title", with the old pattern kept as a fallback.

Against your two bundled pages:
    ca0021   was: ic x106      now: attenuator 47, limiter 15, phase_shifter 13
    ca0118   was: ic x106      now: amplifier, filter 18, switch 4,
                                    transceiver 6, power 7  (+ 66 genuine ICs)


3. EVERYTHINGRF RESUME — TWO REAL CAUSES FIXED
----------------------------------------------
(a) The per-file signature included st_mtime_ns. Re-extracting the zip, copying
    the Sources tree, or a sync client touching the files all change mtime while
    the bytes are identical -- and every page then looked modified. The signature
    is now size + a hash of the first and last 8 kB: cheap, and stable across
    copies. Existing checkpoints are migrated when the size still matches, so
    nothing is thrown away on upgrade.
    Verified: run 2 skips the source; run 3 after touching every mtime still
    skips it.

(b) A run that was STOPPED, or that hit page errors, still wrote
    source_complete=True. That is worse than re-parsing: it makes every later run
    skip the remainder permanently. The flag is now withheld, with the reason
    stated in the log.

Every run now ends with one line that settles the question:
    RESUME SUMMARY | 586 file(s) in source, 586 skipped by resume, 0 parsed,
                     source_complete=True
If it still re-parses, that line plus the RESUME STATE block above it says why.


4. NEW: MISSING-SPEC AUDIT  ("Audit missing specs…" in the main window)
----------------------------------------------------------------------
    GUI :  main part-picker window, next to "Debug selected…"
    CLI :  python -m rfparts.cli audit --per-vendor 3
           python -m rfparts.cli audit --category amplifier --missing nf_db

For a sample of parts that lack an expected spec, it finds the file the part was
parsed from, re-runs the parser on it, and returns one of three verdicts per
missing spec:

    STALE ROW      the parser extracts it from that source TODAY -- the stored
                   row predates a parser fix. Re-ingest and the gap closes.
    PARSER GAP     the source states the value and we miss it. Actionable, and
                   verdict.txt quotes the exact source text we failed to read.
    NOT IN SOURCE  the source never stated it. Nothing to fix.
    NO SOURCE      no file on disk mentions that part number.

The zip holds, per part: the source file (for a spreadsheet, the header plus that
part's own rows), what the parser gets from it now, and the verdict with the source
quoted. Plus summary.txt and findings.csv for sorting. Nothing is written to the
database.


IT FOUND A REAL GAP ON ITS FIRST RUN
------------------------------------
Against your bundled everythingRF pages it reported 16 PARSER GAPs, all psat_dbm,
quoting source text like

    "Frequency: 600 to 2600 MHz Gain: 41 dB Output Power: 3.16 W"

everythingRF quotes output power in WATTS, so we stored power_w only -- correct,
but the filters, the ranking code and the coverage report all speak dBm, so the
value was effectively invisible. psat_dbm is now derived alongside it
(3.16 W -> 35 dBm, 20 W -> 43 dBm, 0.0001 W -> -10 dBm).

Re-ran the audit after the fix: 16 parser gaps -> 0. That is the loop working.

Two false-positive classes I had to remove first, worth knowing about because they
would have wasted your time:
  * searching the WHOLE page for evidence found some other part's "gain" on a
    24-part listing and declared a gap for every row (410 findings). Evidence is
    now scoped to the region around that part number.
  * substring matching over raw HTML matched "sel" inside "Select to compare"
    (71 false SEL findings) and "outline" inside the CSS class
    "btn-outline-primary" (42 false package findings). Now word-boundary regexes
    over VISIBLE TEXT with the markup stripped.
  * the inspector had no everythingRF branch, so it reported zero parsed parts for
    every erf page and the audit blamed the parser for all of them. Added.

Final ratio on your data: 370 NOT IN SOURCE, 0 PARSER GAP, 1 NO SOURCE -- i.e.
almost every remaining gap is genuinely absent from everythingRF, which is the
answer you wanted.


NOT TESTED HERE
---------------
No Tk, so the new main-window button is verified by AST assertion
(App.audit_missing_specs) and by driving build_audit directly, not by eye.
