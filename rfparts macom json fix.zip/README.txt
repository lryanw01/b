rfparts — MACOM parametrics, ADI space frequency, and an audit correction
========================================================================
3 files, all modified. Drop into rfparts/.
Run:  python -m rfparts.selfcheck


FIRST, AN IMPORTANT CORRECTION TO MY LAST MESSAGE
-------------------------------------------------
I told you 92 NOT IN SOURCE vs 7 PARSER GAP meant the evidence matching was
trustworthy. For EverythingRF and the two ADI sources that holds. For QORVO,
MARKI and SKYWORKS it did not, and the audit itself was at fault.

Every Qorvo sample in your report says something like

    other sources    10 more mention this part

and the audit judged the part against ONE arbitrarily chosen file. For Qorvo a
part appears on several categoryID pages, and for Marki/Skyworks the listing page
mentions it while the specs live on its own page. Picking the wrong file yields
NOT IN SOURCE for a value that is sitting in a file we already have. So those
verdicts were false negatives -- the mirror of the false positives I fixed last
round. QPK1520 had 10 candidate sources and only package data stored; that verdict
should not be believed.

FIXED: the audit now ranks every candidate source by how much the parser gets out
of it, judges against the best one, and only returns NOT IN SOURCE when NO
candidate states the value. If another source does state it the verdict becomes
STALE ROW (with the file named) or PARSER GAP (with the text quoted). verdict.txt
now records how many sources were checked.

Your interruption theory fits this exactly: stopping the build halfway leaves
parts enumerated from a listing but never enriched from their own page. The old
audit would have blamed the source for that; the new one names the file that has
the data.


1. MACOM — THE BIG ONE
----------------------
Every row of a MACOM listing carries the whole record in an HTML-escaped JSON
attribute:

  <tr data-part="{ &#034;partNumber&#034;: &#034;CGH55015&#034;, ...
       &#034;specs&#034;: [{&#034;specName&#034;:&#034;Gain&#034;,
                          &#034;uom&#034;:&#034;dB&#034;,&#034;value&#034;:12}, ...] }">

One page holds 1012 parts and ~7,600 spec entries. We were reading only the
/products/product-detail/<PN> href out of those rows and discarding all of it,
which is why 5,017 MACOM parts had no specs.

Now parsed, with units normalised (MHz -> GHz, W -> dBm), plus description,
form factor, process, frequency band and application from the attributes array.

Measured on your own cached page, ingested through the real pipeline:
    1013 parts     frequency  99.9%     gain 99.0%
                   P1dB       55.6%     OIP3 52.0%     Psat 46.2%
    2N6439: 0.225-0.4 GHz, gain 7.8 dB, 47.8 dBm (from "Pout 60 W"), 28 V, 55%

AND IT FIXES THE DUPLICATE PART NUMBERS. Your audit sampled 2N6439, 2N6439_ and
A1_ -- the underscores are my folder-sanitising of '&'. Scraping the href out of
the ESCAPED json captured a trailing '&' (from &#034;) because the regex stopped
at the '#'. Taking partNumber from the JSON avoids it, and the href fallback now
truncates at '&' too. Verified: 0 part numbers containing '&', where before every
MACOM part had a phantom twin.


2. ADI SPACE PORTFOLIO — FREQUENCY FROM THE DESCRIPTION
-------------------------------------------------------
The portfolio has no frequency column, but the description routinely states it:
ADH913S is "0.6 GHz to 20 GHz, SDLVA". The audit caught this. It now reuses the
same description parser the parametric ingest uses, and writes a proper freq_ghz
range. 102 of 233 parts gain a frequency; ADH913S -> 0.6 to 20 GHz.


WHAT LOOKS GENUINELY FINE
-------------------------
EverythingRF's gaps are largely real. 1167T-500-1030's listing card states only
frequency, configuration, type and application -- the aggregator does not publish
gain or NF for many parts, and single-source verdicts there are trustworthy
because each erf part appears on exactly one page.

ADI Parametrics: only 14 parts with gaps, and the sampled ones are missing
tid_krad/sel_mev, which commercial parts legitimately do not have.

Skyworks and Marki did NOT appear in your audit at all. With 9,444 erf and 5,017
MACOM parts carrying gaps, that is consistent with the build being stopped before
it reached them rather than with those walkers being clean. Worth re-running with
resume on and auditing again.


SUGGESTED ORDER
---------------
    1. python -m rfparts.selfcheck
    2. re-ingest MACOM: python -m rfparts.cli ingest --vendors macom
       (resume is on by default; the cached pages make this fast)
    3. re-ingest the space portfolio so the frequencies land
    4. python -m rfparts.cli audit --per-source 3   and send it again
       -- the Qorvo/Marki/Skyworks verdicts will mean something this time


NOT TESTED HERE
---------------
No network: the MACOM parser is verified against the page from YOUR bundle,
driven through the real ingest path. No Tk, so nothing GUI-side changed.
