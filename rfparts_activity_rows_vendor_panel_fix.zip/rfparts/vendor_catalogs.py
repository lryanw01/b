"""Walk vendor product catalogues and put every part into partdb.

Five vendors, each needing a different route. What is here was established by
probing the live sites (see the debug reports), not guessed:

QORVO      https://www.qorvo.com/products/product-list?categoryID=<caNNNN>
           Server-rendered PARAMETRIC TABLES. Each row carries the part number,
           a datasheet id, and the family's spec columns -- so the listing alone
           yields frequency, gain, NF, OIP3, isolation and so on. The
           /products/<family>/<sub> pages are marketing landing pages with no
           table, so only the categoryID form is useful. Datasheet ids are opaque
           (/products/d/da009265), which is why the table must be parsed rather
           than the URL guessed.

MACOM      https://www.macom.com/products/... category pages
           Parts live at /products/product-detail/<PN>. Anything else that looks
           like a last path segment is a filter facet (200_V, SWITCHES-SP3T), so
           the product-detail path is required. Datasheets follow a clean
           pattern: https://cdn.macom.com/datasheets/<PN>.pdf

SKYWORKS   https://www.skyworksinc.com/en/Products/<Category>/<PN>
           Categories are listed on /en/Products. The datasheet document number
           is opaque (SKY58281-11_205951B_PS.pdf), so each product page has to be
           opened to find its PDF link.

MARKI      https://markimicrowave.com/products/<form>/<category>/[?page=N]
           form = connectorized | surface-mount | bare-die | waveguide.
           Listings are PAGED. Their per-part PDFs are Chrome print renderings
           (producer=Skia/PDF, no text layer), so the /datasheet/ PAGE is the
           real source -- it carries the full spec tables as HTML.

MINI-CIRCUITS is not here: the local products JSON already covers it.

Politeness: one rate limit per host, robots.txt honoured per host with a hard
timeout (urllib.robotparser has none of its own and will hang forever on a host
that accepts the connection then goes quiet), every page cached on disk, and the
walk rotates between vendors so no single host sees a burst.
"""
from __future__ import annotations

import html as htmllib
import json
import os
import re
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
import urllib.robotparser
from collections import Counter
from pathlib import Path

try:
    from . import partdb
    from .partdb import SpecRow, upsert_part, put_specs, put_evidence
except ImportError:                                     # loose-script fallback
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from rfparts import partdb                            # type: ignore
    from rfparts.partdb import (                           # type: ignore
        SpecRow, upsert_part, put_specs, put_evidence)

UA = ("rfparts/2.0 (RF parts sourcing research; "
      "contact: set RFPARTS_CONTACT env var)")
CACHE = partdb.DATA / "vendor_cache"
DEFAULT_RATE = 1.0
socket.setdefaulttimeout(30)

# --------------------------------------------------------------- vendor table
VENDORS = {
    "qorvo": {"name": "Qorvo", "host": "https://www.qorvo.com"},
    "macom": {"name": "MACOM", "host": "https://www.macom.com"},
    "skyworks": {"name": "Skyworks", "host": "https://www.skyworksinc.com"},
    "marki": {"name": "Marki Microwave", "host": "https://markimicrowave.com"},
    "adi": {"name": "Analog Devices", "host": "https://www.analog.com"},
}
ALL_VENDORS = list(VENDORS)

# Qorvo categoryIDs. ca0021 and ca0118 confirmed live by fetching them; the rest
# are probed and silently skipped when empty, so an unknown id costs one request.
QORVO_CATEGORY_IDS = [f"ca{n:04d}" for n in range(1, 200)]
QORVO_KNOWN_GOOD = ["ca0021", "ca0118"]

MARKI_FORMS = ["connectorized", "surface-mount", "bare-die", "waveguide"]
MARKI_KNOWN_CATEGORIES = [
    "mixers", "amplifiers", "filters", "couplers", "power-dividers", "baluns",
    "bias-tees", "equalizers", "limiters", "multipliers", "detectors",
    "attenuators", "switches", "phase-shifters", "diplexers", "terminations"]

MACOM_SEEDS = ["https://www.macom.com/products"]
SKYWORKS_SEED = "https://www.skyworksinc.com/en/Products"

# ----------------------------------------------------------- text/HTML helpers
_DROP = re.compile(r"<(script|style|noscript|svg|head)\b.*?</\1>", re.S | re.I)
_TAG = re.compile(r"<[^>]+>")
_HREF = re.compile(r'href\s*=\s*["\']([^"\']+)["\']', re.I)
_ROW = re.compile(r"<tr\b[^>]*>(.*?)</tr>", re.S | re.I)
_CELL = re.compile(r"<(t[dh])\b[^>]*>(.*?)</\1>", re.S | re.I)
_TABLE = re.compile(r"<table\b[^>]*>(.*?)</table>", re.S | re.I)
_HEADING = re.compile(r"<h[1-4][^>]*>\s*(.{2,80}?)\s*</h[1-4]>", re.S | re.I)
_WORDY = re.compile(r"^[A-Za-z]{4,}$")


def _txt(fragment):
    s = _TAG.sub(" ", fragment or "")
    return re.sub(r"\s+", " ", htmllib.unescape(s)).strip()


def looks_like_pn(s):
    """A part number, not a category slug or a filter facet."""
    s = (s or "").strip().strip("-_")
    if not (2 < len(s) <= 40) or not any(c.isdigit() for c in s):
        return False
    return not any(_WORDY.match(seg) for seg in re.split(r"[-_]", s)[1:])


def _num(v):
    if v is None:
        return None
    s = str(v).replace(",", "")
    if re.search(r"\bDC\b", s, re.I) and not re.search(r"\d", s):
        return 0.0
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    return float(m.group(0)) if m else None


# Column header -> (spec key, unit hint). Units usually live in the header text
# ("Frequency Min GHz"), so they are read from there.
_COLS = [
    (r"freq(uency)?\s*min", "freq_min"), (r"freq(uency)?\s*max", "freq_max"),
    (r"^freq(uency)?\b(?!.*(min|max))", "freq_range"),
    (r"\bgain\b(?!.*block)", "gain_db"),
    (r"\bnf\b|noise figure", "nf_db"),
    (r"oip3|\bip3\b|iip3", "oip3_dbm"),
    (r"op1db|ip1db|p1db|p0\.1db|ip0\.1db", "p1db_dbm"),
    (r"insertion loss", "insertion_loss_db"),
    (r"isolation", "isolation_db"),
    (r"conversion loss|conversion gain", "conversion_loss_db"),
    (r"attenuation", "attenuation_db"),
    (r"psat|pout|output power|\bpower\b", "psat_dbm"),
    (r"switching speed", "switching_speed_ns"),
    (r"phase error|rms phase", "phase_error_deg"),
    (r"package type", "package"),
    (r"^package\b", "package_size"),
    (r"voltage|vcc|vdd", "supply_v"),
    (r"current", "current_ma"),
]


def _unit_from_header(h):
    m = re.search(r"\b(GHz|MHz|kHz|dBm|dBc|dBi|dB|ns|ps|mA|uA|V|W|mm|degrees?|%)\b",
                  h, re.I)
    return m.group(1) if m else ""


def map_headers(headers):
    """{column index: (spec key, unit)} for a parametric table."""
    out = {}
    for i, h in enumerate(headers):
        hl = h.lower()
        for pat, key in _COLS:
            if re.search(pat, hl):
                out[i] = (key, _unit_from_header(h))
                break
    return out


def parse_tables(html):
    """[(headers, [row cells...], raw_row_html), ...] for every table."""
    out = []
    for tbl in _TABLE.findall(html):
        rows = _ROW.findall(tbl)
        if len(rows) < 2:
            continue
        parsed = [[(_txt(c[1]), c[1]) for c in _CELL.findall(r)] for r in rows]
        parsed = [r for r in parsed if r]
        if len(parsed) < 2:
            continue
        headers = [c[0] for c in parsed[0]]
        out.append((headers, parsed[1:]))
    return out


# ------------------------------------------------------------ polite fetching
class Fetcher:
    """Per-host rate limit, per-host robots.txt WITH a timeout, disk cache."""

    def __init__(self, rate=DEFAULT_RATE, timeout=30, ignore_robots=False,
                 robots_timeout=10, cache=True, progress=print):
        self.rate = rate
        self.timeout = timeout
        self.ignore_robots = ignore_robots
        self.robots_timeout = robots_timeout
        self.use_cache = cache
        self.say = progress
        self._last = {}
        self._robots = {}
        self.robots_state = {}
        self.stats = Counter()
        contact = os.environ.get("RFPARTS_CONTACT", "")
        self.ua = UA if not contact else f"rfparts/2.0 (+{contact})"
        CACHE.mkdir(parents=True, exist_ok=True)

    def _cache_path(self, url):
        import hashlib
        h = hashlib.sha256(url.encode()).hexdigest()[:20]
        host = urllib.parse.urlparse(url).netloc.replace(":", "_")
        d = CACHE / host
        d.mkdir(parents=True, exist_ok=True)
        return d / (h + (".pdf" if url.lower().endswith(".pdf") else ".html"))

    def _robots_ok(self, url):
        if self.ignore_robots:
            return True, "ignored"
        host = urllib.parse.urlparse(url).netloc
        if host not in self._robots:
            rp = None
            state = "error"
            try:
                req = urllib.request.Request(f"https://{host}/robots.txt",
                                             headers={"User-Agent": self.ua})
                with urllib.request.urlopen(req,
                                            timeout=self.robots_timeout) as r:
                    text = r.read(200_000).decode("utf-8", "replace")
                rp = urllib.robotparser.RobotFileParser()
                rp.parse(text.splitlines())
                state = "ok"
            except urllib.error.HTTPError as e:
                state = "missing" if e.code == 404 else f"HTTP {e.code}"
            except Exception as e:
                state = "timeout" if "timed out" in str(e).lower() else \
                        type(e).__name__
            self._robots[host] = rp
            self.robots_state[host] = state
            self.say(f"      robots.txt {host}: {state}")
        state = self.robots_state[host]
        rp = self._robots[host]
        if state == "missing":
            return True, state
        if rp is None:
            # Unreadable robots: do not crawl this host. Failing closed is the
            # conservative reading, and it is also what stops the run silently
            # hammering a host that is refusing to state its policy.
            return False, state
        return rp.can_fetch(self.ua, url), state

    def get(self, url, kind="html", force=False):
        """(text_or_bytes, source) where source is 'cache' | 'net'."""
        path = self._cache_path(url)
        if self.use_cache and path.exists() and not force:
            self.stats["cache_hit"] += 1
            data = path.read_bytes()
            return (data if kind == "pdf"
                    else data.decode("utf-8", "replace")), "cache"
        ok, state = self._robots_ok(url)
        if not ok:
            self.stats["robots_blocked"] += 1
            raise PermissionError(f"robots.txt ({state}) disallows {url}")
        host = urllib.parse.urlparse(url).netloc
        wait = self.rate - (time.time() - self._last.get(host, 0.0))
        if wait > 0:
            time.sleep(wait)
        req = urllib.request.Request(url, headers={
            "User-Agent": self.ua,
            "Accept": "application/pdf,*/*" if kind == "pdf"
                      else "text/html,*/*"})
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                blob = r.read(8_000_000)
            self.stats["fetched"] += 1
        except urllib.error.HTTPError as e:
            self.stats[f"http_{e.code}"] += 1
            raise
        finally:
            self._last[host] = time.time()
        if self.use_cache:
            path.write_bytes(blob)
        return (blob if kind == "pdf"
                else blob.decode("utf-8", "replace")), "net"


# =============================================================== Qorvo
_QORVO_PD = re.compile(r"/products/(p|d)/([^\"'?#]+)", re.I)
_QORVO_HEAD = re.compile(r"<h[23][^>]*>\s*([^<]{3,70}?)\s*\((\d+)\)\s*</h[23]>",
                         re.I)

_QORVO_SECTION_CAT = [
    ("low noise amplif", ("amplifier", "lna")),
    ("power amplif", ("amplifier", "pa")),
    ("driver amplif", ("amplifier", "driver")),
    ("gain block", ("amplifier", "buffer")),
    ("variable gain", ("amplifier", "vga")),
    ("distributed amplif", ("amplifier", "")),
    ("amplif", ("amplifier", "")),
    ("attenuator", ("attenuator", "")),
    ("limiter", ("limiter", "")),
    ("phase shifter", ("phase_shifter", "")),
    ("mixer", ("mixer", "")),
    ("multiplier", ("multiplier", "")),
    ("modulator", ("modulator", "")),
    ("upconverter", ("mixer", "")), ("downconverter", ("mixer", "")),
    ("synthesizer", ("synthesizer", "")), ("vco", ("oscillator", "")),
    ("switch", ("switch", "")),
    ("filter", ("filter", "")), ("diplexer", ("filter", "")),
    ("duplexer", ("filter", "")), ("multiplexer", ("filter", "")),
    ("transformer", ("balun", "")), ("balun", ("balun", "")),
    ("beamformer", ("beamformer", "")),
    ("transistor", ("transistor", "")), ("hemt", ("transistor", "")),
    ("front end module", ("ic", "")), ("transceiver", ("transceiver", "")),
    ("pmic", ("power", "")), ("power management", ("power", "")),
    ("converter", ("power", "")),
]


def _qorvo_category(section):
    low = (section or "").lower()
    for needle, pair in _QORVO_SECTION_CAT:
        if needle in low:
            return pair
    return ("ic", "")


def walk_qorvo(fetcher, say, catids=None, max_ids=None):
    """Parts from Qorvo's parametric tables, with their spec columns."""
    ids = list(catids or (QORVO_KNOWN_GOOD +
                          [c for c in QORVO_CATEGORY_IDS
                           if c not in QORVO_KNOWN_GOOD]))
    if max_ids:
        ids = ids[:max_ids]
    say(f"    walking {len(ids)} categoryID(s) "
        f"(tables live only behind product-list?categoryID=)")
    parts, live = {}, 0
    for n, cid in enumerate(ids, 1):
        url = f"https://www.qorvo.com/products/product-list?categoryID={cid}"
        try:
            html, src = fetcher.get(url)
        except PermissionError as e:
            say(f"      {cid}: {e}")
            break
        except Exception as e:
            continue
        # section headings in document order, to label each table
        heads = [h[0] for h in _QORVO_HEAD.findall(html)]
        tables = parse_tables(html)
        if not tables:
            continue
        live += 1
        before = len(parts)
        for ti, (headers, rows) in enumerate(tables):
            section = heads[ti] if ti < len(heads) else ""
            cat, sub = _qorvo_category(section)
            colmap = map_headers(headers)
            for cells in rows:
                joined = " ".join(c[1] for c in cells)
                pn = ds = ""
                for kind, ident in _QORVO_PD.findall(joined):
                    if kind.lower() == "p" and not pn:
                        pn = urllib.parse.unquote(ident).strip("/")
                    elif kind.lower() == "d" and not ds:
                        ds = f"https://www.qorvo.com/products/d/{ident}"
                if not pn or not looks_like_pn(pn):
                    continue
                rec = parts.setdefault(pn.upper(), {
                    "mpn": pn, "vendor": "Qorvo", "category": cat,
                    "subcategory": sub, "specs": {},
                    "product_url": f"https://www.qorvo.com/products/p/{pn}",
                    "datasheet_url": ds, "description": "",
                    "section": section, "source": f"qorvo:{cid}"})
                if ds and not rec["datasheet_url"]:
                    rec["datasheet_url"] = ds
                for i, (text, _raw) in enumerate(cells):
                    if i == 1 and text and not rec["description"]:
                        rec["description"] = text[:200]
                    if i not in colmap:
                        continue
                    key, unit = colmap[i]
                    _absorb_spec(rec, key, text, unit)
        got = len(parts) - before
        if got:
            say(f"      {cid}: {len(tables):>2} table(s), +{got} part(s)"
                f"   [{src}]   {'; '.join(heads[:2])[:52]}")
    say(f"    Qorvo: {live} live categoryID(s), {len(parts)} part(s)")
    return list(parts.values())


def _absorb_spec(rec, key, text, unit):
    """Put one table cell into rec['specs'], normalising frequency to GHz."""
    if not text or text in ("-", "--", "N/A", "n/a", "TBD"):
        return
    if key == "package":
        rec["specs"]["package"] = (text[:60], "")
        return
    if key in ("freq_min", "freq_max", "freq_range"):
        u = (unit or "GHz").lower()
        if key == "freq_range":
            m = re.search(r"(-?[\d.]+)\s*(?:to|-|–)\s*(-?[\d.]+)", text)
            if m:
                a, b = float(m.group(1)), float(m.group(2))
            else:
                v = _num(text)
                if v is None:
                    return
                a = b = v
        else:
            v = _num(text)
            if v is None:
                return
            a = b = v
        if u == "mhz":
            a, b = a / 1e3, b / 1e3
        elif u == "khz":
            a, b = a / 1e6, b / 1e6
        elif u == "hz":
            a, b = a / 1e9, b / 1e9
        if key == "freq_min":
            rec["specs"]["freq_min"] = (a, "GHz")
        elif key == "freq_max":
            rec["specs"]["freq_max"] = (b, "GHz")
        else:
            rec["specs"]["freq_min"] = (min(a, b), "GHz")
            rec["specs"]["freq_max"] = (max(a, b), "GHz")
        return
    v = _num(text)
    if v is not None:
        rec["specs"][key] = (v, unit)


# =============================================================== MACOM
_MACOM_PART = re.compile(r"/products/product-detail/([^\"'?#/]+)", re.I)


def walk_macom(fetcher, say, max_categories=None):
    cats = []
    for seed in MACOM_SEEDS:
        try:
            html, src = fetcher.get(seed)
        except Exception as e:
            say(f"      seed {seed}: {e}")
            continue
        for href in _HREF.findall(html):
            u = urllib.parse.urljoin(seed, href.strip())
            pr = urllib.parse.urlparse(u)
            if pr.netloc != "www.macom.com":
                continue
            if not re.match(r"^/products/[a-z0-9-]+(/[a-z0-9-]+){1,4}/?$",
                            pr.path, re.I):
                continue
            if _MACOM_PART.search(pr.path):
                continue
            if u not in cats:
                cats.append(u)
    # deepest paths first: those are the leaf listings that hold parts
    cats.sort(key=lambda u: -urllib.parse.urlparse(u).path.count("/"))
    if max_categories:
        cats = cats[:max_categories]
    say(f"    {len(cats)} category page(s) discovered")
    parts = {}
    for u in cats:
        try:
            html, src = fetcher.get(u)
        except PermissionError as e:
            say(f"      {e}")
            break
        except Exception:
            continue
        before = len(parts)
        cat, sub = _category_from_path(urllib.parse.urlparse(u).path)
        for pn in {urllib.parse.unquote(m) for m in _MACOM_PART.findall(html)}:
            if not looks_like_pn(pn):
                continue
            parts.setdefault(pn.upper(), {
                "mpn": pn, "vendor": "MACOM", "category": cat,
                "subcategory": sub, "specs": {}, "description": "",
                "product_url": f"https://www.macom.com/products/"
                               f"product-detail/{pn}",
                "datasheet_url": f"https://cdn.macom.com/datasheets/"
                                 f"{urllib.parse.quote(pn, safe='+-_.')}.pdf",
                "source": "macom:" + urllib.parse.urlparse(u).path})
        got = len(parts) - before
        if got:
            say(f"      +{got:>4} part(s)  [{src}]  {cat:<12} "
                f"{urllib.parse.urlparse(u).path[:56]}")
    say(f"    MACOM: {len(parts)} part(s)")
    return list(parts.values())


_PATH_CAT = [
    ("low-noise", ("amplifier", "lna")), ("lna", ("amplifier", "lna")),
    ("power-amplifier", ("amplifier", "pa")),
    ("gain-block", ("amplifier", "buffer")),
    ("driver", ("amplifier", "driver")),
    ("amplifier", ("amplifier", "")),
    ("attenuator", ("attenuator", "")), ("limiter", ("limiter", "")),
    ("phase-shifter", ("phase_shifter", "")), ("mixer", ("mixer", "")),
    ("multiplier", ("multiplier", "")), ("modulator", ("modulator", "")),
    ("switch", ("switch", "")), ("filter", ("filter", "")),
    ("coupler", ("coupler", "")), ("divider", ("divider", "")),
    ("splitter", ("divider", "")), ("balun", ("balun", "")),
    ("transformer", ("balun", "")), ("detector", ("detector", "")),
    ("oscillator", ("oscillator", "")), ("vco", ("oscillator", "")),
    ("synthesizer", ("synthesizer", "")), ("diode", ("diode", "")),
    ("transistor", ("transistor", "")), ("isolator", ("isolator", "")),
    ("circulator", ("circulator", "")), ("equalizer", ("equalizer", "")),
    ("bias-tee", ("bias_tee", "")), ("terminat", ("termination", "")),
    ("beamformer", ("beamformer", "")), ("transceiver", ("transceiver", "")),
]


def _category_from_path(path):
    low = (path or "").lower()
    for needle, pair in _PATH_CAT:
        if needle in low:
            return pair
    return ("ic", "")


# =============================================================== Skyworks
_SKY_PART = re.compile(r"^/en/Products/([^/]+)/([^/?#]+)/?$", re.I)
_SKY_CAT = re.compile(r"^/en/Products/([^/?#]+)/?$", re.I)


def walk_skyworks(fetcher, say, max_categories=None, fetch_product_pages=True,
                  max_products=None):
    try:
        html, src = fetcher.get(SKYWORKS_SEED)
    except Exception as e:
        say(f"      seed failed: {e}")
        return []
    cats = []
    for href in _HREF.findall(html):
        u = urllib.parse.urljoin(SKYWORKS_SEED, href.strip().split("#")[0])
        pr = urllib.parse.urlparse(u)
        if pr.netloc == "www.skyworksinc.com" and _SKY_CAT.match(pr.path):
            if u not in cats:
                cats.append(u)
    if max_categories:
        cats = cats[:max_categories]
    say(f"    {len(cats)} category page(s) discovered")
    parts = {}
    for u in cats:
        try:
            page, src = fetcher.get(u)
        except PermissionError as e:
            say(f"      {e}")
            break
        except Exception:
            continue
        before = len(parts)
        for href in _HREF.findall(page):
            pu = urllib.parse.urljoin(u, href.strip().split("#")[0])
            pr = urllib.parse.urlparse(pu)
            m = _SKY_PART.match(pr.path)
            if not m or pr.netloc != "www.skyworksinc.com":
                continue
            pn = urllib.parse.unquote(m.group(2))
            if not looks_like_pn(pn):
                continue
            cat, sub = _category_from_path(m.group(1))
            parts.setdefault(pn.upper(), {
                "mpn": pn, "vendor": "Skyworks", "category": cat,
                "subcategory": sub, "specs": {}, "description": "",
                "product_url": pu, "datasheet_url": "",
                "source": "skyworks:" + m.group(1)})
        got = len(parts) - before
        if got:
            say(f"      +{got:>4} part(s)  [{src}]  "
                f"{urllib.parse.urlparse(u).path[:58]}")
    say(f"    Skyworks: {len(parts)} part(s) from listings")

    # The datasheet document number is opaque, so the product page is the only
    # place the PDF URL can be found.
    if fetch_product_pages:
        todo = list(parts.values())
        if max_products:
            todo = todo[:max_products]
        say(f"    opening {len(todo)} product page(s) for datasheet links")
        found = 0
        for i, rec in enumerate(todo, 1):
            try:
                page, src = fetcher.get(rec["product_url"])
            except PermissionError as e:
                say(f"      {e}")
                break
            except Exception:
                continue
            pdfs = [urllib.parse.urljoin(rec["product_url"], h)
                    for h in _HREF.findall(page)
                    if re.search(r"\.pdf($|[?#])", h, re.I)]
            best = _best_pdf(pdfs, rec["mpn"])
            if best:
                rec["datasheet_url"] = best
                found += 1
            if i % 25 == 0 or i == len(todo):
                say(f"      {i}/{len(todo)} page(s), {found} datasheet link(s)")
        say(f"    Skyworks: {found} datasheet URL(s) resolved")
    return list(parts.values())


_CATALOGUE_WORDS = re.compile(
    r"catalog|catalogue|brochure|selection|short.?form|price|portfolio", re.I)


def _best_pdf(urls, pn):
    """Prefer a PDF whose filename names the part; never a catalogue."""
    key = re.sub(r"[^A-Z0-9]", "", (pn or "").upper())
    best, best_score = None, 0
    for u in dict.fromkeys(urls):
        name = urllib.parse.unquote(u.rsplit("/", 1)[-1])
        flat = re.sub(r"[^A-Z0-9]", "", name.upper())
        score = 0
        if key and key in flat:
            score += 100
        elif key and len(key) > 5 and key[:6] in flat:
            score += 40
        if _CATALOGUE_WORDS.search(name):
            score -= 200
        if score > best_score:
            best, best_score = u, score
    return best


# =============================================================== Marki
_MARKI_PART = re.compile(
    r"^(?:https?://[^/]+)?(/products/[a-z-]+/[a-z0-9-]+/"
    r"([A-Za-z0-9][A-Za-z0-9._-]*)/?)$", re.I)
# 'copyright ©' and 'privacy policy' appear INSIDE Marki's datasheet body (they
# stamp "Rev: - | Copyright © 2025 ..." into the revision history), and trimming
# there cut the Electrical Specifications table off. Only strong footers here.
_MARKI_END = ("stay informed", "be the first to know")
_MARKI_START = ("device overview", "general description")
_SPEC_MARK = re.compile(r"electrical specification|absolute maximum|"
                        r"recommended operating|package information", re.I)


def marki_datasheet_text(raw):
    """Readable datasheet text from a Marki /datasheet/ page.

    Their per-part PDFs are Chrome print renderings with no text layer, so this
    HTML is the real source; it carries General Description, Features, Absolute
    Maximum Ratings, Electrical Specifications and Package Information."""
    s = _DROP.sub(" ", raw)
    s = re.sub(r"</(td|th)\s*>", " | ", s, flags=re.I)
    s = re.sub(r"</(p|div|li|tr|h[1-6]|table|section|br)\s*/?>", "\n", s,
               flags=re.I)
    s = _TAG.sub(" ", s)
    s = htmllib.unescape(s)
    s = re.sub(r"[ \t\xa0]+", " ", s)
    lines = [ln.strip(" |").strip() for ln in s.split("\n")]
    lines = [ln for ln in lines if ln]
    lo = 0
    for i, ln in enumerate(lines):
        if any(h in ln.lower() for h in _MARKI_START):
            lo = i
            break
    hi = len(lines)
    for i in range(lo + 1, len(lines)):
        if any(h in lines[i].lower() for h in _MARKI_END):
            hi = i
            break
    body = lines[lo:hi] or lines
    seen, out = set(), []
    for ln in body:
        k = re.sub(r"\s+", " ", ln.lower())
        if len(k) > 12 and k in seen:
            continue
        seen.add(k)
        out.append(ln)
    return "\n".join(out).strip()


def walk_marki(fetcher, say, forms=None, categories=None, max_pages=40,
               fetch_datasheets=True, max_products=None):
    forms = forms or MARKI_FORMS
    parts = {}
    for form in forms:
        cats = categories
        if not cats:
            cats = []
            try:
                html, src = fetcher.get(f"https://markimicrowave.com/products/"
                                        f"{form}/")
                for href in _HREF.findall(html):
                    m = re.match(rf"^(?:https?://[^/]+)?/products/"
                                 rf"{re.escape(form)}/([a-z0-9-]+)/?$",
                                 href.strip(), re.I)
                    if m and not looks_like_pn(m.group(1)):
                        c = m.group(1).lower()
                        if c not in cats:
                            cats.append(c)
            except Exception as e:
                say(f"      {form}: category listing failed ({e})")
            cats = cats or list(MARKI_KNOWN_CATEGORIES)
        say(f"    {form}: {len(cats)} category slug(s)")
        for cat in cats:
            page, empties, before = 1, 0, len(parts)
            while page <= max_pages:
                url = (f"https://markimicrowave.com/products/{form}/{cat}/"
                       if page == 1 else
                       f"https://markimicrowave.com/products/{form}/{cat}/"
                       f"?page={page}")
                try:
                    html, src = fetcher.get(url)
                except PermissionError as e:
                    say(f"      {e}")
                    return list(parts.values())
                except Exception:
                    break
                new = 0
                for href in _HREF.findall(html):
                    m = _MARKI_PART.match(href.strip())
                    if not m or not looks_like_pn(m.group(2)):
                        continue
                    pn = m.group(2).upper()
                    if pn in parts:
                        continue
                    ccat, sub = _category_from_path(cat)
                    parts[pn] = {
                        "mpn": m.group(2), "vendor": "Marki Microwave",
                        "category": ccat, "subcategory": sub, "specs": {},
                        "description": "",
                        "product_url": urllib.parse.urljoin(
                            "https://markimicrowave.com", m.group(1)),
                        "datasheet_url": "",
                        "source": f"marki:{form}/{cat}"}
                    new += 1
                if not new:
                    empties += 1
                    if empties >= 1:
                        break
                page += 1
            got = len(parts) - before
            if got:
                say(f"      {form}/{cat:<16} +{got:>4} part(s) over "
                    f"{page - 1} page(s)")
    say(f"    Marki: {len(parts)} part(s) from listings")

    if fetch_datasheets:
        todo = list(parts.values())
        if max_products:
            todo = todo[:max_products]
        say(f"    reading {len(todo)} /datasheet/ page(s) for spec text")
        withspec = 0
        for i, rec in enumerate(todo, 1):
            ds = rec["product_url"].rstrip("/") + "/datasheet/"
            try:
                html, src = fetcher.get(ds)
            except PermissionError as e:
                say(f"      {e}")
                break
            except Exception:
                continue
            text = marki_datasheet_text(html)
            if not text:
                continue
            rec["datasheet_url"] = ds
            rec["datasheet_text"] = text
            if _SPEC_MARK.search(text):
                withspec += 1
                _marki_specs_from_text(rec, text)
            if not rec["description"]:
                m = re.search(r"General Description\s*\n(.{20,300})", text)
                if m:
                    rec["description"] = m.group(1).strip()[:200]
            if i % 25 == 0 or i == len(todo):
                say(f"      {i}/{len(todo)} page(s), {withspec} with spec tables")
        say(f"    Marki: {withspec} part(s) with spec tables")
    return list(parts.values())


# Marki's spec tables come out of the HTML as pipe-separated rows with a HEADER
# row naming the columns, e.g.
#   Parameter | Test Conditions | Minimum Frequency (GHz) | Maximum Frequency (GHz) | Min | Typ | Max | Unit
#   Small Signal Gain | 3V bias, -30 dBm Input Power | 2 | 20 | - | 15.1 | - | dB
# A naive "take the middle number" read 20 (the max frequency) for every
# parameter, so the columns have to be mapped from the header first.
_MARKI_PARAM_KEYS = [
    (r"small signal gain|^gain\b", "gain_db"),
    (r"noise figure|^nf\b", "nf_db"),
    (r"output ip3|input ip3|\boip3\b|\biip3\b|\bip3\b", "oip3_dbm"),
    (r"output p1db|input p1db|\bp1db\b", "p1db_dbm"),
    (r"reverse isolation|isolation", "isolation_db"),
    (r"conversion loss", "conversion_loss_db"),
    (r"insertion loss", "insertion_loss_db"),
    (r"input return loss", "input_return_loss_db"),
    (r"output return loss", "output_return_loss_db"),
    (r"current consumption|positive dc current|supply current", "current_ma"),
    (r"power supply dc voltage|drain supply voltage", "supply_v"),
    (r"maximum operating temperature", "temp_max_c"),
    (r"minimum operating temperature", "temp_min_c"),
    (r"attenuation", "attenuation_db"),
    (r"psat|saturated output power|output power", "psat_dbm"),
]


def _marki_param_key(name):
    low = (name or "").strip().lower()
    for pat, key in _MARKI_PARAM_KEYS:
        if re.search(pat, low):
            return key
    return None


def _marki_specs_from_text(rec, text):
    """Read the pipe-separated spec tables, mapping columns from their header."""
    lines = text.split("\n")
    cols = None
    for line in lines:
        if "|" not in line:
            cols = None
            continue
        cells = [c.strip() for c in line.split("|")]
        low = [c.lower() for c in cells]
        if low and low[0].startswith("parameter"):
            # header row: remember where the useful columns are
            cols = {}
            for i, c in enumerate(low):
                if c in ("typ", "typical"):
                    cols["typ"] = i
                elif c == "min" or c == "minimum":
                    cols.setdefault("min", i)
                elif c == "max" or c == "maximum":
                    cols.setdefault("max", i)
                elif c.startswith("unit"):
                    cols["unit"] = i
                elif c.startswith("nominal"):
                    cols["nom"] = i
                elif "maximum rating" in c:
                    cols["typ"] = i
                elif "minimum frequency" in c:
                    cols["fmin"] = i
                elif "maximum frequency" in c:
                    cols["fmax"] = i
            continue
        if not cols:
            continue
        key = _marki_param_key(cells[0])
        # frequency range travels with each row; take it once
        if "fmin" in cols and "fmax" in cols:
            a = _num(cells[cols["fmin"]]) if cols["fmin"] < len(cells) else None
            b = _num(cells[cols["fmax"]]) if cols["fmax"] < len(cells) else None
            if a is not None and b is not None and b > 0:
                rec["specs"].setdefault("freq_min", (min(a, b), "GHz"))
                rec["specs"].setdefault("freq_max", (max(a, b), "GHz"))
        if not key:
            continue
        unit = ""
        if "unit" in cols and cols["unit"] < len(cells):
            unit = cells[cols["unit"]][:8]
        val = None
        for pref in ("typ", "nom", "min", "max"):
            i = cols.get(pref)
            if i is not None and i < len(cells):
                v = _num(cells[i])
                if v is not None:
                    val = v
                    break
        if val is None:
            continue
        rec["specs"].setdefault(key, (val, unit))


# ============================================================ datasheet files
def download_datasheets(records, fetcher, say, outdir=None, limit=0,
                        rotate=True):
    """Save datasheet PDFs (and Marki HTML) to disk, rotating between hosts."""
    outdir = Path(outdir or (partdb.DATA / "datasheets"))
    todo = [r for r in records if r.get("datasheet_url")]
    if rotate:
        buckets = {}
        for r in todo:
            buckets.setdefault(r["vendor"], []).append(r)
        order, todo = sorted(buckets), []
        while any(buckets[k] for k in order):
            for k in order:
                if buckets[k]:
                    todo.append(buckets[k].pop(0))
    if limit:
        todo = todo[:limit]
    say(f"    downloading up to {len(todo)} datasheet(s), rotating hosts")
    saved = failed = 0
    for i, r in enumerate(todo, 1):
        url = r["datasheet_url"]
        is_pdf = url.lower().endswith(".pdf")
        folder = outdir / re.sub(r"[^A-Za-z0-9]+", "-", r["vendor"]).strip("-")
        folder.mkdir(parents=True, exist_ok=True)
        name = re.sub(r"[^A-Za-z0-9._+-]", "_", r["mpn"])[:80]
        path = folder / (name + (".pdf" if is_pdf else ".html"))
        if path.exists():
            r["local_path"] = str(path)
            continue
        try:
            blob, src = fetcher.get(url, kind="pdf" if is_pdf else "html")
        except PermissionError as e:
            say(f"      {e}")
            break
        except Exception as e:
            failed += 1
            if failed <= 12:
                say(f"      [fail] {r['vendor'][:14]:<14} {r['mpn'][:22]:<22} "
                    f"{type(e).__name__}")
            continue
        data = blob if isinstance(blob, bytes) else blob.encode("utf-8", "replace")
        if is_pdf and data[:5] != b"%PDF-":
            failed += 1
            continue
        path.write_bytes(data)
        r["local_path"] = str(path)
        saved += 1
        if saved % 25 == 0:
            say(f"      {saved} saved, {failed} failed  ({i}/{len(todo)})")
    say(f"    datasheets: {saved} saved, {failed} failed -> {outdir}")
    return saved, failed


# ============================================================ partdb writing
def write_records(records, say, source_signal="vendor-catalog"):
    """One partdb row per part, with its specs and an evidence marker."""
    n = 0
    per_vendor = Counter()
    for rec in records:
        pid = upsert_part(mpn=rec["mpn"], vendor=rec.get("vendor", ""),
                          category=rec.get("category", ""),
                          subcategory=rec.get("subcategory", ""),
                          product_url=rec.get("product_url", ""),
                          description=rec.get("description", "")[:200])
        rows = []
        s = rec.get("specs", {})
        lo, hi = s.get("freq_min"), s.get("freq_max")
        if lo or hi:
            a = (lo or hi)[0]
            b = (hi or lo)[0]
            rows.append(SpecRow(key="freq_ghz", value_min=min(a, b),
                                value_max=max(a, b), unit="GHz",
                                method="catalog", confidence=0.85,
                                source_url=rec.get("product_url", ""),
                                snippet=rec.get("section", "")[:100]))
        for key, val in s.items():
            if key in ("freq_min", "freq_max"):
                continue
            v, unit = val if isinstance(val, tuple) else (val, "")
            if isinstance(v, str):
                rows.append(SpecRow(key=key, value_text=v[:200], unit=unit,
                                    method="catalog", confidence=0.8,
                                    source_url=rec.get("product_url", "")))
            else:
                rows.append(SpecRow(key=key, value_typ=v, unit=unit,
                                    method="catalog", confidence=0.8,
                                    source_url=rec.get("product_url", "")))
        if rec.get("datasheet_url"):
            rows.append(SpecRow(key="datasheet_url",
                                value_text=rec["datasheet_url"][:200],
                                method="catalog", confidence=0.9,
                                source_url=rec.get("product_url", "")))
        if rec.get("local_path"):
            rows.append(SpecRow(key="datasheet_file",
                                value_text=str(rec["local_path"])[:200],
                                method="catalog", confidence=0.9))
        if rows:
            put_specs(pid, rows)
        put_evidence(pid, [(source_signal, 2.0, rec.get("product_url", ""),
                            rec.get("source", "")[:120])])
        n += 1
        per_vendor[rec.get("vendor", "?")] += 1
    for v, c in per_vendor.most_common():
        say(f"      {v:<18} {c:>6} row(s)")
    return n


# ==================================================================== driver
def ingest(vendors=None, rate=DEFAULT_RATE, progress=None, limits=None,
           download=True, download_limit=0, ignore_robots=False,
           adi_dir=None, use_cache=True, categories=None):
    """Walk the selected vendors and write every part into partdb.

    vendors  subset of ('adi','qorvo','macom','skyworks','marki')
    limits   {'qorvo_ids':N,'macom_categories':N,'skyworks_categories':N,
              'skyworks_products':N,'marki_products':N,'marki_forms':[...]}
    """
    say = progress or print
    vendors = [v for v in (vendors or ALL_VENDORS) if v in VENDORS]
    limits = limits or {}
    category_filter = {str(c).strip().lower() for c in (categories or []) if str(c).strip()}
    fetcher = Fetcher(rate=rate, ignore_robots=ignore_robots,
                      cache=use_cache, progress=say)
    summary = {"per_vendor": {}, "errors": [], "records": 0}
    all_records = []

    say("=" * 66)
    say(f"VENDOR CATALOG INGEST -- {len(vendors)} vendor(s): "
        f"{', '.join(VENDORS[v]['name'] for v in vendors)}")
    say(f"  rate {rate}s per host, cache {'on' if use_cache else 'off'} "
        f"({CACHE})")
    say("=" * 66)

    for v in vendors:
        t0 = time.time()
        say(f"\n  {VENDORS[v]['name']}  [{v}]")
        recs = []
        try:
            if v == "adi":
                d = adi_dir or _guess_adi_dir()
                if not d:
                    say("    no ADI parametric folder found; pass adi_dir="
                        "<folder of ADIParametricSearch*.xlsx>")
                    summary["errors"].append("adi: no parametric folder")
                else:
                    say(f"    parametric exports from {d}")
                    from . import adi_parametric_ingest as adi_p
                    c = adi_p.ingest(d, dry_run=False, verbose=False,
                                     progress=say)
                    summary["per_vendor"]["adi"] = {
                        "parts": c.get("parts", 0), "secs": time.time() - t0}
                    say(f"    ADI: {c.get('parts', 0)} part(s) written directly")
                    continue
            elif v == "qorvo":
                recs = walk_qorvo(fetcher, say,
                                  max_ids=limits.get("qorvo_ids"))
            elif v == "macom":
                recs = walk_macom(fetcher, say,
                                  max_categories=limits.get("macom_categories"))
            elif v == "skyworks":
                recs = walk_skyworks(
                    fetcher, say,
                    max_categories=limits.get("skyworks_categories"),
                    max_products=limits.get("skyworks_products"))
            elif v == "marki":
                recs = walk_marki(
                    fetcher, say, forms=limits.get("marki_forms"),
                    max_products=limits.get("marki_products"))
        except PermissionError as e:
            say(f"    stopped: {e}")
            summary["errors"].append(f"{v}: {e}")
        except Exception as e:
            say(f"    FAILED: {type(e).__name__}: {e}")
            summary["errors"].append(f"{v}: {type(e).__name__}: {e}")
        if recs:
            if category_filter:
                before = len(recs)
                recs = [r for r in recs
                        if str(r.get("category", "")).strip().lower() in category_filter]
                say(f"    category filter: kept {len(recs)}/{before} parsed part(s)")
            with_ds = sum(1 for r in recs if r.get("datasheet_url"))
            with_freq = sum(1 for r in recs if r.get("specs", {}).get("freq_min"))
            say(f"    parsed: {len(recs)} part(s), {with_ds} datasheet URL(s), "
                f"{with_freq} with frequency")
            cats = Counter(r.get("category") for r in recs)
            say(f"    categories: " +
                ", ".join(f"{k}={n}" for k, n in cats.most_common(8)))

            # Show a parsed row as soon as this scrape returns records.  Do this
            # before optional datasheet downloads, which may take long enough to
            # make the GUI look as though parsing has not started.
            example = recs[0]
            say("EXAMPLE ROW | "
                f"vendor={example.get('vendor', '')} | "
                f"mpn={example.get('mpn', '')} | "
                f"category={example.get('category', '') or '(uncategorized)'} | "
                f"subcategory={example.get('subcategory', '') or '-'} | "
                f"url={example.get('product_url', '') or '-'}")

            # Finish this scrape as a complete batch: optional documents first,
            # then immediately commit every parsed part before starting the next
            # vendor. This keeps the DB useful even if a later scrape is stopped.
            if download:
                say(f"    DATASHEETS | {VENDORS[v]['name']}")
                download_datasheets(recs, fetcher, say, limit=download_limit)
            say(f"DB WRITE | {VENDORS[v]['name']} | {len(recs)} parsed part(s)")
            written = write_records(recs, say)
            summary["records"] += written
            summary["per_vendor"][v] = {
                "parts": written, "parsed": len(recs),
                "with_datasheet": with_ds, "with_freq": with_freq,
                "secs": time.time() - t0}

    say(f"\n  fetcher: " + ", ".join(f"{k}={v}"
                                    for k, v in sorted(fetcher.stats.items())))
    summary["fetch_stats"] = dict(fetcher.stats)
    summary["robots"] = dict(fetcher.robots_state)
    return summary


def _guess_adi_dir():
    for c in (Path.home() / "Downloads" / "ADIParametrics",
              Path.home() / "Downloads" / "newSources",
              Path.home() / "Downloads"):
        if c.is_dir() and any(c.glob("ADIParametricSearch*.xlsx")):
            return c
    return None
