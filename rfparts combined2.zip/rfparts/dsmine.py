
"""dsmine — mine specs out of the datasheets already sitting on disk.

WHY THIS EXISTS
---------------
The rebuild read vendor CATALOG LISTINGS only. `space_dataset.rebuild()` calls
the vendor ingests and the everythingRF page parser, and none of them open a
datasheet. `extract.py`'s pattern engine -- which knows how to read switching
speed, P1dB, OIP3, noise figure and the rest out of prose -- runs only in the
live-crawler path, which a local rebuild never touches.

The practical consequence was that thousands of downloaded datasheets sat in
the library contributing nothing, and any spec a listing did not happen to
tabulate was simply absent. Switching speed is the clearest case: it is on
essentially every switch datasheet, and everythingRF's switch listings do not
carry it as an attribute, so the field was empty across the entire dataset.

WHAT IT DOES
------------
Builds a part-number index of the local datasheet library once, then for each
part: reads the datasheet (PDF or HTML), mines the parametric patterns, and
returns SpecRows so a catalog value normally wins over a text-mined one.

READ THE TABLE AS A TABLE (v4)
------------------------------
Everything below the index is organised around one finding: nearly every wrong
value this module used to produce came from reading a spec TABLE as prose.
pypdf's `extract_text()` flattens columns, which fuses cells into strings no
regex can recover -- a real switch datasheet came out as

    Isolation1
    DC-8 GHz 75 90
    dB8-18 GHz 60 66
    18-26.5 GHz 55 65

and the old first-match-wins scan read that as a 66 dB part (it is a 55 dB
part), while

    RF Input Power
    Cold switching 30
    WHot switching3 0.1

produced a 0.1 W rating for a part rated 30 W cold. The unit had migrated onto
the next row's label.

So the primary path is now positional: `pdfplumber.extract_words()` clustered
into rows and split into cells on x-gaps, or for HTML the actual <tr>/<td>
structure. That recovers `Frequency Range | DC | 26.5 | GHz` and
`Isolation | 18-26.5 GHz | 55 | 65 | dB` as the rows they are, with real
min/typ/max columns. Regex-over-prose is kept, but demoted to a fallback that
only fills what no table row supplied, and only after a negative-context guard.

Three further changes follow from the same finding:

  * band-segmented rows aggregate conservatively. Isolation quoted as 75/66/55
    dB across three bands is a 55 dB part; insertion loss quoted as
    0.30/0.50/0.80 is a 0.80 dB part. Taking whichever row the label landed on
    is not a defensible answer.
  * every spec has a plausibility window, and a value outside it is refused
    rather than stored at low confidence. A 230914 W attenuator is not a low
    confidence measurement, it is a parse artifact.
  * family datasheets are detected. One MACOM sheet serves 23 couplers and the
    per-part frequency cell is VERTICALLY MERGED across groups of four rows, so
    it does not appear on the part's own row at all; a limiter sheet lists the
    requested MPN only as a cross-reference to a different part number. Mining
    either one part-blind gives every sharer the same wrong values. When the
    part's own row cannot be located on a family sheet, per-part specs are
    suppressed instead of guessed.

CONFIDENCE
----------
No longer a single number. A value read from a table cell with a matching unit
and an in-range magnitude is worth more than a regex hit in a paragraph, and
the difference is what lets datasheet precedence be decided per spec rather
than globally. See CONF_*.
"""
from __future__ import annotations

import html as _html
import math
import os
import re
from pathlib import Path

from . import specmatch
from .partdb import SpecRow
from .registry import PARAM_SPECS

# ---------------------------------------------------------------- versioning
# BUMP THIS ON ANY CHANGE BELOW. The disk cache keys on it, so without a bump a
# pattern fix is invisible on every file already parsed -- exactly the bug the
# everythingRF ingest hit before it grew a parser stamp.
# 14: connector/package mining, the space-score interaction bonuses and the
# title capture all landed WITHOUT a bump, so every already-parsed datasheet
# kept returning its pre-connector result from the cache. The stamp is the only
# thing that makes a parser change take effect on files already read -- adding
# a feature and forgetting it is exactly the bug this exists to prevent.
PARSER_VERSION = 22

# Confidence tiers. A table cell that carried its own unit is a different kind
# of evidence from a regex hit in a paragraph, and collapsing both to one number
# is what forced datasheet precedence to be an all-or-nothing decision.
CONF_TABLE = 0.72        # label + unit + min/typ/max columns, in range
CONF_TABLE_WEAK = 0.55   # table row, but unit absent or columns ambiguous
CONF_PROSE = 0.35        # regex over prose, negative-context guard passed
CONF_DERIVED = 0.50      # band from an explicit "Frequency Range" row
# Kept for callers that still reference it; equals the prose tier.
MINED_CONFIDENCE = CONF_PROSE

MAX_TEXT_CHARS = 60000
_HEAD_CHARS = 6000
# Stop paging once this many distinct HARD parametric specs have been found.
# It used to count every key in the mine, and freq_min, freq_max,
# space_score_pct, space_evidence and throw_config all come off page one -- so
# the threshold tripped before the electrical table was ever read, on every
# datasheet in the library.
EARLY_EXIT_SPECS = 4
_DS_EXT = {".pdf", ".htm", ".html", ".txt"}

# Positional row extraction costs a pdfplumber open (~0.4 s) where the old path
# cost a pypdf open (~0.1 s). It runs once per file ever, because the mined
# result is cached, but set RFPARTS_DSMINE_ROWS=0 to fall back to prose-only if
# a rebuild has to be fast.
ROWS_ENABLED = os.environ.get("RFPARTS_DSMINE_ROWS", "1").strip() != "0"
# Positional extraction opens the PDF a second time with pdfplumber, which is
# ~4x the cost of the pypdf text pass. Spec tables are on the first pages;
# pages 4 and 5 are almost always outline drawings and legal text, so reading
# three covers the tables at 60% of the cost. RFPARTS_DSMINE_PAGES overrides,
# and RFPARTS_DSMINE_ROWS=0 skips the positional pass entirely for a fast,
# lower-quality sweep.
try:
    ROW_PAGES = max(1, int(os.environ.get("RFPARTS_DSMINE_PAGES", "3")))
except ValueError:
    ROW_PAGES = 3


def default_roots():
    """Datasheet library roots, each physical folder listed ONCE.

    The candidates deliberately include both "data/datasheets" and
    "Data/datasheets" because either spelling may be the real one. On a
    case-insensitive filesystem BOTH resolve, and DATASHEET_DIR usually
    resolves to the same place again -- so a library of 5,621 files was walked
    three times and reported as 16,863. Every count downstream inherited that:
    the rebuild's progress and ETA, the debug surveys, the per-vendor totals.

    Deduped on the resolved, case-folded path, which is what makes two
    spellings of one directory compare equal.
    """
    env = os.environ.get("RFPARTS_DATASHEETS", "").strip()
    roots = [Path(env)] if env else []
    home = Path.home()
    roots += [home / "Downloads" / "rfparts" / "data" / "datasheets",
              home / "Downloads" / "rfparts" / "Data" / "datasheets"]
    try:
        from .paths import DATASHEET_DIR
        roots.append(Path(DATASHEET_DIR))
    except Exception:
        pass
    out, seen = [], set()
    for r in roots:
        if not r.is_dir():
            continue
        try:
            key = str(r.resolve()).casefold()
        except OSError:
            key = str(r).casefold()
        if key in seen:
            continue
        seen.add(key)
        out.append(r)
    return out


def _loose(pn):
    return re.sub(r"[^A-Z0-9]", "", str(pn or "").upper())


def build_index(roots=None, say=None):
    """{loose part number: path} for every datasheet on disk.

    One walk, then O(1) lookups. Globbing per part across a 4000-file tree would
    dominate the rebuild."""
    roots = roots or default_roots()
    index = {}
    for root in roots:
        root = Path(root)
        if not root.is_dir():
            continue
        for f in root.rglob("*"):
            try:
                if not f.is_file() or f.suffix.lower() not in _DS_EXT:
                    continue
            except OSError:
                continue
            key = _loose(f.stem)
            if not key:
                continue
            # Prefer the larger file when two match: a stub redirect page loses
            # to the real datasheet.
            prev = index.get(key)
            if prev is None:
                index[key] = f
            else:
                try:
                    if f.stat().st_size > prev.stat().st_size:
                        index[key] = f
                except OSError:
                    pass
    if say:
        say(f"    datasheet library: {len(index)} file(s) indexed from "
            + ", ".join(str(r) for r in roots) if roots else
            "    datasheet library: none found")
    return index


_SCRIPTISH = re.compile(r"(?is)<(script|style|noscript|svg)\b.*?</\1\s*>")
_COMMENT = re.compile(r"(?s)<!--.*?-->")
_TAG = re.compile(r"(?s)<[^>]+>")


_SNIFF_BYTES = 65536


def _sniff(path):
    # 64 kB, not 1 kB. The corruption test counts UTF-8 replacement bytes, and a
    # 1 kB sample was too small to reach the threshold on the text-mangled Qorvo
    # PDFs -- so they were classed as readable, handed to pypdf, and it spent a
    # long time attempting xref recovery on each of nearly a thousand files
    # before returning nothing. 64 kB is the sample size that was measured to
    # separate them cleanly.
    try:
        head = Path(path).open("rb").read(_SNIFF_BYTES)
    except OSError:
        return "unreadable"
    # Corruption is tested BEFORE the PDF magic bytes. It used to come after, and
    # since a mangled PDF still begins with "%PDF-" the function returned "pdf"
    # and the corruption branch was unreachable for the entire population it
    # exists to catch. Every one of those files then went to pypdf, which spent a
    # long time on xref recovery before returning nothing.
    replacement_ratio = head.count(b"\xef\xbf\xbd") * 3 / max(1, len(head))
    if replacement_ratio > 0.02:
        return "corrupt"
    if head[:5] == b"%PDF-":
        return "pdf"
    low = head.lstrip()[:400].lower()
    if low.startswith(b"<!doctype html") or b"<html" in low:
        return "html"
    return "text"


def _quiet_pdf_logs():
    import logging
    for _n in ("pdfminer", "pdfminer.pdfinterp", "pdfminer.pdfpage",
               "pypdf", "pypdf._reader", "PyPDF2", "pdfplumber"):
        logging.getLogger(_n).setLevel(logging.ERROR)


def _pdf_pages_pdfium(path, pages):
    """Per-page text via PDFium, the fastest engine available.

    Measured at 32 ms/file against pypdf's 385 ms on the same ten datasheets --
    PDFium is Chromium's C++ engine, pypdf is Python. Tried first; pypdf and
    then pdfplumber remain the fallbacks, so a file PDFium cannot read takes
    exactly the path it took before.
    """
    try:
        from . import dstables
    except ImportError:
        import dstables
    got = dstables._pdfium_pages(path, pages)
    if not got:
        raise RuntimeError("pdfium unavailable")
    for text, _words in got:
        yield text or ""


def _pdf_pages_pypdf(path, pages):
    """Per-page text via pypdf. Measured at ~99 ms/file against ~448 ms for
    pdfplumber on the same seven real datasheets, and it extracted MORE text
    (44k vs 41k chars) -- pdfplumber builds a full layout model that this step
    does not use for PROSE. Kept as a generator so reading can stop early.
    (The layout model IS used, separately, by pdf_rows.)"""
    from pypdf import PdfReader
    reader = PdfReader(str(path))
    for pg in reader.pages[:pages]:
        try:
            yield pg.extract_text() or ""
        except Exception:
            yield ""


def _pdf_pages_plumber(path, pages):
    """Fallback for PDFs pypdf cannot read. Slower but differently capable."""
    import pdfplumber
    with pdfplumber.open(str(path)) as pdf:
        for pg in pdf.pages[:pages]:
            try:
                yield pg.extract_text() or ""
            except Exception:
                yield ""


# Text -> (rows, path) for the most recent few files read. This exists so that
# mine_text(text) alone can still reach the positional table data: callers
# (including dbg_datasheet_parse.py) read the text with datasheet_text(path) and
# then mine it with mine_text(text), with no path in between. Bounded, and a
# miss simply means the prose path is used.
_ROWS_MEMO = {}
_ROWS_MEMO_MAX = 8


def _memo_key(text):
    if not text:
        return None
    return (len(text), hash(text[:400]), hash(text[-400:]))


def _memo_put(text, rows, path):
    k = _memo_key(text)
    if k is None:
        return
    if len(_ROWS_MEMO) >= _ROWS_MEMO_MAX:
        _ROWS_MEMO.clear()
    _ROWS_MEMO[k] = (rows, str(path))


def _memo_get(text):
    return _ROWS_MEMO.get(_memo_key(text), (None, None))


def datasheet_text(path, max_chars=MAX_TEXT_CHARS, pages=6, want=None):
    """Readable text from a local datasheet, or ''.

    File type comes from the bytes, not the extension: parts of the library are
    PDFs saved with a .html name, and dispatching on the suffix fed PDF bytes to
    the HTML stripper and produced nothing at all.

    `want` is an optional callable taking the accumulated text and returning True
    once enough has been read. Datasheets put the summary table on page one, so
    stopping there avoids parsing five more pages for nothing -- which on a
    four-thousand-file library is most of the run.

    Side effect: the positional rows for this file are cached against the text
    that was returned, so mine_text(text) can use them (see _ROWS_MEMO).
    """
    path = Path(path)
    kind = _sniff(path)
    if kind in ("unreadable", "corrupt"):
        return ""
    text = ""
    if kind == "pdf":
        _quiet_pdf_logs()
        readers = (_pdf_pages_pdfium, _pdf_pages_pypdf, _pdf_pages_plumber) \
            if os.environ.get("RFPARTS_PDFIUM", "1").strip() != "0" \
            else (_pdf_pages_pypdf, _pdf_pages_plumber)
        for reader in readers:
            chunks = []
            try:
                for page_text in reader(path, pages):
                    chunks.append(page_text)
                    if want is not None and want("\n".join(chunks)):
                        break
                    if sum(len(c) for c in chunks) >= max_chars:
                        break
            except Exception:
                continue
            candidate = "\n".join(chunks)[:max_chars]
            # pypdf occasionally returns almost nothing for a PDF pdfplumber can
            # read, so a thin result falls through to the slower backend rather
            # than being accepted.
            if len(candidate.strip()) >= 200:
                text = candidate
                break
    else:
        try:
            raw = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return ""
        if kind == "html":
            raw = _SCRIPTISH.sub(" ", raw)
            raw = _COMMENT.sub(" ", raw)
            raw = re.sub(r"(?i)</(p|div|li|tr|td|th|h[1-6]|table)\s*>", "\n", raw)
            raw = _TAG.sub(" ", raw)
            raw = _html.unescape(raw)
        text = re.sub(r"[ \t\xa0]+", " ", raw)[:max_chars]
    if text and ROWS_ENABLED:
        try:
            _memo_put(text, rows_for(path), path)
        except Exception:
            pass
    return text


# ============================================================ positional rows
# A "row" is (page_number, [cell, ...]). Cells are split on horizontal gaps, so
# the spec table's columns survive instead of being concatenated into one string.

def _merge_fragments(rows):
    """Join label text that wrapped onto its own line.

    'Insertion' / 'Loss1' arrive as two rows because the cell wrapped, and a
    bare 'Isolation1' arrives as its own row sitting between the sub-band rows
    it labels. Both are label text rather than data, and both are recognisable
    by carrying no numeric cell."""
    out = []
    for top, cells in rows:
        numeric = any(_cell_num(c) is not None for c in cells)
        if not numeric and len(cells) <= 2 and out:
            prev_top, prev_cells = out[-1]
            if abs(top - prev_top) <= 8 and not any(
                    _cell_num(c) is not None for c in prev_cells):
                out[-1] = (prev_top, prev_cells + cells)
                continue
        out.append((top, list(cells)))
    merged, i = [], 0
    while i < len(out):
        top, cells = out[i]
        if (i + 1 < len(out) and not any(_cell_num(c) is not None for c in cells)
                and len(cells) <= 2 and abs(out[i + 1][0] - top) <= 10):
            nt, nc = out[i + 1]
            merged.append((nt, cells + nc))
            i += 2
            continue
        merged.append((top, cells))
        i += 1
    return merged


def pdf_rows(path, pages=ROW_PAGES, y_tol=3.0, x_gap=8.0):
    """[(page, [cell, ...]), ...] from word positions.

    y_tol groups words into a visual line; x_gap is the horizontal whitespace
    that separates one cell from the next. Both were tuned against real
    Mini-Circuits, MACOM and Marki tables -- at x_gap below ~6 the min and typ
    columns merge, above ~12 a wrapped condition splits."""
    # POSITIONAL words stay on pdfplumber. PDFium is far faster and its TEXT is
    # equivalent, but its word grouping is not: pdfplumber's extract_words does
    # more than join characters across gaps, and substituting a gap-based
    # grouping changed the cells enough to break four spec extractions
    # (SMA88 noise figure, SXBP VSWR and centre frequency, HMC284A loss).
    # The row readers were tuned against pdfplumber's output and that output is
    # the reference; swapping the engine here needs them re-validated, which is
    # a bigger job than it looks and is not worth risking for the time saved.
    import pdfplumber
    _quiet_pdf_logs()
    out = []
    with pdfplumber.open(str(path)) as pdf:
        for pno, page in enumerate(pdf.pages[:pages], 1):
            try:
                words = page.extract_words(use_text_flow=False,
                                           keep_blank_chars=False)
            except Exception:
                continue
            buckets = {}
            for w in words:
                buckets.setdefault(round(w["top"] / y_tol), []).append(w)
            raw = []
            for k in sorted(buckets):
                ws = sorted(buckets[k], key=lambda w: w["x0"])
                cells, cur, prev = [], [], None
                for w in ws:
                    if prev is not None and w["x0"] - prev > x_gap:
                        cells.append(" ".join(cur))
                        cur = []
                    cur.append(w["text"])
                    prev = w["x1"]
                if cur:
                    cells.append(" ".join(cur))
                raw.append((k * y_tol, cells))
            for _top, cells in _merge_fragments(raw):
                out.append((pno, cells))
    return out


_TR = re.compile(r"(?is)<tr[^>]*>(.*?)</tr>")
_TD = re.compile(r"(?is)<t[dh][^>]*>(.*?)</t[dh]>")


def html_rows(path):
    """[(1, [cell, ...]), ...] from real <tr>/<td> markup.

    Deliberately regex-based rather than BeautifulSoup: this module must not add
    a dependency the rebuild does not already have. Marki pages carry a proper
    DOM table, and stripping it to prose (what this module used to do) is why a
    boilerplate footnote -- "Mixer Noise Figure typically measures within 0.5 dB
    of conversion loss" -- beat the actual Noise Figure row on every Marki
    mixer in the library.
    """
    try:
        raw = Path(path).read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    raw = _SCRIPTISH.sub(" ", raw)
    raw = _COMMENT.sub(" ", raw)
    out, seen = [], set()
    for tr in _TR.findall(raw):
        cells = []
        for c in _TD.findall(tr):
            c = _TAG.sub(" ", c)
            cells.append(re.sub(r"\s+", " ", _html.unescape(c)).strip())
        if not any(cells):
            continue
        sig = "|".join(cells)
        if sig in seen:            # server-rendered + hydrated copy of one table
            continue
        seen.add(sig)
        out.append((1, cells))
    return out


def rows_for(path):
    """Positional rows for a datasheet, dispatching on the bytes."""
    if not ROWS_ENABLED:
        return []
    kind = _sniff(path)
    if kind == "pdf":
        return pdf_rows(path)
    if kind == "html":
        return html_rows(path)
    return []


# cells_xy opens the PDF for EVERY page it is asked about, and callers ask
# page by page -- so a three-page look costs three opens, on top of the pypdf
# text pass and the pdfplumber row pass. Measured at ~1.8 s/file, most of it
# reopening the same document. Results are memoised per file identity so the
# document is parsed once per page and reused.
_XY_CACHE = {}
_XY_CACHE_MAX = 24


def _xy_key(path, pno, y_tol, x_gap):
    try:
        st = Path(path).stat()
        return (str(path), st.st_size, int(st.st_mtime), pno, y_tol, x_gap)
    except OSError:
        return (str(path), 0, 0, pno, y_tol, x_gap)


def cells_xy(path, pno, y_tol=3.0, x_gap=8.0):
    key = _xy_key(path, pno, y_tol, x_gap)
    hit = _XY_CACHE.get(key)
    if hit is not None:
        return hit
    out = _cells_xy_uncached(path, pno, y_tol, x_gap)
    if len(_XY_CACHE) >= _XY_CACHE_MAX:
        _XY_CACHE.clear()
    _XY_CACHE[key] = out
    return out


def _cells_xy_uncached(path, pno, y_tol=3.0, x_gap=8.0):
    """Rows whose cells keep their x extents, for column mapping on family
    sheets. Separate from pdf_rows because carrying the geometry everywhere
    would double the memory for the 99% of files that never need it."""
    import pdfplumber
    _quiet_pdf_logs()
    with pdfplumber.open(str(path)) as pdf:
        if pno > len(pdf.pages):
            return []
        words = pdf.pages[pno - 1].extract_words(use_text_flow=False,
                                                 keep_blank_chars=False)
    buckets = {}
    for w in words:
        buckets.setdefault(round(w["top"] / y_tol), []).append(w)
    rows = []
    for k in sorted(buckets):
        line = sorted(buckets[k], key=lambda w: w["x0"])
        cells, cur, prev = [], [], None
        for w in line:
            if prev is not None and w["x0"] - prev > x_gap:
                cells.append({"t": " ".join(x["text"] for x in cur),
                              "x0": cur[0]["x0"], "x1": cur[-1]["x1"]})
                cur = []
            cur.append(w)
            prev = w["x1"]
        if cur:
            cells.append({"t": " ".join(x["text"] for x in cur),
                          "x0": cur[0]["x0"], "x1": cur[-1]["x1"]})
        rows.append({"top": k * y_tol, "cells": cells})
    return rows


# --------------------------------------------------------------- cell helpers
_NUMERIC = re.compile(r"^[+-]?\d+(?:\.\d+)?$")
_LEADING_NUM = re.compile(
    r"^([+-]?\d+(?:\.\d+)?)\s*(?:\u00b1|W|mW|kW|dBm|dBc|dB|GHz|MHz|kHz|ns|"
    r"\u00b5s|\u03bcs|us|ms|mA|V|Degree|deg)\b", re.I)
# Footnote markers ride on the end of table labels: "Isolation1", "Loss1",
# "Noise Figure 3". Left in place they defeat every label match.
# A trailing digit is usually a footnote marker ("Isolation1", "Loss1") but it
# is part of the NAME in IP2, IP3, OIP3, IIP3, P1dB, S21, RF1. Stripping it
# turned "Low-Side IP3" into "Low-Side IP", which matched nothing -- so ADI's
# sub-spec breakdown was invisible and the parent prose regex won instead.
_FOOTNOTE = re.compile(
    r"(?<=[A-Za-z\)])\s?\d{1,2}\s*$"
    r"(?<!(?<![A-Za-z])[Ii][Pp]2)(?<!(?<![A-Za-z])[Ii][Pp]3)")
_NAME_ENDS_DIGIT = re.compile(
    r"(?:^|[\s(\[-])(?:[OI]?IP\s?[23]|P\s?1\s?dB|P\s?0\.1\s?dB|S\s?\d{2}|"
    r"RF\s?\d|LO\s?\d|IF\s?\d|LUT\s?\d+|MSL\s?\d)\s*$", re.I)
_PLACEHOLDER = {"-", "--", "\u2013", "\u2014", "", "n/a", "na", "tbd"}
_UNIT_TOKEN = re.compile(
    r"^(dBm|dBc|dB|GHz|MHz|kHz|Hz|W|mW|kW|ns|us|\u00b5s|\u03bcs|ms|sec|s|"
    r"mA|A|V|Degree|deg|\u00b0|%|:1)$", re.I)


_VSWR_PAIR = re.compile(
    r"(\d+(?:\.\d+)?)\s*:\s*1(?:\s*/\s*(\d+(?:\.\d+)?)\s*:\s*1)?")


def vswr_from_cell(cell):
    """The worse of a 'X:1 / Y:1' pair, or a single 'X:1'.

    MACOM quote input and output together in one cell. _cell_num reads the
    leading number and stops, so "1.6:1 / 2.0:1" became 1.6 -- the better port,
    on a max spec."""
    m = _VSWR_PAIR.search(str(cell or ""))
    if not m:
        return None
    vals = [float(g) for g in m.groups() if g]
    v = max(vals) if vals else None
    return v if v is not None and 1.0 <= v <= 6.0 else None


def _cell_num(cell):
    s = str(cell or "").strip().replace("\u2212", "-").replace(",", "")
    if _NUMERIC.match(s):
        return float(s)
    m = _LEADING_NUM.match(s)
    return float(m.group(1)) if m else None


def _clean_label(cell):
    s = str(cell or "").strip()
    # Leave the digit alone when it is part of the spec's name.
    if _NAME_ENDS_DIGIT.search(s):
        return s
    return _FOOTNOTE.sub("", s).strip()


def _row_unit(cells):
    """The unit token from the tail of a row, if any."""
    for c in reversed(cells[-3:]):
        t = str(c or "").strip()
        if _UNIT_TOKEN.match(t):
            return t
    tail = " ".join(str(c) for c in cells[-2:])
    m = re.search(r"\d\s*(dBm|dBc|dB|GHz|MHz|kHz|W|mW|kW|ns|\u00b5s|us|ms)\b",
                  tail, re.I)
    return m.group(1) if m else ""


def _row_numbers(cells):
    """Numeric cells after the label, with '-' placeholders preserved as None.

    Placeholders matter: 'Noise Figure | cond | - | 9 | - | dB' is a typ-only
    row, and collapsing the dashes would make 9 look like the minimum."""
    vals = []
    for c in cells[1:]:
        s = str(c or "").strip().lower()
        if s in _PLACEHOLDER:
            vals.append(None)
            continue
        if _UNIT_TOKEN.match(str(c).strip()):
            continue
        n = _cell_num(c)
        if n is not None:
            vals.append(n)
    # trailing placeholders carry no information
    while vals and vals[-1] is None:
        vals.pop()
    return vals


def _min_typ_max(vals, kind="max"):
    """(min, typ, max) from a row's numeric columns.

    Two numbers are ambiguous without a header, and the spec's own SENSE
    resolves it. A loss is quoted Typ. then Max. -- "0.4 | 0.87" is a typical
    0.4 dB with a 0.87 dB worst case. A return loss or isolation is quoted Min.
    then Typ. -- "15.9 | 24" is a guaranteed 15.9 dB with a typical 24, and
    reading it as typ/max inverted the part: the guaranteed floor became the
    typical and the typical became a ceiling.

    Both appear in ONE Mini-Circuits table, so this cannot be a per-vendor
    rule; it follows the spec.
    """
    if any(v is None for v in vals):
        slots = vals[:3] + [None] * (3 - len(vals[:3]))
        return slots[0], slots[1], slots[2]
    nums = [v for v in vals if v is not None]
    if not nums:
        return None, None, None
    if len(nums) == 1:
        return None, nums[0], None
    if len(nums) == 2:
        if kind == "min":
            return nums[0], nums[1], None       # Min. then Typ.
        return None, nums[0], nums[1]           # Typ. then Max.
    return nums[0], nums[1], nums[2]


# ======================================================== table spec vocabulary
# (key, label pattern, canonical unit, kind)
#
# `kind` decides two things: which column is authoritative, and how several rows
# under one label aggregate. A `max` spec keeps the worst (largest) value across
# condition rows, a `min` spec keeps the worst (smallest). That is the only
# defensible reading of a part quoted at 75/66/55 dB isolation over three bands.
SPEC_ROWS = [
    ("gain_db",            r"(?:small[\s-]*signal\s+|power\s+|linear\s+|"
                           r"conversion\s+|transducer\s+)?gain",         "dB",  "min"),
    ("nf_db",              r"noise\s*figure|^nf$",                        "dB",  "max"),
    ("p1db_dbm",           r"(?:output\s*)?p\s*1\s*-?\s*db|"
                           r"(?:output\s*)?1\s*db\s*compression",         "dBm", "min"),
    ("oip3_dbm",           r"(?:output\s*)?oip3|^output\s*ip3$|"
                           r"(?:third|3rd)[\s-]*order\s*(?:output\s*)?"
                           r"intercept|^ip3$",                            "dBm", "min"),
    ("psat_dbm",           r"(?:saturated\s*)?output\s*power|psat",       "dBm", "min"),
    ("isolation_db",       r"(?:\S+\s*(?:to|-|/)\s*\S+\s*)?isolation",    "dB",  "min"),
    ("insertion_loss_db",  r"insertion\s*loss|mainline\s*loss",           "dB",  "max"),
    ("conversion_loss_db", r"conversion\s*loss",                          "dB",  "max"),
    ("coupling_db",        r"coupling",                                   "dB",  "approx"),
    # Port-qualified return losses are DIFFERENT specs. A coupler quotes input,
    # output and coupled-port return loss separately, and folding them into one
    # key kept whichever was read last. Listed before the generic form so the
    # longest match wins.
    ("input_return_loss_db",   r"(?:input|in|rf\s*in)\s*(?:port\s*)?"
                               r"return\s*loss",                     "dB",  "min"),
    ("output_return_loss_db",  r"(?:output|out|rf\s*out)\s*(?:port\s*)?"
                               r"return\s*loss",                     "dB",  "min"),
    ("coupled_return_loss_db", r"coupled\s*(?:port\s*)?return\s*loss",
                                                                      "dB",  "min"),
    ("isolated_return_loss_db", r"isolated\s*(?:port\s*)?return\s*loss",
                                                                      "dB",  "min"),
    ("return_loss_db",     r"return\s*loss|\bVRL\b",                 "dB",  "min"),
    ("attenuation_db",     r"attenuation(?:\s*range)?",                   "dB",  "approx"),
    ("rejection_db",       r"(?:stopband\s*)?rejection|out[\s-]*of[\s-]*"
                           r"band\s*rejection",                           "dB",  "min"),
    ("power_w",            r"(?:rf\s*)?(?:input\s*)?power(?:\s*handling)?|"
                           r"rf\s*input\s*power|cw\s*power|rated\s*power|"
                           r"input\s*power\s*handling",                   "W",   "max"),
    ("switching_time_ns",  r"switching\s*(?:time|speed)|^t\s*(?:on|off)$|"
                           r"rise\s*/?\s*fall\s*time",                    "ns",  "max"),
    ("vswr",               r"vswr",                                       "",    "max"),
    ("impedance_ohm",      r"impedance",                                  "",    "approx"),
    ("current_ma",         r"(?:supply|dc|bias)\s*current|current"
                           r"\s*consumption",                             "mA",  "max"),
    ("supply_v",           r"(?:supply|bias)\s*voltage",                  "V",   "approx"),
]
SPEC_ROWS += [
    # From review: labels seen on real datasheets that nothing matched.
    # "Power Output @ 1 dB comp. (min)" is P1dB, not Psat -- the compression
    # point is stated in the label, and reading it as saturated power would
    # overstate the part.
    ("p1db_dbm", r"power\s*output\s*@?\s*1\s*db\s*comp(?:ression)?\.?|"
                 r"output\s*power\s*@?\s*1\s*db",                "dBm", "min"),
    ("oip2_dbm", r"(?:output\s*)?ip2|second[\s-]*order\s*(?:harmonic\s*)?"
                 r"(?:output\s*)?(?:ip|intercept)",                "dBm", "min"),
    ("amplitude_balance_db", r"amplitude\s*(?:un)?balance",         "dB",  "max"),
    ("phase_balance_deg",    r"phase\s*(?:un)?balance",             "deg", "max"),
    ("mainline_loss_db",     r"(?:total|main\s*line|mainline)\s*loss", "dB", "max"),
    ("gain_flatness_db",     r"gain\s*flatness",                    "dB",  "max"),
]
SPEC_ROWS += [
    # Labels seen in vendor header-tables that the list above does not reach.
    ("ways", r"(?:no\.?|number)\s*of\s*(?:ways|outputs|ports|channels)|"
             r"^ways$|^way$|^n\s*way$|configuration\s*\(ways\)",   "",    "approx"),
    ("group_delay_ns",          r"group\s*delay",                    "ns",  "max"),
    ("center_freq_ghz",         r"cent(?:er|re)\s*freq(?:uency)?",   "GHz", "approx"),
    ("passband_return_loss_db", r"passband\s*return\s*loss",        "dB",  "min"),
    ("rejection_db",            r"\d+\s*d?bc?\s*rejection(?:\s*point)?", "dB", "min"),
]
SPEC_ROWS = [(k, re.compile(r"^(?:%s)$" % p, re.I), u, kind)
             for k, p, u, kind in SPEC_ROWS]

# Trailing test conditions ride on the label -- "Insertion Loss @ fc",
# "Isolation (LO-RF)", "Gain, 25C". Anchoring the whole cell means every one of
# those misses, so the label is retried with the qualifier removed.
_LABEL_TAIL = re.compile(r"\s*(?:@|,|;|\bat\b)\s*[^|]*$", re.I)
_LABEL_PARENS = re.compile(r"\s*\([^)]*\)\s*$")
# Group headings that ride on the front of a merged label cell.
_LABEL_LEAD = re.compile(
    r"^(?:passband|pass\s*band|stopband|stop\s*band|lower|upper|"
    r"low\s*side|high\s*side|in[\s-]?band|out[\s-]?of[\s-]?band|"
    r"broadband|mid\s*band|small\s*signal|total|overall|nominal|"
    r"typical|input|output)\b[\s,;:-]*", re.I)


def match_spec(label):
    """The SPEC_ROWS entry for a table label, or None.

    Tries the label as written, then progressively strips trailing test
    conditions. Port-qualified names are checked FIRST so "passband return
    loss" reaches its own key instead of collapsing into plain return loss.
    """
    # LEADING group words merge into the label when the group cell is
    # vertically centred: ABF-26G+ yields "Passband Insertion Loss" and
    # "Stopband, Lower Rejection" as single cells, and an anchored match on the
    # whole string finds neither. The group is stripped and the remainder
    # retried, which is what the label would have been had the cell not merged.
    stripped = _LABEL_LEAD.sub("", label).strip(" ,:-")
    seen = []
    for cand in (label,
                 _LABEL_PARENS.sub("", label).strip(),
                 _LABEL_TAIL.sub("", label).strip(),
                 stripped,
                 _LABEL_TAIL.sub("", stripped).strip()):
        if not cand or cand in seen:
            continue
        seen.append(cand)
        hits = [tp for tp in SPEC_ROWS if tp[1].match(cand)]
        if hits:
            # Longest pattern wins: "passband return loss" beats "return loss".
            return max(hits, key=lambda tp: len(tp[1].pattern))
    return None

# Rows whose label names a port other than the part's main signal path. An IQ
# mixer's "LO Power Handling" is not its RF power rating.
_LABEL_OTHER_PORT = re.compile(r"^(lo|if|local\s*oscillator|intermediate)\b", re.I)
# Input-referred figures are a different spec from the output-referred one this
# vocabulary stores. "Input P1dB 9 dBm" is not P1dB(out).
_LABEL_INPUT_REFERRED = re.compile(r"^input\s*(p\s*1|1\s*db|ip3|iip3)", re.I)

# Physically possible windows. Outside these a value is a parse artifact, not a
# low-confidence measurement, and it is refused. Every one of these bounds was
# set by a real failure: 230914 W, 0.5 dB mixer NF, 2 dB isolation, 0 dBm OIP3.
# Specs whose SIGN is a convention, not information. ADI quote isolation and
# rejection as negative numbers off an S-parameter plot; the magnitude is the
# spec. Applied before the plausibility window, or a -45 dB isolation is
# rejected as out of range and the part loses the spec entirely.
ABS_SPECS = frozenset({
    "isolation_db", "isolation_lo_rf_db", "isolation_lo_if_db",
    "isolation_rf_if_db", "insertion_loss_db", "return_loss_db",
    "input_return_loss_db", "output_return_loss_db", "rejection_db",
    "stopband_rejection_db", "passband_return_loss_db", "conversion_loss_db",
    "coupling_db", "directivity_db", "mainline_loss_db", "attenuation_db",
    "reverse_isolation_db", "amplitude_balance_db", "phase_balance_deg",
})


def apply_sign(key, value):
    if value is None or key not in ABS_SPECS:
        return value
    try:
        return abs(float(value))
    except (TypeError, ValueError):
        return value


PLAUSIBLE = {
    "gain_db": (-5.0, 90.0),
    "nf_db": (0.2, 30.0),
    "p1db_dbm": (-40.0, 60.0),
    "oip3_dbm": (-10.0, 80.0),
    "psat_dbm": (-20.0, 70.0),
    "isolation_db": (5.0, 130.0),
    "insertion_loss_db": (0.01, 20.0),
    "conversion_loss_db": (2.0, 25.0),
    "coupling_db": (1.0, 60.0),
    "return_loss_db": (3.0, 45.0),
    "attenuation_db": (0.0, 120.0),
    "rejection_db": (5.0, 120.0),
    "power_w": (1e-4, 3000.0),
    "switching_time_ns": (0.5, 1e10),
    "vswr": (1.0, 6.0),
    "impedance_ohm": (10.0, 300.0),
    "current_ma": (0.01, 20000.0),
    "supply_v": (-60.0, 60.0),
    "freq_min": (0.0, 500.0),
    "freq_max": (1e-6, 500.0),
}

_TIME_SCALE = {"ns": 1.0, "nsec": 1.0, "us": 1e3, "usec": 1e3,
               "\u00b5s": 1e3, "\u03bcs": 1e3, "ms": 1e6, "msec": 1e6,
               "s": 1e9, "sec": 1e9}
_POWER_SCALE = {"w": 1.0, "mw": 1e-3, "kw": 1e3}
_CURRENT_SCALE = {"ma": 1.0, "a": 1e3, "\u00b5a": 1e-3, "ua": 1e-3}

# A row whose first cell is a CONDITION rather than a label continues the block
# above it. Mini-Circuits prints one 'Isolation' label beside three band rows;
# without this only the row the label happened to land on is read, and a 55 dB
# part is recorded as a 60 dB part.
_CONDITIONISH = re.compile(
    r"^(DC|\d+(?:\.\d+)?)\s*(?:-|\u2013|to)\s*\d|"
    r"^(?:cold|hot)\s*switch|^into\s+|^over\s+|^at\s+|^RF\s*/\s*LO\s*=|"
    r"^f\s*=|^all\s+|^per\s+", re.I)
# Condition text that identifies the headline rating among several. "Cold
# switching 30 W" is a mechanical switch's power rating; the hot-switching
# figure is a lifetime derating, two orders of magnitude lower.
_COND_HEADLINE = re.compile(r"cold\s*switch|non[\s-]*operating|\bmax(?:imum)?\b",
                            re.I)


def _scale_for(key, unit):
    u = (unit or "").strip().lower()
    if key == "switching_time_ns":
        return _TIME_SCALE.get(u, 1.0 if not u else None)
    if key == "power_w":
        if u == "dbm":
            return "dbm"
        return _POWER_SCALE.get(u, 1.0 if not u else None)
    if key == "current_ma":
        return _CURRENT_SCALE.get(u, 1.0 if not u else None)
    return 1.0


# --------------------------------------------------------- header-mapped rows
# Some vendors head their spec table with an explicit column row:
#
#   Parameter | Test Conditions | Minimum Frequency (GHz) | Maximum Frequency (GHz) | Min | Typ | Max
#   1 dBc Passband | 25C | 22.25 | 33.17 | - | - | -
#   Insertion Loss @ fc | 25C | - | - | - | 1.3 | -
#
# Read positionally without that header, cells[1] (a temperature condition) and
# the two frequency columns are mistaken for min/typ/max, so every Marki filter
# came out with either nothing or the wrong numbers. The header says exactly
# which column is which -- including telling min from typ from max, which is
# otherwise guessed from how many numbers happen to be present.
_HDR_PARAM = re.compile(r"^(parameter|specification|spec|description|item)s?$",
                        re.I)
_HDR_COND = re.compile(r"^(test\s*)?conditions?$|^notes?$", re.I)
_HDR_MIN = re.compile(r"^min(?:imum)?\.?$", re.I)
_HDR_TYP = re.compile(r"^typ(?:ical)?\.?$", re.I)
_HDR_MAX = re.compile(r"^max(?:imum)?\.?$", re.I)
_HDR_FMIN = re.compile(r"^min(?:imum)?\s*freq(?:uency)?", re.I)
_HDR_FMAX = re.compile(r"^max(?:imum)?\s*freq(?:uency)?", re.I)
_HDR_UNIT = re.compile(r"^units?$", re.I)


def parse_header(cells):
    """{role: column index} if this row is a spec-table header, else None.

    Requires a Parameter-ish first cell AND at least one of min/typ/max, so an
    ordinary data row whose first cell happens to read 'description' is not
    mistaken for a header."""
    if not cells or len(cells) < 3:
        return None
    roles = {}
    for i, c in enumerate(cells):
        s = str(c or "").strip()
        s = re.sub(r"\s*\([^)]*\)\s*$", "", s).strip()   # drop "(GHz)"
        if i == 0 and _HDR_PARAM.match(s):
            roles["param"] = i
        elif _HDR_FMIN.match(s):
            roles["fmin"] = i
        elif _HDR_FMAX.match(s):
            roles["fmax"] = i
        elif _HDR_MIN.match(s):
            roles["min"] = i
        elif _HDR_TYP.match(s):
            roles["typ"] = i
        elif _HDR_MAX.match(s):
            roles["max"] = i
        elif _HDR_COND.match(s):
            roles["cond"] = i
        elif _HDR_UNIT.match(s):
            roles["unit"] = i
    if "param" not in roles:
        return None
    if not ({"min", "typ", "max"} & set(roles)):
        return None
    # Remember the header text of the frequency columns so their unit is known.
    roles["_freq_unit"] = "GHz"
    for key in ("fmin", "fmax"):
        if key in roles:
            m = re.search(r"\((\w*Hz)\)", str(cells[roles[key]]), re.I)
            if m:
                roles["_freq_unit"] = m.group(1)
    return roles


def _cell_at(cells, roles, role):
    i = roles.get(role)
    if i is None or i >= len(cells):
        return None
    s = str(cells[i] or "").strip()
    if s.lower() in _PLACEHOLDER:
        return None
    return _cell_num(s)


# ------------------------------------------------- column-oriented tables
# Mini-Circuits print couplers and filters with the SPEC NAMES ACROSS THE TOP
# and one data row per frequency band:
#
#   FREQ.   | COUPLING | MAINLINE LOSS1 | DIRECTIVITY | VSWR | POWER
#   (MHz)   | (dB)     | (dB)           | (dB)        | (:1) | (W)
#   f-f     | Nom.     | Flatness       | Typ. | Max. | Typ. | Min.
#   400-470 | 32.5+-0.8| +-0.9          | 0.02 | 0.20 | 30   | 23
#
# Neither of the other readers can see this: both expect the label in column 0,
# and here column 0 is a frequency band. Cell COUNTS also differ row to row --
# 6 on one line, 7 on the next -- because empty cells collapse, so columns have
# to be matched by x-position rather than by index. That is what defeated the
# whole Mini-Circuits coupler folder (600 datasheets, every one yielding
# nothing).
_UNIT_ROW = re.compile(r"^\(?\s*(dB|dBm|MHz|GHz|W|:1|mA|V|ns|deg)\s*\)?$", re.I)


def _overlaps(a0, a1, b0, b1, pad=4.0):
    return a1 > b0 - pad and a0 < b1 + pad


# ------------------------------------------------- typical-performance sweeps
# Mini-Circuits print a "Typical Performance Data" table -- a frequency sweep,
# eighteen rows of measurements at 5/570/575/600 MHz and so on. It is not a spec
# table, but it looks exactly like one to a positional reader, and being LATER
# in the document it overwrites the real values. SXBP-1430+ came out with a
# 10.23 dB insertion loss (its loss at 650 MHz, deep in the stopband) and a
# 5.26 dB return loss, when the actual spec row says passband loss < 1.5 dB.
#
# A sweep is recognisable without knowing the vendor: a run of rows with the
# same shape whose first column is a frequency that only ever increases.
def sweep_rows(rows, min_run=4):
    """Indices of rows belonging to a frequency-sweep table."""
    marked, i, n = set(), 0, len(rows)
    while i < n:
        run, prev, j = [], None, i
        while j < n:
            cells = rows[j][1]
            if len(cells) < 3:
                break
            # A cell that is a RANGE is a band label, not a sweep point.
            # "10 GHz to 18 GHz" reads as 10 through _cell_num, and 10/18/27/38
            # increase, so ADI's piecewise blocks were being deleted as sweeps
            # before any reader saw them.
            if parse_band_cell(cells[0]):
                break
            v = _cell_num(cells[0])
            if v is None or (prev is not None and v <= prev):
                break
            run.append(j)
            prev = v
            j += 1
        if len(run) >= min_run:
            marked.update(run)
            # The heading directly above a sweep belongs to it as well.
            if run[0] > 0:
                head = " ".join(str(c) for c in rows[run[0] - 1][1])
                if re.search(r"typical|performance|data|frequency", head, re.I):
                    marked.add(run[0] - 1)
        i = j if j > i else i + 1
    return marked


def strip_sweeps(rows):
    """Rows with any frequency-sweep table removed."""
    bad = sweep_rows(rows)
    return [r for k, r in enumerate(rows) if k not in bad]


# --------------------------------------------------- temperature-column tables
# MACOM head their amplifier tables with TEMPERATURE RANGES, not min/typ/max:
#
#   Parameter              | Units | 25C  | 0 to 50C | -54 to +85C
#   Small Signal Gain (min)| dB    | 18.0 | 17.5     | 17.0
#   Noise Figure (max)     | dB    | 3.5  | 5.0      | 5.5
#
# Read positionally those become min/typ/max and the answer is the 25 C figure,
# which is the best case. Across a temperature range the honest number is the
# WORST one: 17.0 dB of gain, 5.5 dB of noise figure, 87 mA of current.
_TEMP_COL = re.compile(
    r"^[-+\u2212]?\d{1,3}\s*\u00b0?\s*[oC]?C?\s*(?:to|\u2013|-)\s*"
    r"[-+\u2212]?\d{1,3}\s*\u00b0?\s*[oC]?C?\*?$|"
    r"^[-+\u2212]?\d{1,3}\s*\u00b0?\s*[oC]?C\*?$", re.I)


def temperature_columns(cells):
    """Indices of cells that name a temperature or temperature range."""
    out = []
    for i, c in enumerate(cells):
        s = str(c or "").strip().replace("º", "\u00b0")
        if _TEMP_COL.match(s):
            out.append(i)
    return out if len(out) >= 2 else []


def mine_temperature_table(rows):
    """{key: rec} for tables whose columns are temperature conditions."""
    found, cols = {}, None
    for _pno, cells in rows:
        if not cells:
            continue
        tc = temperature_columns(cells)
        if tc:
            cols = tc
            continue
        if not cols:
            continue
        label = _clean_label(cells[0])
        if not label or len(label) > 52:
            continue
        hit = match_spec(label)
        if not hit:
            continue
        key, _rx, want_unit, kind = hit
        if key == "vswr":
            vals = [v for v in (vswr_from_cell(c) for c in cells[1:])
                    if v is not None]
        else:
            vals = [v for v in (_cell_num(c) for c in cells[1:])
                    if v is not None]
        if len(vals) < 2:
            continue
        # Worst across the quoted temperatures, per the spec's own sense.
        v = max(vals) if kind == "max" else min(vals)
        bounds = PLAUSIBLE.get(key)
        if bounds and not (bounds[0] <= v <= bounds[1]):
            continue
        found[key] = {"value": v, "min": min(vals), "typ": None,
                      "max": max(vals), "unit": want_unit, "kind": kind,
                      "method": "table-temp", "confidence": CONF_TABLE,
                      "row": re.sub(r"\s+", " ",
                                    " | ".join(str(c) for c in cells))[:110]}
    return found


# ------------------------------------------- filter symbol-row tables (F1..F6)
# Mini-Circuits filters head their spec table with a SYMBOL row that aligns 1:1
# with the data row, while the human-readable labels are spread over the two
# rows above it:
#
#   CENTER | PASSBAND | STOPBANDS (MHz)                    | VSWR (:1)
#   FREQ.  | (MHz)    | (Loss<1.5dB) | Loss>20dB | Loss 30dB Typ. | Passband | Stopband
#   Fc     | F1 - F2  | F3 | F4 | F5 | F6                  | Typ. | Max.
#   1430   | 950-2150 | 575| 2850| 570| 2850-5000          | 1.3  | 1.9
#
# The symbols are the reliable anchor: no other table uses Fc/F1-F2/F3..F6, and
# they map positionally onto the data. Reading the label rows instead means
# guessing which of three header lines a given number belongs to.
_SYM_FC = re.compile(r"^F\s*c$|^fc$", re.I)
_SYM_BAND = re.compile(r"^F\s*1\s*-\s*F\s*2$", re.I)
_SYM_FN = re.compile(r"^F\s*([3-9])$", re.I)
_SYM_TYP = re.compile(r"^typ\.?$", re.I)
_SYM_MAX = re.compile(r"^max\.?$", re.I)


def filter_symbol_table(rows, default_unit="MHz"):
    """{key: rec} from a Mini-Circuits filter symbol/data row pair."""
    out = {}
    scale = _FREQ_UNIT.get(default_unit.lower(), 1e-3)
    for i, (_pno, cells) in enumerate(rows):
        syms = [str(c).strip() for c in cells]
        if not any(_SYM_FC.match(s) for s in syms):
            continue
        if not any(_SYM_BAND.match(s) for s in syms):
            continue
        # The data row is the next row with at least as many numeric cells.
        data = None
        for j in range(i + 1, min(i + 4, len(rows))):
            cand = rows[j][1]
            if sum(1 for c in cand if _cell_num(c) is not None
                   or parse_band_cell(c)) >= 3:
                data = cand
                break
        if data is None:
            continue
        stop_edges = []
        for k, s in enumerate(syms):
            if k >= len(data):
                break
            cell = data[k]
            if _SYM_FC.match(s):
                v = _cell_num(cell)
                if v is not None:
                    out["center_freq_ghz"] = {
                        "value": round(v * scale, 9), "unit": "GHz",
                        "kind": "approx", "method": "table-symbols",
                        "confidence": CONF_TABLE,
                        "row": f"Fc = {cell}"}
            elif _SYM_BAND.match(s):
                band = parse_band_cell(cell, default_unit=default_unit)
                if band:
                    out["_passband"] = {"lo": band[0], "hi": band[1],
                                        "method": "table-symbols",
                                        "confidence": CONF_TABLE,
                                        "row": f"F1-F2 = {cell}"}
            elif _SYM_FN.match(s):
                band = parse_band_cell(cell, default_unit=default_unit)
                if band:
                    stop_edges += [band[0], band[1]]
                else:
                    v = _cell_num(cell)
                    if v is not None:
                        stop_edges.append(round(v * scale, 9))
            elif _SYM_TYP.match(s) or _SYM_MAX.match(s):
                v = _cell_num(cell)
                # A VSWR is the only thing in this table quoted around unity.
                if v is not None and 1.0 <= v <= 6.0:
                    prev = out.get("vswr")
                    worst = max(prev["value"], v) if prev else v
                    out["vswr"] = {"value": worst, "unit": "", "kind": "max",
                                   "method": "table-symbols",
                                   "confidence": CONF_TABLE,
                                   "row": f"VSWR typ/max = {cell}"}
        if stop_edges:
            out["_stopband_edges"] = sorted(set(stop_edges))
        break
    return out


# ----------------------------------------------- hierarchical sub-spec rows
# ADI break one spec into named sub-rows beneath a parent label:
#
#   Input Third-Order Intercept (IP3)
#     Low-Side IP3   48 dBm   f1 = 0.9 x fCENTER
#     High-Side IP3  51 dBm
#     In-Band IP3    40 dBm
#
# Those are three measurements of ONE spec, so the part is a 40 dBm part -- the
# worst of them. Reading the parent line by regex picked 48, which is both the
# wrong figure and the wrong spec: it is an INPUT intercept, so it belongs to
# iip3_dbm, not oip3_dbm.
_SUB_QUALIFIER = re.compile(
    r"^(low[\s-]?side|high[\s-]?side|in[\s-]?band|upper|lower|mid[\s-]?band|"
    r"band\s*\d|state\s*\d)\s+", re.I)
# Input-referred names, mapped to their own keys rather than discarded.
_INPUT_REFERRED = {
    "ip3": "iip3_dbm", "iip3": "iip3_dbm",
    "third-order intercept": "iip3_dbm", "third order intercept": "iip3_dbm",
    "compression": "p1db_input_dbm", "p1db": "p1db_input_dbm",
    "p0.1db": "p1db_input_dbm",
}


def _input_referred_key(label):
    low = str(label or "").lower()
    if not re.search(r"\binput\b|^i(?:ip3|p1db)\b", low):
        return None
    for frag, key in _INPUT_REFERRED.items():
        if frag in low:
            return key
    return None


def mine_sub_spec_rows(rows):
    """{key: rec} for specs split into qualifier-prefixed sub-rows."""
    groups, parents = {}, {}
    for idx, (_pno, cells) in enumerate(rows):
        if not cells:
            continue
        label = _clean_label(cells[0])
        if not label:
            continue
        m = _SUB_QUALIFIER.match(label)
        if not m:
            continue
        base = label[m.end():].strip()
        if not base:
            continue
        # The PARENT row decides input- vs output-referred. The sub-rows say
        # only "Low-Side IP3"; the line above says "Input Third-Order
        # Intercept", and that is the difference between iip3 and oip3 -- a
        # 10 dB error in the wrong direction if the parent is ignored.
        # Scan ALL of the few rows above for an input/output cue rather than
        # stopping at the first non-sub label: ADI wrap the test conditions onto
        # their own line, so the row immediately above is a fragment of the
        # condition text, not the parent heading.
        # The parent heading is resolved for the GROUP, keyed on the base name,
        # not re-derived per row: scanning back a fixed distance found the cue
        # for the first sub-row and missed it for the later ones, so the three
        # IP3 sub-rows landed under two different keys and the worst case never
        # won.
        base_norm = re.sub(r"[^a-z0-9]", "", base.lower())
        if base_norm not in parents:
            found_parent = ""
            for back in range(1, 8):
                if idx - back < 0:
                    break
                row_txt = " ".join(str(c) for c in
                                   (rows[idx - back][1] or [])[:2])
                if re.search(r"\b(input|output)\b.{0,40}"
                             r"(intercept|compression|ip3|ip2|p1\s?db)",
                             row_txt, re.I):
                    found_parent = row_txt
                    break
            parents[base_norm] = found_parent
        parent = parents[base_norm]
        key = (_input_referred_key(base) or _input_referred_key(label)
               or _input_referred_key(f"{parent} {base}"))
        if key is None:
            hit = match_spec(base)
            if not hit:
                continue
            key = hit[0]
        vals = [v for v in (_cell_num(c) for c in cells[1:]) if v is not None]
        if not vals:
            continue
        groups.setdefault(key, []).append(
            {"sub": m.group(1).strip(), "value": vals[0],
             "row": re.sub(r"\s+", " ",
                           " | ".join(str(c) for c in cells))[:90]})
    out = {}
    for key, subs in groups.items():
        if len(subs) < 2:
            continue
        kind = next((d for a, _b, _c, d in SPEC_ROWS if a == key), "min")
        vals = [s["value"] for s in subs]
        v = max(vals) if kind == "max" else min(vals)
        bounds = PLAUSIBLE.get(key)
        if bounds and not (bounds[0] <= v <= bounds[1]):
            continue
        unit = next((c for a, _b, c, _d in SPEC_ROWS if a == key), "dBm")
        out[key] = {"value": v, "unit": unit, "kind": kind,
                    "method": "table-subspecs", "confidence": CONF_TABLE,
                    "subs": subs,
                    "row": f"{len(subs)} sub-spec(s), worst {kind} {v}: "
                           + ", ".join(f"{s['sub']} {s['value']:g}"
                                       for s in subs)[:70]}
    return out


def mine_column_table(path, pages=ROW_PAGES):
    """{key: rec} from tables whose spec names are column headings.

    Columns are located by x-extent, so a data row with fewer cells than the
    header still lines up. Values are aggregated the same way as elsewhere:
    the worst case across the band rows, because a coupler quoted at 30/28 dB
    directivity over two sub-bands is a 28 dB part.
    """
    found = {}
    try:
        for pno in range(1, pages + 1):
            try:
                xy = cells_xy(path, pno)
            except Exception:
                continue
            if not xy:
                continue
            # mine_column_table reads the page from disk, so the sweep rows
            # stripped upstream are still present here. Detect them again on
            # this view or the sweep wins: it sits below the spec table and
            # overwrites it.
            as_rows = [(pno, [c["t"] for c in r["cells"]]) for r in xy]
            sweep = sweep_rows(as_rows)
            for hi, hrow in enumerate(xy):
                cols = []
                for c in hrow["cells"]:
                    lab = _clean_label(c["t"])
                    if not lab or len(lab) > 30:
                        continue
                    hit = match_spec(lab)
                    if hit:
                        cols.append((hit, c["x0"], c["x1"]))
                # Two or more spec names on one line is a column header; one is
                # an ordinary label row and belongs to the other readers.
                if len(cols) < 2:
                    continue
                for di, drow in list(enumerate(xy))[hi + 1: hi + 12]:
                    if di in sweep:
                        continue
                    if is_header_fragment([c["t"] for c in drow["cells"]]):
                        continue
                    numeric = [c for c in drow["cells"]
                               if _cell_num(c["t"]) is not None]
                    if len(numeric) < 2:
                        continue        # a unit row or a qualifier row
                    if all(_UNIT_ROW.match(c["t"].strip())
                           for c in drow["cells"][:3]):
                        continue
                    for (hit, x0, x1) in cols:
                        key, _rx, want_unit, kind = hit
                        vals = [_cell_num(c["t"]) for c in drow["cells"]
                                if _overlaps(c["x0"], c["x1"], x0, x1)
                                and _cell_num(c["t"]) is not None]
                        if not vals:
                            continue
                        v = max(vals) if kind == "max" else min(vals)
                        bounds = PLAUSIBLE.get(key)
                        if bounds and not (bounds[0] <= v <= bounds[1]):
                            continue
                        prev = found.get(key)
                        if prev is None:
                            found[key] = {
                                "value": v, "min": None, "typ": v, "max": None,
                                "unit": want_unit, "kind": kind,
                                "method": "table-columns",
                                "confidence": CONF_TABLE,
                                "row": re.sub(r"\s+", " ", " | ".join(
                                    c["t"] for c in drow["cells"]))[:110]}
                        else:
                            agg = max if kind == "max" else min
                            prev["value"] = agg(prev["value"], v)
                            prev["typ"] = prev["value"]
    except Exception:
        return found
    return found


# ===================================================== piecewise band specs
# A spec is often NOT one number. A cable's insertion loss is 0.34 dB to 2 GHz
# and 1.22 dB to 18 GHz; a switch's isolation is 45 dB to 2 GHz and 40 dB to
# 3.5 GHz. Collapsing that to a single value throws away the part -- and picks
# an arbitrary band while doing it.
#
# Two further structures have to be handled to read them at all:
#
#   * the label sits on the MIDDLE row of its group, because the cell is
#     vertically merged and the text is centred:
#         Dc - 2.0 Ghz   | 0.5 | 0.8 | dB
#         insertion Loss | Dc - 3.0 Ghz | 0.6 | 0.9 | dB
#         Dc - 3.5 Ghz   | 0.7 | 1.1 | dB
#     so a reader that only looks at cells[0] of each row finds the label once
#     and the bands never.
#
#   * the condition column may name a PORT or a SUB-SPEC rather than a band
#     ("RF1 & RF2", "Low-Side IP3"), which makes a separate series, not a
#     separate band of the same series.
# ADI write the unit on BOTH numbers -- "10 GHz to 18 GHz" -- while
# Mini-Circuits write it once at the end. Requiring the unit only at the end
# meant not one ADI band cell matched, so an entire common ADI layout produced
# no piecewise specs at all.
_BAND_CELL = re.compile(
    r"^(DC|\d+(?:\.\d+)?)\s*(GHz|MHz|kHz)?\s*(?:-|\u2013|\u2014|to)\s*"
    r"(\d+(?:\.\d+)?)\s*(GHz|MHz|kHz)?$", re.I)
_SUBSPEC_CELL = re.compile(
    r"^(low[\s-]?side|high[\s-]?side|in[\s-]?band|rf\s*\d|lo|if|"
    r"input|output|on\s*state|off\s*state)", re.I)


def parse_band_cell(text, default_unit="GHz"):
    """(lo, hi) in GHz from 'DC - 2.0 GHz', '2 - 6' or '10 GHz to 18 GHz'."""
    m = _BAND_CELL.match(str(text or "").strip())
    if not m:
        return None
    lo_raw, lo_u, hi_raw, hi_u = m.groups()
    # A unit on the second number governs both unless the first states its own.
    hi_unit = (hi_u or lo_u or default_unit).lower()
    lo_unit = (lo_u or hi_unit).lower()
    lo = (0.0 if lo_raw.upper() == "DC"
          else float(lo_raw) * _FREQ_UNIT.get(lo_unit, 1.0))
    hi = float(hi_raw) * _FREQ_UNIT.get(hi_unit, 1.0)
    if hi <= lo or hi > _MAX_GHZ:
        return None
    return round(lo, 9), round(hi, 9)


# A wrapped header line looks like a data row: "(MHz) | (dB) | Unbalance |
# (dB) | Unbalance | S | 1 | 2" is the SECOND line of a column heading, and
# reading it gave PSCQ-2-26+ a VSWR of 2.0 from the column index "2".
_HEADER_FRAGMENT = re.compile(
    r"^\(?\s*(?:MHz|GHz|dB|dBm|deg\.?|W|mA|V|ns|%|:1)\s*\)?$|"
    r"^(?:unbalance|balance|typ\.?|max\.?|min\.?|nom\.?|units?|s|f)$", re.I)


def is_header_fragment(cells):
    """Is this row the wrapped continuation of a column heading?"""
    tokens = [str(c or "").strip() for c in cells if str(c or "").strip()]
    if len(tokens) < 3:
        return False
    frag = sum(1 for x in tokens if _HEADER_FRAGMENT.match(x))
    # Bare column indices ("1", "2", "3") beside unit tokens are heading text.
    tiny = sum(1 for x in tokens if re.fullmatch(r"\d{1,2}", x))
    return (frag + tiny) >= max(3, int(0.7 * len(tokens)))


def band_segments(rows, roles=None, window=2):
    """{spec key: [segment, ...]} where a segment is one band's numbers.

    Each band row is assigned to its OWN nearest spec label -- the row itself
    first, then rows within `window` above and below. Grouping consecutive band
    rows into one run instead was wrong: a switch lists insertion loss and
    isolation as adjacent band blocks, and the run swallowed both, filing twelve
    isolation and loss bands under whichever label it happened to find first.
    """
    out = {}
    labelled = {}
    for idx, (_pno, cells) in enumerate(rows):
        for c in list(cells[:2]):
            lab = _clean_label(c)
            if not lab or parse_band_cell(c):
                continue
            hit = match_spec(lab)
            if hit:
                labelled[idx] = hit
                break
    # Runs of contiguous rows that either carry a band or carry a spec label:
    # one block of the spec table. Bounding the label search to the run stops a
    # band borrowing a name from an unrelated table further down the page.
    def _is_subport(cells):
        """A short, numberless row naming a port: 'S1', 'P1, P2', 'RF1 & RF2'.

        ADI subdivide one spec by port -- RETURN LOSS, then S1 with four bands,
        then P1, P2 with four more. These rows carry neither a band nor a spec
        name, so treating them as the end of the block orphaned every band
        after the first sub-port and let the next heading claim them: the
        ADAR5001's P1/P2 return loss was filed as isolation."""
        toks = [str(c or "").strip() for c in (cells or []) if str(c or "").strip()]
        if not toks or len(toks) > 2:
            return False
        if any(_cell_num(c) is not None for c in toks):
            return False
        return bool(re.fullmatch(
            r"(?:[SPRLI][0-9]?|RF\s?\d?|LO|IF|P\d(?:\s*[,&/]\s*P\d)*|"
            r"S\d(?:\s*[,&/]\s*S\d)*|all\s+ports?|each\s+port)"
            r"(?:\s*[,&/]\s*\w{1,4})*", toks[0], re.I))

    run_bounds, subport_at, i0 = {}, {}, 0
    n_rows = len(rows)
    while i0 < n_rows:
        cells0 = rows[i0][1] or []
        has_band = any(parse_band_cell(c) for c in cells0[:3])
        if not (has_band or i0 in labelled):
            i0 += 1
            continue
        j0 = i0
        while j0 + 1 < n_rows:
            nxt = rows[j0 + 1][1] or []
            if (any(parse_band_cell(c) for c in nxt[:3])
                    or (j0 + 1) in labelled or _is_subport(nxt)):
                if _is_subport(nxt):
                    subport_at[j0 + 1] = " ".join(
                        str(c) for c in nxt if str(c or "").strip())[:24]
                j0 += 1
            else:
                break
        for k0 in range(i0, j0 + 1):
            run_bounds[k0] = (i0, j0)
        i0 = j0 + 1

    headings = {j for j in labelled
                if not any(parse_band_cell(c)
                           for c in (rows[j][1] or [])[:3])}

    last_label = None
    for idx, (_pno, cells) in enumerate(rows):
        if not cells:
            continue
        if idx in labelled:
            last_label = (idx, labelled[idx])
        band = None
        for c in cells[:3]:
            band = parse_band_cell(c)
            if band:
                break
        if band is None:
            # A labelled row with no band ends the previous block; an unlabelled
            # non-band row (a wrapped header) does not.
            if idx in labelled:
                last_label = (idx, labelled[idx])
            continue
        hit = labelled.get(idx)
        if hit is None:
            # NEAREST label by distance, above or below, bounded to the run of
            # contiguous band rows this row belongs to.
            #
            # A merged cell CENTRES its label, so a four-band block carries its
            # name on row three. E50-2FT stacks insertion loss (rows 19-22,
            # label on 21) directly against return loss (rows 23-26, label on
            # 25) with no gap between them: "nearest above" gives rows 23-24 to
            # insertion loss, and a fixed window gives them to nobody. Nearest
            # by distance splits the two blocks at their midpoint, which is
            # exactly where a centred label puts the boundary.
            lo_i, hi_i = run_bounds.get(idx, (idx, idx))
            # Two conventions, told apart by whether the label row carries a
            # band of its own:
            #   centred  -- "Insertion Loss | dB | 26.5-40 | 3.0 | 3.9"  (E50)
            #   heading  -- "INSERTION LOSS" alone, block beneath it     (ADI)
            # A heading owns everything below it until the next heading, so
            # nearest-by-distance is wrong there: the last band of a block is
            # closer to the NEXT heading than to its own.
            head = None
            for j in sorted(headings):
                if lo_i <= j <= idx:
                    head = j
            if head is not None:
                hit = labelled[head]
                best_d = None
            else:
                best_d = None
            for j, h in labelled.items():
                if head is not None:
                    break
                if not (lo_i <= j <= hi_i):
                    continue
                d = abs(j - idx)
                # Ties resolve DOWNWARD. A centred label in a four-row block
                # sits on row three, so a row equidistant from two labels
                # belongs to the block below: E50-2FT's "DC - 18 | 19 | 20" is
                # two rows from both "Insertion Loss" and "Return Loss", and it
                # is the first return-loss band.
                if best_d is None or d <= best_d:
                    best_d, hit = d, h
        if hit is None:
            # A row that carries its OWN label must not borrow a neighbour's.
            # "Gain Flatness" sits directly under "Gain", matches no spec, and
            # borrowing gave gain_db a 0.5 dB band that then won as the worst
            # case -- turning a 24.5 dB amplifier into a 0.5 dB one. Only a
            # BARE band row (no label text at all) may look at its neighbours,
            # which is the merged-cell case the window exists for.
            own = _clean_label(cells[0]) if cells else ""
            if own and not parse_band_cell(cells[0]) and len(own) > 3:
                continue
            for d in range(1, window + 1):
                hit = labelled.get(idx - d) or labelled.get(idx + d)
                if hit:
                    break
        if hit is None:
            continue
        key, _rx, want_unit, kind = hit
        # Drop the band by POSITION, not by value. "DC - 18 | 18 | 34" is a
        # 18 dB minimum with a 34 dB typical, but 18 also happens to be the
        # band's upper edge -- filtering on the number deleted the minimum and
        # left a single value that then read as the typical.
        vals = []
        for c in cells:
            if parse_band_cell(c):
                continue                # this cell IS the band
            v = _cell_num(c)
            if v is not None:
                vals.append(v)
        if not vals:
            continue
        lo, typ, hi = _min_typ_max(vals[:3], kind)
        lo, typ, hi = (apply_sign(key, lo), apply_sign(key, typ),
                       apply_sign(key, hi))
        sub = None
        for c in cells[:3]:
            if _SUBSPEC_CELL.match(str(c).strip()):
                sub = str(c).strip()
                break
        if sub is None:
            # The nearest sub-port divider above this row names its series.
            for j in sorted(subport_at, reverse=True):
                if j < idx and run_bounds.get(j) == run_bounds.get(idx):
                    sub = subport_at[j]
                    break
        bounds = PLAUSIBLE.get(key)
        probe = typ if typ is not None else (hi if hi is not None else lo)
        if bounds and probe is not None and not (bounds[0] <= probe <= bounds[1]):
            continue
        out.setdefault(key, []).append(
            {"band_ghz": list(band), "unit": want_unit, "min": lo, "typ": typ, "max": hi,
             "sub": sub,
             "row": re.sub(r"\s+", " ",
                           " | ".join(str(c) for c in cells))[:90]})
    # Identical bands repeated from a second page add nothing.
    for key, segs in out.items():
        seen, uniq = set(), []
        for s in segs:
            sig = (tuple(s["band_ghz"]), s["min"], s["typ"], s["max"], s["sub"])
            if sig in seen:
                continue
            seen.add(sig)
            uniq.append(s)
        out[key] = uniq
    return out


def worst_of(segments, kind):
    """The value to store as the headline for a piecewise spec.

    The WORST band, not the first and not an average: a cable whose loss reaches
    1.22 dB at 18 GHz is a 1.22 dB cable for any purpose that has to hold across
    its range. Same rule the multi-row aggregation already uses, applied across
    bands instead of across condition rows."""
    vals = []
    for s in segments:
        v = {"max": s.get("max"), "min": s.get("min")}.get(kind)
        if v is None:
            v = s.get("typ")
        if v is None:
            v = s.get("max") if s.get("max") is not None else s.get("min")
        if v is not None:
            vals.append(v)
    if not vals:
        return None
    return max(vals) if kind == "max" else min(vals)


def mine_header_rows(rows):
    """{key: rec} for tables that declare their own columns.

    Returned in the same shape as mine_rows so the two can be merged, but with
    min/typ/max taken from the columns the vendor labelled rather than inferred
    from position -- which is what makes 'only Min is populated' readable
    instead of looking like a typ value.
    """
    found, roles = {}, None
    band = None
    for _pno, cells in rows:
        if not cells:
            continue
        hdr = parse_header(cells)
        if hdr:
            roles = hdr
            continue
        if not roles:
            continue
        label = _clean_label(cells[0])
        if not label or len(label) > 52:
            continue
        lo = _cell_at(cells, roles, "min")
        typ = _cell_at(cells, roles, "typ")
        hi = _cell_at(cells, roles, "max")
        fmin = _cell_at(cells, roles, "fmin")
        fmax = _cell_at(cells, roles, "fmax")

        # A row carrying only frequency columns describes a BAND, not a scalar:
        # "1 dBc Passband | 22.25 | 33.17" is the part's passband.
        if fmin is not None or fmax is not None:
            scale = _FREQ_UNIT.get(str(roles.get("_freq_unit", "GHz")).lower(),
                                   1.0)
            edges = [v * scale for v in (fmin, fmax) if v is not None]
            if edges and re.search(r"passband|pass\s*band|frequency\s*range|"
                                   r"operating", label, re.I):
                lo_e, hi_e = min(edges), max(edges)
                # Prefer the 1 dB passband over the 3 dB one when both appear.
                rank = 0 if re.search(r"\b1\s*d?bc?\b", label, re.I) else 1
                if band is None or rank < band[2]:
                    band = (lo_e, hi_e if hi_e > lo_e else None, rank,
                            " | ".join(str(c) for c in cells)[:110])
            if lo is None and typ is None and hi is None:
                continue

        if lo is None and typ is None and hi is None:
            continue
        hit = match_spec(label)
        if not hit:
            continue
        key, _rx, want_unit, kind = hit
        if _LABEL_OTHER_PORT.match(label) or _LABEL_INPUT_REFERRED.match(label):
            continue
        primary = {"max": hi, "min": lo}.get(kind, typ)
        if primary is None:
            primary = typ if typ is not None else (hi if hi is not None else lo)
        bounds = PLAUSIBLE.get(key)
        if bounds and (primary is None
                       or not (bounds[0] <= primary <= bounds[1])):
            continue
        found[key] = {"value": primary, "min": lo, "typ": typ, "max": hi,
                      "unit": want_unit, "kind": kind, "method": "table-header",
                      "confidence": CONF_TABLE,
                      "row": re.sub(r"\s+", " ",
                                    " | ".join(str(c) for c in cells))[:110]}
    if band:
        found["_band"] = {"lo": band[0], "hi": band[1], "row": band[3],
                          "method": "table-header", "confidence": CONF_TABLE}
    return found


def mine_rows(rows):
    """{key: {...}} from positional table rows.

    The returned dict carries min/typ/max, the literal row it came from and a
    confidence, so a caller can both filter on the conservative edge and compare
    typ-to-typ against a catalog value.
    """
    found = {}
    block_key = None
    for _pno, cells in rows:
        if not cells or is_header_fragment(cells):
            continue
        label = _clean_label(cells[0])
        if not label or len(label) > 52:
            block_key = None
            continue
        unit = _row_unit(cells)
        vals = _row_numbers(cells)
        matched = [x for x in (match_spec(label),) if x]
        if matched:
            block_key = matched[0][0]
            if _LABEL_OTHER_PORT.match(label) or _LABEL_INPUT_REFERRED.match(label):
                block_key = None
                continue
        elif block_key and _CONDITIONISH.match(label) and vals:
            matched = [t for t in SPEC_ROWS if t[0] == block_key]
        elif not _CONDITIONISH.match(label):
            block_key = None
        if not matched or not vals:
            continue
        key, _rx, want_unit, kind = matched[0]
        scale = _scale_for(key, unit)
        if scale is None:
            continue                    # unit present but not one we understand
        if want_unit and unit and not _UNIT_COMPATIBLE.get(key, lambda u: True)(unit):
            continue
        lo, typ, hi = _min_typ_max(vals, kind)
        if scale == "dbm":              # power quoted in dBm
            conv = lambda v: None if v is None else 10 ** ((v - 30) / 10.0)
        elif isinstance(scale, (int, float)) and scale != 1.0:
            conv = lambda v, s=scale: None if v is None else v * s
        else:
            conv = lambda v: v
        lo, typ, hi = conv(lo), conv(typ), conv(hi)
        primary = {"max": hi, "min": lo}.get(kind, typ)
        if primary is None:
            primary = typ if typ is not None else (hi if hi is not None else lo)
        lo, typ, hi, primary = (apply_sign(key, lo), apply_sign(key, typ),
                                apply_sign(key, hi), apply_sign(key, primary))
        if kind == "max" and hi is not None:
            primary = hi
        elif kind == "min" and lo is not None:
            primary = lo
        bounds = PLAUSIBLE.get(key)
        if bounds and (primary is None or not (bounds[0] <= primary <= bounds[1])):
            continue
        conf = CONF_TABLE if (unit or not want_unit) else CONF_TABLE_WEAK
        rec = {"value": primary, "min": lo, "typ": typ, "max": hi,
               "unit": want_unit, "kind": kind, "method": "table",
               "confidence": conf,
               "row": re.sub(r"\s+", " ", " | ".join(str(c) for c in cells))[:110]}
        prev = found.get(key)
        if prev is None:
            found[key] = rec
            continue
        # Several rows under one label: keep the worst case, but let an
        # explicitly headline condition ("cold switching") override outright.
        cond = " ".join(str(c) for c in cells[1:3])
        if _COND_HEADLINE.search(cond) and kind == "max":
            found[key] = rec
            continue
        agg = max if kind == "max" else min
        if kind in ("max", "min"):
            if agg(prev["value"], primary) != prev["value"]:
                rec["row"] = prev["row"] + "  //  " + rec["row"]
                found[key] = rec
            else:
                for edge, fn in (("min", min), ("max", max)):
                    a, b = prev.get(edge), rec.get(edge)
                    if a is not None and b is not None:
                        prev[edge] = fn(a, b)
    return found


# Unit sanity per spec: a dB value cannot satisfy a dBm spec, and "RF Power
# Handling 25 dBm" is 0.32 W, not 25 W.
_UNIT_COMPATIBLE = {
    "gain_db": lambda u: u.lower() in ("db",),
    "nf_db": lambda u: u.lower() in ("db",),
    "isolation_db": lambda u: u.lower() in ("db",),
    "insertion_loss_db": lambda u: u.lower() in ("db",),
    "conversion_loss_db": lambda u: u.lower() in ("db",),
    "coupling_db": lambda u: u.lower() in ("db",),
    "return_loss_db": lambda u: u.lower() in ("db",),
    "attenuation_db": lambda u: u.lower() in ("db",),
    "rejection_db": lambda u: u.lower() in ("db",),
    "p1db_dbm": lambda u: u.lower() in ("dbm",),
    "oip3_dbm": lambda u: u.lower() in ("dbm",),
    "psat_dbm": lambda u: u.lower() in ("dbm",),
    "power_w": lambda u: u.lower() in ("w", "mw", "kw", "dbm"),
    "switching_time_ns": lambda u: u.lower() in _TIME_SCALE,
    "current_ma": lambda u: u.lower() in _CURRENT_SCALE,
    "supply_v": lambda u: u.lower() in ("v",),
    "vswr": lambda u: u.lower() in (":1", ""),
    "impedance_ohm": lambda u: u.lower() in ("\u00b0", "", "ohm", "ohms"),
}


# ============================================================== family sheets
_MPNISH = re.compile(r"^[A-Z0-9]{2,}(?:[-/][A-Z0-9]+){1,4}\+?$", re.I)


# "400-470" and "470-610" are frequency bands, not part numbers, but they fit
# the MPN shape exactly. On a Mini-Circuits coupler the band rows made the sheet
# look like a four-part family, its own row was never found, and every spec was
# suppressed -- 600 datasheets yielding nothing for that reason alone.
_BAND_LIKE = re.compile(r"^\d{1,5}(?:\.\d+)?\s*[-\u2013]\s*\d{1,5}(?:\.\d+)?$")
_ALL_DIGITS = re.compile(r"^[\d.\-\u2013\s]+$")


def looks_like_mpn(tok):
    """Is this token a part number rather than a number range?

    A real MPN carries letters. A token that is only digits and a dash is a
    band, a pin range or a date, whatever the shape says."""
    s = str(tok or "").strip()
    if not s or not _MPNISH.match(s):
        return False
    if _BAND_LIKE.match(s) or _ALL_DIGITS.match(s):
        return False
    return bool(re.search(r"[A-Za-z]", s))


def family_mpns(rows, min_cells=4):
    """MPN-shaped tokens that start a data row -- an ordering table's rows."""
    starts = []
    for _p, cells in rows:
        if len(cells) >= min_cells and looks_like_mpn(cells[0]):
            starts.append(str(cells[0]).strip().upper())
    return sorted(set(starts))


def _share_prefix(tokens, least=3):
    """Do these tokens look like SIBLINGS of one family?

    A real ordering table lists MSS40-045-C15, MSS40-048-C15, MSS40-141-B10B --
    one stem, several suffixes. A single-part datasheet lists accessory codes
    instead: PL-713 (PCB layout), TR-F004 (tape and reel), VG3044 (case style),
    ENV120 (environmental rating), TB-ABF-26G+ (eval board). Those share no
    stem with each other, and counting them made ABF-26G+ look like a
    five-part family -- so its own row was never found and every spec on an
    ordinary filter datasheet was suppressed.
    """
    stems = {}
    for tok in tokens:
        m = re.match(r"^[A-Za-z]{2,}[0-9]*", str(tok))
        if not m:
            continue
        stems.setdefault(m.group(0).upper(), 0)
        stems[m.group(0).upper()] += 1
    return any(n >= least for n in stems.values())


def is_family_sheet(rows):
    """Three or more distinct parts tabulated on one page.

    Deliberately not 'two': a datasheet often lists the part and one variant
    (a +RoHS suffix, a die version), and treating that as a family would
    suppress mining on ordinary single-part sheets."""
    toks = family_mpns(rows)
    return len(toks) >= 3 and _share_prefix(toks)


def part_row(rows, mpn, min_cells=4):
    """The ordering-table row whose first cell is this MPN, or None."""
    want = _loose(mpn)
    if not want:
        return None
    for _p, cells in rows:
        if cells and _loose(cells[0]) == want and len(cells) >= min_cells:
            return cells
    return None


def family_column(xy_rows, part_top, header_cell, y_window=24.0, pad=6.0):
    """The cell under `header_cell`'s column nearest the part's row.

    Needed because ordering tables merge cells vertically: on a MACOM coupler
    sheet the Freq. Range cell spans a group of four part rows and therefore is
    not on the part's own row at all. Flattened text loses it completely, and
    the module used to fall back to the family's advertised span -- reading
    "0.5 through 18 GHz" for a 4-8 GHz part."""
    best = None
    for r in xy_rows:
        dy = abs(r["top"] - part_top)
        if dy > y_window:
            continue
        for c in r["cells"]:
            if c["x1"] > header_cell["x0"] - pad and c["x0"] < header_cell["x1"] + pad:
                if best is None or dy < best[0]:
                    best = (dy, c["t"])
    return best[1] if best else None


_FREQ_HDR = re.compile(r"^freq(?:uency)?\.?(?:\s*range)?$|^range$", re.I)


def family_band(path, mpn):
    """(lo, hi, evidence) for one part on an ordering-table sheet, or None."""
    try:
        for pno in range(1, ROW_PAGES + 1):
            xy = cells_xy(path, pno)
            if not xy:
                continue
            target = None
            for r in xy:
                if r["cells"] and _loose(r["cells"][0]["t"]) == _loose(mpn):
                    target = r
                    break
            if target is None:
                continue
            hdr = None
            for r in xy:
                if r["top"] >= target["top"]:
                    continue
                for c in r["cells"]:
                    if _FREQ_HDR.match(c["t"].strip()):
                        hdr = c
                if hdr is not None and r["top"] > target["top"] - 220:
                    break
            if hdr is None:
                continue
            cell = family_column(xy, target["top"], hdr)
            if not cell:
                continue
            band = _parse_band_text(cell)
            if band:
                return band[0], band[1], f"ordering table column: {cell!r}"
    except Exception:
        return None
    return None


_UNITLESS_RANGE = re.compile(
    r"^(DC|\d+(?:\.\d+)?)\s*(?:-|\u2013|to)\s*(\d+(?:\.\d+)?)$", re.I)


def _parse_band_text(text, default_unit="ghz"):
    """'4.0-8.0' or '1000 to 4500 MHz' -> (lo_ghz, hi_ghz)."""
    s = str(text or "").strip()
    m = _RANGE_RE.search(s)
    if m:
        lo_raw, lo_u, hi_raw, hi_u = m.groups()
        hs = _FREQ_UNIT.get((hi_u or "").lower())
        if hs is not None:
            ls = _FREQ_UNIT.get((lo_u or "").lower(), hs)
            lo = 0.0 if lo_raw.lower() == "dc" else float(lo_raw) * ls
            hi = float(hi_raw) * hs
            if 0 <= lo < hi <= 500:
                return round(lo, 9), round(hi, 9)
    m = _UNITLESS_RANGE.match(s)
    if m:
        scale = _FREQ_UNIT[default_unit]
        lo = 0.0 if m.group(1).lower() == "dc" else float(m.group(1)) * scale
        hi = float(m.group(2)) * scale
        if 0 <= lo < hi <= 500:
            return round(lo, 9), round(hi, 9)
    return None


# ============================================================ frequency band
_FREQ_UNIT = {"thz": 1e3, "ghz": 1.0, "mhz": 1e-3, "khz": 1e-6, "hz": 1e-9}
_RANGE_RE = re.compile(
    r"(?<![\w.])(DC|\d+(?:\.\d+)?)\s*(thz|ghz|mhz|khz)?\s*"
    r"(?:-|\u2013|\u2014|to|through)\s*"
    r"(\d+(?:\.\d+)?)\s*(thz|ghz|mhz|khz)\b", re.I)
_MIN_GHZ, _MAX_GHZ = 1e-6, 500.0

_FREQ_ROW_LABEL = re.compile(
    r"^(?:rf\s*)?(?:operating\s*)?freq(?:uency)?\.?\s*(?:range)?$|"
    r"^passband$|^tuning\s*range$|^bandwidth$", re.I)
_FREQ_BAD = re.compile(
    r"\b(series|family|portfolio|key features|product line|catalog|"
    r"other models|selection guide|available in|models? from)\b", re.I)
_FREQ_PORT_OTHER = re.compile(r"\b(if|lo|local\s*oscillator|"
                              r"intermediate\s*frequency)\b", re.I)
_FREQ_LOOSE = re.compile(r"\b(typ\.?|typical|wide\s*bandwidth|up to|nominal)\b",
                         re.I)
# Temperature ranges look exactly like frequency ranges once a unit lands
# nearby, so the word still has to be RECOGNISED even though no temperature
# spec is stored. The window is deliberately tight: at 90 characters an
# unrelated "Storage Temperature" three lines up was penalising the correct
# band on Mini-Circuits coupler sheets.
_FREQ_UNIT_ONLY = re.compile(r"\b(temperature|storage|humidity|altitude)\b", re.I)
# A range with dB values right after it is a per-band PERFORMANCE row, not the
# part's band. The old scorer REWARDED this (+1 for digits nearby), which is
# how "18-26.5 GHz" off an insertion-loss table beat "DC to 26.5 GHz" from the
# page header on every wideband switch in the library.
_PERF_AFTER = re.compile(r"\d[\d.\s]*\s*(dB|dBm)\b", re.I)
_FIFTY_OHM = re.compile(r"(\u03a9|\b50\s*ohm)", re.I)

_CAND_CACHE = {}


def _candidates(text):
    """{(lo, hi): {n, best_ctx_score}} for every plausible range in `text`."""
    key = _memo_key(text)
    hit = _CAND_CACHE.get(key)
    if hit is not None:
        return hit
    seen = {}
    for m in _RANGE_RE.finditer(text or ""):
        lo_raw, lo_u, hi_raw, hi_u = m.groups()
        hs = _FREQ_UNIT.get((hi_u or "").lower())
        if hs is None:
            continue
        # A unit given only on the second number governs both: "1 to 2500 MHz"
        # is megahertz at each end, not 1 GHz to 2.5 GHz.
        ls = _FREQ_UNIT.get((lo_u or "").lower(), hs)
        lo = 0.0 if lo_raw.lower() == "dc" else float(lo_raw) * ls
        hi = float(hi_raw) * hs
        if hi <= lo or hi > _MAX_GHZ or lo < 0 or hi < _MIN_GHZ:
            continue
        pair = (round(lo, 9), round(hi, 9))
        rec = seen.setdefault(pair, {"n": 0, "ctx": -99, "snippet": ""})
        rec["n"] += 1
        s = _context_score(text, m)
        if s > rec["ctx"]:
            rec["ctx"] = s
            rec["snippet"] = re.sub(r"\s+", " ", m.group(0))[:70]
    if len(_CAND_CACHE) > 8:
        _CAND_CACHE.clear()
    _CAND_CACHE[key] = seen
    return seen


def _context_score(text, m):
    """Wording immediately around one candidate."""
    before = text[max(0, m.start() - 70):m.start()]
    after = text[m.end():m.end() + 45]
    score = 0
    if _FREQ_BAD.search(before):
        score -= 6
    if _FREQ_PORT_OTHER.search(before[-26:]):
        score -= 5
    if _FREQ_LOOSE.search(before) or _FREQ_LOOSE.search(after):
        score -= 2
    if _FREQ_UNIT_ONLY.search(before[-22:]):
        score -= 8
    if _PERF_AFTER.search(after):
        score -= 4
    if _FIFTY_OHM.search(before[-22:]):
        score += 4
    return score


def _range_score(text, m):
    """Total score for one candidate: context, repetition and containment.

    Kept at this signature because the debug tooling re-derives the winning
    snippet by calling it directly, and a scorer that disagreed with
    freq_range_ghz would print evidence contradicting the answer.

    Repetition is the strong signal. A part's own band is repeated -- the page
    header on every page, the overview sentence, the features bullet -- while a
    sub-band from a performance table appears once. Containment is the other:
    the L/M/U segment legends that flattened tables are full of
    ("L = 5-50 MHz  M = 50-375 MHz  U = 375-750 MHz") are always strictly
    inside the real band.
    """
    lo_raw, lo_u, hi_raw, hi_u = m.groups()
    hs = _FREQ_UNIT.get((hi_u or "").lower())
    if hs is None:
        return -99
    ls = _FREQ_UNIT.get((lo_u or "").lower(), hs)
    lo = 0.0 if lo_raw.lower() == "dc" else float(lo_raw) * ls
    hi = float(hi_raw) * hs
    pair = (round(lo, 9), round(hi, 9))
    cands = _candidates(text)
    rec = cands.get(pair)
    if rec is None:
        return _context_score(text, m)
    score = rec["ctx"] + min(4, 2 * (rec["n"] - 1))
    for (olo, ohi), other in cands.items():
        if (olo, ohi) == pair:
            continue
        if olo <= lo and hi <= ohi and (hi - lo) < (ohi - olo) \
                and other["n"] >= rec["n"]:
            score -= 4
            break
    return score


def freq_from_rows(rows):
    """(lo, hi, evidence) from an explicit 'Frequency Range' row, or None.

    This is the highest-confidence band there is and it was not being read at
    all: 'Frequency Range | DC | 26.5 | GHz' has no separator between the two
    numbers, so the prose range regex cannot see it."""
    for _pno, cells in rows:
        if not cells:
            continue
        label = _clean_label(cells[0])
        if not _FREQ_ROW_LABEL.match(label):
            continue
        if _FREQ_PORT_OTHER.match(label):
            continue        # "IF Frequency Range" is not the part's band
        unit = _row_unit(cells) or "GHz"
        scale = _FREQ_UNIT.get(unit.lower())
        if scale is None:
            continue
        edges = []
        for c in cells[1:]:
            s = str(c).strip()
            if s.upper() == "DC":
                edges.append(0.0)
                continue
            if s.lower() in _PLACEHOLDER or _UNIT_TOKEN.match(s):
                continue
            band = _parse_band_text(s, default_unit=unit.lower())
            if band:
                edges.extend(band)
                continue
            n = _cell_num(c)
            if n is not None:
                edges.append(n * scale)
        if len(edges) >= 2:
            lo, hi = min(edges), max(edges)
            if hi > lo and hi <= _MAX_GHZ:
                return (round(lo, 9), round(hi, 9),
                        re.sub(r"\s+", " ", " | ".join(str(c) for c in cells))[:90])
    return None


def freq_range_ghz(text, head_chars=_HEAD_CHARS):
    """(low, high) in GHz for the part's own band, or None.

    Candidates are SCORED rather than taken in order: a datasheet's front page
    carries the family's span, the operating temperature and sometimes a
    competitor comparison, all of which look like ranges.
    """
    best, best_score = None, -99
    for chunk in (text[:head_chars], text):
        for m in _RANGE_RE.finditer(chunk or ""):
            lo_raw, lo_u, hi_raw, hi_u = m.groups()
            hi_scale = _FREQ_UNIT.get((hi_u or "").lower())
            if hi_scale is None:
                continue
            lo_scale = _FREQ_UNIT.get((lo_u or "").lower(), hi_scale)
            lo = 0.0 if lo_raw.lower() == "dc" else float(lo_raw) * lo_scale
            hi = float(hi_raw) * hi_scale
            if hi <= lo or hi > _MAX_GHZ or lo < 0 or hi < _MIN_GHZ:
                continue
            s = _range_score(chunk, m)
            if s > best_score:
                best, best_score = (round(lo, 9), round(hi, 9)), s
        if best is not None:
            break
    return best


# ============================================================ prose fallback
# The registry's patterns are used as-is except where a specific pattern was
# measured producing wrong values. Overriding here rather than in registry.py
# keeps the live-crawler path (extract.py) unchanged while every consumer of
# _PATTERNS -- including the debug tooling -- picks up the fix.
#
# The construct `(?:(?!BAD)[^.\n\r]){0,30}?` is a tempered gap: it spans up to
# thirty characters but refuses to cross any of the listed words, so a label
# cannot reach past a test condition to grab the condition's number. That is the
# entire cause of "IP3 Two-tone inputs up to +5 dBm" being read as OIP3 = 5,
# "OIP3 measured with 0 dBm" as OIP3 = 0, and "IP3 data shown for a +19 dBm" as
# OIP3 = 19.
_COND_WORDS = (r"two[- ]tone|per\s*tone|each\s*tone|measured|shown|drive|"
               r"input|referred|typical|within|assum|reference|example|"
               r"condition")
_GAP = r"(?:(?!%s)[^.\n\r]){0,30}?" % _COND_WORDS
_GAP_SHORT = r"(?:(?!%s)[^.\n\r]){0,20}?" % _COND_WORDS

_WORD_WAYS = {"two": 2, "three": 3, "four": 4, "five": 5, "six": 6,
              "eight": 8, "nine": 9, "ten": 10, "twelve": 12, "sixteen": 16}


def ways_from_text(text):
    """Way count for a splitter/combiner, or None.

    The title carries it far more reliably than any table row -- "2 Way Power
    Splitter", "Four-Way Combiner" -- and a divider without its way count is
    missing the thing it is selected on.
    """
    head = (text or "")[:1200]
    m = re.search(r"(?<![\w.])(\d{1,2})\s*[-\u2013 ]?\s*way\b", head, re.I)
    if m:
        n = int(m.group(1))
        return n if 2 <= n <= 64 else None
    m = re.search(r"\b(" + "|".join(_WORD_WAYS) + r")[-\s]?way\b", head, re.I)
    if m:
        return _WORD_WAYS[m.group(1).lower()]
    return None


_PATTERN_OVERRIDES = {
    # The bare `(\d+)\s*(?:W|watt)` fallback is DELETED, not tightened. With
    # re.I and no trailing boundary it matched a number followed by the footer
    # URL -- "251202\nwww.minicircuits.com" became a 251202 W transformer --
    # and with no leading boundary it matched inside part numbers, so
    # "MADL-000301-01340W" became a 1340 W limiter. Both appeared on hundreds
    # of files. There is no context in which a bare number beside the letter W
    # is trustworthy evidence of a power rating.
    "power_w": [
        r"(?:power\s*handling|input\s*power|cw\s*power|rated\s*power|"
        r"rf\s*power)" + _GAP_SHORT +
        r"(?<![\w.\-])(\d+(?:\.\d+)?)\s*(?:W|watts?)\b",
    ],
    "oip3_dbm": [
        r"OIP3" + _GAP + r"(?<![\w.\-])([+-]?\d+(?:\.\d+)?)\s*dBm\b",
        r"(?:third|3rd)[-\s]*order\s*(?:output\s*)?intercept" + _GAP +
        r"(?<![\w.\-])([+-]?\d+(?:\.\d+)?)\s*dBm\b",
        r"(?<!input\s)\bIP3\b" + _GAP +
        r"(?<![\w.\-])([+-]?\d+(?:\.\d+)?)\s*dBm\b",
    ],
    "gain_db": [
        # "Power Gain" and "Transducer Gain" are gain; only "gain flatness"
        # and "gain step" are not.
        r"(?:small[\s-]*signal|power|linear|transducer)?\s*gain"
        r"(?!\s*(?:flatness|step|range|slope|control|error))" + _GAP +
        r"(?<![\w.\-])([-+]?\d+(?:\.\d+)?)\s*dB\b",
    ],
    "nf_db": [
        r"noise\s*figure" + _GAP + r"(?<![\w.\-])(\d+(?:\.\d+)?)\s*dB\b",
        r"\bNF\b" + _GAP_SHORT + r"(?<![\w.\-])(\d+(?:\.\d+)?)\s*dB\b",
    ],
    # These had NO prose pattern at all -- they were reachable only from a
    # table. "Insertion loss above 4.8 dB" in a features bullet was therefore
    # invisible, while the same spec on a near-identical datasheet was found
    # because that one happened to tabulate it.
    "insertion_loss_db": [
        # "mainline loss" is deliberately NOT matched here: on a coupler it is
        # its own spec, and letting it fill insertion_loss_db too put one
        # number in two fields a search could disagree about. Expressed as a
        # negated alternation rather than a lookbehind -- Python needs those
        # fixed-width, and the multi-word forms are not.
        # "above"/"in excess of" must NOT be crossed: the number after it is
        # the theoretical split baseline printed in the header, not the part's
        # loss. Matching it stored 3.1 dB as a 2-way splitter's insertion loss
        # when 3.1 is what every 2-way loses before any dissipation at all.
        r"(?:^|[^A-Za-z])(?:(?!mainline|main line|through|thru)[A-Za-z]{0,10}\s*)?"
        r"insertion\s*loss"
        r"(?:(?!above|excess|in excess)[^.\n\r]){0,30}?"
        r"(?<![\w.\-])(\d+(?:\.\d+)?)\s*dB\b",
    ],
    "return_loss_db": [
        r"(?<!input\s)(?<!output\s)(?<!coupled\s)(?<!isolated\s)"
        r"(?<!port\s)return\s*loss(?!\s*\()" + _GAP +
        r"(?<![\w.\-])(\d+(?:\.\d+)?)\s*dB\b",
    ],
    "input_return_loss_db": [
        r"input\s*(?:port\s*)?return\s*loss" + _GAP +
        r"(?<![\w.\-])(\d+(?:\.\d+)?)\s*dB\b",
    ],
    "output_return_loss_db": [
        r"output\s*(?:port\s*)?return\s*loss" + _GAP +
        r"(?<![\w.\-])(\d+(?:\.\d+)?)\s*dB\b",
    ],
    "coupled_return_loss_db": [
        r"coupled\s*(?:port\s*)?return\s*loss" + _GAP +
        r"(?<![\w.\-])(\d+(?:\.\d+)?)\s*dB\b",
    ],
    "coupling_db": [
        r"\bcoupling\b(?!\s*(?:nut|cap))" + _GAP +
        r"(?<![\w.\-])(\d+(?:\.\d+)?)\s*dB\b",
    ],
    "directivity_db": [
        r"\bdirectivity\b" + _GAP + r"(?<![\w.\-])(\d+(?:\.\d+)?)\s*dB\b",
    ],
    "mainline_loss_db": [
        r"(?:mainline|main\s*line|through|thru)\s*(?:insertion\s*)?loss"
        + _GAP + r"(?<![\w.\-])(\d+(?:\.\d+)?)\s*dB\b",
    ],
    "amplitude_balance_db": [
        r"amplitude\s*(?:un)?balance" + _GAP +
        r"(?<![\w.\-])(\d+(?:\.\d+)?)\s*dB\b",
    ],
    "phase_balance_deg": [
        r"phase\s*(?:un)?balance" + _GAP +
        r"(?<![\w.\-])(\d+(?:\.\d+)?)\s*(?:deg|degrees?|\u00b0)\b",
    ],
    "isolation_db": [
        r"isolation" + _GAP + r"(?<![\w.\-])(\d+(?:\.\d+)?)\s*dB\b",
    ],
    "p1db_dbm": [
        r"(?<!input\s)P\s*1\s*-?\s*dB" + _GAP +
        r"(?<![\w.\-])([+-]?\d+(?:\.\d+)?)\s*dBm\b",
        r"(?<!input\s)1\s*-?\s*dB\s*compression" + _GAP +
        r"(?<![\w.\-])([+-]?\d+(?:\.\d+)?)\s*dBm\b",
    ],
}


def _compile_patterns():
    """Prose patterns by spec key.

    Iterates the UNION of the registry and the overrides. Iterating only the
    registry meant an override for a key the registry does not declare was
    silently discarded -- insertion_loss_db and return_loss_db are not in
    PARAM_SPECS, so they had no prose pattern at all and were reachable only
    from a table. A spec written in a features bullet was invisible.
    """
    out = {}
    keys = set(PARAM_SPECS) | set(_PATTERN_OVERRIDES)
    for key in sorted(keys):
        meta = PARAM_SPECS.get(key) or {}
        pats = _PATTERN_OVERRIDES.get(key) or meta.get("patterns")
        if not pats:
            continue
        compiled = []
        for p in pats:
            try:
                compiled.append(re.compile(p, re.I))
            except re.error:
                continue
        if compiled:
            out[key] = compiled
    return out


_PATTERNS = _compile_patterns()

# Words that mark a nearby number as a test condition rather than a
# measurement. Applied as a second guard even after the tempered gaps, because
# a footnote can carry the condition wording AFTER the value: "Noise Figure
# typically measures within 0.5 dB of conversion loss" is the one that gave
# every Marki mixer a 0.5 dB noise figure.
_NEG_CTX = re.compile(
    r"\b(two[- ]tone|per tone|each tone|measured with|measured at|shown for|"
    r"test condition|input drive|drive level|referred to|typically measures|"
    r"within \d|approximately|assumes|for reference|for example|e\.g\.)\b",
    re.I)


def _prose_guard(text, m):
    before = text[max(0, m.start() - 90):m.start()]
    after = text[m.end():m.end() + 45]
    return not (_NEG_CTX.search(before) or _NEG_CTX.search(after))


# Table rows put the number AFTER the unit -- "Small Signal Gain (min) dB 8.5" --
# while the PARAM_SPECS patterns expect "Gain 8.5 dB". Neither ordering is more
# correct, and datasheets use both, so the reversed form is read here rather
# than doubling every pattern in the registry. This is a text-level fallback for
# files where positional extraction is unavailable; mine_rows supersedes it.
_TABLE_ROW = [
    ("gain_db", r"(?:small\s*signal\s*)?gain(?:\s*\((?:min|typ|max)\))?", "dB"),
    ("nf_db", r"noise\s*figure(?:\s*\((?:min|typ|max)\))?|\bNF\b", "dB"),
    ("p1db_dbm", r"(?:output\s*)?P\s*1\s*-?\s*dB(?:\s*\((?:min|typ|max)\))?", "dBm"),
    ("oip3_dbm", r"(?:output\s*)?(?:OIP3|IP3)(?:\s*\((?:min|typ|max)\))?", "dBm"),
    ("isolation_db", r"isolation(?:\s*\((?:min|typ|max)\))?", "dB"),
    ("insertion_loss_db", r"insertion\s*loss(?:\s*\((?:min|typ|max)\))?", "dB"),
    ("conversion_loss_db", r"conversion\s*loss(?:\s*\((?:min|typ|max)\))?", "dB"),
    ("psat_dbm", r"(?:saturated\s*)?output\s*power(?:\s*\((?:min|typ|max)\))?", "dBm"),
]
# The label must be wrapped: an un-grouped alternation like "noise figure|NF"
# binds only its last branch to what follows, so a match on the first branch
# leaves the value group unset and float(None) raises.
_TABLE_ROW = [(k, re.compile(rf"(?:{pat})\s*{unit}\s+"
                             rf"(?<![\w.\-])([-+]?\d+(?:\.\d+)?)", re.I), unit)
              for k, pat, unit in _TABLE_ROW]


def mine_table_rows(text):
    """Specs written as 'Label unit value', the way spec tables flatten."""
    out = {}
    for key, rx, unit in _TABLE_ROW:
        m = rx.search(text or "")
        if not m:
            continue
        try:
            value = float(m.group(1))
        except (TypeError, ValueError):
            continue
        bounds = PLAUSIBLE.get(key)
        if bounds and not (bounds[0] <= value <= bounds[1]):
            continue
        if not _prose_guard(text, m):
            continue
        out[key] = (value, unit)
    return out


# ============================================================== cross-checks
def cross_check(specs, note=None):
    """Drop values that contradict other values from the same datasheet.

    Cheap, and it catches what per-spec bounds cannot: 0.5 dB is a perfectly
    plausible noise figure in isolation, and impossible beside a 9 dB
    conversion loss on the same page."""
    dropped = []

    def _val(k):
        v = specs.get(k)
        if isinstance(v, dict):
            return v.get("value")
        if isinstance(v, (tuple, list)) and v:
            return v[0] if isinstance(v[0], (int, float)) else None
        return None

    nf, cl = _val("nf_db"), _val("conversion_loss_db")
    if nf is not None and cl is not None and abs(nf - cl) > 2.5:
        # A passive mixer's SSB noise figure equals its conversion loss to
        # within a fraction of a dB. Anything else on the same page is the
        # footnote, not the spec.
        method = specs.get("nf_db")
        if not (isinstance(method, dict) and method.get("method") == "table"):
            specs.pop("nf_db", None)
            dropped.append(("nf_db", f"{nf} dB beside a {cl} dB conversion loss"))
    oip3, p1db = _val("oip3_dbm"), _val("p1db_dbm")
    if oip3 is not None and p1db is not None and oip3 < p1db:
        specs.pop("oip3_dbm", None)
        dropped.append(("oip3_dbm", f"{oip3} dBm below P1dB {p1db} dBm"))
    fmin, fmax = _val("freq_min"), _val("freq_max")
    if fmin is not None and fmax is not None and fmax <= fmin:
        specs.pop("freq_min", None)
        specs.pop("freq_max", None)
        dropped.append(("freq_min/max", f"{fmin}-{fmax} GHz is not a band"))
    if note and dropped:
        for k, why in dropped:
            note(f"      dropped {k}: {why}")
    return dropped


# ------------------------------------------------- space-qualification hint
# Weighted evidence for how space-capable a datasheet SOUNDS. This is a hint for
# the many parts where no source states a qualification, not a replacement for
# the `space` field -- a stated qualification always wins, and this is stored
# under its own key so the two can never be confused.
#
# It is deliberately rule-based and explainable: every score comes with the list
# of terms that produced it, so a number can always be argued with. spacequal.py
# remains the statistical view; this is the cheap one that runs during a rebuild.
_SPACE_EVIDENCE = [
    # (weight, label, pattern)  -- strong: an actual qualification standard
    (30, "MIL-PRF-38534 Class K", r"38534.{0,20}class\s*k|class\s*k.{0,20}38534"),
    (30, "MIL-PRF-38535 Class V/QML-V", r"38535|qml-?\s*v\b|class\s*v\b"),
    (28, "JANS", r"\bjans\b"),
    (26, "ESCC", r"\bescc\b|european space components"),
    (26, "radiation hardened", r"radiation[- ]hardened|rad[- ]?hard\b"),
    (22, "TID rating", r"\btid\b.{0,24}\d+\s*k?rad|\d+\s*krad"),
    (22, "SEL/SEE rating", r"\bsel\b.{0,24}mev|mev\s*[\u00b7*x]?\s*cm|single event"),
    (20, "space qualified", r"space[- ]qualified|qualified for space|space[- ]grade"),
    (18, "Class S", r"\bclass\s*s\b"),
    # moderate: screening and construction that space parts require
    (12, "hermetic", r"\bhermetic|hermetically sealed"),
    (12, "MIL-STD-883", r"mil-?std-?883|method\s*20\d\d"),
    (10, "screened", r"\bscreen(?:ed|ing)\b|\bburn-?in\b|\b100%\s*test"),
    # NOT any MIL-STD. The generic "MIL-STD-\d{3}" awarded 10 points to
    # MIL-STD-348, the RF coaxial CONNECTOR INTERFACE standard, which appears
    # on every Mini-Circuits cable and says nothing whatever about space. The
    # standards below are the ones that actually bear on space suitability --
    # screening, environmental stress, radiation and space-vehicle interfaces:
    #   750  semiconductor test methods (screening)
    #   202  electronic component test methods
    #   1540 test requirements for launch and space vehicles
    #   1541 electromagnetic compatibility, space systems
    #   461  EMI/EMC
    #   810  environmental engineering
    #   883  handled separately, above
    (10, "MIL-STD (screening/environmental)",
     r"mil-?std-?(?:750|202|1540|1541|461|810)\b"),
    # "TML" alone is too thin a thread to hang 8 points on -- it is three
    # letters that can turn up anywhere -- and it made the evidence
    # unverifiable: the label said ASTM E595 when the text contained neither
    # "ASTM" nor "E595". Outgassing has to be stated outright.
    (8,  "outgassing/ASTM E595",
     r"outgassing|astm\s*e-?595|total\s+mass\s+loss|\bCVCM\b"),
    # weak: materials common in space parts but also in ordinary ones
    (6,  "LTCC/ceramic", r"\bltcc\b|\bceramic\b|\balumina\b"),
    (5,  "GaAs", r"\bgaas\b|gallium arsenide"),
    (5,  "GaN", r"\bgan\b|gallium nitride"),
    (4,  "Kovar/gold", r"\bkovar\b|gold[- ]plated|au plated"),
    (4,  "MMIC", r"\bmmic\b"),
    # negative: statements that rule it out
    (-30, "commercial only", r"commercial\s*(use|grade)\s*only|not\s*for\s*space"),
    (-14, "plastic encapsulated", r"plastic\s*(encapsulat|package)"),
    (-10, "consumer/automotive", r"\bconsumer\b|\bautomotive\b|aec-?q\d+"),
]
_SPACE_EVIDENCE = [(w, lbl, re.compile(pat, re.I)) for w, lbl, pat in _SPACE_EVIDENCE]

# Above this, calling it a strong hint is fair; the cap keeps one very wordy
# datasheet from scoring higher than a genuinely qualified part.
_SPACE_MAX = 100

# Bare-die / chip form. Deliberately narrow: "die" appears in "died", "diode"
# and in ordering codes, so it has to be qualified by a form word.
_DIE_FORM = re.compile(
    r"\bbare\s+die\b|\bdie\s+form\b|\bchip\s+form\b|\bin\s+die\b|"
    r"\bunpackaged\b|\bdie\s+(?:size|thickness|attach)\b|"
    r"\bchip\s+and\s+wire\b", re.I)


# ------------------------------------------------------ connector / package
# dsmine mined neither, so a connectorised cable arrived with no package and no
# connector at all -- the two facts that identify it physically. They are kept
# SEPARATE: a connector is only meaningful when the part is connectorised, and
# a surface-mount part's package says nothing about connectors.
#
# The list is ordered longest-first so "2.92 mm" is not read as "2 mm" and
# "SMA-Female" is not reduced to "SMA".
_CONNECTORS = [
    ("0.8 mm",   r"\b0\.8\s*mm\b(?!\s*(?:pitch|thick|dia))"),
    ("1.0 mm",   r"\b1\.0\s*mm\b(?!\s*(?:pitch|thick|dia))"),
    ("1.35 mm",  r"\b1\.35\s*mm\b"),
    ("1.85 mm",  r"\b1\.85\s*mm\b|\bV\s*connector\b"),
    ("2.4 mm",   r"\b2\.4\s*mm\b(?!\s*(?:pitch|thick))"),
    ("2.92 mm",  r"\b2\.92\s*mm\b|\bK\s*connector\b"),
    ("3.5 mm",   r"\b3\.5\s*mm\b(?!\s*(?:pitch|thick|jack|audio))"),
    ("SMPM",     r"\bSMPM\b|\bGPPO\b"),
    ("SMPS",     r"\bSMPS\b(?!\s*supply)"),
    ("SMP",      r"\bSMP\b|\bGPO\b"),
    ("SSMA",     r"\bSSMA\b"),
    ("SSMC",     r"\bSSMC\b"),
    ("SMA",      r"\bSMA\b"),
    ("SMB",      r"\bSMB\b"),
    ("SMC",      r"\bSMC\b"),
    ("Type-N",   r"\btype[\s-]?N\b|\bN[\s-]?type\b|\bN\s*connector\b|"
                 r"\bN[\s-]?(?:male|female)\b"),
    ("TNC",      r"\bTNC\b"),
    ("BNC",      r"\bBNC\b"),
    ("7/16 DIN", r"\b7\s*/\s*16\b|\bDIN\s*7[\s/-]?16\b"),
    ("QMA",      r"\bQMA\b"),
    ("MCX",      r"\bMCX\b"),
    ("MMCX",     r"\bMMCX\b"),
    ("F-type",   r"\bF[\s-]?type\b"),
    ("Waveguide", r"\bWR[\s-]?\d{1,3}\b|\bwaveguide\s*flange\b"),
]
_CONNECTORS = [(n, re.compile(p, re.I)) for n, p in _CONNECTORS]
_GENDER = re.compile(r"\b(male|female|plug|jack)\b", re.I)
_CONNECTORIZED = re.compile(
    r"connectori[sz]ed|\bconnector(?:s|ized)?\b|coaxial\s+cable|"
    r"cable\s+assembl|\bjumper\b|\bin[\s-]?line\b\s*(?:package|unit)|"
    r"\badapter\b|\btransition\b|\bbetween\s+series\b", re.I)
# Package bodies, for parts that are NOT connectorised.
_PACKAGES = [
    ("bare die",  r"\bbare\s+die\b|\bdie\s+form\b|\bchip\s+form\b|"
                  r"\bunpackaged\b|\bchip\s+and\s+wire\b"),
    ("QFN",       r"\bQFN\b|\bAQFN\b|quad\s+flat\s+no[\s-]?lead"),
    ("LGA",       r"\bLGA\b|land\s+grid\s+array"),
    ("BGA",       r"\bBGA\b|ball\s+grid\s+array"),
    ("SOIC",      r"\bSOIC\b|\bSO-?\d{1,2}\b"),
    ("MSOP",      r"\bMSOP\b"),
    ("TSSOP",     r"\bTSSOP\b"),
    ("SOT",       r"\bSOT[\s-]?\d{2,3}\b"),
    ("TO-8",      r"\bTO-?8\b"),
    ("TO-can",    r"\bTO-?\d{1,3}\b"),
    ("DIP",       r"\bDIP\b|dual\s+in[\s-]?line"),
    ("flatpack",  r"\bflat[\s-]?pack\b"),
    ("surface mount", r"surface\s+mount|\bSMT\b|\bSMD\b"),
]
_PACKAGES = [(n, re.compile(p, re.I)) for n, p in _PACKAGES]


# "Insertion loss ABOVE x dB" on a splitter is EXCESS loss -- the dissipative
# loss on top of the unavoidable 10*log10(N) of dividing power N ways. Storing
# x as the insertion loss understates a 2-way by 3 dB and an 8-way by 9, which
# is the difference between a part working in a budget and not.
# The BASELINE is stated in the header -- "Insertion Loss above 3.1 dB" -- and
# the numbers in the rows beneath are the excess over it. The baseline is the
# theoretical 10*log10(N) of an N-way split, printed by the vendor: 3.1 for a
# 2-way, 4.8 for a 3-way, 6.0 for a 4-way.
_EXCESS_LOSS = re.compile(
    r"(?:insertion\s*)?loss\s*[,]?\s*(?:above|in\s+excess\s+of|"
    r"over\s+theoretical|excess\s+of)\s*"
    r"(\d+(?:\.\d+)?)?\s*dB?", re.I)


def split_loss_db(ways):
    """The theoretical loss of dividing power N ways, in dB."""
    try:
        n = int(float(ways))
    except (TypeError, ValueError):
        return None
    if n < 2 or n > 64:
        return None
    return round(10.0 * math.log10(n), 2)


def excess_baseline(text, ways=None):
    """The dB baseline that row values sit ABOVE, or None.

    Prefers the figure the datasheet PRINTS, since that is what its own rows
    were measured against; falls back to computing it from the way count when
    the phrase omits it.
    """
    m = _EXCESS_LOSS.search(text or "")
    if not m:
        return None
    stated = m.group(1)
    if stated:
        try:
            v = float(stated)
            if 2.0 <= v <= 20.0:        # a plausible split loss, 2-way to 64
                return v
        except ValueError:
            pass
    return split_loss_db(ways)


def mine_connector(text, head_chars=4000):
    """(connector, package, package_body) -- any may be ''.

    package is the mounting FORM: connectorized, smt or die.
    package_body is the specific body, where the datasheet names one.

    A connector is only reported when the part is actually CONNECTORISED. An
    SMA-packaged surface-mount die is not an SMA-connectorised part, and the
    string "SMA" appears in plenty of datasheets that have no connector on
    them at all (evaluation boards, test setups, application circuits).
    """
    head = (text or "")[:head_chars]
    if not head:
        return "", "", ""
    connectorized = bool(_CONNECTORIZED.search(head))
    conn = ""
    if connectorized:
        # A part can have TWO different interfaces -- "1.35 mm Female to
        # 1.85 mm Male" is an adapter or a transition cable, and reporting one
        # of them describes the wrong end. Every distinct connector found in
        # the title area is kept, in the order stated, joined by " | ".
        found = []
        for name, rx in _CONNECTORS:
            for m in rx.finditer(head):
                # Gender is read from a SHORT window AFTER the name. A wider
                # or two-sided window straddled the neighbouring interface:
                # "1.35 mm Female to 1.85 mm Male" gave 1.85 mm the word
                # "Female" from the connector before it.
                after = head[m.end():m.end() + 14]
                g = _GENDER.search(after)
                gender = ""
                if g:
                    w = g.group(1).lower()
                    gender = {"plug": "male", "jack": "female"}.get(w, w)
                found.append((m.start(), f"{name} {gender}".strip()))
        seen, ordered = set(), []
        for _pos, label in sorted(found):
            if label in seen:
                continue
            # "SMA" after "SMA male" is the same interface stated twice.
            if any(label != other and label in other for _p, other in found):
                continue
            seen.add(label)
            ordered.append(label)
        conn = " | ".join(ordered[:2])
    # Package is the MOUNTING FORM only -- connectorized, smt or die. The
    # specific body (QFN, LGA, MSOP) is a different fact and belongs in
    # package_body; putting the connector in the package duplicated a value
    # that already has its own field, so filtering on either could disagree
    # with the other.
    body = ""
    for name, rx in _PACKAGES:
        if rx.search(head):
            body = name
            break
    if connectorized:
        pkg = "connectorized"
    elif body == "bare die":
        pkg = "die"
    elif body:
        pkg = "smt"
    else:
        pkg = ""
    return conn, pkg, body


def space_score(text):
    """(percent 0-100, [evidence labels]) for how space-capable a datasheet reads.

    Returns (None, []) when nothing at all fires, because "no evidence" and
    "evidence for zero" are different things and storing 0 for the first would
    look like a judgement that was never made.

    The clamp at zero used to hide the most informative case: a part with a
    positive material signal and an explicit negative came out as 0, which is
    indistinguishable from "found nothing". The raw sum now rides along in the
    evidence list so the two can be told apart.
    """
    if not text:
        return None, []
    hits, score = [], 0
    fired = set()
    for weight, label, rx in _SPACE_EVIDENCE:
        m = rx.search(text)
        if m:
            score += weight
            fired.add(label)
            # Quote what MATCHED. A label alone is unverifiable -- "MIL-STD
            # (other)" gave no way to tell that the hit was MIL-STD-348, a
            # connector interface standard, and "ASTM E595" was reported for
            # text containing neither "ASTM" nor "E595". Anyone should be able
            # to search the datasheet for the quoted phrase and find it.
            found = re.sub(r"\s+", " ", m.group(0)).strip()[:28]
            shown = f"{label} [{found}]" if found.lower() != label.lower() \
                else label
            hits.append(shown if weight > 0 else f"NOT: {shown}")

    # Qualifiability is a property of the PACKAGE, not the die. GaAs is
    # genuinely radiation-tolerant -- no gate oxide, majority carrier, TID
    # typically past 1 Mrad unhardened -- but it is also the default technology
    # for nearly every microwave part above a few GHz, so on its own it
    # separates nothing and stays weak. In a hermetic or ceramic package it
    # means something: that combination is what makes a part qualifiable when
    # no qualification is stated, which is most parts.
    semi = {"GaAs", "GaN"} & fired
    sealed = {"hermetic", "LTCC/ceramic"} & fired
    if semi and sealed and "plastic encapsulated" not in fired:
        score += 10
        hits.append("qualifiable construction (%s in %s)"
                    % ("/".join(sorted(semi)), "/".join(sorted(sealed))))
    # Bare die has no package to outgas, crack or delaminate, so the usual
    # package objection does not apply to it at all.
    if semi and _DIE_FORM.search(text) and "plastic encapsulated" not in fired:
        score += 8
        hits.append("die form -- no package limitation")

    if not hits:
        return None, []
    pct = max(0, min(_SPACE_MAX, score))
    if score < 0:
        hits.append(f"(raw {score})")
    return pct, hits


# ============================================================ the mine itself
# Keys that are not evidence the electrical table has been reached, and so must
# not count toward the early exit. Counting them is why paging stopped on page
# one across the whole library: freq_min, freq_max, space_score_pct,
# space_evidence and throw_config all come off the front page, and that is five.
_SOFT_KEYS = {"freq_min", "freq_max", "space_score_pct", "space_evidence",
              "throw_config"}


def hard_spec_count(mined):
    return sum(1 for k in mined if k not in _SOFT_KEYS)


# --------------------------------------------------- header-anchored tables
# dstables reads a table by locating its HEADER and taking the column
# boundaries from where the headings sit, instead of from ruling lines. On the
# ADI families that pdfplumber's own table finder cannot see -- four of the
# sampled datasheets produced no tables at all -- it recovers 293 value rows
# where the existing path found 78 specs.
#
# It runs FIRST and only where it succeeds. The older readers still handle
# everything it does not find a header for, so nothing that works today can
# regress: a file dstables cannot parse takes exactly the path it took before.
def _worth_keeping(segs):
    """Is there more than one number here worth recording?

    Not just "more than one band". A single-band cable states insertion loss as
    a typ AND a max; storing only the worst threw the typical away, and the
    part then looked like it had one measurement when it had two. Any segment
    carrying two of min/typ/max is worth keeping whole.
    """
    if not segs:
        return False
    if len(segs) > 1:
        return True
    s = segs[0]
    return sum(1 for k in ("min", "typ", "max")
               if s.get(k) is not None) >= 2


def _dump_segments(segs, limit=900):
    """Valid JSON for a piecewise spec, within a length budget.

    Slicing the encoded string to 900 characters produced JSON that could not
    be parsed at all -- the band data was being written in a form no reader
    could use. Segments are dropped instead, so what is stored is always whole.
    """
    import json as _json
    keep = list(segs)
    while keep:
        s = _json.dumps(keep, separators=(",", ":"))
        if len(s) <= limit or len(keep) == 1:
            return s
        keep = keep[:-1]
    return "[]"


def mine_header_tables(path):
    """{key: rec} from dstables records, or {} if it found nothing."""
    try:
        from . import dstables
    except ImportError:
        try:
            import dstables
        except ImportError:
            return {}
    try:
        recs = dstables.records(path)
    except Exception:
        return {}
    out = {}
    for rec in recs:
        label = _clean_label(rec.get("name") or "")
        if not label:
            continue
        hit = match_spec(label)
        if not hit and rec.get("section"):
            # "On State" means nothing alone; under RETURN LOSS it is the
            # on-state return loss, and the section is the only place that says
            # so.
            hit = match_spec(f"{rec['section']} {label}")
        if not hit:
            continue
        key, _rx, want_unit, kind = hit
        if _LABEL_OTHER_PORT.match(label) or _LABEL_INPUT_REFERRED.match(label):
            continue
        segs = []
        for row in rec.get("rows") or []:
            lo, typ, hi = row.get("min"), row.get("typ"), row.get("max")
            v = {"max": hi, "min": lo}.get(kind, typ)
            if v is None:
                v = typ if typ is not None else (hi if hi is not None else lo)
            v = apply_sign(key, v)
            if v is None:
                continue
            # The unit is stated PER ROW. Assuming one per spec key is a silent
            # 1000x error when a table quotes uA above mA.
            unit = (row.get("unit") or "").strip() or want_unit
            segs.append({"value": v, "min": apply_sign(key, lo),
                         "typ": apply_sign(key, typ),
                         "max": apply_sign(key, hi), "unit": unit,
                         "band_ghz": row.get("band_ghz"),
                         "cond": (row.get("cond") or "")[:60]})
        if not segs:
            continue
        vals = [s["value"] for s in segs]
        primary = max(vals) if kind == "max" else min(vals)
        bounds = PLAUSIBLE.get(key)
        if bounds and not (bounds[0] <= primary <= bounds[1]):
            continue
        out[key] = {"value": primary, "unit": segs[0]["unit"], "kind": kind,
                    "method": "table-header-anchored", "confidence": CONF_TABLE,
                    "segments": segs, "section": rec.get("section", ""),
                    "row": (f"{len(segs)} row(s); worst {kind} {primary:g}"
                            + (f"; section {rec['section'][:24]}"
                               if rec.get("section") else ""))}
    return out


def mine_text(text, path=None, rows=None, mpn=None):
    """{spec key: (value, unit)} for one datasheet.

    Signature is backward compatible: mine_text(text) still works, and will
    still reach the positional table data when the text came from
    datasheet_text() (see _ROWS_MEMO). Pass `path` explicitly for the
    unambiguous route.

    Provenance for the most recent call -- which extractor produced each value,
    the literal row or snippet, the confidence -- is left in
    `mine_text.provenance` rather than folded into the return value, so callers
    that unpack (value, unit) keep working.
    """
    out, prov = {}, {}
    if not text and not rows:
        mine_text.provenance = prov
        return out
    if rows is None:
        rows, memo_path = _memo_get(text)
        if path is None:
            path = memo_path
    if rows is None and path is not None:
        try:
            rows = rows_for(path)
        except Exception:
            rows = []
    rows = rows or []
    if mpn is None and path:
        mpn = Path(path).stem

    # --- family sheets -----------------------------------------------------
    # One MACOM coupler sheet tabulates 23 parts; one limiter sheet lists the
    # requested MPN only as a cross-reference to a different part number. Mining
    # either one part-blind hands every sharer the same values, which is how two
    # byte-identical files produced identical specs for parts the catalog knows
    # differ.
    # Packaging variants are not a family. MAAP-011341's ordering table lists
    # MAAP-011341-TR1000, -TR3000 and -SMB -- three tokens, so the sheet looked
    # like a three-part family, its own row was never matched, and every spec on
    # a perfectly ordinary single-part datasheet was suppressed. A token that is
    # the requested part plus a suffix is the same part in a different reel.
    family = is_family_sheet(rows)
    if family and mpn:
        base = _loose(mpn)
        others = [x for x in family_mpns(rows)
                  if base and not _loose(x).startswith(base)
                  and not base.startswith(_loose(x))]
        if len(others) < 3:
            family = False
    own_row = part_row(rows, mpn) if (family and mpn) else None
    if family and own_row is None:
        # Refuse per-part specs. Qualification wording is a property of the
        # family and stays.
        pct, why = space_score(text)
        if pct is not None:
            out["space_score_pct"] = (float(pct), "%")
            out["space_evidence"] = (", ".join(why)[:180], "")
        prov["_family"] = {"mpns": len(family_mpns(rows)),
                           "note": "family sheet; this part's row was not found "
                                   "-- per-part specs suppressed"}
        mine_text.provenance = prov
        return out

    # --- table rows (primary) ---------------------------------------------
    # A header-declared table wins over a positionally-guessed one: the vendor
    # named which column is min, typ and max, so there is nothing left to infer.
    header_band = None
    if rows:
        # Drop frequency-sweep tables first. They are later in the document than
        # the spec table, so anything they match overwrites the real value.
        rows = strip_sweeps(rows)
        if path and _sniff(path) == "pdf":
            import json as _json
            for key, rec in mine_header_tables(path).items():
                out[key] = (rec["value"], rec["unit"])
                prov[key] = rec
                segs = rec["segments"]
                if _worth_keeping(segs):
                    out[key + "_bands"] = (
                        _dump_segments(segs), "")
        # Temperature-column tables first: where they exist they are the
        # authoritative spec table, and the worst-over-temperature reading is
        # the only one that holds across the part's rated range.
        for key, rec in mine_temperature_table(rows).items():
            if key in out:
                continue
            out[key] = (rec["value"], rec["unit"])
            prov[key] = rec
        # Sub-spec groups next: a named breakdown is more specific than the
        # parent row it sits under, and the parent is what the prose regex
        # would otherwise match.
        for key, rec in mine_sub_spec_rows(rows).items():
            if key in out:
                continue
            out[key] = (rec["value"], rec["unit"])
            prov[key] = rec
        # Filter symbol tables (Fc / F1-F2 / F3..F6 / Typ. / Max.)
        sym = filter_symbol_table(rows)
        sym_band = sym.pop("_passband", None)
        sym.pop("_stopband_edges", None)
        for key, rec in sym.items():
            if key in out:
                continue
            out[key] = (rec["value"], rec["unit"])
            prov[key] = rec
        hdr = mine_header_rows(rows)
        header_band = hdr.pop("_band", None)
        for key, rec in hdr.items():
            if key in out:
                continue
            out[key] = (rec["value"], rec["unit"])
            prov[key] = rec
        for key, rec in mine_rows(rows).items():
            if key in out:
                continue
            out[key] = (rec["value"], rec["unit"])
            prov[key] = rec
        # Piecewise bands. The headline value is the WORST band so a filter
        # cannot be satisfied by a band the part is not being used in; the full
        # curve is kept alongside under "<key>_bands" as JSON, so nothing is
        # lost and a caller that cares about a specific frequency can ask.
        import json as _json
        for key, segs in band_segments(rows).items():
            if not _worth_keeping(segs):
                continue
            kind = next((k for k, _rx, _u, k2 in
                         [(a, b, c, d) for a, b, c, d in SPEC_ROWS]
                         if k == key for k in (d,)), "max") \
                if False else next((d for a, _b, _c, d in SPEC_ROWS
                                    if a == key), "max")
            v = worst_of(segs, kind)
            bounds = PLAUSIBLE.get(key)
            if v is None or (bounds and not (bounds[0] <= v <= bounds[1])):
                continue
            unit = next((c for a, _b, c, _d in SPEC_ROWS if a == key), "")
            out[key] = (v, unit)
            out[key + "_bands"] = (_dump_segments(segs),
                                   "")
            prov[key] = {"value": v, "method": "table-bands",
                         "confidence": CONF_TABLE, "segments": len(segs),
                         "kind": kind,
                         "row": f"{len(segs)} band(s); worst {kind}: {v}  "
                                + segs[0]["row"][:60]}
        # Column-oriented tables last: only worth the extra pdfplumber pass
        # when the label-in-column-0 readers found little, which is exactly the
        # case where the table is laid out the other way round.
        if path and hard_spec_count(out) < 2 and _sniff(path) == "pdf":
            for key, rec in mine_column_table(path).items():
                if key in out:
                    continue
                out[key] = (rec["value"], rec["unit"])
                prov[key] = rec

    # --- prose regex (fills blanks only) ----------------------------------
    for key, pats in _PATTERNS.items():
        if key in out:
            continue
        # A key may exist only as a pattern override, with no registry entry.
        meta = PARAM_SPECS.get(key) or {}
        ugroup = meta.get("unit_group")
        uscale = meta.get("unit_scale") or {}
        for pat in pats:
            for m in pat.finditer(text or ""):
                try:
                    value = float(m.group(1))
                except (TypeError, ValueError, IndexError):
                    continue
                if ugroup:
                    try:
                        unit = (m.group(ugroup) or "").strip().lower()
                    except (IndexError, re.error):
                        unit = ""
                    factor = uscale.get(unit)
                    if factor is None:
                        continue        # unknown unit: refuse rather than guess
                    # round: scaling by a float factor leaves binary noise
                    # (700 * 1e-3 -> 0.7000000000000001)
                    value = round(value * factor, 9)
                bounds = PLAUSIBLE.get(key)
                if bounds and not (bounds[0] <= value <= bounds[1]):
                    continue
                if not _prose_guard(text, m):
                    continue
                out[key] = (value, meta.get("unit", ""))
                prov[key] = {"value": value, "unit": meta.get("unit", ""),
                             "method": "prose", "confidence": CONF_PROSE,
                             "row": re.sub(r"\s+", " ", m.group(0))[:110]}
                break
            if key in out:
                break

    # Reversed 'Label unit value' ordering, for files with no usable geometry.
    for k, v in mine_table_rows(text).items():
        if k not in out:
            out[k] = v
            prov[k] = {"value": v[0], "unit": v[1], "method": "table-text",
                       "confidence": CONF_TABLE_WEAK, "row": ""}

    # --- frequency band ---------------------------------------------------
    band = None
    if 'sym_band' in dir() and sym_band:
        band = (sym_band["lo"], sym_band["hi"])
        prov["freq_min"] = prov["freq_max"] = {
            "method": "table-symbols", "confidence": CONF_TABLE,
            "row": sym_band["row"]}
    if band is None and header_band and header_band.get("lo") is not None:
        lo_e, hi_e = header_band["lo"], header_band.get("hi")
        if hi_e is not None and hi_e > lo_e:
            band = (round(lo_e, 9), round(hi_e, 9))
            prov["freq_min"] = prov["freq_max"] = {
                "method": "table-header", "confidence": CONF_TABLE,
                "row": header_band["row"]}
        else:
            # A high-pass states only its lower edge; recording that alone is
            # honest, and inventing an upper edge would not be.
            out["freq_min"] = (round(lo_e, 9), "GHz")
            prov["freq_min"] = {"method": "table-header",
                                "confidence": CONF_TABLE,
                                "row": header_band["row"]}
    if band is None and rows:
        fr = freq_from_rows(rows)
        if fr:
            band = (fr[0], fr[1])
            prov["freq_min"] = prov["freq_max"] = {
                "method": "table", "confidence": CONF_TABLE, "row": fr[2]}
    if band is None and family and own_row is not None and path:
        fb = family_band(path, mpn)
        if fb:
            band = (fb[0], fb[1])
            prov["freq_min"] = prov["freq_max"] = {
                "method": "family-column", "confidence": CONF_TABLE,
                "row": fb[2]}
    if band is None:
        b = freq_range_ghz(text)
        if b:
            band = b
            cands = _candidates(text)
            rec = cands.get((round(b[0], 9), round(b[1], 9)), {})
            prov["freq_min"] = prov["freq_max"] = {
                "method": "prose-vote", "confidence": CONF_DERIVED,
                "row": f"{rec.get('snippet','')} (seen {rec.get('n',1)}x, "
                       f"score {_score_of(text, b)})"}
    if band:
        out["freq_min"] = (band[0], "GHz")
        out["freq_max"] = (band[1], "GHz")

    # --- non-numeric -------------------------------------------------------
    if "ways" not in out:
        w = ways_from_text(text)
        if w:
            out["ways"] = (float(w), "")
            prov["ways"] = {"value": float(w), "method": "title",
                            "confidence": CONF_PROSE, "row": f"{w}-way"}
    cfg = specmatch.parse_throw_config(text[:4000]) if text else ""
    if cfg:
        out["throw_config"] = (cfg, "")
        prov["throw_config"] = {"method": "prose", "confidence": CONF_PROSE}
    conn, pkg, body = mine_connector(text)
    if conn:
        out["connector"] = (conn, "")
        prov["connector"] = {"method": "prose", "confidence": CONF_PROSE}
    if pkg:
        out["package"] = (pkg, "")
        prov["package"] = {"method": "prose", "confidence": CONF_PROSE}
    if body:
        out["package_body"] = (body, "")
        prov["package_body"] = {"method": "prose", "confidence": CONF_PROSE}

    pct, why = space_score(text)
    if pct is not None:
        out["space_score_pct"] = (float(pct), "%")
        out["space_evidence"] = (", ".join(why)[:180], "")
    elif text:
        # A datasheet that was READ and mentions nothing qualification-related
        # scores zero -- that is a finding, not a gap. Leaving it absent made
        # "no evidence" indistinguishable from "no datasheet", so most parts
        # scraped from a folder showed no score at all. Absence now means only
        # that no datasheet was read.
        out["space_score_pct"] = (0.0, "%")
        out["space_evidence"] = ("assessed; no qualification wording found", "")

    # The title is the clearest statement of what a part IS -- "Coaxial Cable",
    # "Bandpass Filter", "Power Splitter/Combiner" -- and inferring the category
    # from specs alone cannot see it. A cable has no gain, no conversion loss
    # and no way count, so it fell through every rule and stayed uncategorized.
    # Kept in provenance so it rides the parse cache and costs nothing to reuse.
    if text:
        # NOT the first 400 characters: pypdf returns text in content-stream
        # order, not reading order, so a page footer routinely comes out first
        # ("www.minicircuits.com P.O. Box 350166..."). A wider window is kept
        # and the category phrase is looked for anywhere in it -- "Coaxial
        # Cable" is in the running header of every page, which makes it more
        # reliable than any single position.
        # A generous window. pypdf returns text in content-stream order, so the
        # notes and footer routinely come FIRST and the part's own name lands
        # well down: ADC-20-4-75R+ says "Directional Coupler" at character
        # 1581, just past the old 1500 cap, and was left with no category at
        # all. Strong phrases are unambiguous enough to search this widely.
        head = re.sub(r"\s+", " ", text[:12000]).strip()
        prov["_title"] = {"text": head[:8000]}

    # Excess loss -> real insertion loss. Done here rather than at extraction
    # because it needs the WAY COUNT, which is mined separately and may come
    # from the title rather than the same table.
    if "insertion_loss_db" in out:
        base = excess_baseline(text, out.get("ways", (None,))[0])
        if base is not None:
            excess = out["insertion_loss_db"][0]
            # The mined number IS the excess; the real loss is excess + base.
            out["excess_loss_db"] = (excess, "dB")
            out["insertion_loss_db"] = (round(excess + base, 2), "dB")
            prov["insertion_loss_db"] = {
                "method": "excess+baseline", "confidence": CONF_PROSE,
                "row": f"{excess} dB excess + {base} dB theoretical split"}
            extra = base
            # The stored bands are excess figures too, so each is corrected.
            bands = out.get("insertion_loss_db_bands")
            if bands:
                try:
                    import json as _j
                    segs = _j.loads(bands[0])
                    for s in segs:
                        for k in ("value", "min", "typ", "max"):
                            if s.get(k) is not None:
                                s[k] = round(s[k] + extra, 2)
                    out["insertion_loss_db_bands"] = (_dump_segments(segs), "")
                except Exception:
                    pass

    cross_check(out)
    if family:
        prov["_family"] = {"mpns": len(family_mpns(rows)),
                           "note": "family sheet; this part's row was located"}
    mine_text.provenance = prov
    return out


mine_text.provenance = {}


def _score_of(text, pair):
    rec = _candidates(text).get((round(pair[0], 9), round(pair[1], 9)))
    if not rec:
        return 0
    return rec["ctx"] + min(4, 2 * (rec["n"] - 1))


# ---------------------------------------------------------------- parse cache
# Parsing is the whole cost of this step: several thousand PDFs at up to six
# pages each. Without a cache that work is repeated in full on EVERY rebuild,
# which is what made the enrichment pass take ten minutes every single time.
# Keyed on path + size + mtime AND the parser version, so an edited datasheet is
# re-read, a parser change re-reads everything once, and nothing else is touched.
def _cache_path():
    from .paths import CACHE_DIR
    return Path(CACHE_DIR) / "datasheet_mining.json"


def load_cache():
    fp = _cache_path()
    if fp.is_file():
        try:
            import json
            data = json.loads(fp.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
        except Exception:
            pass
    return {}


def save_cache(cache):
    fp = _cache_path()
    try:
        import json
        fp.parent.mkdir(parents=True, exist_ok=True)
        fp.write_text(json.dumps(cache), encoding="utf-8")
        return True
    except OSError as e:
        # Never silent: a cache that fails to persist looks exactly like "mining
        # is slow again", which is the bug this exists to fix.
        print(f"  ! could not save the datasheet mining cache: {e}")
        return False


def _file_key(path):
    try:
        st = Path(path).stat()
        return f"{st.st_size}:{int(st.st_mtime)}"
    except OSError:
        return ""


def part_file_key(mpn, index):
    """Identity of the datasheet that would be used for this part.

    Path + size + mtime + parser version, so replacing or editing the file
    re-enriches the part, a parser change re-enriches everything once, and an
    untouched file with an untouched parser is skipped."""
    path = index.get(_loose(mpn))
    if not path:
        return ""
    fk = _file_key(path)
    return f"{path}|{fk}|v{PARSER_VERSION}" if fk else ""


def has_datasheet(mpn, index):
    """Is there a local datasheet for this part? O(1), no file opened."""
    return _loose(mpn) in index


def mine_part(mpn, index, cache=None, disk_cache=None, stats=None):
    """SpecRows mined from this part's datasheet, or [].

    Rows carry min/typ/max where the table supplied them, so a filter can use
    the conservative edge while a comparison against a catalog value can use
    typ. Storing only typ is what made honest band-dependent differences look
    like parse errors in the debug diff."""
    key = _loose(mpn)
    path = index.get(key)
    if not path:
        return []
    provenance = {}
    if cache is not None and key in cache:
        mined, provenance = cache[key]           # already parsed this run
    else:
        mined = None
        fkey = _file_key(path)
        if disk_cache is not None and fkey:
            hit = disk_cache.get(str(path))
            if isinstance(hit, dict) and hit.get("k") == fkey \
                    and hit.get("v") == PARSER_VERSION:
                mined = {kk: tuple(vv) for kk, vv in (hit.get("s") or {}).items()}
                provenance = hit.get("p") or {}
                if stats is not None:
                    stats["reused"] = stats.get("reused", 0) + 1
        if mined is None:
            # Stop reading pages as soon as the mine is productive -- counting
            # only HARD specs, so front-page boilerplate cannot end the read
            # before the electrical table.
            def _enough(text, _n=EARLY_EXIT_SPECS):
                return hard_spec_count(mine_text(text)) >= _n
            # Count REAL parses. Overwriting an existing cache entry does not
            # change the dict length, so measuring progress by len(cache)
            # reported "0 newly parsed" even when a changed datasheet had just
            # been re-read.
            if stats is not None:
                stats["parsed"] = stats.get("parsed", 0) + 1
            text = datasheet_text(path, want=_enough)
            mined = mine_text(text, path=path, mpn=mpn)
            provenance = {k: {kk: vv for kk, vv in v.items()
                              if kk in ("method", "confidence", "row",
                                        "min", "typ", "max", "note", "text")}
                          for k, v in (mine_text.provenance or {}).items()}
            if disk_cache is not None and fkey:
                disk_cache[str(path)] = {
                    "k": fkey, "v": PARSER_VERSION,
                    "s": {kk: list(vv) for kk, vv in mined.items()},
                    "p": provenance}
            if stats is not None and provenance.get("_family"):
                stats["family"] = stats.get("family", 0) + 1
        if cache is not None:
            cache[key] = (mined, provenance)
    mine_part.last_title = ((provenance.get("_title") or {}).get("text") or "")
    rows = []
    fname = Path(path).name
    for spec_key, (value, unit) in mined.items():
        p = provenance.get(spec_key) or {}
        method = p.get("method", "datasheet")
        conf = float(p.get("confidence", CONF_PROSE))
        detail = p.get("row") or ""
        snippet = f"mined from {fname}" + (f": {detail}" if detail else "")
        if isinstance(value, str):
            # Piecewise band data is JSON and must survive whole: clipping it
            # to 60 characters left a fragment nothing could parse, so the
            # curve was written to the database in a form no reader could use.
            # Same defect as the 900-character truncation, one layer down.
            keep = value if spec_key.endswith("_bands") else value[:60]
            rows.append(SpecRow(key=spec_key, value_text=keep,
                                method="datasheet", confidence=conf,
                                snippet=snippet[:240]))
        else:
            rows.append(SpecRow(key=spec_key, value_typ=float(value),
                                value_min=p.get("min"), value_max=p.get("max"),
                                unit=unit, method="datasheet", confidence=conf,
                                snippet=snippet[:240]))
    return rows


mine_part.last_title = ""


def mine_parts(parts, roots=None, say=None, every=250, limit=None):
    """Mine a sequence of {'mpn': ...} records. Returns (rows_by_mpn, stats)."""
    index = build_index(roots, say=say)
    if not index:
        if say:
            say("    no local datasheets found; skipping datasheet mining")
        return {}, {"indexed": 0, "matched": 0, "mined": 0}
    out, cache = {}, {}
    stats = {"indexed": len(index), "matched": 0, "mined": 0, "parsed": 0,
             "reused": 0, "family": 0}
    for i, p in enumerate(parts, 1):
        mpn = p.get("mpn") if isinstance(p, dict) else p
        if not mpn:
            continue
        if _loose(mpn) in index:
            stats["matched"] += 1
            rows = mine_part(mpn, index, cache, stats=stats)
            if rows:
                out[mpn] = rows
                stats["mined"] += 1
        if say and every and i % every == 0:
            say(f"      mined {i} part(s): {stats['matched']} with a datasheet, "
                f"{stats['mined']} yielding specs")
        if limit and i >= limit:
            break
    if say:
        say(f"    datasheet mining: {stats['matched']} part(s) had a datasheet, "
            f"{stats['mined']} yielded at least one spec"
            + (f"; {stats['family']} were family sheets with no locatable row"
               if stats.get("family") else ""))
    return out, stats
