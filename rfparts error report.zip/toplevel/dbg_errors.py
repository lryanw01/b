"""dbg_errors.py — reproduce parse failures and group them by root cause.

    python dbg_errors.py --vendor Marki-Microwave
    python dbg_errors.py --vendor MACOM --limit 2000
    python dbg_errors.py                      (every vendor folder)
    python dbg_errors.py --vendor Marki-Microwave --out errors.txt

153 failures are rarely 153 bugs. This parses each file, catches the exception
with its full traceback, and groups identical failures together -- so the output
is a handful of distinct causes with counts and example files, small enough to
paste back.

The rebuild's own log truncates each error to sixty characters and prints no
traceback, which makes a failure countable but not fixable. That is what this
exists to replace.

Read-only: nothing is written except the report you ask for.
"""
from __future__ import annotations

import argparse
import io
import sys
import traceback
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))


def _opt(name):
    for pkg in ("rfparts", "pythonrfparts"):
        try:
            return __import__(f"{pkg}.{name}", fromlist=[name])
        except Exception:
            continue
    return None


dsmine = _opt("dsmine")
if dsmine is None:
    sys.exit("Could not import dsmine. Run this from the folder holding "
             "rfparts/.")

EXTS = (".pdf", ".html", ".htm", ".txt")


def vendor_folders():
    out = []
    for root in dsmine.default_roots():
        r = Path(root)
        if not r.is_dir():
            continue
        for d in sorted(r.iterdir()):
            if d.is_dir():
                out.append(d)
    return out


def files_for(vendor=None):
    out = []
    for root in dsmine.default_roots():
        base = Path(root)
        if not base.is_dir():
            continue
        if vendor:
            cands = [d for d in base.iterdir()
                     if d.is_dir() and vendor.lower() in d.name.lower()]
        else:
            cands = [base]
        for c in cands:
            try:
                out += [f for f in c.rglob("*")
                        if f.is_file() and f.suffix.lower() in EXTS]
            except OSError:
                continue
    return sorted(set(out))


def signature(exc_info):
    """A key that collapses the same bug hit from many files into one group.

    Keyed on the exception type, the LAST frame inside our own code, and the
    message with any file path stripped out -- paths differ per file and would
    otherwise split one bug into hundreds of groups.
    """
    etype, evalue, tb = exc_info
    frames = traceback.extract_tb(tb)
    ours = [f for f in frames
            if "rfparts" in str(f.filename) or "dsmine" in str(f.filename)]
    last = (ours or frames)[-1] if (ours or frames) else None
    where = f"{Path(last.filename).name}:{last.lineno} in {last.name}" \
        if last else "?"
    msg = str(evalue)
    for token in (".pdf", ".html", ".htm"):
        if token in msg:
            msg = "<path>" + msg.split(token)[-1]
    return (etype.__name__, where, msg[:120]), (where, last.line if last else "")


def run_one(path):
    """(n_specs, exc_info or None)."""
    try:
        idx = {dsmine._loose(path.stem): path}
        rows = dsmine.mine_part(path.stem, idx, {}, disk_cache={})
        return len(rows), None
    except Exception:
        return 0, sys.exc_info()


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--vendor", default=None,
                    help="folder name under the datasheet library")
    ap.add_argument("--limit", type=int, default=0, help="0 = all")
    ap.add_argument("--out", default=None, help="also write the report here")
    ap.add_argument("--examples", type=int, default=3,
                    help="example files to name per group")
    ap.add_argument("--full", action="store_true",
                    help="include one complete traceback per group")
    args = ap.parse_args(argv)

    if not args.vendor:
        print("vendor folders found: "
              + ", ".join(d.name for d in vendor_folders()))
    files = files_for(args.vendor)
    if args.limit:
        files = files[:args.limit]
    if not files:
        print("No datasheets found. --vendor takes a folder name, e.g. "
              "Marki-Microwave.")
        return 1

    buf = io.StringIO()

    def say(s=""):
        print(s)
        buf.write(s + "\n")

    say(f"{len(files)} file(s)" + (f" under {args.vendor}" if args.vendor
                                   else ""))
    groups = defaultdict(list)
    tracebacks = {}
    empty, ok, total_specs = [], 0, 0
    for i, f in enumerate(files, 1):
        n, exc = run_one(f)
        if exc is not None:
            sig, extra = signature(exc)
            groups[sig].append(f)
            if sig not in tracebacks:
                tracebacks[sig] = "".join(traceback.format_exception(*exc))
        elif n == 0:
            empty.append(f)
        else:
            ok += 1
            total_specs += n
        if i % 500 == 0:
            print(f"  ...{i}/{len(files)}")

    say(f"\n  {ok} parsed ({total_specs / max(1, ok):.1f} specs each), "
        f"{len(empty)} yielded nothing, "
        f"{sum(len(v) for v in groups.values())} raised")

    if groups:
        say(f"\n{'=' * 74}\n  FAILURES, grouped -- "
            f"{sum(len(v) for v in groups.values())} error(s), "
            f"{len(groups)} distinct cause(s)\n{'=' * 74}")
        for (etype, where, msg), hits in sorted(groups.items(),
                                                key=lambda kv: -len(kv[1])):
            say(f"\n  {len(hits)} x  {etype}")
            say(f"      at   {where}")
            say(f"      msg  {msg}")
            say(f"      e.g. " + ", ".join(p.name for p in
                                           hits[:args.examples]))
            if args.full:
                say("      ---- full traceback ----")
                for line in tracebacks[(etype, where, msg)].splitlines():
                    say(f"      {line}")
    else:
        say("\n  no exceptions raised")

    if empty:
        say(f"\n  {len(empty)} file(s) parsed cleanly but yielded no specs, "
            f"e.g. " + ", ".join(p.name for p in empty[:6]))

    if args.out:
        try:
            Path(args.out).write_text(buf.getvalue(), encoding="utf-8")
            print(f"\nwritten to {args.out}")
        except OSError as e:
            print(f"\n! could not write {args.out}: {e}")

    say("\n  Paste the grouped section back -- it is the distinct causes that "
        "matter,\n  not the count. Add --full for one traceback per group if a "
        "cause is unclear.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nstopped.")
        sys.exit(130)
