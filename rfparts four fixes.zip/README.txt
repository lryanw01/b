rfparts — the four things you reported
=====================================
7 files: 1 new, 6 modified. Drop into rfparts/ over the existing ones.
Run first:  python -m rfparts.selfcheck


1. SPECS IN THE DATABASE BUT BLANK IN THE NEW-PARTS TABLE
---------------------------------------------------------
parse_page() yields the part with the key **spec_rows** (a list of SpecRow
objects). The part channel sent `part.get("specs", {})` -- a key that never
exists -- so every row arrived at the table with an empty spec dict. Meanwhile
_write() reads spec_rows and stores the real values, which is exactly why the
health report showed specs while the table showed nothing.

Added flat_specs(): SpecRow objects -> {key: scalar} in the shape the table
reads, splitting the freq_ghz min/max range into freq_min / freq_max and
preferring typ, then max, then min, then text. Verified it produces
  {'freq_min': 1.0, 'freq_max': 20.0, 'gain_db': 15.0, 'nf_db': 2.1,
   'oip3_dbm': 29.0, 'package': 'LFCSP', 'mount_type': 'Surface Mount'}
which is precisely what _row_values() looks for.


2. EVERYTHINGRF RE-PARSED ON EVERY RUN
--------------------------------------
Same root cause as the Reset crash you hit. ingest() called _stopped() inside the
page loop, and that helper was never defined (my patch anchored on
`def emit(message):` while the file says `def emit(message: str) -> None:`). The
NameError aborted the loop AFTER parts had been written but BEFORE the
`source_complete` checkpoint was reached -- so the checkpoint never completed and
every subsequent run started over. Resume itself was fine.

Verified: run 1 parses and checkpoints; run 2 reports source_skipped=1 and parses
nothing.

Also hardened: a failure on one page can no longer abort the whole source. It is
logged as PARSE FAILED, counted in page_errors, and the run continues to the
checkpoint. Losing a whole source's progress to one bad file is too expensive.


3. NO STOP BUTTON VISIBLE
-------------------------
It existed, but its row was packed LAST, after a parts table that expands. When
the requested heights exceed the window, the last-packed row is the one Tk clips,
so the button was off the bottom edge. The bar is now created and packed with
side="bottom" BEFORE the expanding table, so the packer reserves that row first
and it can never be squeezed out. Added minsize(900, 560) and relabelled it
"Stop  (finish current request)" so it is obvious what it does.


4. ADI WAS BEING PARSED BADLY -- TWO SEPARATE FILES, BOTH UNDER-READ
--------------------------------------------------------------------
(a) THE SPACE PORTFOLIO. This is the important one. adi_space_portfolio_*.xlsx has
nineteen columns and we were reading ONE of them (the part number). Everything
below was discarded:

    Space Qualification Level   "ASD Model (MIL-PRF-38535 Class V)"  -> pedigree
    TID Threshold (kRad)        -> the radiation data the health report has been
    SEL Threshold (MeV*cm2/mg)     showing as ~0% coverage all along
    Displacement Damage (TNID)
    Package / Package Material  "Ceramic/Metal" -> direct hermeticity evidence
    Lead Finish, Operating Temperature, Category / Sub-Category
    Datasheet URL               -> the REAL url. We were guessing
                                   analog.com/.../<pn>.pdf and getting HTTP 403;
                                   the sheet had the working link all along.

New module adi_space_ingest.py reads all of it. It also collapses the several
orderable rows per generic part, keeping the STRONGEST qualification level --
otherwise an "Engineering Model" row would downgrade the flight part sitting two
rows above it.

Result on your file: 233 generic parts from 550 orderable rows,
    178 space_qualified, 1 hi-rel, 54 listed-only
    220 with TID, 135 with SEL, 154 hermetic, 233 with a real datasheet URL
    radiation coverage: 0% -> 94.4%

classify_file() previously routed EVERY .xlsx to adi_ingest, so the portfolio was
being read by the wrong adapter. It now recognises the space portfolio and the
parametric exports separately, and _run() passes progress/part/categories to
whichever adapter accepts them, so these parts appear in the live table too.

(b) THE PARAMETRIC EXPORTS (from the previous patch, included here for
completeness): Package was unmapped in eight of nine workbooks, IIP3 never
matched because the pattern was ^oip3, and the mixer IF/LO frequency ranges were
dropped entirely. Also the "Conversion Gain" sign bug: -10 dB means 10 dB of
LOSS, and filing it as conversion_loss_db = -10 made passive mixers pass any
"loss below N dB" filter.


ON THE SPACEQUAL SCRIPTS
------------------------
spacequal.py in your tree is the space-qualification EVIDENCE ENGINE (weighted
signal classifier) -- it has no ADI parsing in it, so nothing to fix there. The
ADI reading you were thinking of lives in the standalone spacequal debug tools,
and it had the same fault as (a) above: it read only the "Generic Part Number"
column and then guessed datasheet URLs that ADI answers with 403. That is now
moot: adi_space_ingest.py takes the real Datasheet URL column, so when we return
to the classifier it can use ADI's own links, plus the TID/SEL/package-material
evidence, instead of scraping anything.


VERIFICATION
------------
    selfcheck                                     all checks passed
    erf resume                                    run 2: source_skipped=1
    erf flat_specs                                correct keys for the table
    space portfolio through rebuild()             233 parts, all with specs
    radiation coverage                            94.4%
    pedigree                                      178 qualified / 1 grade / 54 none

Not exercised here: no Tk, so the Stop-button repositioning is verified by pack
order rather than by eye. If a Marki row still shows blank specs in the table,
run  python -m rfparts.parse_debug <cached datasheet page> --vendor marki  and
send that report.
