rfparts — why there is no gain or NF in the space portfolio
==========================================================
2 files. Drop into rfparts/.  Run: python -m rfparts.selfcheck


THE ANSWER: THE DATA IS NOT IN THE FILE
---------------------------------------
I dumped the workbook you attached exhaustively -- every sheet, every column, no
assumptions -- and then searched the raw XML inside the .xlsx.

  ONE sheet: "ADI Space Qualified Parts", A1:S555, 19 columns, NO hidden columns.
  The header row (row 4) is, in full:

    1  Generic Part Number        11  SEL Threshold (MeV*cm2/mg)
    2  Description                12  SEE Report
    3  Orderable Material Number  13  Displacement Damage (TNID)
    4  Category                   14  Displacement Damage Report
    5  Sub-Category               15  Package
    6  Space Qualification Level  16  Package Material
    7  Operating Temperature      17  Lead Finish
    8  Production Radiation Hard  18  ADI POD No.
    9  TID Threshold (kRad)       19  Datasheet URL
   10  TID Report

  There is no gain column. No noise figure, P1dB, OIP3 or Psat column either.

  Searching the RAW XML of the whole workbook, the word "Gain" appears exactly
  FIVE times -- every one of them inside description prose, e.g.
      AD8367S  "Aerospace 500 MHz, 45 dB Linear-in-dB Variable Gain Amplifier"
  and the strings "noise figure", "NF", "OIP3", "P1dB" and "Psat" appear ZERO
  times anywhere in the file.

  Of 234 distinct parts: 1 states a gain figure in its description, 0 state a
  noise figure, 117 state a frequency (which we already extract), 2 state a power.


YOUR TWO THEORIES, TESTED
------------------------
"Is the code assigning it to the parametric data?"  No. I enumerated every spec key
the portfolio ingest is capable of emitting, across all 233 parts:

    freq_max, freq_min, lead_finish, package, package_material, psat_dbm,
    radiation_hardness, sel_mev, temp_max_c, temp_min_c, tid_krad, tnid

gain_db: never emitted. nf_db: never emitted. There is nothing to misassign.

(There IS one legitimate cross-source mechanism, and it is deliberate: 76 portfolio
parts share a part number with a parametric export row, so upsert merges them and
those parts end up with both qualification AND RF parametrics. That is how 33 of
the portfolio's 39 genuine RF amplifiers get their gain. It is a merge, not a
misassignment.)

"Is it skipping gain in the excel?"  There is no gain column to skip -- proven by
the raw-XML search above, not by reading my own mapping table.


SO THAT THIS QUESTION ANSWERS ITSELF NEXT TIME
----------------------------------------------
An empty column looks identical whether the parser failed or the source never had
the data, which is why this has taken several rounds. Every rebuild now prints a
declared capability table before the coverage numbers:

    Source capabilities (what each input can actually provide)
      ADI space portfolio
        provides : space_qual_level, tid_krad, sel_mev, tnid, temp_min_c,
                   temp_max_c, package, package_material, lead_finish,
                   datasheet_url, freq_ghz (from the description, ~117 of 234)
        CANNOT   : gain_db, nf_db, p1db_dbm, oip3_dbm, psat_dbm
        note     : 19 columns, none parametric. RF numbers for its 39 genuine RF
                   amplifiers arrive by merging with the parametric exports.
      ADI parametric exports
        provides : freq_ghz, gain_db (Amplifiers + LNA/PA sheets only), nf_db, ...
        CANNOT   : tid_krad, sel_mev, space_qual_level
        note     : 3 of 9 sheets carry a gain column; the other 6 have none.
      ... and the same for everythingRF, MACOM, Qorvo, Marki, Skyworks

Verified against the real files, so it is a statement of fact about each input
rather than a guess.


WHILE I WAS THERE — THE DESCRIPTIONS
------------------------------------
Widened the description parser to take what little is genuinely available:

    "20 dB Gain Block, 2 to 18 GHz"          -> gain_db 20, freq 2-18 GHz
    ">1.5 W (34 dBm), 24 GHz to 34 GHz"      -> psat 34 dBm (the STATED dBm, not
                                                1.5 W converted to 31.8)
    "45 dB Linear-in-dB Variable Gain Amp"   -> gain_RANGE_db 45, NOT gain_db

That last one matters: on a VGA the figure is a gain control range, and filing it
as gain_db would let the part pass a "gain above 40 dB" filter it has no business
passing. It goes to gain_range_db instead.

This adds gain for exactly one portfolio part. I am not overselling it -- the point
of the change is the capability table above.


NOT TESTED HERE
---------------
No Tk. The capability table and the description patterns are verified by driving
rebuild() and specs_from_description() directly against your actual spreadsheet.
