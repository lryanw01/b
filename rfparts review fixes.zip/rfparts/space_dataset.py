"""Build/refresh the space-qualified parts dataset from LOCAL catalogs.

One place that knows how to turn the catalogs on disk into partdb rows, then
dedupe. Everything is offline: it only reads files you already downloaded.

Sources understood:
  * everythingRF saved listing folders  -> erf_space_ingest  (EverythingRFSpace*)
  * ADI space portfolio .xlsx            -> adi_ingest
  * Qorvo defense/aerospace .pdf         -> qorvo_ingest
  * TI Space Products Guide .pdf         -> ti_ingest

Adding another catalog later = drop a new ``*_ingest`` module with an
``ingest(path, dry_run, verbose)`` and add one line to ``_ADAPTERS``.

Public API (used by the GUI "Rebuild dataset" button and the CLI `ingest`):
    rebuild(erf_parent=None, source_files=(), source_dir=None,
            dedupe=True, progress=None) -> summary dict
    scan_dir(folder) -> list[(path, kind)]
"""
from __future__ import annotations

import traceback
from pathlib import Path
from .paths import EVERYTHING_RF, NEW_SOURCES, ADI_PARAMETRICS, EXPORT_DIR

try:
    from . import (adi_ingest, qorvo_ingest, ti_ingest, erf_space_ingest,
                   partdb, vendor_catalogs)
except ImportError:                                    # loose-script fallback
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from rfparts import (adi_ingest, qorvo_ingest, ti_ingest,   # type: ignore
                         erf_space_ingest, partdb, vendor_catalogs)

# Vendors whose live catalogues can be walked (see vendor_catalogs). Selectable
# so a refresh can target one vendor instead of re-walking everything.
CATALOG_VENDORS = vendor_catalogs.ALL_VENDORS

# kind -> (module, human label)
_ADAPTERS = {
    "adi": (adi_ingest, "ADI space portfolio"),
    "qorvo": (qorvo_ingest, "Qorvo defense/aerospace brochure"),
    "ti": (ti_ingest, "TI Space Products Guide"),
}


def classify_file(path: Path) -> str | None:
    """Best-effort adapter kind for a file, from its name/extension."""
    name = path.name.lower()
    ext = path.suffix.lower()
    if ext in (".xlsx", ".xlsm", ".csv") and "adi" in name:
        return "adi"
    if ext in (".xlsx", ".xlsm", ".csv"):
        return "adi"          # only ADI ships an xlsx today
    if ext == ".pdf" and "qorvo" in name:
        return "qorvo"
    if ext == ".pdf" and ("slyt" in name or name.startswith("ti") or "space-products" in name
                          or "space_products" in name):
        return "ti"
    if ext == ".pdf":
        return None           # unknown PDF -> let the caller decide
    return None


def scan_dir(folder) -> list[tuple[Path, str | None]]:
    """Every ingestable file under `folder` (one level), with its guessed kind."""
    folder = Path(folder)
    out = []
    if not folder.is_dir():
        return out
    for p in sorted(folder.rglob("*")):
        if p.is_file() and p.suffix.lower() in (".pdf", ".xlsx", ".xlsm", ".csv"):
            out.append((p, classify_file(p)))
    return out


def _run(kind, path, progress) -> dict:
    module, label = _ADAPTERS[kind]
    progress(f"ingesting {label}: {Path(path).name} ...")
    counts = module.ingest(Path(path), dry_run=False, verbose=False)
    progress(f"  {label}: {counts.get('parts', 0)} parts "
             f"({counts.get('space_qualified', 0)} qualified, "
             f"{counts.get('space_grade', 0)} grade)")
    return counts


def rebuild(erf_parent=None, source_files=(), source_dir=None,
            erf_glob="EverythingRFSpace*", dedupe=True, progress=None,
            vendors=None, vendor_rate=1.0, vendor_limits=None,
            download_datasheets=True, download_limit=0, adi_dir=None,
            use_cache=True, categories=None, reset=False,
            resume=True, reset_vendors_only=False, part=None, event=None,
            cancel=None) -> dict:
    """Ingest everything selected into partdb, then dedupe.

    Local sources (unchanged):
      erf_parent   folder holding the EverythingRFSpace* listing subfolders
      source_files explicit catalog files (kind auto-detected by name)
      source_dir   a folder to scan for catalog files
      dedupe       run partdb.merge_duplicates() at the end (richest specs win)

    Live vendor catalogues (new):
      vendors      subset of CATALOG_VENDORS to walk, e.g. ['qorvo','marki'].
                   None or [] walks none, so existing callers behave as before.
      vendor_rate  seconds between requests to the SAME host
      vendor_limits e.g. {'qorvo_ids': 40, 'marki_products': 200}
      adi_dir      folder of ADIParametricSearch*.xlsx (ADI is never scraped)
      use_cache    reuse pages already downloaded into partdb.DATA/vendor_cache
    """
    def emit(m):
        if progress:
            progress(m)

    summary = {"sources": [], "errors": [], "parts_ingested": 0}
    if reset:
        # The GUI/CLI pass vendor KEYS ('adi'), but parts are stored under
        # display NAMES ('Analog Devices'). Without translating, a scoped reset
        # matched nothing and silently deleted zero rows.
        scope = None
        if reset_vendors_only and vendors:
            scope = []
            for v in vendors:
                scope.append(v)
                name = vendor_catalogs.VENDORS.get(v, {}).get("name")
                if name and name not in scope:
                    scope.append(name)
        emit("RESET dataset | deleting parts, scrape state and caches"
             + (f" for {', '.join(scope)}" if scope else " (everything)"))
        removed = partdb.reset_dataset(vendors=scope, clear_cache=True,
                                       progress=emit)
        summary["reset"] = removed
        # Resume state is meaningless immediately after a reset.
        resume = False

    files: list[tuple[Path, str | None]] = [(Path(f), classify_file(Path(f)))
                                            for f in source_files]
    if source_dir:
        files += scan_dir(source_dir)

    # everythingRF first (it carries the real manufacturer part numbers that
    # ADI/TI/Qorvo rows later dedupe against).
    if erf_parent:
        try:
            erf_path = Path(erf_parent)
            ingest_parent, ingest_glob = erf_path, erf_glob
            if erf_path.is_dir() and erf_path.name.lower().startswith("everythingrfspace"):
                ingest_parent, ingest_glob = erf_path.parent, erf_path.name
            emit(f"ingesting everythingRF space folders under {ingest_parent} ...")
            c = erf_space_ingest.ingest(
                ingest_parent, ingest_glob, dry_run=False, verbose=False,
                resume=bool(resume), progress=emit, part=part, cancel=cancel)
            n = c.get("parts", 0)
            summary["parts_ingested"] += n
            summary["sources"].append(("everythingRF", n, c))
            emit(f"  everythingRF: {n} parts "
                 f"({c.get('space_qualified', 0)} qualified, "
                 f"{c.get('space_grade', 0)} grade)")
        except Exception as e:                          # keep going on one bad source
            summary["errors"].append(f"everythingRF: {e}")
            emit(f"  everythingRF FAILED: {e}")
            traceback.print_exc()

    # Every HTML catalog under newSources is a trusted space source. Folder
    # names containing SpaceQual are qualified; names containing Space (but not
    # SpaceQual) are grade; all other newSources folders default to qualified.
    if source_dir:
        html_root = Path(source_dir)
        if html_root.is_dir() and any(html_root.rglob("*.htm*")):
            try:
                emit(f"ingesting trusted space HTML folders under {html_root} ...")
                c = erf_space_ingest.ingest(
                    html_root, "*", dry_run=False, verbose=False,
                    default_variant="space_qualified",
                    resume=bool(resume), progress=emit, part=part,
                    cancel=cancel)
                n = c.get("parts", 0)
                summary["parts_ingested"] += n
                summary["sources"].append(("newSources-html", n, c))
                emit(f"  newSources HTML: {n} parts "
                     f"({c.get('space_qualified', 0)} qualified, "
                     f"{c.get('space_grade', 0)} grade)")
            except Exception as e:
                summary["errors"].append(f"newSources HTML: {e}")
                emit(f"  newSources HTML FAILED: {e}")
                traceback.print_exc()

    for path, kind in files:
        if kind not in _ADAPTERS:
            summary["errors"].append(f"unrecognized source: {path.name}")
            emit(f"  skipped (unrecognized): {path.name}")
            continue
        try:
            c = _run(kind, path, emit)
            summary["parts_ingested"] += c.get("parts", 0)
            summary["sources"].append((kind, c.get("parts", 0), c))
        except Exception as e:
            summary["errors"].append(f"{path.name}: {e}")
            emit(f"  {path.name} FAILED: {e}")
            traceback.print_exc()

    # --- live vendor catalogues -------------------------------------------
    if vendors:
        emit("")
        try:
            vsum = vendor_catalogs.ingest(
                vendors=vendors, rate=vendor_rate, progress=emit,
                limits=vendor_limits, download=download_datasheets,
                download_limit=download_limit, adi_dir=adi_dir,
                use_cache=use_cache, categories=categories,
                resume=bool(resume), part=part, event=event, cancel=cancel)
            summary["vendors"] = vsum
            for v, info in vsum.get("per_vendor", {}).items():
                n = info.get("parts", 0)
                summary["parts_ingested"] += n
                summary["sources"].append((f"vendor:{v}", n, info))
            summary["errors"].extend(vsum.get("errors", []))
        except Exception as e:
            summary["errors"].append(f"vendor catalogs: {e}")
            emit(f"  vendor catalogs FAILED: {e}")
            traceback.print_exc()

    if dedupe:
        emit("de-duplicating (keeping the richest copy of each part) ...")
        d = partdb.merge_duplicates(progress=None)
        summary["dedupe"] = d
        emit(f"  merged {d['groups']} duplicate group(s), removed {d['deleted']} row(s)")

    summary["stats"] = partdb.dataset_stats()
    s = summary["stats"]
    emit(f"dataset now: {s['parts']} parts, {s['qualified']} space-qualified, "
         f"{s['grade']} space-grade, {s['vendors']} vendors")
    exported = partdb.export_parts_json(EXPORT_DIR)
    summary["json_export"] = exported
    emit(f"normalized JSON export: {exported['parts']} parts -> {exported['folder']}")
    return summary
