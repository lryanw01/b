"""Show exactly what the parsers extract from a vendor page.

The build log tells you a page produced 37 parts. It does not tell you which
columns were recognised, what a spec cell actually contained before it became a
number, or why the other 12 rows on that page were thrown away. This module
answers those questions against a real file or URL, without touching the
database.

    python -m rfparts.parse_debug --list
    python -m rfparts.parse_debug "Data/vendor_cache/www.qorvo.com/ab12cd.html"
    python -m rfparts.parse_debug "Sources/newSources/ADM-10699PSM.html"
    python -m rfparts.parse_debug --url "https://www.qorvo.com/products/product-list?categoryID=ca0021"
    python -m rfparts.parse_debug --all-cached --vendor qorvo --json report.json

WHAT IT REPORTS
    * which vendor parser was chosen, and why
    * every table found, its header row, and the header -> spec-key mapping,
      including headers that were NOT recognised (the usual cause of a missing
      spec is an unmapped column, not a broken number parser)
    * per part: the raw cell text alongside the parsed value and unit, so a
      wrong number can be traced to the cell it came from
    * rejected rows with the reason (no part number, category filtered,
      looks like a facet/slug, no digits, ...)
    * for a Marki datasheet page: extracted text length, which spec sections
      were found, and the pipe-table column mapping
    * construction cues present in the text, which is what the space-qualifiable
      classifier will eventually read

Nothing here writes to partdb.
"""
from __future__ import annotations

import argparse
import json
import re
import urllib.parse
from collections import Counter
from pathlib import Path

try:
    from . import vendor_catalogs as vc
    from .paths import PARSE_DEBUG_DIR, VENDOR_CACHE
except ImportError:                                     # loose-script fallback
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from rfparts import vendor_catalogs as vc            # type: ignore
    from rfparts.paths import PARSE_DEBUG_DIR, VENDOR_CACHE   # type: ignore

CUES = ("hermetic", "ceramic", "GaAs", "GaN", "alumina", "bare die", "MIL-",
        "screened", "laser weld", "plastic", "epoxy", "-55", "kovar",
        "glass-to-metal", "hi-rel", "LTCC", "thin film", "space")

_HOST_PARSER = [
    ("qorvo.com", "qorvo"),
    ("macom.com", "macom"),
    ("skyworksinc.com", "skyworks"),
    ("markimicrowave.com", "marki"),
    ("everythingrf.com", "everythingrf"),
]


def detect_vendor(html, source_hint=""):
    """(vendor_key, why). Host in the hint wins; otherwise sniff the markup."""
    hint = str(source_hint).lower()
    for needle, key in _HOST_PARSER:
        if needle in hint:
            return key, f"source path/URL contains {needle}"
    low = html[:200_000].lower()
    for needle, key in _HOST_PARSER:
        if needle in low:
            return key, f"page markup references {needle}"
    if "/products/product-list" in low or "/products/d/" in low:
        return "qorvo", "found Qorvo product-list markers"
    if "/products/product-detail/" in low:
        return "macom", "found MACOM product-detail links"
    return "unknown", "no vendor marker found"


# --------------------------------------------------------------------- tables
def inspect_tables(html, categories=None):
    """Every table, its header mapping, and each row's raw-vs-parsed values."""
    out = []
    for ti, (headers, rows) in enumerate(vc.parse_tables(html)):
        colmap = vc.map_headers(headers)
        mapped, unmapped = [], []
        for i, h in enumerate(headers):
            if i in colmap:
                key, unit = colmap[i]
                mapped.append({"column": i, "header": h, "spec_key": key,
                               "unit_from_header": unit or "(none)"})
            else:
                unmapped.append({"column": i, "header": h})
        out.append({"table": ti, "headers": headers, "row_count": len(rows),
                    "mapped_columns": mapped, "unmapped_columns": unmapped})
    return out


def inspect_qorvo(html, base, categories=None):
    """Reproduce walk_qorvo's extraction, keeping the raw cell text."""
    heads = [h[0] for h in vc._QORVO_HEAD.findall(html)]
    tables = vc.parse_tables(html)
    parts, rejects = [], []
    for ti, (headers, rows) in enumerate(tables):
        section = heads[ti] if ti < len(heads) else ""
        cat, sub = vc._qorvo_category(section)
        colmap = vc.map_headers(headers)
        cat_ok = vc.category_allowed(cat, categories)
        for ri, cells in enumerate(rows):
            joined = " ".join(c[1] for c in cells)
            pn = ds = ""
            for kind, ident in vc._QORVO_PD.findall(joined):
                if kind.lower() == "p" and not pn:
                    pn = urllib.parse.unquote(ident).strip("/")
                elif kind.lower() == "d" and not ds:
                    ds = f"https://www.qorvo.com/products/d/{ident}"
            if not pn:
                rejects.append({"table": ti, "row": ri, "reason":
                                "no /products/p/ link in the row",
                                "first_cells": [c[0] for c in cells[:3]]})
                continue
            if not vc.looks_like_pn(pn):
                rejects.append({"table": ti, "row": ri, "candidate": pn,
                                "reason": "did not look like a part number "
                                          "(no digit, or a word-like segment)"})
                continue
            if not vc.is_orderable_part(pn):
                rejects.append({"table": ti, "row": ri, "candidate": pn,
                                "reason": "evaluation board / dev kit"})
                continue
            if not cat_ok:
                rejects.append({"table": ti, "row": ri, "candidate": pn,
                                "reason": f"category '{cat}' excluded by filter"})
                continue
            rec = {"specs": {}}
            raw = {}
            for i, (text, _h) in enumerate(cells):
                if i not in colmap:
                    continue
                key, unit = colmap[i]
                before = dict(rec["specs"])
                vc._absorb_spec(rec, key, text, unit)
                for k, v in rec["specs"].items():
                    if k not in before or before[k] != v:
                        raw[k] = {"header": headers[i] if i < len(headers) else "",
                                  "raw_cell": text, "parsed": v[0],
                                  "unit": v[1]}
            parts.append({
                "mpn": pn, "section": section, "category": cat,
                "subcategory": sub, "datasheet_url": ds or "(none on this row)",
                "description": cells[1][0][:160] if len(cells) > 1 else "",
                "specs": raw,
                "unparsed_cells": [
                    {"header": headers[i] if i < len(headers) else f"col{i}",
                     "text": c[0]}
                    for i, c in enumerate(cells)
                    if i in colmap and not any(
                        r for k, r in raw.items() if r["raw_cell"] == c[0])][:6],
            })
    return {"sections": heads, "parts": parts, "rejects": rejects}


def inspect_link_vendor(html, base, vendor, categories=None):
    """MACOM / Skyworks / Marki: which links became parts, which did not."""
    host = urllib.parse.urlparse(base).netloc or {
        "macom": "www.macom.com", "skyworks": "www.skyworksinc.com",
        "marki": "markimicrowave.com"}.get(vendor, "")
    parts, rejects = [], []
    seen = set()
    for href in vc._HREF.findall(html):
        u = urllib.parse.urljoin(base or f"https://{host}/", href.strip())
        pr = urllib.parse.urlparse(u)
        if host and pr.netloc != host:
            continue
        path = pr.path
        cand = None
        if vendor == "macom":
            m = vc._MACOM_PART.search(path)
            cand = urllib.parse.unquote(m.group(1)) if m else None
            if not m and re.search(r"/products?/", path, re.I):
                rejects.append({"url": path, "reason":
                                "not under /products/product-detail/ "
                                "(category page or filter facet)"})
                continue
        elif vendor == "skyworks":
            m = vc._SKY_PART.match(path)
            cand = urllib.parse.unquote(m.group(2)) if m else None
            if not m and path.lower().startswith("/en/products"):
                rejects.append({"url": path,
                                "reason": "category page, not /Products/<cat>/<PN>"})
                continue
        elif vendor == "marki":
            m = vc._MARKI_PART.match(href.strip())
            cand = m.group(2) if m else None
        if not cand:
            continue
        if cand.upper() in seen:
            continue
        if not vc.looks_like_pn(cand):
            rejects.append({"url": path, "candidate": cand, "reason":
                            "rejected by looks_like_pn (no digit, or a "
                            "word-like segment after the first)"})
            continue
        if not vc.is_orderable_part(cand):
            rejects.append({"url": path, "candidate": cand,
                            "reason": "evaluation board / dev kit, not a part"})
            continue
        cat, sub = vc._category_from_path(path)
        if not vc.category_allowed(cat, categories):
            rejects.append({"url": path, "candidate": cand,
                            "reason": f"category '{cat}' excluded by filter"})
            continue
        seen.add(cand.upper())
        rec = {"mpn": cand, "category": cat, "subcategory": sub,
               "product_url": u}
        if vendor == "macom":
            rec["datasheet_url"] = (
                "https://cdn.macom.com/datasheets/"
                + urllib.parse.quote(cand, safe="+-_.") + ".pdf")
        parts.append(rec)
    return {"parts": parts, "rejects": rejects}


def inspect_marki_datasheet(html):
    """A Marki /datasheet/ page: the text, its sections, and the pipe tables."""
    text = vc.marki_datasheet_text(html)
    lines = text.split("\n")
    sections = [ln for ln in lines
                if re.match(r"^(general description|features|applications|"
                            r"absolute maximum|recommended operating|"
                            r"electrical specification|package information|"
                            r"port functions|mechanical data)", ln, re.I)]
    tables, cur = [], None
    for ln in lines:
        if "|" not in ln:
            cur = None
            continue
        cells = [c.strip() for c in ln.split("|")]
        if cells and cells[0].lower().startswith("parameter"):
            cur = {"header": cells, "rows": []}
            tables.append(cur)
        elif cur is not None:
            cur["rows"].append(cells)
    rec = {"specs": {}}
    vc._marki_specs_from_text(rec, text)
    return {
        "text_chars": len(text), "text_words": len(text.split()),
        "sections_found": sections,
        "has_spec_table": bool(vc._SPEC_MARK.search(text)),
        "pipe_tables": [{"header": t["header"],
                         "row_count": len(t["rows"]),
                         "sample_rows": t["rows"][:6]} for t in tables],
        "parsed_specs": {k: {"value": v[0], "unit": v[1]}
                         for k, v in rec["specs"].items()},
        "cues": [c for c in CUES if re.search(re.escape(c), text, re.I)],
        "text_head": " ".join(text.split())[:400],
    }


# ------------------------------------------------------------------- driver
def inspect_source(html, source="", categories=None, vendor=None):
    vendor_key, why = (vendor, "forced by --vendor") if vendor else \
        detect_vendor(html, source)
    base = source if str(source).startswith("http") else \
        {"qorvo": "https://www.qorvo.com/",
         "macom": "https://www.macom.com/",
         "skyworks": "https://www.skyworksinc.com/",
         "marki": "https://markimicrowave.com/"}.get(vendor_key, "")
    report = {"source": str(source), "bytes": len(html),
              "vendor": vendor_key, "vendor_reason": why,
              "categories_filter": sorted(categories or []) or "all",
              "tables": inspect_tables(html, categories)}
    looks_marki_ds = (vendor_key == "marki" and
                      re.search(r"electrical specification|device overview",
                                html, re.I))
    if vendor_key == "qorvo":
        report.update(inspect_qorvo(html, base, categories))
    elif looks_marki_ds:
        report["marki_datasheet"] = inspect_marki_datasheet(html)
        report.update(inspect_link_vendor(html, base, "marki", categories))
    elif vendor_key in ("macom", "skyworks", "marki"):
        report.update(inspect_link_vendor(html, base, vendor_key, categories))
    else:
        report["parts"] = []
        report["rejects"] = [{"reason": "no vendor parser selected; "
                                        "pass --vendor to force one"}]
    return report


def cached_files(vendor=None):
    if not VENDOR_CACHE.exists():
        return []
    out = []
    for f in sorted(VENDOR_CACHE.rglob("*.html")):
        host = f.parent.name
        if vendor and vendor.lower() not in host.lower():
            continue
        out.append(f)
    return out


def render(report, max_parts=12, show_rejects=12):
    L = []
    A = L.append
    A("=" * 78)
    A(f"PARSE REPORT  {report['source']}")
    A("=" * 78)
    A(f"  {report['bytes']:,} bytes    vendor={report['vendor']}  "
      f"({report['vendor_reason']})")
    A(f"  category filter: {report['categories_filter']}")
    tabs = report.get("tables", [])
    A(f"\n  TABLES FOUND: {len(tabs)}")
    for t in tabs[:6]:
        A(f"    table {t['table']}: {t['row_count']} row(s), "
          f"{len(t['headers'])} column(s)")
        for m in t["mapped_columns"]:
            A(f"      col {m['column']:>2}  {m['header'][:34]:<34} -> "
              f"{m['spec_key']}  [{m['unit_from_header']}]")
        if t["unmapped_columns"]:
            A(f"      UNMAPPED (a missing spec usually starts here):")
            for u in t["unmapped_columns"][:8]:
                A(f"        col {u['column']:>2}  {u['header'][:56]}")
    if report.get("sections"):
        A(f"\n  SECTION HEADINGS: {'; '.join(report['sections'][:8])}")
    ds = report.get("marki_datasheet")
    if ds:
        A(f"\n  MARKI DATASHEET PAGE")
        A(f"    text: {ds['text_chars']:,} chars / {ds['text_words']:,} words"
          f"    spec table present: {ds['has_spec_table']}")
        A(f"    sections: {'; '.join(ds['sections_found'][:8]) or '(none)'}")
        for t in ds["pipe_tables"][:3]:
            A(f"    pipe table header: {' | '.join(t['header'][:8])}")
            for r in t["sample_rows"][:4]:
                A(f"        {' | '.join(r[:8])[:96]}")
        A(f"    parsed specs:")
        for k, v in sorted(ds["parsed_specs"].items()):
            A(f"      {k:<24} {v['value']} {v['unit']}")
        A(f"    construction cues: {', '.join(ds['cues']) or 'NONE'}")
        A(f"    text starts: \"{ds['text_head'][:180]}\"")
    parts = report.get("parts", [])
    A(f"\n  PARTS EXTRACTED: {len(parts)}")
    for p in parts[:max_parts]:
        A(f"    {p['mpn']:<24} {p.get('category', ''):<14}"
          f"{p.get('subcategory', '')}")
        if p.get("description"):
            A(f"      {p['description'][:70]}")
        if p.get("datasheet_url"):
            A(f"      datasheet: {p['datasheet_url'][:70]}")
        for k, r in (p.get("specs") or {}).items():
            if isinstance(r, dict):
                A(f"      {k:<20} {str(r['parsed']):>10} {r['unit']:<5} "
                  f"<- \"{r['raw_cell'][:26]}\"  ({r['header'][:24]})")
    if len(parts) > max_parts:
        A(f"    ... and {len(parts) - max_parts} more")
    rej = report.get("rejects", [])
    A(f"\n  ROWS/LINKS REJECTED: {len(rej)}")
    for r in Counter(x.get("reason", "?") for x in rej).most_common():
        A(f"    {r[1]:>5}  {r[0]}")
    for r in rej[:show_rejects]:
        who = r.get("candidate") or r.get("url") or r.get("first_cells") or ""
        A(f"      {str(who)[:56]:<56} {r.get('reason', '')[:40]}")
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("path", nargs="?", help="an HTML file to inspect")
    ap.add_argument("--url", help="fetch and inspect a live URL (uses the cache)")
    ap.add_argument("--vendor", help="force a parser: qorvo macom skyworks marki")
    ap.add_argument("--categories", nargs="*", help="apply a category filter")
    ap.add_argument("--list", action="store_true",
                    help="list cached vendor pages and exit")
    ap.add_argument("--all-cached", action="store_true",
                    help="inspect every cached page (use with --vendor)")
    ap.add_argument("--max-parts", type=int, default=12)
    ap.add_argument("--json", help="also write the full report as JSON")
    args = ap.parse_args(argv)

    if args.list:
        files = cached_files(args.vendor)
        print(f"{len(files)} cached page(s) under {VENDOR_CACHE}")
        for f in files[:200]:
            print(f"  {f.stat().st_size:>9,}  {f.parent.name:<26} {f.name}")
        return 0

    reports = []
    if args.url:
        fetcher = vc.Fetcher(rate=1.0, progress=print)
        html, src = fetcher.get(args.url)
        reports.append(inspect_source(html, args.url, args.categories,
                                      args.vendor))
    elif args.all_cached:
        for f in cached_files(args.vendor):
            html = f.read_text(encoding="utf-8", errors="replace")
            reports.append(inspect_source(html, str(f), args.categories,
                                          args.vendor))
    elif args.path:
        f = Path(args.path)
        if not f.is_file():
            raise SystemExit(f"not a file: {f}")
        html = f.read_text(encoding="utf-8", errors="replace")
        reports.append(inspect_source(html, str(f), args.categories,
                                      args.vendor))
    else:
        ap.error("give a file, --url, --all-cached, or --list")

    for r in reports:
        print(render(r, max_parts=args.max_parts))
        print()
    total = sum(len(r.get("parts", [])) for r in reports)
    rej = sum(len(r.get("rejects", [])) for r in reports)
    print(f"{len(reports)} source(s): {total} part(s) extracted, "
          f"{rej} row(s)/link(s) rejected")
    if args.json:
        out = Path(args.json)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(reports, indent=2, default=str),
                       encoding="utf-8")
        print(f"full JSON -> {out.resolve()}")
    return 0


if __name__ == "__main__":
    main()
