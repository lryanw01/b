rfparts — fixes for the issues found in the seven patch zips
============================================================
10 files: 3 new, 7 modified. Drop the rfparts/ folder over your existing one.

FIRST, RUN THIS:
    python -m rfparts.selfcheck
It imports every module and compares each cross-layer call against the target's
real signature. Both shipped breakages below were this class of fault, and both
are caught in under a second. Run it before applying any future patch.

WAS BROKEN
----------
paths.py DID NOT EXIST.  gui.py, space_dataset.py and erf_space_ingest.py all did
    `from .paths import ...` unconditionally, but no zip contained the file, so a
    clean tree died on import. It ships now, as the single source of truth for
    every root: Data/ and Sources/ as siblings of the package, each overridable
    by an env var, with paths.describe() dumping what resolved where. partdb
    reads its root from it so the two cannot disagree.

partdb.reset_dataset DID NOT EXIST.  space_dataset.py:115 called it unguarded, so
    Reset raised AttributeError the first time it was used. Added, with vendor
    scoping. It also clears the everythingRF resume checkpoints -- which is
    correct, and is now stated in the confirm dialog rather than being a surprise.

RESET SCOPED BY VENDOR DELETED NOTHING.  The GUI passes vendor KEYS ('adi') but
    parts are stored under display NAMES ('Analog Devices'), and nothing
    translated between them, so a scoped reset silently matched zero rows.
    Verified: now removes the right 1044.

VENDOR WALKS NEVER RESUMED.  There was no scrape_log; resume was inferred as
    `use_cache and not reset` and only ever reached the local everythingRF
    ingest. Every Qorvo categoryID and Marki page was re-walked on every run.
    Now backed by a real scrape_log table recording catalogue pages, product
    pages and datasheet files, with resume and cache as SEPARATE controls --
    they answer different questions, and welding them together is why this broke.
    Verified: run 2 over the same source fetches 0 parts and reports "skipped 1".

TWO WRITE PATHS, ONLY ONE REPORTING.  Only Marki went through stream_records;
    Qorvo/MACOM/Skyworks were committed by a second call that neither reported
    parts to the live table NOR applied the category filter. Everything funnels
    through one path now. Verified: category filter 'attenuator' yields 1 of 3
    parts; 'mixer' yields 159 of 1044 ADI parts.

PER-VENDOR HEALTH WAS GLOBAL.  show_health() called dataset_health() with no
    argument and the signature took none, so every "per-vendor" window showed the
    same dataset-wide numbers -- dominated by whichever vendor contributed most
    rows, which is exactly what you cannot learn anything from. Now scoped, and
    it resolves a loose name ('marki' -> 'Marki Microwave').
    Also fixed there: `erf, vendor = ...` inside the source-overlap loop rebound
    the scoping argument mid-function, silently unscoping every later query.

'PART ROW | {json}' TUNNELLED THROUGH THE LOG.  Each part was serialised to JSON,
    prefixed with literal text, pushed down the progress(str) channel and
    re-parsed by prefix in the GUI. Any description containing that prefix, any
    embedded newline, or any log line starting with 'SCRAPE |' corrupted it, and
    failures showed up only as a parse error in a text box. Replaced with a
    Reporter carrying real channels: log(str), part(dict), event(dict), cancel.
    selfcheck now FAILS if 'PART ROW' reappears in gui.py.

A FULL-TABLE AGGREGATE PER PART.  _upsert_part called _refresh_vendor_rows for
    every row, which destroyed and recreated every vendor widget and ran a GROUP
    BY over the whole parts table -- on the Tk thread, ~1000 times for one ADI
    import. Now a 1s timer that fires only when something changed, labels are
    reused rather than rebuilt, and auto-scroll only happens when you are already
    at the tail. The queue is bounded (4000) and drains 300/tick instead of 40;
    under pressure it drops progress TEXT, never parts or events.

NO WAY TO STOP A BUILD.  cancel_event was wired to the search path only. A Stop
    button now sets a threading.Event checked between requests in every walker,
    the datasheet downloader, the ADI reader and the local HTML ingest.

RESUME COULD SKIP 500 FILES FOREVER.  erf_space_ingest treated any checkpoint
    with >=50 entries as proof the source had finished. Interrupt a 586-file
    source after 60 and it marked the whole thing complete, so the remaining 526
    were skipped on every future run and their parts never appeared. It now
    counts the files actually present and only migrates when the checkpoint
    accounts for all of them; otherwise it reports "60/586 done, continuing".
    (I withdraw an earlier claim that checkpoints were written every 50 files --
    they are per file. The bug was the migration rule, which was worse.)

FOUND BY THE NEW PARSE INSPECTOR
--------------------------------
EVAL BOARDS WERE BEING STORED AS PARTS.  EVB-ADM-10699P sat next to the amplifier
    it evaluates. It has no RF performance of its own, so it polluted the pick
    list and every coverage percentage. Filtered, and the inspector shows the
    rejection with its reason.

ABSOLUTE MAXIMUM RATINGS WERE STORED AS OPERATING SPECS.  current_ma read 110 mA
    and supply_v read 6.0 V -- destruction limits. The Recommended Operating
    table says 54 mA and 3 V. Marki tables are now classified by their own HEADER
    ("maximum rating" / "nominal" / "typ") rather than by the prose above them,
    and abs-max values are kept under absmax_* keys so nothing is lost and
    nothing is confused. First attempt at this classified by prose and dropped
    every performance spec, which the inspector caught immediately.

NEW: THE PARSE INSPECTOR
------------------------
    python -m rfparts.parse_debug --list
    python -m rfparts.parse_debug "Data/vendor_cache/www.qorvo.com/ab12.html"
    python -m rfparts.parse_debug ADM-10699PSM_html.txt --vendor marki
    python -m rfparts.parse_debug --url "https://www.qorvo.com/products/product-list?categoryID=ca0021"
    python -m rfparts.parse_debug --all-cached --vendor qorvo --json report.json
GUI: "Parse inspector…" in the build window.

It answers what the build log cannot: which columns were recognised, which were
NOT (an unmapped column is the usual cause of a missing spec, not a broken number
parser), the raw cell text beside each parsed value and unit, and every rejected
row or link WITH ITS REASON. For a Marki datasheet page it also shows the
extracted text size, which spec sections were found, the pipe-table column
mapping, and the construction cues the space classifier will read.

WHAT IS NOT TESTED
------------------
No Tk and no network where this was built. The GUI is import- and AST-checked
(selfcheck verifies every class and method the queue dispatcher calls, and fails
on missing wiring) but never rendered. Live fetching is exercised against
simulated responses; parsers are verified against your two real Marki HTML files
and your real ADI spreadsheets. Start with:
    python -m rfparts.selfcheck
    python -m rfparts.cli ingest --vendors adi --adi-dir <your ADIParametrics>
    python -m rfparts.cli ingest --vendors qorvo --qorvo-ids 20
