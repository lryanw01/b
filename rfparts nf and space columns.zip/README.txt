rfparts — NF precedence, and the space portfolio's specs made visible
====================================================================
2 files. Drop into rfparts/.  Run: python -m rfparts.selfcheck


1. NF FIRST, THEN INSERTION LOSS, NO "(IL)" MARKER
--------------------------------------------------
Applied in two places so everything agrees:

  * the parts table now reads nf_db -> noise_nf_db -> insertion_loss_db ->
    conversion_loss_db and prints a bare number
  * partdb.query_candidates fills noise_nf_db from insertion (or conversion) loss
    when no measured NF exists, so the search grid's NF column, the ranking code
    and the coverage report all use one rule instead of each having a special case

Verified:
    amplifier  nf_db 2.1                          -> "2.1 dB"
    filter     insertion_loss_db 1.4              -> "1.4 dB"
    switch     nf_db 3.0 AND insertion_loss 0.8   -> "3.0 dB"   (measured wins)
    mixer      conversion_loss_db 7.5             -> "7.5 dB"
    amplifier  nothing                            -> ""
Candidates carry noise_nf_db_from so the provenance is still recoverable.


2. THE ATTACHED SPREADSHEET — WHY YOU ONLY SAW FREQUENCY
-------------------------------------------------------
I checked the file you attached against my copy: identical (same md5), so nothing
had changed there. The extraction was also fine. The problem was that the parts
table had NOWHERE TO PUT what the portfolio actually contains.

ADH913S parses to eight specs:
    freq_min 0.6, freq_max 20.0, package "12-Terminal Ceramic LCC",
    package_material Ceramic, lead_finish Gold, temp_min_c -55, temp_max_c 85,
    radiation_hardness No

The table's columns were Vendor, Part, Category, Subcategory, Frequency, Gain, NF,
P1dB, OIP3, Package, Space, Source. So of those eight, only frequency and package
had a home -- and the file has no gain/NF/P1dB/OIP3 at all, so four columns sat
empty. That is exactly "no specs other than frequency".

Added four columns: TID (kRad), SEL (MeV), Temp (°C) and Pkg material. Now:

    ADH913S   Frequency 0.6-20.0 GHz   Package 12-Terminal Ceramic LCC
              Temp -55 to 85           Pkg material Ceramic
    AD1671S   TID 100.0                Package 28-Lead Side-Brazed Ceramic
              Temp -55 to 125          Pkg material Ceramic/Metal

Temperature is shown as one cell ("-55 to 125") since the portfolio always gives
both ends.

Worth restating plainly, because it will not change: this spreadsheet has no gain,
NF, P1dB or OIP3 columns for any of its 233 parts. Its content is qualification
level, TID, SEL, TNID, operating temperature, package, package material, lead
finish and the datasheet URL. The RF numbers for its 39 genuine RF amplifiers come
from merging with the ADI parametric exports -- which you confirmed are working --
so both inputs need to be ingested for those parts to look complete.


NOT TESTED HERE
---------------
No Tk. The new columns and the NF cell are verified by executing _row_values and
query_candidates directly against your actual spreadsheet and a synthetic
filter/amplifier pair, not by eye.
