#!/usr/bin/env python3
r"""rfparts_debug.py -- huge read-only diagnostic sweep of the sourcing pipeline.

Place this file in the PROJECT ROOT (next to scan_minicircuits_snp.py and
debug_sources.py) and run it. It never edits project files, never writes to the
spec caches, and drives the *real* discover/extract code so what you see is what
the GUI/CLI actually produces.

What it does
------------
For every vendor x every (major) category it:
  * runs discover.candidates(vendor, query) and times it,
  * deep-extracts specs for up to --limit-per candidates via extract.extract_specs
    (with the Mini-Circuits background overlay applied, exactly like cli.py),
  * records, per part: assigned category, full specs, mount-type PROVENANCE
    (which field/regex made it connectorized/SMT/etc.), an ATTENUATION probe, a
    physical-DIMENSION probe, and manufacturer/MPN (for DigiKey de-dup analysis),
  * prints a LIVE running commentary to the terminal, and
  * writes two artifacts:
        rfparts_debug_log.txt    human-readable, truncated live log
        rfparts_debug_data.json  full structured data (send THIS back to Claude)

It also produces four focused analyses at the end:
  1. Spec-coverage table (how often each key spec is actually found, per category).
  2. Mini-Circuits connectorized deep-dive (why each MC part got its mount type).
  3. Attenuation diagnosis (attenuators: what the pipeline stored vs what the
     text/name/fields actually contain).
  4. DigiKey duplicate analysis (DigiKey parts whose manufacturer+MPN collide
     with a native-vendor part -- the ones that should be dropped).

Nothing here changes behavior; it only observes. Fixes come next.

Usage
-----
  python rfparts_debug.py                      # full sweep, sensible defaults
  python rfparts_debug.py --limit-per 15       # fewer deep extracts per cell
  python rfparts_debug.py --categories attenuator switch amplifier
  python rfparts_debug.py --vendors "Mini-Circuits" "Digi-Key"
  python rfparts_debug.py --no-deep            # discovery counts only (fast)
  python rfparts_debug.py --self-test          # offline sanity check, no network

Env that affects the real pipeline still applies (DIGIKEY_CLIENT_ID/SECRET to
exercise DigiKey; RFPARTS_PDF=0 to skip slow datasheet parsing; RFPARTS_HOME).
"""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import re
import sys
import time
import traceback
from collections import Counter, defaultdict

# --- make the rfparts package importable when run from the project root ----
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

try:
    from rfparts import cli, discover, extract, fetch, minicircuits_cache
    from rfparts.registry import load_vendors, synonyms
    import rfparts.registry as registry
    import rfparts.spec as specmod
except Exception as exc:  # noqa: BLE001
    print(f"could not import the rfparts package from {PROJECT_ROOT}: "
          f"{type(exc).__name__}: {exc}", file=sys.stderr)
    print("run this from the project root (next to scan_minicircuits_snp.py).",
          file=sys.stderr)
    sys.exit(2)


# The "major" categories to sweep by default (functional blocks, not every
# subcategory). Drawn from the GUI category model plus the ferrite parts that
# only some vendors carry.
DEFAULT_CATEGORIES = [
    "amplifier", "attenuator", "filter", "mixer", "coupler", "divider",
    "switch", "termination", "phase_shifter", "limiter",
    "isolator", "circulator", "cable", "connector",
]

# The key specs we care about per category, for the coverage table. These are
# the fields the ranker/report actually read.
COVERAGE_FIELDS = [
    "freq_ghz", "mount_type", "connector", "ports", "impedance_ohm",
    "price_usd", "lead_weeks", "attenuation_db", "gain_db", "noise_k",
    "nf_db", "p1db_dbm", "oip3_dbm", "isolation_db", "coupling_db",
    "conversion_loss_db", "power_w", "dimensions",  # dimensions: not yet stored
]


# =========================================================================
# tee logger: live to terminal + truncated human log file
# =========================================================================
class Tee:
    def __init__(self, log_path, max_line=2000):
        self.fh = open(log_path, "w", encoding="utf-8")
        self.max_line = max_line

    def __call__(self, msg=""):
        line = str(msg)
        # terminal (never let an encoding hiccup kill the run)
        try:
            print(line)
        except Exception:
            print(line.encode("ascii", "replace").decode("ascii"))
        # file, lightly truncated so a runaway blob can't bloat the log
        if len(line) > self.max_line:
            line = line[: self.max_line] + f" ...[+{len(line) - self.max_line} chars]"
        self.fh.write(line + "\n")
        self.fh.flush()

    def close(self):
        try:
            self.fh.close()
        except Exception:
            pass


def rule(sink, title, ch="="):
    sink("")
    sink(ch * 78)
    sink(title)
    sink(ch * 78)


def short(value, n=160):
    s = "" if value is None else str(value)
    s = re.sub(r"\s+", " ", s).strip()
    return s if len(s) <= n else s[:n] + "…"


# =========================================================================
# part-number normalization (shared by the DigiKey de-dup analysis)
# =========================================================================
def norm_mpn(value):
    """Loose part-number key: uppercase, drop spaces and most punctuation, but
    KEEP the trailing '+' (Mini-Circuits RoHS marker) and internal digits/letters.
    Good enough to catch 'ZX60-P33+' == 'zx60 p33 +' style collisions."""
    if value is None:
        return ""
    s = str(value).upper().strip()
    s = s.replace("+", "\u0001")            # protect the RoHS plus
    s = re.sub(r"[^A-Z0-9]", "", s)          # drop spaces, dashes, slashes, dots
    s = s.replace("\u0001", "+")
    return s


def mpn_from_title(title):
    """A part-number-shaped token (letters+digits) from a free-text title."""
    if not title:
        return ""
    best = ""
    for tok in re.findall(r"[A-Za-z0-9][A-Za-z0-9._/\-]*\+?", str(title)):
        has_a = any(c.isalpha() for c in tok)
        has_d = any(c.isdigit() for c in tok)
        if has_a and has_d and len(tok) >= 3:
            return tok
        if not best and (has_a or has_d):
            best = tok
    return best


# =========================================================================
# attenuation probe  (why isn't attenuation being parsed?)
# =========================================================================
# Candidate patterns for mining attenuation from a name/text/field. The current
# pipeline stores NONE of these (extract.ATTEN exists but is never called), so
# this probe shows what a fixed extractor *could* recover.
_ATT_PATTERNS = [
    ("labeled", re.compile(r"attenuat(?:ion|or)[^.\n\r]{0,25}?(\d{1,3}(?:\.\d+)?)\s*dB", re.I)),
    ("value_db_name", re.compile(r"\b(\d{1,3}(?:\.\d+)?)\s*dB\b", re.I)),
    ("model_suffix", re.compile(r"[-_](\d{1,3})(?:dB)?(?:[-_+]|$)", re.I)),
]


_ATT_RELEVANT = {"attenuator"}


def probe_attenuation(title, text, specs, category):
    """Return {stored, guesses:[(source, pattern, value)], best}. Non-destructive.

    Guessing is gated to attenuator-type categories: a bare 'N dB' or a '-NNN'
    model suffix is meaningful for a pad but is just noise for an amplifier
    (e.g. the '103' in 'PGA-103+'), so we don't mine it elsewhere.
    """
    relevant = category in _ATT_RELEVANT
    if not relevant:
        return {"stored_attenuation_db": specs.get("attenuation_db"),
                "guesses": [], "best_guess": None, "relevant": False}
    guesses = []
    for label, pat in _ATT_PATTERNS:
        for src_name, src in (("title", title), ("text", text)):
            if not src:
                continue
            m = pat.search(str(src))
            if m:
                try:
                    guesses.append({"source": src_name, "pattern": label,
                                    "value": float(m.group(1)),
                                    "matched": short(m.group(0), 40)})
                except (TypeError, ValueError):
                    pass
    # Prefer a labeled hit, else a bare 'N dB' in the title, else anything.
    best = None
    for pref in ("labeled", "value_db_name", "model_suffix"):
        for g in guesses:
            if g["pattern"] == pref:
                best = g
                break
        if best:
            break
    return {
        "stored_attenuation_db": specs.get("attenuation_db"),  # expect None today
        "guesses": guesses,
        "best_guess": best,
        "relevant": True,
    }


# =========================================================================
# physical-dimension probe  (LxWxH in inches/cm/mm)
# =========================================================================
_DIM_PATTERNS = [
    # L x W x H with a unit after EACH number: 0.75" x 0.4" x 0.4"
    ("LxWxH_each", re.compile(
        r"(\d+(?:\.\d+)?)\s*(?:in\b|inch|inches|\"|mm|cm)\s*[x\u00d7]\s*"
        r"(\d+(?:\.\d+)?)\s*(?:in\b|inch|inches|\"|mm|cm)\s*[x\u00d7]\s*"
        r"(\d+(?:\.\d+)?)\s*(in\b|inch|inches|\"|mm|cm)", re.I)),
    # L x W x H (three numbers) with a single trailing unit
    ("LxWxH", re.compile(
        r"(\d+(?:\.\d+)?)\s*[x\u00d7]\s*(\d+(?:\.\d+)?)\s*[x\u00d7]\s*"
        r"(\d+(?:\.\d+)?)\s*(in\b|inch|inches|\"|mm|cm)", re.I)),
    # L x W with a unit after each or once
    ("LxW_each", re.compile(
        r"(\d+(?:\.\d+)?)\s*(?:in\b|inch|inches|\"|mm|cm)\s*[x\u00d7]\s*"
        r"(\d+(?:\.\d+)?)\s*(in\b|inch|inches|\"|mm|cm)", re.I)),
    ("LxW", re.compile(
        r"(\d+(?:\.\d+)?)\s*[x\u00d7]\s*(\d+(?:\.\d+)?)\s*"
        r"(in\b|inch|inches|\"|mm|cm)", re.I)),
    # a single inch measurement like 0.5" or 1.25 in
    ("single_in", re.compile(r"(\d+(?:\.\d+)?)\s*(?:\"|inch|inches|in\b)", re.I)),
    # a single metric measurement
    ("single_metric", re.compile(r"(\d+(?:\.\d+)?)\s*(mm|cm)\b", re.I)),
]

# DigiKey / catalog field names that tend to carry sizes.
_DIM_FIELD_HINT = re.compile(r"size|dimension|length|width|height|depth|package.?/.?case", re.I)


def probe_dimensions(title, text, record):
    """Return {guesses:[...], field_hits:[...], best}. Non-destructive."""
    guesses = []
    for label, pat in _DIM_PATTERNS:
        for src_name, src in (("title", title), ("text", text)):
            if not src:
                continue
            m = pat.search(str(src))
            if m:
                guesses.append({"source": src_name, "pattern": label,
                                "matched": short(m.group(0), 50)})
                break  # one hit per pattern/source is enough for a probe

    # Look for dimension-ish fields in the raw catalog / api record.
    field_hits = []
    rec = record if isinstance(record, dict) else {}
    # flatten one level of a nested 'specs' object too
    flat = {}
    for k, v in rec.items():
        if isinstance(v, dict):
            for k2, v2 in v.items():
                if not isinstance(v2, (dict, list)):
                    flat[f"{k}.{k2}"] = v2
        elif not isinstance(v, list):
            flat[k] = v
    for k, v in flat.items():
        if _DIM_FIELD_HINT.search(str(k)) and v not in (None, "", "-"):
            field_hits.append({"field": k, "value": short(v, 60)})

    best = None
    for pref in ("LxWxH_each", "LxWxH", "LxW_each", "LxW", "single_in", "single_metric"):
        for g in guesses:
            if g["pattern"] == pref:
                best = g
                break
        if best:
            break
    return {"guesses": guesses, "field_hits": field_hits, "best_guess": best,
            "any": bool(guesses or field_hits)}


# =========================================================================
# mount-type provenance  (why did this become connectorized / smt / ...?)
# =========================================================================
def mount_provenance(candidate, final_specs):
    """Re-derive the mount signals to explain the final mount_type.

    Reads the same inputs the pipeline used (candidate['_specs'] from the catalog
    loader, and the candidate text blob) and runs extract.py's regexes so we can
    see WHICH signal drove the classification. Read-only.
    """
    text = candidate.get("text", "") or ""
    title = candidate.get("title", "") or ""
    blob = f"{title} {text}"
    catalog_specs = candidate.get("_specs") or {}

    def hit(pat):
        m = pat.search(blob)
        return short(m.group(0), 40) if m else None

    connector_tok = hit(extract.CONNECTOR)          # SMA / N-type / ... token
    connectorized = hit(extract.CONNECTORIZED)       # "connectorized"/"SMA input"
    smt = hit(extract.SMT)
    die = hit(extract.DIE)
    flange = hit(extract.FLANGE)

    catalog_mount = catalog_specs.get("mount_type")
    catalog_connector = catalog_specs.get("connector")
    final_mount = final_specs.get("mount_type")

    # Reconstruct the decision logic in extract._mount_type / catalog._mount_type.
    verdict = []
    if catalog_mount:
        verdict.append(f"catalog structured mount_type={catalog_mount!r}")
    if catalog_connector:
        verdict.append(f"catalog connector field={catalog_connector!r} "
                       f"(MOUNT_MAP may promote this to connectorized)")
    if final_mount == "connectorized":
        if connectorized:
            verdict.append(f"CONNECTORIZED regex fired on: {connectorized!r}")
        if connector_tok and not connectorized:
            verdict.append(f"connector TOKEN {connector_tok!r} in text -> "
                           f"_mount_type treated it as connectorized "
                           f"(likely FALSE positive for a module that merely "
                           f"*mentions* a connector option)")
    if final_mount == "smt" and not (smt or catalog_mount):
        verdict.append("defaulted to SMT (Mini-Circuits leftover-unknown rule)")

    return {
        "catalog_mount_type": catalog_mount,
        "catalog_connector": catalog_connector,
        "regex_connector_token": connector_tok,
        "regex_connectorized": connectorized,
        "regex_smt": smt,
        "regex_die": die,
        "regex_flange": flange,
        "final_mount_type": final_mount,
        "why": verdict or ["no explicit signal; see extract._mount_type default"],
    }


# =========================================================================
# per-candidate analysis
# =========================================================================
def analyze_candidate(candidate, category):
    """Deep-extract one candidate and return a rich record. Never raises."""
    rec = {"title": candidate.get("title"), "url": candidate.get("url"),
           "vendor": candidate.get("vendor"),
           "assigned_category": candidate.get("category")}
    try:
        specs = extract.extract_specs(candidate)
        # apply the same Mini-Circuits background overlay cli.py applies
        specs = cli._apply_background_specs(candidate, specs)
    except Exception as exc:  # noqa: BLE001
        rec["error"] = f"{type(exc).__name__}: {exc}"
        rec["traceback"] = short(traceback.format_exc(), 800)
        return rec

    if specs.get("_error"):
        rec["error"] = "extract reported _error (page/data unusable)"

    title = candidate.get("title", "") or ""
    text = candidate.get("text", "") or ""
    raw_record = candidate.get("_catalog_record") or candidate.get("_api_record")

    rec["specs"] = {k: v for k, v in specs.items() if not k.startswith("_")}
    rec["mount_provenance"] = mount_provenance(candidate, specs)
    rec["attenuation_probe"] = probe_attenuation(title, text, specs, category)
    rec["dimension_probe"] = probe_dimensions(title, text, raw_record)
    rec["manufacturer"] = specs.get("manufacturer")
    # MPN for de-dup: DigiKey stores manufacturer separately; else use a
    # part-number-shaped token from the title / catalog model.
    model = None
    if isinstance(raw_record, dict):
        for k in ("pn", "model", "model_name", "modelName", "part_number",
                  "partNumber", "sku"):
            if raw_record.get(k):
                model = str(raw_record[k])
                break
    rec["mpn"] = model or mpn_from_title(title)
    rec["mpn_norm"] = norm_mpn(rec["mpn"])
    return rec


# =========================================================================
# a vendor x category cell
# =========================================================================
def run_cell(vendor, category, args, sink):
    """Discover + (optionally) deep-extract one vendor/category cell."""
    ns = argparse.Namespace(category=category, freq=None, temp_k=None,
                            gain_db_min=None, noise_k_max=None,
                            attenuation_db=None, impedance=None, ports=None,
                            connector=None, mount=None, package=None, space=False,
                            max_lead_weeks=None, prefer=None, exclude=None,
                            other=None, subcategory=None, subcategory_terms=None)
    query = specmod.build(ns)

    cell = {"vendor": vendor["name"], "strategy": vendor.get("strategy", "sitemap"),
            "category": category, "candidates_found": 0, "deep_extracted": 0,
            "error": None, "parts": []}

    t0 = time.time()
    try:
        cands = discover.candidates(vendor, query) or []
    except Exception as exc:  # noqa: BLE001
        cell["error"] = f"discover raised {type(exc).__name__}: {exc}"
        sink(f"  [{vendor['name']} / {category}] ERROR discovering: {cell['error']}")
        return cell
    for c in cands:
        c["vendor"] = vendor["name"]
        c.setdefault("category", category)
    cell["candidates_found"] = len(cands)
    cell["discover_seconds"] = round(time.time() - t0, 2)

    sink(f"  [{vendor['name']} / {category}] {len(cands)} candidate(s) "
         f"in {cell['discover_seconds']}s"
         + ("" if cands else "  <-- nothing found"))

    if args.no_deep or not cands:
        return cell

    for i, c in enumerate(cands[: args.limit_per]):
        rec = analyze_candidate(c, category)
        cell["parts"].append(rec)
        cell["deep_extracted"] += 1

        s = rec.get("specs", {})
        mp = rec.get("mount_provenance", {})
        att = rec.get("attenuation_probe", {})
        dim = rec.get("dimension_probe", {})
        flags = []
        if rec.get("error"):
            flags.append(f"ERROR:{rec['error']}")
        if category == "attenuator" and att.get("stored_attenuation_db") is None:
            bg = att.get("best_guess")
            flags.append("atten NOT stored" + (
                f" (text suggests {bg['value']}dB via {bg['pattern']})" if bg else ""))
        if mp.get("final_mount_type") == "connectorized" and \
                mp.get("regex_connectorized") is None and \
                mp.get("regex_connector_token"):
            flags.append("MOUNT connectorized from bare connector token(!)")
        if dim.get("best_guess"):
            flags.append(f"dims~{dim['best_guess']['matched']}")

        sink(f"    [{i+1:>2}] {short(rec.get('title'), 62)}")
        sink(f"         cat={rec.get('assigned_category')} "
             f"mount={s.get('mount_type')} freq={s.get('freq_ghz')} "
             f"ports={s.get('ports')} price={s.get('price_usd')} "
             f"conn={s.get('connector')}")
        if flags:
            sink(f"         >> " + " | ".join(flags))
    return cell


# =========================================================================
# end-of-run analyses
# =========================================================================
def coverage_table(all_cells, sink):
    rule(sink, "SPEC COVERAGE by category (found / deep-extracted)")
    by_cat_field = defaultdict(lambda: defaultdict(int))
    by_cat_total = defaultdict(int)
    for cell in all_cells:
        cat = cell["category"]
        for part in cell["parts"]:
            if part.get("error"):
                continue
            by_cat_total[cat] += 1
            specs = part.get("specs", {})
            for f in COVERAGE_FIELDS:
                present = specs.get(f) is not None
                if f == "dimensions":
                    present = bool(part.get("dimension_probe", {}).get("any"))
                if present:
                    by_cat_field[cat][f] += 1
    hdr = "category".ljust(14) + "n".rjust(5) + "  " + "".join(
        f.replace("_", "")[:7].rjust(8) for f in COVERAGE_FIELDS)
    sink(hdr)
    sink("-" * len(hdr))
    for cat in sorted(by_cat_total):
        n = by_cat_total[cat]
        row = cat.ljust(14) + str(n).rjust(5) + "  "
        for f in COVERAGE_FIELDS:
            got = by_cat_field[cat][f]
            pct = f"{100*got//n}%" if n else "-"
            row += pct.rjust(8)
        sink(row)
    sink("")
    sink("Columns: " + ", ".join(COVERAGE_FIELDS))
    sink("NOTE: 'attenuationdb' and 'dimensions' are expected ~0% today -- the "
         "pipeline never stores them. That's the gap to fix next.")


def minicircuits_connectorized_deepdive(all_cells, sink):
    rule(sink, "MINI-CIRCUITS connectorized deep-dive (suspected mislabels)")
    rows = []
    for cell in all_cells:
        for part in cell["parts"]:
            if part.get("vendor") != "Mini-Circuits":
                continue
            mp = part.get("mount_provenance", {})
            if mp.get("final_mount_type") == "connectorized":
                rows.append((part, mp))
    if not rows:
        sink("  (no Mini-Circuits parts classified connectorized in this run)")
        return
    # SUSPECT = the connectorized verdict came from TEXT MINING (a connector token
    # or the CONNECTORIZED regex, which also matches eval-board phrases like
    # "SMA connectors"), not from a structured catalog interface field. Those are
    # the ones most likely to be true modules mislabeled connectorized.
    suspects = [r for r in rows if r[1].get("catalog_mount_type") != "connectorized"]
    sink(f"  {len(rows)} MC parts marked connectorized; "
         f"{len(suspects)} are SUSPECT (verdict came from text, not a structured "
         f"catalog interface field):")
    for part, mp in suspects[:60]:
        trigger = (f"CONNECTORIZED regex={mp.get('regex_connectorized')!r}"
                   if mp.get("regex_connectorized")
                   else f"connector token={mp.get('regex_connector_token')!r}")
        sink(f"    - {short(part.get('title'), 58)}")
        sink(f"        trigger: {trigger}"
             f" | catalog_connector={mp.get('catalog_connector')!r}"
             f" | smt_signal={mp.get('regex_smt')!r}")
    if len(suspects) > 60:
        sink(f"    ... +{len(suspects) - 60} more (see JSON)")


def attenuation_diagnosis(all_cells, sink):
    rule(sink, "ATTENUATION diagnosis (attenuators only)")
    total = stored = recoverable = 0
    examples = []
    for cell in all_cells:
        if cell["category"] != "attenuator":
            continue
        for part in cell["parts"]:
            if part.get("error"):
                continue
            att = part.get("attenuation_probe", {})
            total += 1
            if att.get("stored_attenuation_db") is not None:
                stored += 1
            elif att.get("best_guess"):
                recoverable += 1
                if len(examples) < 30:
                    examples.append((part, att["best_guess"]))
    sink(f"  attenuator parts examined: {total}")
    sink(f"  currently STORE an attenuation value: {stored}  "
         f"(expected 0 -- extract.ATTEN is defined but never called)")
    sink(f"  attenuation RECOVERABLE from name/text with a simple regex: {recoverable}")
    for part, bg in examples:
        sink(f"    - {short(part.get('title'), 58)} -> {bg['value']} dB "
             f"(via {bg['pattern']} on {bg['source']}: {bg['matched']})")


def digikey_dedup_analysis(all_cells, sink):
    rule(sink, "DIGI-KEY duplicate analysis (drop DK when a native vendor has it)")
    # native (non-DigiKey) parts, keyed by normalized MPN -> vendor(s)
    native = defaultdict(set)
    dk_parts = []
    for cell in all_cells:
        for part in cell["parts"]:
            if part.get("error"):
                continue
            v = part.get("vendor")
            key = part.get("mpn_norm")
            if not key:
                continue
            if v == "Digi-Key":
                dk_parts.append(part)
            else:
                native[key].add(v)

    collisions = []
    for part in dk_parts:
        key = part.get("mpn_norm")
        if key and key in native:
            collisions.append((part, sorted(native[key])))

    sink(f"  DigiKey parts examined: {len(dk_parts)}")
    sink(f"  DigiKey parts whose MPN also appears at a native vendor "
         f"(=> should be de-duped, keep native): {len(collisions)}")
    for part, vendors in collisions[:60]:
        mfr = part.get("manufacturer") or "?"
        sink(f"    - DK '{short(part.get('mpn'), 30)}' (mfr {short(mfr, 24)}) "
             f"== native vendor(s): {', '.join(vendors)}")
    if len(collisions) > 60:
        sink(f"    ... +{len(collisions) - 60} more (see JSON)")
    sink("")
    sink("  Planned rule (next turn): if a DigiKey candidate's manufacturer maps "
         "to a registry vendor AND its MPN matches that vendor's own listing, "
         "drop the DigiKey row and keep the native one.")


# =========================================================================
# self-test (offline): fabricate candidates so the analysis code is exercised
# =========================================================================
def self_test(sink):
    rule(sink, "SELF-TEST (offline, synthetic candidates -- no network/DB)")
    fake = [
        {  # MC module that merely *mentions* SMA (eval board) with NO surface-mount
           # text -> reproduces the false connectorized flip
            "vendor": "Mini-Circuits", "category": "amplifier",
            "title": "Mini-Circuits PGA-103+ Low Noise Amplifier",
            "url": "https://www.minicircuits.com/WebStore/dashboard.html?model=PGA-103%2B",
            "text": "PGA-103+ MMIC amplifier, DF782 case. Characterization done on a "
                    "test board with SMA connectors. 0.05 to 4 GHz.",
            "_catalog": True,
            "_specs": {"freq_ghz": [0.05, 4.0]},
            "_catalog_record": {"pn": "PGA-103+", "specs": {"case_style": "DF782"}},
        },
        {  # attenuator with attenuation only in the name (offline: catalog candidate)
            "vendor": "Pasternack", "category": "attenuator",
            "title": "PE7003-10 SMA Fixed Attenuator 10 dB DC-18 GHz",
            "url": "https://www.pasternack.com/pe7003-10-p.aspx",
            "text": "Fixed attenuator, 10 dB attenuation, DC to 18 GHz, SMA male/female, "
                    "2 Watts, 0.75\" x 0.4\" x 0.4\". VSWR 1.25:1.",
            "_catalog": True,
            "_specs": {},
        },
        {  # DigiKey duplicate of the Mini-Circuits part
            "vendor": "Digi-Key", "category": "amplifier",
            "title": "Mini-Circuits PGA-103+ — RF Amplifier IC 4GHz",
            "url": "https://www.digikey.com/en/products/detail/pga-103",
            "text": "manufacturer: Mini-Circuits mounting type: surface mount frequency: 4 ghz",
            "_catalog": True, "_api": True,
            "_specs": {"manufacturer": "Mini-Circuits", "mount_type": "smt",
                       "freq_ghz": [0.05, 4.0], "price_usd": 2.15},
            "_api_record": {"ManufacturerProductNumber": "PGA-103+"},
        },
    ]
    cells = []
    for cat in ("amplifier", "attenuator"):
        cell = {"vendor": "SELFTEST", "category": cat, "candidates_found": 0,
                "deep_extracted": 0, "error": None, "parts": []}
        for c in fake:
            if c["category"] != cat:
                continue
            cell["candidates_found"] += 1
            rec = analyze_candidate(c, cat)
            cell["parts"].append(rec)
            cell["deep_extracted"] += 1
            sink(f"  {c['vendor']:<14} {short(rec['title'], 50)}")
            sink(f"     final mount={rec['specs'].get('mount_type')} "
                 f"| atten stored={rec['attenuation_probe']['stored_attenuation_db']} "
                 f"guess={(rec['attenuation_probe']['best_guess'] or {}).get('value')} "
                 f"| dims={(rec['dimension_probe']['best_guess'] or {}).get('matched')}")
            sink(f"     mount why: {rec['mount_provenance']['why']}")
        cells.append(cell)
    coverage_table(cells, sink)
    minicircuits_connectorized_deepdive(cells, sink)
    attenuation_diagnosis(cells, sink)
    digikey_dedup_analysis(cells, sink)
    sink("")
    sink("SELF-TEST complete. If the three synthetic findings above look right "
         "(MC flagged as false-positive connectorized, attenuator recoverable "
         "10 dB + dims, DK PGA-103+ flagged as native duplicate), the probes work.")


# =========================================================================
# main
# =========================================================================
def main(argv=None):
    ap = argparse.ArgumentParser(description="Read-only rfparts pipeline diagnostics.")
    ap.add_argument("--categories", nargs="+", default=None,
                    help=f"categories to sweep (default: {' '.join(DEFAULT_CATEGORIES)})")
    ap.add_argument("--vendors", nargs="+", default=None,
                    help="restrict to these vendor names (default: all in registry)")
    ap.add_argument("--limit-per", type=int, default=20,
                    help="max candidates to deep-extract per vendor/category (default 20)")
    ap.add_argument("--no-deep", action="store_true",
                    help="discovery counts only; skip per-part extraction (fast)")
    ap.add_argument("--log", default="rfparts_debug_log.txt",
                    help="human-readable log path (default rfparts_debug_log.txt)")
    ap.add_argument("--json", default="rfparts_debug_data.json",
                    help="structured data path -- SEND THIS BACK (default rfparts_debug_data.json)")
    ap.add_argument("--self-test", action="store_true",
                    help="offline synthetic sanity check (no network, no DB)")
    args = ap.parse_args(argv)

    fetch.VERBOSE = True  # let the real fetch layer narrate too
    sink = Tee(args.log)
    fetch.LOG_SINK = sink  # route pipeline log lines into our tee

    rule(sink, "rfparts debug sweep")
    sink(f"project root : {PROJECT_ROOT}")
    sink(f"python       : {sys.version.split()[0]}")
    sink(f"RFPARTS_HOME : {os.environ.get('RFPARTS_HOME', '~/.rfparts')}")
    sink(f"DigiKey creds: {'set' if os.environ.get('DIGIKEY_CLIENT_ID') else 'NOT set (DK skipped)'}")
    sink(f"PDF parsing  : {'on' if os.environ.get('RFPARTS_PDF', '1') != '0' else 'off'}")
    try:
        minicircuits_cache.reload_if_changed(force=True)
        sink(f"MC snp cache : mtime_ns={minicircuits_cache.cache_mtime_ns()}")
    except Exception as exc:  # noqa: BLE001
        sink(f"MC snp cache : unavailable ({type(exc).__name__})")

    if args.self_test:
        self_test(sink)
        sink.close()
        fetch.LOG_SINK = None
        print(f"\nself-test log written to {args.log}")
        return 0

    categories = args.categories or DEFAULT_CATEGORIES
    all_vendors = load_vendors()
    if args.vendors:
        want = {v.lower() for v in args.vendors}
        vendors = [v for v in all_vendors if v["name"].lower() in want]
    else:
        vendors = all_vendors

    sink(f"categories   : {', '.join(categories)}")
    sink(f"vendors      : {', '.join(v['name'] for v in vendors)}")
    sink(f"limit-per    : {'(discovery only)' if args.no_deep else args.limit_per}")

    all_cells = []
    errors = []
    for category in categories:
        # which vendors even claim this category (mirrors vendors_for)
        elig = [v for v in vendors
                if "*" in v.get("categories", []) or category in v.get("categories", [])]
        rule(sink, f"CATEGORY: {category}  ({len(elig)} vendor(s) carry it)", ch="-")
        for vendor in elig:
            cell = run_cell(vendor, category, args, sink)
            all_cells.append(cell)
            if cell.get("error"):
                errors.append(f"{vendor['name']} / {category}: {cell['error']}")

    # -------- analyses --------
    if not args.no_deep:
        coverage_table(all_cells, sink)
        minicircuits_connectorized_deepdive(all_cells, sink)
        attenuation_diagnosis(all_cells, sink)
        digikey_dedup_analysis(all_cells, sink)

    rule(sink, "RUN SUMMARY")
    total_cands = sum(c["candidates_found"] for c in all_cells)
    total_deep = sum(c["deep_extracted"] for c in all_cells)
    empty = [c for c in all_cells if c["candidates_found"] == 0]
    sink(f"cells run          : {len(all_cells)}")
    sink(f"candidates found   : {total_cands}")
    sink(f"parts deep-extracted: {total_deep}")
    sink(f"empty cells        : {len(empty)}")
    if errors:
        sink(f"errors ({len(errors)}):")
        for e in errors:
            sink(f"  - {e}")
    else:
        sink("errors: none")

    # -------- structured artifact --------
    payload = {
        "meta": {
            "project_root": str(PROJECT_ROOT),
            "python": sys.version.split()[0],
            "categories": categories,
            "vendors": [v["name"] for v in vendors],
            "limit_per": args.limit_per, "no_deep": args.no_deep,
            "digikey_creds": bool(os.environ.get("DIGIKEY_CLIENT_ID")),
            "totals": {"cells": len(all_cells), "candidates": total_cands,
                       "deep": total_deep, "empty_cells": len(empty),
                       "errors": len(errors)},
        },
        "cells": all_cells,
        "errors": errors,
    }
    try:
        pathlib.Path(args.json).write_text(
            json.dumps(payload, indent=1, ensure_ascii=False, default=str),
            encoding="utf-8")
        sink(f"\nstructured data -> {args.json}  (send this file back to Claude)")
    except Exception as exc:  # noqa: BLE001
        sink(f"\ncould not write JSON artifact: {type(exc).__name__}: {exc}")

    sink.close()
    fetch.LOG_SINK = None
    print(f"\nlogs: {args.log} (human)  +  {args.json} (send this back)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
