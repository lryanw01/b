"""erf_probe2.py — clearer diagnosis + smoother saved-HTML ingest.

Two changes vs the original erf_probe.py:

  1. PROBE now reports the *reason* a fetch failed instead of a bare "nothing".
     It calls the site through the same polite fetch.get(), but also does a
     single diagnostic request so it can distinguish, on screen:
        - robots.txt disallow          (the tool voluntarily skipped it)
        - HTTP 4xx / Cloudflare 403     (the site refused the request)
        - Cloudflare challenge shell    (200, small body, challenge markers)
        - served-but-unparsed markup    (200, large body, parser needs updating)
        - genuinely working

  2. INGEST is unchanged in behaviour but adds a --watch-free recursive glob and
     a tiny per-file error guard so one bad file doesn't abort the batch.

It does NOT bypass anything. If the site gates automated requests, the answer is
still: save the listing pages from your browser (Ctrl-S) and ingest them here,
or ask everythingRF for authorized/partner data access.

Usage:
    python erf_probe2.py                     # diagnose the live site
    python erf_probe2.py <file-or-folder>    # ingest saved HTML into the database
"""
import pathlib
import sys

from rfparts import fetch
fetch.VERBOSE = True

from rfparts import erf, partdb
from rfparts.partdb import SpecRow

CF_MARKERS = ("cf-browser-verification", "cf_chl_", "checking your browser",
              "just a moment", "turnstile", "__cf_chl", "attention required")


def _diagnose_reason(url):
    """Return (reason, detail) without changing fetch.py's polite behaviour.

    We reuse fetch's own robots check, then do exactly one diagnostic GET so we
    can name the HTTP status. This is the same request fetch.get() would make;
    we're only surfacing what it currently swallows.
    """
    if not fetch.allowed(url):
        return "robots-disallow", "robots.txt disallows this path for our UA"
    try:
        fetch._polite(url)  # honour the same per-domain delay
        r = fetch.requests.get(url, headers=fetch.HEADERS, timeout=fetch.TIMEOUT)
    except fetch.requests.Timeout:
        return "timeout", f"no response within {fetch.TIMEOUT}s"
    except fetch.requests.RequestException as e:
        return "network", type(e).__name__
    body = r.text or ""
    low = body.lower()
    hits = [m for m in CF_MARKERS if m in low]
    if r.status_code >= 400:
        tag = "cloudflare/403" if (r.status_code == 403 and hits) else "http-error"
        return tag, f"HTTP {r.status_code} ({len(body):,} bytes)"
    if hits and len(body) < 30000:
        return "cf-challenge", f"HTTP 200 shell, markers={hits}, {len(body):,} bytes"
    return "served", f"HTTP {r.status_code}, {len(body):,} bytes"


def probe():
    url = erf.search_url("amplifier", 1, space_only=True)
    print(f"fetching: {url}\n")

    reason, detail = _diagnose_reason(url)
    print(f"diagnosis        : {reason}  ({detail})")

    body = fetch.get(url)
    cards = erf.parse_listing(body, url) if body else []
    pages = erf.page_count(body) if body else 0

    print(f"cached fetch.get : {'body returned' if body else 'None'}")
    print(f"product cards    : {len(cards)}")
    print(f"reported pages   : {pages}")
    if cards:
        c = cards[0]
        print(f"first card       : {c['mpn']} — {c['vendor']} "
              f"(space={c['space_application']}, {len(c['spec_rows'])} specs)")

    print()
    if cards:
        print(f"VERDICT: WORKING. ~{len(cards)} parts/page x {pages} pages. "
              "No action needed.")
    elif reason == "robots-disallow":
        print("VERDICT: robots.txt disallows this path. The tool is correctly "
              "skipping it. Use saved-HTML ingest, or ask the vendor for access.")
    elif reason in ("cloudflare/403", "http-error"):
        print("VERDICT: the site refused the request outright. Not a bug to fix "
              "in code — save the listing pages from your browser and ingest "
              "them:  python erf_probe2.py <folder>")
    elif reason == "cf-challenge":
        print("VERDICT: Cloudflare challenge shell. The site gates automated "
              "requests. Save the listing pages from your browser and ingest "
              "them:  python erf_probe2.py <folder>")
    elif reason == "served":
        print("VERDICT: page served but no cards parsed — the markup likely "
              "changed. Send this page's HTML so the parser can be updated.")
    else:
        print(f"VERDICT: {reason} — {detail}. Inspect manually.")


def ingest(target):
    """Parse saved .html files into the parts database."""
    p = pathlib.Path(target)
    if p.is_dir():
        files = sorted(set(p.rglob("*.htm")) | set(p.rglob("*.html")))
    else:
        files = [p]
    if not files:
        print(f"no .html files found in {p}")
        return
    total = 0
    for f in files:
        try:
            html = f.read_text(encoding="utf-8", errors="replace")
            items = erf.parse_listing(html, f"file://{f.name}")
        except Exception as e:  # one bad file shouldn't kill the batch
            print(f"  {f.name}: SKIPPED ({type(e).__name__}: {e})")
            continue
        n = 0
        for it in items:
            if not it["mpn"]:
                continue
            vendor = (f'{it["vendor"]} (everythingRF)' if it["vendor"]
                      else "everythingRF")
            part_id = partdb.upsert_part(
                mpn=it["mpn"], vendor=vendor, category="amplifier",
                product_url=it["url"],
                description=it["description"] or it["title"])
            if it["spec_rows"]:
                partdb.put_specs(part_id, it["spec_rows"])
            if it.get("vendor_url"):
                partdb.put_specs(part_id, [SpecRow(
                    key="vendor_url", value_text=it["vendor_url"],
                    method="aggregator", confidence=0.8, source_url=it["url"])])
            if it["space_application"]:
                partdb.put_specs(part_id, [SpecRow(
                    key="space", value_text="qualified", method="evidence",
                    confidence=0.85, source_url=it["url"],
                    snippet="everythingRF Industry Application includes Space")])
                partdb.put_evidence(part_id, [(
                    "erf-space-application", 8.0, it["url"],
                    "everythingRF Industry Application includes Space")])
            partdb.apply_satnow_crosslink(it["mpn"], it["url"])
            n += 1
        print(f"  {f.name}: {len(items)} cards -> {n} parts")
        total += n
    print(f"\ningested {total} parts into {partdb.DB_PATH}")
    print("They will appear in the next GUI search for that category.")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        ingest(sys.argv[1])
    else:
        probe()
