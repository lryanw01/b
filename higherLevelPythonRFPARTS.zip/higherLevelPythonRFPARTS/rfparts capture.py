
r"""rfparts_capture.py — capture ALL available specs from every data source.

Goal: dump the *complete* raw data each source exposes for a part (every catalog
field, every DigiKey parameter, live page/datasheet text) next to what the
pipeline currently mines — so the extractor can be rebuilt to catch everything.
It also encodes a space-qualification signal taxonomy and subcategory-naming
signals, so the logs answer three questions directly:

  1. Which parts are space-qualified / hi-rel / space-*qualifiable*.
  2. How to sort parts into the right subcategory (esp. Mini-Circuits model
     prefixes — e.g. HPA-... is a high-power amp, not an LNA).
  3. Every possible key spec per category (a field/parameter inventory).

Read-only: never edits project files or the spec caches. Drives the real
discover/extract code, so the raw records are exactly what the pipeline sees.
Uses the existing polite, robots-obeying, *cached* fetch path — re-running after
a normal GUI/CLI search reuses those caches and is much faster.

Output:
  rfparts_capture_log.txt    human-readable summary (live)
  rfparts_capture_data.json  FULL structured capture — send THIS back

Usage:
  python rfparts_capture.py                       # MC + DigiKey + Marki, all major cats
  RFPARTS_PDF=1 python rfparts_capture.py          # include datasheet text (slower, richer)
  python rfparts_capture.py --categories amplifier --subcategory lna
  python rfparts_capture.py --vendors "Mini-Circuits" --live-limit 80
  python rfparts_capture.py --skip-live            # MC + DigiKey only (fast, no page fetches)
  python rfparts_capture.py --space-probe          # also fetch a few space/hi-rel program pages
  python rfparts_capture.py --self-test            # offline sanity check
"""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import re
import sys
import time
import traceback
from collections import Counter, defaultdict

PROJECT_ROOT = pathlib.Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

try:
    from rfparts import cli, discover, extract, fetch, minicircuits_cache
    from rfparts import registry
    from rfparts.registry import load_vendors
    import rfparts.spec as specmod
    from rfparts.sources import digikey as dk
except Exception as exc:  # noqa: BLE001
    print(f"could not import the rfparts package from {PROJECT_ROOT}: "
          f"{type(exc).__name__}: {exc}", file=sys.stderr)
    sys.exit(2)


DEFAULT_CATEGORIES = [
    "amplifier", "attenuator", "filter", "mixer", "coupler", "divider",
    "switch", "termination", "phase_shifter", "limiter",
]
DEFAULT_VENDORS = ["Mini-Circuits", "Digi-Key", "Marki Microwave"]


# =========================================================================
# SPACE-QUALIFICATION taxonomy (from MIL-PRF-38534/38535/19500 + NASA levels)
# =========================================================================
# Space level (high confidence): Class K (38534 hybrids), Class V / QML-V and
# Class Y (38535 monolithic, incl. non-hermetic space), JANS (19500 discretes),
# and explicit "space level/grade/qualified/flight" / "Class S" wording.
SPACE_LEVEL = re.compile(
    r"\bclass\s*[kvy]\b|\bqml\s*-?\s*[vy]\b|\bqmlv\b|\bjans\b|\bjansr\b|"
    r"space[-\s]?(?:level|grade|qualified|qualification|flight|heritage|screen)|"
    r"flight[-\s]?(?:qualified|proven|heritage)|\bclass\s*s\b|\bs-?level\b|"
    r"mil-?prf-?19500|rad(?:iation)?[-\s]?hard(?:ened)?|\bqml-?v\b", re.I)
# Hi-rel / mil (capable, not necessarily space): Class H/G/Q, MIL-STD-883,
# JAN/JANTX/JANTXV, screening/burn-in/hermetic wording.
HIREL = re.compile(
    r"\bhi-?rel\b|high[-\s]reliability|mil-?prf-?3853[45]|mil-?std-?883|"
    r"mil-?prf-?55310|\bclass\s*[hgq]\b|\bqml\b|\bjantxv?\b|\bjan\b|"
    r"screen(?:ed|ing)|up-?screen(?:ed|ing)?|burn-?in|hermetic(?:ally)?|"
    r"\bqci\b|group\s*[abc]\b|rad(?:iation)?[-\s]?toleran|\bTID\b|\bSEE\b|"
    r"single[-\s]event", re.I)
# Construction hints that make a passive part space-*qualifiable* via up-screening.
CONSTRUCTION = re.compile(
    r"\bLTCC\b|ceramic|hermetic|core\s*&?\s*wire|multi-?layer|low[-\s]?temp"
    r"(?:erature)?\s+co-?fired", re.I)

# Vendors/manufacturers with a documented space/hi-rel up-screening program.
# Membership alone is a *low-confidence* "qualifiable" hint (they can up-screen
# catalog parts on request). Keep names normalized (lowercased, spaces kept).
SPACE_PROGRAM_VENDORS = {
    "mini-circuits", "micross", "criteria labs", "infineon", "ir hirel",
    "analog devices", "macom", "qorvo", "cobham", "teledyne e2v", "teledyne",
    "api technologies", "mercury systems", "ciao wireless", "narda-miteq",
    "custom mmic", "skyworks",
}

# Reference sources for space/hi-rel RF sourcing (printed; optionally probed).
SPACE_SOURCES = [
    ("Mini-Circuits — Space Upscreening", "https://www.minicircuits.com/ads/space-upscreening.html"),
    ("Mini-Circuits — Hi-Rel Screening", "https://www.minicircuits.com/ads/Hi-Rel_screening.html"),
    ("Mini-Circuits — AN00-018 Hi-Rel for Space", "https://www.minicircuits.com/appdoc/AN00-018.html"),
    ("Micross — Hi-Rel RF Solutions", "https://www.micross.com/components-and-services/hi-rel-rf-solutions"),
    ("Infineon / IR HiRel — MIL-PRF-38534", "https://www.infineon.com/cms/en/product/high-reliability/quality/mil-prf-38534/"),
    ("DLA Land & Maritime — QML-38534 (Class K = space)", "https://landandmaritimeapps.dla.mil/"),
]


def classify_space(vendor, text, mfr=""):
    """Return {tier, confidence, hits, construction, vendor_program}.

    tier ∈ {space, hi_rel, qualifiable, none}. Non-destructive; text-based.
    """
    blob = text or ""
    hits = []
    m = SPACE_LEVEL.search(blob)
    if m:
        hits.append(("space_level", m.group(0)))
    h = HIREL.search(blob)
    if h:
        hits.append(("hi_rel", h.group(0)))
    con = CONSTRUCTION.search(blob)
    construction = con.group(0) if con else None
    v = str(vendor or "").lower()
    mf = str(mfr or "").lower()
    in_program = any(p in v or p in mf for p in SPACE_PROGRAM_VENDORS)

    if m:
        tier, conf = "space", "high"
    elif h:
        tier, conf = "hi_rel", "medium"
    elif in_program and construction:
        tier, conf = "qualifiable", "low"      # passive ceramic part at an up-screening house
    elif in_program:
        tier, conf = "qualifiable", "very_low"  # vendor can up-screen on request
    else:
        tier, conf = "none", "none"
    return {"tier": tier, "confidence": conf,
            "hits": [f"{k}:{v}" for k, v in hits],
            "construction": construction, "vendor_program": in_program}


# =========================================================================
# SUBCATEGORY signals (Mini-Circuits model prefixes etc.)
# =========================================================================
def model_prefix(model):
    """Leading alpha prefix of a model number ('HPA-20M2G7025+' -> 'HPA')."""
    m = re.match(r"\s*([A-Za-z]{2,6})", str(model or ""))
    return m.group(1).upper() if m else ""


def subcat_signals(category, model, title, text):
    """What the part's naming/text says about its subcategory."""
    prefix = model_prefix(model)
    blob = f"{title} {text}".lower()
    matched = {}
    for key, _lbl, syns in registry.subcategories(category):
        hit = [s for s in syns if s.lower() in blob]
        if hit:
            matched[key] = hit
    return {"model": model, "model_prefix": prefix,
            "subcategory_terms_matched": matched}


# =========================================================================
# helpers
# =========================================================================
class Tee:
    def __init__(self, path, max_line=4000):
        self.fh = open(path, "w", encoding="utf-8")
        self.max_line = max_line

    def __call__(self, msg=""):
        line = str(msg)
        try:
            print(line)
        except Exception:
            print(line.encode("ascii", "replace").decode("ascii"))
        self.fh.write((line[: self.max_line] + " …[trunc]" if len(line) > self.max_line
                       else line) + "\n")
        self.fh.flush()

    def close(self):
        try:
            self.fh.close()
        except Exception:
            pass


def rule(sink, title, ch="="):
    sink("")
    sink(ch * 78)
    sink(title)
    sink(ch * 78)


def short(v, n=140):
    s = "" if v is None else str(v)
    s = re.sub(r"\s+", " ", s).strip()
    return s if len(s) <= n else s[:n] + "…"


def flatten(value, out, prefix=""):
    """Flatten a nested dict/list into {dotted_key: scalar}."""
    if isinstance(value, dict):
        for k, v in value.items():
            flatten(v, out, f"{prefix}.{k}" if prefix else str(k))
    elif isinstance(value, (list, tuple)):
        for i, v in enumerate(value):
            flatten(v, out, f"{prefix}[{i}]")
    elif isinstance(value, bool) or value is None:
        pass
    else:
        out[prefix] = value


def digikey_params(rec):
    """{ParameterText: ValueText} for a DigiKey api record."""
    out = {}
    if isinstance(rec, dict):
        for p in (dk._first(rec, "Parameters", "parameters", default=[]) or []):
            name = dk._param_text(p)
            if name:
                out[name] = dk._param_value(p)
    return out


def _looks_product(url):
    """False for listing/section/landing pages (so a catalog page isn't captured
    as if it were a single part)."""
    from rfparts import catalog
    from urllib.parse import urlparse as _up
    u = str(url or "")
    if discover.LISTING_HINT.search(_up(u).path.lower()):
        return False
    return catalog._is_product_url(u)


def _is_cached(url):
    """True if the page text for this URL is already in the fetch cache (so
    capturing it costs no network)."""
    try:
        body, hit = fetch._cached(str(url), fetch.TTL, binary=False)
        return bool(hit and body)
    except Exception:
        return False


# =========================================================================
# per-candidate capture
# =========================================================================
def capture_candidate(candidate, category):
    """Deep-extract one candidate and capture ALL available data. Never raises."""
    rec = {"vendor": candidate.get("vendor"), "category": category,
           "title": candidate.get("title"), "url": candidate.get("url"),
           "source_type": ("catalog" if candidate.get("_catalog") and not candidate.get("_api")
                           else "digikey_api" if candidate.get("_api")
                           else "live_page")}
    raw = candidate.get("_catalog_record") or candidate.get("_api_record")
    # Model / part number.
    model = ""
    if isinstance(raw, dict):
        for k in ("ManufacturerProductNumber", "ManufacturerPartNumber",
                  "pn", "model", "model_name", "modelName", "part_number",
                  "partNumber", "sku"):
            if raw.get(k):
                model = str(raw[k])
                break
    rec["model"] = model

    # Extract (mined) specs — this is what the pipeline currently gets.
    try:
        specs = extract.extract_specs(candidate)
        specs = cli._apply_background_specs(candidate, specs)
    except Exception as exc:  # noqa: BLE001
        rec["error"] = f"{type(exc).__name__}: {exc}"
        rec["traceback"] = short(traceback.format_exc(), 600)
        specs = {}
    rec["mined_specs"] = {k: v for k, v in specs.items() if not k.startswith("_")}
    if specs.get("_error"):
        rec["error"] = rec.get("error") or "extract reported _error"

    # RAW capture, per source type.
    text_blob = candidate.get("text", "") or ""
    if rec["source_type"] == "digikey_api":
        params = digikey_params(raw)
        rec["digikey_parameters"] = params           # <-- full param list
        rec["digikey_category"] = dk._digikey_category(raw)
        rec["all_fields"] = params
    elif rec["source_type"] == "catalog":
        flat = {}
        flatten(raw or {}, flat)
        rec["all_fields"] = {k: short(v, 80) for k, v in flat.items()}   # full flattened record
        rec["catalog_text_blob"] = short(text_blob, 1200)
    else:  # live page
        rec["page_text"] = short(text_blob, 4000)
        rec["all_fields"] = {}

    # Space + subcategory signals.
    space_text = " ".join(str(x) for x in (candidate.get("title", ""), text_blob,
                                           rec.get("all_fields", "")))
    rec["space"] = classify_space(rec["vendor"], space_text,
                                  mfr=specs.get("manufacturer", ""))
    rec["subcat_signals"] = subcat_signals(category, model, candidate.get("title", ""),
                                            text_blob)
    return rec


# =========================================================================
# cell + aggregation
# =========================================================================
def run_cell(vendor, category, args, sink):
    sub = getattr(args, "subcategory", None)
    sub_terms = registry.subcategory_terms(category, sub) if sub else None
    ns = argparse.Namespace(category=category, freq=None, temp_k=None,
                            gain_db_min=None, noise_k_max=None, attenuation_db=None,
                            impedance=None, ports=None, connector=None, mount=None,
                            package=None, space=False, max_lead_weeks=None,
                            prefer=None, exclude=None, other=None,
                            subcategory=sub, subcategory_terms=sub_terms)
    query = specmod.build(ns)

    strategy = vendor.get("strategy", "sitemap")
    offline = strategy in ("catalog", "api")   # no per-part network cost
    cell = {"vendor": vendor["name"], "strategy": strategy, "category": category,
            "subcategory": sub, "candidates_found": 0, "captured": 0,
            "skipped_non_product": 0, "skipped_live_over_limit": 0,
            "error": None, "parts": []}
    if args.skip_live and not offline:
        cell["error"] = "skipped (live vendor, --skip-live)"
        sink(f"  [{vendor['name']} / {category}] skipped (live)")
        return cell

    try:
        cands = discover.candidates(vendor, query) or []
    except Exception as exc:  # noqa: BLE001
        cell["error"] = f"discover raised {type(exc).__name__}: {exc}"
        sink(f"  [{vendor['name']} / {category}] ERROR: {cell['error']}")
        return cell
    for c in cands:
        c["vendor"] = vendor["name"]
        c.setdefault("category", category)
    cell["candidates_found"] = len(cands)

    new_fetches = 0
    for c in cands:
        # Don't treat a listing / section / landing page as a part.
        if not offline and not _looks_product(c.get("url")):
            cell["skipped_non_product"] += 1
            continue
        if offline:
            # Catalog (Mini-Circuits) is fully offline; the DigiKey API returned
            # its whole keyword page in one call. No reason to cap — capture all.
            pass
        else:
            cached = _is_cached(c.get("url"))
            if not cached:
                if new_fetches >= args.live_limit:
                    cell["skipped_live_over_limit"] += 1
                    continue
                new_fetches += 1
        pr = capture_candidate(c, category)
        if not offline:
            pr["from_cache"] = _is_cached(c.get("url"))
        cell["parts"].append(pr)
        cell["captured"] += 1

    extra = ""
    if cell["skipped_non_product"]:
        extra += f", {cell['skipped_non_product']} non-product skipped"
    if cell["skipped_live_over_limit"]:
        extra += f", {cell['skipped_live_over_limit']} live over --live-limit"
    sink(f"  [{vendor['name']} / {category}] {len(cands)} found -> "
         f"{cell['captured']} captured{' (offline, all)' if offline else ''}{extra}")
    return cell


def field_inventory(all_cells, sink):
    rule(sink, "FIELD / PARAMETER INVENTORY per vendor+category (all possible specs)")
    inv = defaultdict(lambda: defaultdict(lambda: {"n": 0, "example": None}))
    for c in all_cells:
        key = (c["vendor"], c["category"])
        for p in c["parts"]:
            for fname, val in (p.get("all_fields") or {}).items():
                slot = inv[key][fname]
                slot["n"] += 1
                if slot["example"] is None and val not in (None, "", "-"):
                    slot["example"] = short(val, 40)
    for (vendor, cat) in sorted(inv):
        fields = inv[(vendor, cat)]
        sink(f"  {vendor} / {cat}  ({len(fields)} distinct fields)")
        for fname in sorted(fields, key=lambda f: -fields[f]["n"]):
            s = fields[fname]
            sink(f"      {fname:<34} x{s['n']:<4} e.g. {s['example']!r}")
    return {f"{v}|{c}": {fn: fs for fn, fs in fields.items()}
            for (v, c), fields in inv.items()}


def prefix_histogram(all_cells, sink):
    rule(sink, "MODEL-PREFIX histogram (for subcategory classification)")
    by_cat = defaultdict(lambda: defaultdict(Counter))  # cat -> prefix -> subcat-terms Counter
    examples = defaultdict(lambda: defaultdict(list))
    for c in all_cells:
        if c["vendor"] != "Mini-Circuits":
            continue
        for p in c["parts"]:
            pre = p["subcat_signals"]["model_prefix"]
            if not pre:
                continue
            subs = tuple(p["subcat_signals"]["subcategory_terms_matched"]) or ("(none)",)
            by_cat[c["category"]][pre][subs] += 1
            if len(examples[c["category"]][pre]) < 3:
                examples[c["category"]][pre].append(p.get("model"))
    for cat in sorted(by_cat):
        sink(f"  {cat}:")
        for pre in sorted(by_cat[cat], key=lambda p: -sum(by_cat[cat][p].values())):
            total = sum(by_cat[cat][pre].values())
            ex = ", ".join(str(m) for m in examples[cat][pre])
            sink(f"      {pre:<7} x{total:<4} e.g. {ex}")
    sink("  >> Use this to build a Mini-Circuits prefix→subcategory map "
         "(e.g. HPA→high-power, PMA/PGA/PHA/GALI/ERA/AVA→MMIC gain, "
         "ZHL/ZVE/ZVA→coaxial power, LNA/PSA/ZX60→low-noise).")


def space_summary(all_cells, sink, args):
    rule(sink, "SPACE-QUALIFICATION capture")
    pdf_on = os.environ.get("RFPARTS_PDF", "1") != "0"
    sink(f"  RFPARTS_PDF: {'ON' if pdf_on else 'OFF'}  "
         f"({'datasheet text included' if pdf_on else 'datasheet text NOT parsed — most space wording is in datasheets!'})")
    tier = Counter()
    by_vendor = defaultdict(Counter)
    examples = defaultdict(list)
    for c in all_cells:
        for p in c["parts"]:
            t = p["space"]["tier"]
            tier[t] += 1
            by_vendor[p["vendor"]][t] += 1
            if t in ("space", "hi_rel") and len(examples[t]) < 20:
                examples[t].append((p.get("vendor"), p.get("model") or p.get("title"),
                                    p["space"]["hits"]))
    sink(f"  totals: space={tier['space']}  hi_rel={tier['hi_rel']}  "
         f"qualifiable={tier['qualifiable']}  none={tier['none']}")
    for v in sorted(by_vendor):
        cc = by_vendor[v]
        sink(f"    {v:<18} space={cc['space']} hi_rel={cc['hi_rel']} "
             f"qualifiable={cc['qualifiable']} none={cc['none']}")
    for t in ("space", "hi_rel"):
        if examples[t]:
            sink(f"  -- {t} examples --")
            for vend, name, hits in examples[t]:
                sink(f"    {vend:<16} {short(name, 34):<36} {hits}")
    sink("")
    sink("  Reference sources for space/hi-rel RF (manual follow-up; not auto-crawled):")
    for name, url in SPACE_SOURCES:
        sink(f"    - {name}: {url}")

    if args.space_probe:
        rule(sink, "SPACE-QUALIFICATION probe (fetching a few program pages, polite/cached)", ch="-")
        probed = {}
        for name, url in SPACE_SOURCES[:4]:
            try:
                html = fetch.get(url)  # robots-obeying + cached
                ok = bool(html)
                hint = "space-level wording present" if html and SPACE_LEVEL.search(html) else \
                       ("hi-rel wording present" if html and HIREL.search(html) else "no strong wording")
                sink(f"    {name}: {'reachable' if ok else 'unreachable'} — {hint}")
                probed[url] = {"reachable": ok, "hint": hint,
                               "excerpt": short(html, 300) if html else None}
            except Exception as exc:  # noqa: BLE001
                sink(f"    {name}: error {type(exc).__name__}")
                probed[url] = {"error": type(exc).__name__}
        return {"tally": dict(tier), "probed": probed}
    return {"tally": dict(tier)}


def amplifier_subcat_bleed(all_cells, sink):
    rule(sink, "AMPLIFIER subcategory bleed (why HPAs show in an LNA search)")
    HP_PREFIXES = ("HPA", "ZHL", "ZVE", "ZVA", "LZY", "ZX60W")
    rows = []
    for c in all_cells:
        if c["category"] != "amplifier":
            continue
        for p in c["parts"]:
            pre = p["subcat_signals"]["model_prefix"]
            blob = f"{p.get('title', '')} {p.get('catalog_text_blob', '')} " \
                   f"{p.get('page_text', '')}".lower()
            has_lna = "low noise" in blob or "low-noise" in blob
            looks_hp = ("high power" in blob or "high-power" in blob
                        or "power amplifier" in blob or pre in HP_PREFIXES)
            rows.append((p.get("vendor"), p.get("model"), pre, has_lna, looks_hp))
    # Leakers: high-power parts with NO explicit "low noise" wording — these slip
    # into an LNA search under a text-only filter.
    leak = [r for r in rows if r[4] and not r[3]]
    sink(f"  amplifier parts captured: {len(rows)}")
    sink(f"  high-power (by prefix/wording) with NO 'low noise' text: {len(leak)}  "
         f"(these evade a text-only LNA filter)")
    for vend, model, pre, _hl, _hp in leak[:25]:
        sink(f"    {vend:<15} {short(model, 24):<26} prefix={pre}")
    sink("  >> Fix direction: add a Mini-Circuits prefix→subcategory map so HPA-*, "
         "ZHL-*, ZVE-* etc. classify as high-power without relying on free-text.")


# =========================================================================
# self-test
# =========================================================================
def self_test(sink):
    rule(sink, "SELF-TEST (offline synthetic capture)")
    fakes = [
        {"vendor": "Mini-Circuits", "category": "amplifier",
         "title": "HPA-20M2G7025+ — amplifier",
         "url": "https://www.minicircuits.com/WebStore/dashboard.html?model=HPA-20M2G7025%2B",
         "text": "HPA-20M2G7025+ 2000-7000 MHz gain 25 dB", "_catalog": True,
         "_specs": {"freq_ghz": [2.0, 7.0], "gain_db": 25.0},
         "_catalog_record": {"pn": "HPA-20M2G7025+", "specs": {"gain": 25, "flo": 2000, "fhi": 7000}}},
        {"vendor": "Mini-Circuits", "category": "filter",
         "title": "LFCN-8400+ — filter",
         "url": "https://www.minicircuits.com/WebStore/dashboard.html?model=LFCN-8400%2B",
         "text": "LTCC low pass filter DC-8400 MHz, ceramic, available for space-level screening",
         "_catalog": True, "_specs": {"freq_ghz": [0, 8.4]},
         "_catalog_record": {"pn": "LFCN-8400+", "specs": {"fhi": 8400, "technology": "LTCC"}}},
        {"vendor": "Digi-Key", "category": "amplifier",
         "title": "Qorvo QPA9501 — RF Amp", "url": "https://www.digikey.com/x",
         "text": "", "_catalog": True, "_api": True,
         "_specs": {"manufacturer": "Qorvo"},
         "_api_record": {"ManufacturerProductNumber": "QPA9501", "Parameters": [
             {"ParameterText": "Gain (dB)", "ValueText": "30 dB"},
             {"ParameterText": "P1dB (dBm)", "ValueText": "40 dBm"},
             {"ParameterText": "Qualification", "ValueText": "Space, Class K"},
             {"ParameterText": "Size / Dimension", "ValueText": '0.180" L x 0.120" W'}]}},
    ]
    cells = [{"vendor": "SELFTEST", "category": cat, "candidates_found": 0,
              "captured": 0, "error": None, "parts": []}
             for cat in ("amplifier", "filter")]
    idx = {"amplifier": cells[0], "filter": cells[1]}
    for f in fakes:
        cell = idx[f["category"]]
        pr = capture_candidate(f, f["category"])
        cell["parts"].append(pr)
        cell["captured"] += 1
        sink(f"  {pr['vendor']:<14} {short(pr.get('model'), 22):<24} "
             f"space={pr['space']['tier']}({pr['space']['confidence']}) "
             f"prefix={pr['subcat_signals']['model_prefix']} "
             f"fields={list((pr.get('all_fields') or {}).keys())[:4]}")
    field_inventory(cells, sink)
    prefix_histogram(cells, sink)
    space_summary(cells, sink, argparse.Namespace(space_probe=False))
    amplifier_subcat_bleed(cells, sink)
    sink("\nSELF-TEST complete. Expect: HPA-20M2G7025+ prefix=HPA flagged as "
         "high-power-no-keyword; LFCN-8400+ qualifiable (LTCC); Qorvo QPA9501 "
         "space (Class K) with full DigiKey parameter capture.")


# =========================================================================
# main
# =========================================================================
def main(argv=None):
    ap = argparse.ArgumentParser(description="Capture ALL specs from every rfparts data source.")
    ap.add_argument("--categories", nargs="+", default=None)
    ap.add_argument("--vendors", nargs="+", default=None,
                    help=f"default: {', '.join(DEFAULT_VENDORS)}")
    ap.add_argument("--subcategory", default=None, help="e.g. lna, spdt, bpf")
    ap.add_argument("--live-limit", type=int, default=40,
                    help="max NEW (uncached) live page fetches per live vendor/category "
                         "(default 40). Catalog/API vendors are never capped; already-"
                         "cached live pages don't count against this.")
    ap.add_argument("--limit-per", type=int, default=None,
                    help="deprecated alias for --live-limit")
    ap.add_argument("--skip-live", action="store_true",
                    help="only catalog/api vendors (no live page fetches — fast)")
    ap.add_argument("--space-probe", action="store_true",
                    help="also fetch a few space/hi-rel program pages (polite, cached)")
    ap.add_argument("--log", default="rfparts_capture_log.txt")
    ap.add_argument("--json", default="rfparts_capture_data.json")
    ap.add_argument("--self-test", action="store_true")
    args = ap.parse_args(argv)
    if args.limit_per is not None:   # back-compat alias
        args.live_limit = args.limit_per

    fetch.VERBOSE = True
    sink = Tee(args.log)
    fetch.LOG_SINK = sink

    rule(sink, "rfparts CAPTURE (all specs)")
    sink(f"project root : {PROJECT_ROOT}")
    sink(f"RFPARTS_PDF  : {'on' if os.environ.get('RFPARTS_PDF', '1') != '0' else 'off'}")
    sink(f"DigiKey creds: {'set' if os.environ.get('DIGIKEY_CLIENT_ID') else 'NOT set'}")
    try:
        minicircuits_cache.reload_if_changed(force=True)
    except Exception:
        pass

    if args.self_test:
        self_test(sink)
        sink.close()
        fetch.LOG_SINK = None
        print(f"\nself-test log: {args.log}")
        return 0

    categories = args.categories or DEFAULT_CATEGORIES
    all_vendors = load_vendors()
    want = {v.lower() for v in (args.vendors or DEFAULT_VENDORS)}
    vendors = [v for v in all_vendors if v["name"].lower() in want] or all_vendors
    sink(f"categories : {', '.join(categories)}")
    sink(f"vendors    : {', '.join(v['name'] for v in vendors)}")
    sink(f"live-limit : {args.live_limit} (catalog/API uncapped)   skip-live={args.skip_live}")

    all_cells, errors = [], []
    for category in categories:
        elig = [v for v in vendors
                if "*" in v.get("categories", []) or category in v.get("categories", [])]
        rule(sink, f"CATEGORY: {category} ({len(elig)} vendor(s))", ch="-")
        for vendor in elig:
            cell = run_cell(vendor, category, args, sink)
            all_cells.append(cell)
            if cell.get("error") and "skipped" not in str(cell["error"]):
                errors.append(f"{vendor['name']}/{category}: {cell['error']}")

    inv = field_inventory(all_cells, sink)
    prefix_histogram(all_cells, sink)
    space = space_summary(all_cells, sink, args)
    amplifier_subcat_bleed(all_cells, sink)

    rule(sink, "SUMMARY")
    tot = sum(c["captured"] for c in all_cells)
    sink(f"cells: {len(all_cells)}   parts captured: {tot}   errors: {len(errors)}")
    for e in errors:
        sink(f"  - {e}")

    payload = {
        "meta": {"project_root": str(PROJECT_ROOT), "categories": categories,
                 "vendors": [v["name"] for v in vendors], "live_limit": args.live_limit,
                 "pdf": os.environ.get("RFPARTS_PDF", "1") != "0",
                 "digikey_creds": bool(os.environ.get("DIGIKEY_CLIENT_ID")),
                 "captured": tot, "errors": errors},
        "field_inventory": inv,
        "space": space,
        "cells": all_cells,
    }
    try:
        pathlib.Path(args.json).write_text(
            json.dumps(payload, indent=1, ensure_ascii=False, default=str), encoding="utf-8")
        sink(f"\nstructured capture -> {args.json}  (SEND THIS BACK)")
    except Exception as exc:  # noqa: BLE001
        sink(f"\ncould not write JSON: {type(exc).__name__}: {exc}")

    sink.close()
    fetch.LOG_SINK = None
    print(f"\nlogs: {args.log}  +  {args.json} (send this back)")
    return 0


if __name__ == "__main__":
    sys.exit(main())