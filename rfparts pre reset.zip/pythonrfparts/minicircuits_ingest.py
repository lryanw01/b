"""minicircuits_ingest.py — the offline Mini-Circuits catalogue JSON.

Reads ``Sources/minicircuits_products_full.json`` and writes parts to partdb.
This is the piece that was missing: ``catalog.py`` builds Mini-Circuits
candidates for a live search but contains no database call at all, and
``space_dataset`` never imports it, so nothing Mini-Circuits ever reached the
dataset from the catalogue side.

THE FIELD SHIFT
---------------
The JSON's spec keys do not line up with their values. From a real record:

    "specs": {"conn_2": "1.0mm", "f_low": "1.0mm", "f_high": "DC",
              "vswr": "110", "impedance": "1.07", ...}
    "flo": 1, "fhi": "DC", "vswr": 110, "impedance": 1.07

10F-10F+ is a 1.0 mm adapter, DC to 110 GHz, VSWR 1.07. Every field is one
position out: the connector lands in f_low, the low frequency lands in f_high,
the high frequency lands in vswr, and the VSWR lands in impedance. Trusting the
key names stores VSWR 110 and a 1.07 ohm impedance -- both impossible, and both
of a kind that quietly poisons filtering.

So values are assigned by WHAT THEY ARE, not by which key they arrived under:
a VSWR is between 1 and about 5, an impedance is 50 or 75, "DC" is zero hertz,
"1.0mm"/"SMA"/"N" are connectors. A value that fits nothing is dropped rather
than forced into a field. That also parses a correctly-keyed record unchanged,
so it keeps working if the export is ever fixed.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

try:
    from .partdb import SpecRow, upsert_part, put_specs, put_evidence
except ImportError:                                      # pragma: no cover
    from partdb import SpecRow, upsert_part, put_specs, put_evidence

# Bump when parsing changes so a rebuild re-reads an unchanged file once.
PARSER_VERSION = 1

DEFAULT_NAME = "minicircuits_products_full.json"

# Mini-Circuits category/group -> the registry's taxonomy. Anything unmapped
# keeps its own name rather than being forced into a neighbouring category:
# a wrong category is worse than an unfamiliar one, because it makes the part
# answer searches it should not.
_CATEGORY_MAP = {
    "adapter": "adapter", "adapters": "adapter",
    "amplifier": "amplifier", "amplifiers": "amplifier",
    "attenuator": "attenuator", "attenuators": "attenuator",
    "fixed attenuator": "attenuator", "variable attenuator": "attenuator",
    "filter": "filter", "filters": "filter",
    "lowpass": "filter", "highpass": "filter", "bandpass": "filter",
    "bandstop": "filter", "diplexer": "filter",
    "mixer": "mixer", "mixers": "mixer", "frequency mixer": "mixer",
    "switch": "switch", "switches": "switch",
    "coupler": "coupler", "couplers": "coupler",
    "directional coupler": "coupler",
    "splitter": "divider", "combiner": "divider",
    "power splitter": "divider", "power splitter/combiner": "divider",
    "splitter/combiner": "divider", "divider": "divider",
    "terminations": "termination", "termination": "termination",
    "dc block": "dc_block", "dc blocks": "dc_block",
    "bias tee": "bias_tee", "bias tees": "bias_tee",
    "limiter": "limiter", "limiters": "limiter",
    "phase shifter": "phase_shifter", "phase detector": "phase_detector",
    "transformer": "transformer", "transformers": "transformer",
    "cable": "cable", "cables": "cable",
    "oscillator": "oscillator", "vco": "oscillator",
    "frequency multiplier": "multiplier", "multiplier": "multiplier",
    "detector": "detector", "detectors": "detector",
    "i/q": "iq_mixer", "iq mixer": "iq_mixer",
    "equalizer": "equalizer", "antenna": "antenna",
}

_CONNECTOR_RE = re.compile(
    r"^\s*(\d+(?:\.\d+)?\s*mm|SMA|SMP|SSMA|N|TNC|BNC|QMA|MMCX|MCX|2\.92|"
    r"2\.4|1\.85|1\.0|K|V|W|7/16|Type\s*N)\b", re.I)
_CASE_RE = re.compile(r"^[A-Z]{1,3}\d{3,4}(?:-\d+)?$")
_NUM_RE = re.compile(r"[-+]?\d+(?:\.\d+)?")

# Above this a bare number is not GHz for an RF part, so it is megahertz. Same
# rule the ADI parametric reader uses, for the same reason.
_MAX_CREDIBLE_GHZ = 300.0


def _num(v):
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return float(v)
    m = _NUM_RE.search(str(v or ""))
    return float(m.group(0)) if m else None


def _freq_ghz(v):
    """A frequency value in GHz. 'DC' is zero, not missing."""
    s = str(v or "").strip()
    if not s:
        return None
    if re.fullmatch(r"(?i)dc", s):
        return 0.0
    n = _num(s)
    if n is None or n < 0:
        return None
    low = s.lower()
    if "ghz" in low:
        return n
    if "mhz" in low:
        return round(n / 1e3, 9)
    if "khz" in low:
        return round(n / 1e6, 9)
    # Bare number: Mini-Circuits quotes MHz for most of the catalogue, but a
    # millimetre-wave adapter really is 110 GHz. Decide on credibility.
    return n if n <= _MAX_CREDIBLE_GHZ else round(n / 1e3, 9)


def _looks_vswr(v):
    n = _num(v)
    return n is not None and 1.0 <= n <= 5.0


def _looks_impedance(v):
    n = _num(v)
    return n is not None and n in (50.0, 75.0, 93.0, 100.0)


def _looks_connector(v):
    s = str(v or "").strip()
    return bool(s) and bool(_CONNECTOR_RE.match(s))


def _looks_case(v):
    s = str(v or "").strip().split()[0] if str(v or "").strip() else ""
    return bool(_CASE_RE.match(s))


def classify_values(rec):
    """{spec key: value} assigned by what each value IS.

    Every candidate value in the record is pooled and then claimed by the field
    it can actually be, so a shifted export lands correctly and a correct one is
    unaffected.
    """
    specs = rec.get("specs") or {}
    pool = []
    for k in ("conn_1", "conn_2", "f_low", "f_high", "vswr", "impedance",
              "case_style", "conn", "connector"):
        if k in specs:
            pool.append(specs[k])
    for k in ("flo", "fhi", "vswr", "impedance", "case_style"):
        if k in rec:
            pool.append(rec[k])

    out = {}
    freqs, connectors, cases = [], [], []
    for v in pool:
        if v is None or str(v).strip() == "":
            continue
        s = str(v).strip()
        if _looks_connector(s):
            connectors.append(s)
            continue
        if _looks_case(s):
            cases.append(s.split()[0])
            continue
        if re.fullmatch(r"(?i)dc", s):
            freqs.append(0.0)
            continue
        n = _num(s)
        if n is None:
            continue
        if _looks_impedance(s) and "impedance" not in out:
            out["impedance_ohm"] = 50.0 if n in (50.0,) else n
            continue
        if _looks_vswr(s) and "vswr" not in out:
            out["vswr"] = round(n, 3)
            continue
        g = _freq_ghz(s)
        if g is not None:
            freqs.append(g)

    # Keys OUTSIDE the shifted block are unambiguous, so read them directly.
    # The shift affects the connector/frequency/vswr/impedance run; gain and
    # noise figure sit on their own keys and would otherwise be dropped.
    _DIRECT = {
        "gain": ("gain_db", "dB"), "gain_db": ("gain_db", "dB"),
        "nf": ("nf_db", "dB"), "noise_figure": ("nf_db", "dB"),
        "p1db": ("p1db_dbm", "dBm"), "p_1db": ("p1db_dbm", "dBm"),
        "ip3": ("oip3_dbm", "dBm"), "oip3": ("oip3_dbm", "dBm"),
        "iip3": ("iip3_dbm", "dBm"),
        "isolation": ("isolation_db", "dB"),
        "insertion_loss": ("insertion_loss_db", "dB"),
        "il": ("insertion_loss_db", "dB"),
        "attenuation": ("attenuation_db", "dB"),
        "coupling": ("coupling_db", "dB"),
        "conversion_loss": ("conversion_loss_db", "dB"),
        "lo_power": ("lo_power_dbm", "dBm"),
        "power": ("power_w", "W"), "power_handling": ("power_w", "W"),
        "directivity": ("directivity_db", "dB"),
        "return_loss": ("return_loss_db", "dB"),
        "supply_voltage": ("supply_v", "V"), "vcc": ("supply_v", "V"),
        "current": ("current_ma", "mA"),
        "phase_balance": ("phase_balance_deg", "deg"),
        "amplitude_balance": ("amplitude_balance_db", "dB"),
        "ways": ("ways", ""), "config": ("configuration", ""),
    }
    for k, v in specs.items():
        target = _DIRECT.get(str(k).strip().lower())
        if not target or v is None or str(v).strip() == "":
            continue
        key, _unit = target
        if key in out:
            continue
        n = _num(v)
        if n is not None:
            out[key] = round(n, 6)
        elif isinstance(v, str):
            out[key] = v.strip()[:60]

    if freqs:
        lo, hi = min(freqs), max(freqs)
        if hi > 0:
            out["freq_min"] = lo
            out["freq_max"] = hi
    if connectors:
        out["connector"] = connectors[0]
    if cases:
        out["package"] = cases[0]
    elif rec.get("case_style"):
        out["package"] = str(rec["case_style"]).split()[0]
    return out


def category_for(rec):
    for key in ("cat", "group", "category"):
        v = str(rec.get(key) or "").strip().lower()
        if not v:
            continue
        if v in _CATEGORY_MAP:
            return _CATEGORY_MAP[v]
        for word, cat in _CATEGORY_MAP.items():
            if word in v:
                return cat
    return str(rec.get("cat") or "").strip().lower() or ""


def load_records(path):
    """[(mpn, record)] from the catalogue JSON, whatever its outer shape."""
    raw = Path(path).read_text(encoding="utf-8", errors="replace")
    data = json.loads(raw)
    if isinstance(data, dict):
        for key in ("products", "parts", "items", "data", "rows"):
            if isinstance(data.get(key), list):
                data = data[key]
                break
        else:
            data = [v for v in data.values() if isinstance(v, dict)]
    if not isinstance(data, list):
        return []
    out = []
    for rec in data:
        if not isinstance(rec, dict):
            continue
        pn = str(rec.get("pn") or rec.get("model") or rec.get("part_number")
                 or "").strip()
        if pn:
            out.append((pn, rec))
    return out


def parse_file(path):
    """Records in the shape vendor_catalogs.write_records expects."""
    recs = []
    for pn, rec in load_records(path):
        specs = classify_values(rec)
        out = {
            "mpn": pn, "vendor": "Mini-Circuits",
            "category": category_for(rec),
            "subcategory": str(rec.get("group") or "").strip(),
            "description": str(rec.get("desc") or rec.get("description")
                               or rec.get("group") or "")[:200],
            "product_url": str(rec.get("url") or ""),
            "datasheet_url": str(rec.get("datasheet_url") or ""),
            "specs": {}, "source": "minicircuits:catalog-json",
        }
        for k, v in specs.items():
            unit = {"freq_min": "GHz", "freq_max": "GHz",
                    "impedance_ohm": "ohm"}.get(k, "")
            out["specs"][k] = (v, unit)
        if rec.get("sparams_url"):
            out["specs"]["sparams_url"] = (str(rec["sparams_url"])[:200], "")
        recs.append(out)
    return recs


def ingest(path, dry_run: bool = False, verbose: bool = False,
           progress=None) -> dict:
    """Adapter entry point, matching the other *_ingest modules."""
    emit = progress or (lambda m: None)
    path = Path(path)
    counts = {"parts": 0, "space_qualified": 0, "space_grade": 0,
              "with_specs": 0, "no_specs": 0}
    try:
        recs = parse_file(path)
    except Exception as e:
        emit(f"  ! could not read {path.name}: {type(e).__name__}: {e}")
        return counts
    emit(f"  {len(recs)} Mini-Circuits record(s) in {path.name}")
    if dry_run:
        for r in recs[:8]:
            emit(f"    {r['mpn']:<18} {r['category']:<12} {r['specs']}")
        counts["parts"] = len(recs)
        return counts
    for r in recs:
        rows = []
        s = r["specs"]
        lo = s.get("freq_min", (None, ""))[0]
        hi = s.get("freq_max", (None, ""))[0]
        if lo is not None and hi is not None:
            rows.append(SpecRow(key="freq_ghz", value_min=min(lo, hi),
                                value_max=max(lo, hi), unit="GHz",
                                method="catalog", confidence=0.85,
                                source_url=r["product_url"],
                                snippet="Mini-Circuits catalogue JSON"))
        for key, (val, unit) in s.items():
            if key in ("freq_min", "freq_max"):
                continue
            if isinstance(val, str):
                rows.append(SpecRow(key=key, value_text=val[:200], unit=unit,
                                    method="catalog", confidence=0.85,
                                    source_url=r["product_url"]))
            else:
                rows.append(SpecRow(key=key, value_typ=float(val), unit=unit,
                                    method="catalog", confidence=0.85,
                                    source_url=r["product_url"]))
        if r["datasheet_url"]:
            rows.append(SpecRow(key="datasheet_url", value_text=r["datasheet_url"],
                                method="catalog", confidence=0.9,
                                source_url=r["product_url"]))
        pid = upsert_part(mpn=r["mpn"], vendor=r["vendor"],
                          category=r["category"], subcategory=r["subcategory"],
                          product_url=r["product_url"],
                          description=r["description"])
        put_specs(pid, rows)
        put_evidence(pid, [("minicircuits-catalog", 2.0, r["product_url"],
                            "Mini-Circuits catalogue JSON")])
        counts["parts"] += 1
        counts["with_specs" if rows else "no_specs"] += 1
    emit(f"  Mini-Circuits: {counts['parts']} part(s), "
         f"{counts['with_specs']} with specs")
    return counts


def main(argv=None):                                     # pragma: no cover
    import argparse
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("path", nargs="?", default=None)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args(argv)
    p = Path(a.path) if a.path else Path("Sources") / DEFAULT_NAME
    print(ingest(p, dry_run=a.dry_run, progress=print))
    return 0


if __name__ == "__main__":                               # pragma: no cover
    raise SystemExit(main())
