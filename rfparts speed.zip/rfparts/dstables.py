"""dstables.py — header-anchored spec-table reader.

Used by dsmine as its primary source of table structure. Kept as its own module
because it is self-contained and was proven separately (dbg_formats.py) before
being wired in.

WHY NOT pdfplumber's extract_tables()
    It infers a table from ruling LINES. ADI rule some edges and not others, so
    it merges or drops columns -- ADRF5040's seven-column table came back as
    two, with Parameter and Symbol gone and Min/Typ/Max fused into one cell.
    Four of a common ADI family produced no tables at all. No settings fix that:
    the lines it needs are not on the page.

    This finds the HEADER ROW, takes the column boundaries from where its
    headings sit, and assigns every word below by x-overlap. The header is
    drawn on every one of these tables and its positions are exact, so the
    columns come from what the vendor laid out. pdfplumber supplies positioned
    words only.

WHAT IT RETURNS
    records() yields one Record per spec, with its condition, its per-row unit,
    and every value row it owns -- so a piecewise spec arrives as one answer in
    several pieces rather than as unrelated rows.
"""
from __future__ import annotations

import os
import re
from pathlib import Path

MAX_PAGES = 8

_HDR_WORDS = re.compile(
    r"^(parameter|symbol|min|min\.|minimum|typ|typ\.|typical|max|max\.|maximum|"
    r"unit|units|conditions?|comments?|test|frequency|freq\.?)$", re.I)
_VALUE_HDR = re.compile(r"^(min|typ|max)\.?$", re.I)
# "+-1" is a tolerance and a perfectly good value.
_NUM = re.compile(r"^[-+\u2212\u00b1<>~]?\s*\d+(?:\.\d+)?$")
_BAND = re.compile(
    r"^(DC|\d+(?:\.\d+)?)\s*(GHz|MHz|kHz)?\s*(?:-|\u2013|to)\s*"
    r"(\d+(?:\.\d+)?)\s*(GHz|MHz|kHz)?$", re.I)
_BAND_IN_TEXT = re.compile(
    r"(?:DC|\d+(?:\.\d+)?)\s*(?:GHz|MHz|kHz)?\s*(?:-|\u2013|to)\s*"
    r"\d+(?:\.\d+)?\s*(?:GHz|MHz|kHz)", re.I)
# A table ends. Without this the parser appended footnotes, the copyright block
# and the page footer, and their words landed in whichever column they sat
# under -- which is most of what looked like vendor text overflowing into
# value columns.
_END_OF_TABLE = re.compile(
    r"^\s*(?:\[\d+\]|\d+\s*Unless|Rev\.|Page\s+\d|Information\s+furnished|"
    r"One\s+Technology|P\.O\.\s*Box|Fax:|Phone:|www\.|\u00a9|Trademarks|"
    r"Specifications\s+subject|All\s+rights)", re.I)
_FREQ_SCALE = {"ghz": 1.0, "mhz": 1e-3, "khz": 1e-6, "hz": 1e-9}


def num(s):
    s = str(s or "").strip().replace("\u2212", "-").replace(",", "")
    if not _NUM.match(s):
        return None
    return float(re.sub(r"^[\u00b1<>~+]\s*", "", s) or 0)


def band_ghz(text, default_unit="GHz"):
    """(lo, hi) in GHz from 'DC - 2 GHz', '2 - 6' or '10 GHz to 18 GHz'."""
    m = _BAND.match(str(text or "").strip())
    if not m:
        return None
    lo_raw, lo_u, hi_raw, hi_u = m.groups()
    hi_unit = (hi_u or lo_u or default_unit).lower()
    lo_unit = (lo_u or hi_unit).lower()
    lo = (0.0 if lo_raw.upper() == "DC"
          else float(lo_raw) * _FREQ_SCALE.get(lo_unit, 1.0))
    hi = float(hi_raw) * _FREQ_SCALE.get(hi_unit, 1.0)
    if hi <= lo or hi > 500:
        return None
    return round(lo, 9), round(hi, 9)


_NUMBERED_NOTE = re.compile(r"^\s*\d+\.\s+\S")
_NEW_SECTION_HDR = re.compile(
    r"^(absolute\s+maximum|ordering\s+information|package|outline|"
    r"pin\s+(?:configuration|description))", re.I)


def _looks_like_footer(cells):
    joined = " ".join(c for c in cells if c.strip())
    if _END_OF_TABLE.match(joined) or _NEW_SECTION_HDR.match(joined):
        return True
    # A numbered footnote ("1. Unjacketed cable also available...") carries
    # digits and would otherwise pass the numeric test below; the leading
    # "N." is the tell, not the presence of a number.
    if _NUMBERED_NOTE.match(joined):
        return True
    words = joined.split()
    if not words:
        return False
    # Ordinary footnote prose starts lower-case and carries no numbers. A
    # section heading also has no numbers but is capitalised -- that is the
    # whole difference, and it holds across every vendor seen so far.
    numeric = any(num(w) is not None for w in words)
    if not numeric and len(words) >= 3 and words[0][:1].islower():
        return True
    return len(words) >= 10 and not numeric


def _group_lines(words, ytol=2.5):
    lines, cur, top = [], [], None
    for w in sorted(words, key=lambda w: (round(float(w["top"]), 1),
                                          float(w["x0"]))):
        y = float(w["top"])
        if top is None:
            cur, top = [w], y
        elif abs(y - top) <= ytol:
            cur.append(w)
        else:
            lines.append(cur)
            cur, top = [w], y
    if cur:
        lines.append(cur)
    return lines


def _header_columns(line, gap=6.0):
    hits = sum(1 for w in line if _HDR_WORDS.match(w["text"].strip(" :.")))
    if hits < 2 or not any(_VALUE_HDR.match(w["text"].strip(" .:"))
                           for w in line):
        return None
    heads, cur = [], None
    for w in sorted(line, key=lambda w: float(w["x0"])):
        if cur and float(w["x0"]) - cur["x1"] <= gap:
            cur["text"] += " " + w["text"]
            cur["x1"] = float(w["x1"])
        else:
            if cur:
                heads.append(cur)
            cur = {"text": w["text"], "x0": float(w["x0"]),
                   "x1": float(w["x1"])}
    if cur:
        heads.append(cur)
    if len(heads) < 3:
        return None
    out = []
    for i, h in enumerate(heads):
        left = -1e6 if i == 0 else (heads[i - 1]["x1"] + h["x0"]) / 2
        right = 1e6 if i == len(heads) - 1 else (h["x1"] + heads[i + 1]["x0"]) / 2
        out.append((left, right, h["text"]))
    return out


def _assign(line, bounds):
    cells = [""] * len(bounds)
    for w in sorted(line, key=lambda w: float(w["x0"])):
        mid = (float(w["x0"]) + float(w["x1"])) / 2
        for i, (lo, hi, _t) in enumerate(bounds):
            if lo <= mid < hi:
                cells[i] = (cells[i] + " " + w["text"]).strip()
                break
    return cells


# ============================================================ page reader
# One open per file, and PDFium rather than pdfminer.
#
# Measured on 10 real datasheets: pypdf text 385 ms/file, pypdfium2 32 ms/file
# -- 12x, because PDFium is Chromium's C++ engine and pdfminer is char-by-char
# Python. pdfplumber's extract_words cost ~760 ms for three pages on top of
# that, and the document was being opened and laid out THREE separate times
# (text, rows, tables). Opening costs 14 ms; the layout is the expense, so
# doing it once and handing out both text and words removes a third of the work
# before any engine change.
#
# pdfplumber remains the fallback. Its output is the reference the extraction
# was tuned against, so anything PDFium cannot read still takes the old path.
# PDFium is used for TEXT (12x faster, byte-equivalent output) but NOT for
# positional words: its grouping differs from pdfplumber's enough to change the
# recovered cells -- 111 records fell to 90 on the same files, and four spec
# extractions broke. pdfplumber's word output is what every positional reader
# here was tuned against, so it stays the source for geometry.
# RFPARTS_PDFIUM_WORDS=1 opts in for anyone who wants to re-validate it.
_USE_PDFIUM = os.environ.get("RFPARTS_PDFIUM_WORDS", "0").strip() != "0"


def _pdfium_pages(path, pages, x_tolerance=1.5):
    """[(text, [word, ...])] per page, from a single PDFium open.

    Words are assembled from character boxes: PDFium gives a box per char, and
    a word is a run between whitespace. Boxes are (x0, bottom, x1, top) in PDF
    space, which is bottom-up -- flipped here to the top-down convention the
    rest of the code uses, so a word dict is interchangeable with pdfplumber's.
    """
    try:
        import pypdfium2 as pdfium
    except ImportError:
        return None
    out = []
    doc = None
    try:
        doc = pdfium.PdfDocument(str(path))
        for i in range(min(pages, len(doc))):
            page = doc[i]
            height = float(page.get_size()[1])
            tp = page.get_textpage()
            text = tp.get_text_range() or ""
            words, cur, n = [], None, tp.count_chars()
            for ci in range(n):
                ch = text[ci] if ci < len(text) else " "
                if ch.isspace():
                    if cur:
                        words.append(cur)
                        cur = None
                    continue
                try:
                    x0, y0, x1, y1 = tp.get_charbox(ci)
                except Exception:
                    continue
                top, bottom = height - y1, height - y0
                if cur is not None and (x0 - cur["x1"]) > x_tolerance:
                    words.append(cur)          # a gap wider than the caller
                    cur = None                 # asked for ends the word
                if cur is None:
                    cur = {"text": ch, "x0": x0, "x1": x1,
                           "top": top, "bottom": bottom}
                else:
                    cur["text"] += ch
                    cur["x1"] = max(cur["x1"], x1)
                    cur["top"] = min(cur["top"], top)
                    cur["bottom"] = max(cur["bottom"], bottom)
            if cur:
                words.append(cur)
            out.append((text, words))
    except Exception:
        return None
    finally:
        if doc is not None:
            try:
                doc.close()
            except Exception:
                pass
    return out or None


def read_pages(path, pages=MAX_PAGES, x_tolerance=1.5, y_tolerance=2):
    """[(text, words)] per page -- PDFium first, pdfplumber as the fallback.

    The tolerances matter and are NOT one size fits all: dsmine's row reader
    was tuned against pdfplumber's DEFAULT word splitting, and handing it the
    tighter x_tolerance this module wants split words that it expects joined,
    which silently changed the cells and broke three spec extractions. Callers
    ask for the splitting they were tuned against.
    """
    if _USE_PDFIUM:
        got = _pdfium_pages(path, pages, x_tolerance)
        if got:
            return got
    try:
        import pdfplumber
    except ImportError:
        return []
    out = []
    try:
        with pdfplumber.open(str(path)) as pdf:
            for page in pdf.pages[:pages]:
                try:
                    words = page.extract_words(x_tolerance=x_tolerance,
                                               y_tolerance=y_tolerance,
                                               keep_blank_chars=False) or []
                except Exception:
                    words = []
                try:
                    text = page.extract_text() or ""
                except Exception:
                    text = ""
                out.append((text, words))
    except Exception:
        return []
    return out


def tables(path, pages=MAX_PAGES):
    """[(headings, rows)] for every header-anchored table in the file."""
    out = []
    try:
        for _text, words in read_pages(path, pages):
                bounds, rows = None, []
                if not words:
                    continue
                for line in _group_lines(words):
                    b = _header_columns(line)
                    if b:
                        if bounds and len(rows) >= 2:
                            out.append(([t for _l, _r, t in bounds], rows))
                        bounds, rows = b, []
                        continue
                    if not bounds:
                        continue
                    cells = _assign(line, bounds)
                    if not any(c.strip() for c in cells):
                        continue
                    if _looks_like_footer(cells):
                        if len(rows) >= 2:
                            out.append(([t for _l, _r, t in bounds], rows))
                        bounds, rows = None, []
                        continue
                    rows.append(cells)
                if bounds and len(rows) >= 2:
                    out.append(([t for _l, _r, t in bounds], rows))
    except Exception:
        pass
    return out


def col_roles(headings):
    """{role: column index}, read from the heading text."""
    roles = {}
    for i, h in enumerate(headings):
        s = h.strip().lower()
        if re.search(r"parameter|description|item", s):
            roles.setdefault("param", i)
        elif re.search(r"symbol", s):
            roles.setdefault("symbol", i)
        elif re.search(r"cond|comment|remark|note", s):
            roles.setdefault("cond", i)
        elif re.fullmatch(r"min\.?|minimum", s):
            roles.setdefault("min", i)
        elif re.fullmatch(r"typ\.?|typical", s):
            roles.setdefault("typ", i)
        elif re.fullmatch(r"max\.?|maximum", s):
            roles.setdefault("max", i)
        elif re.search(r"unit", s):
            roles.setdefault("unit", i)
        elif re.search(r"freq", s):
            # A FREQUENCY column is not a conditions column: the yellow style
            # has one and no Test Conditions column at all.
            roles.setdefault("freq", i)
    if "param" not in roles:
        roles["param"] = roles.get("symbol", 0)
    return roles


class Record(dict):
    """One spec: its name, its value rows, and the context they were taken in."""

    @property
    def name(self):
        return self.get("name", "")

    @property
    def rows(self):
        return self.get("rows", [])


def records(path, pages=MAX_PAGES):
    """[Record] across every spec table in the file.

    A Record carries:
        name       the parameter (and symbol, when the table has one)
        section    the heading above it, whose condition it inherits
        rows       [{min, typ, max, unit, cond, band_ghz}] -- one per value row
    """
    out = []
    for headings, rows in tables(path, pages):
        _by_start = {}
        roles = col_roles(headings)
        pcol = roles["param"]
        scol = roles.get("symbol")
        ccol = roles.get("cond", roles.get("freq"))
        ucol = roles.get("unit")
        vcols = [(k, roles[k]) for k in ("min", "typ", "max") if k in roles]
        if not vcols:
            continue

        def cell(ln, i):
            return ln[i].strip() if i is not None and i < len(ln) else ""

        def values(ln):
            return {k: num(cell(ln, i)) for k, i in vcols}

        # A named row with no values is a SECTION only when the rows beneath it
        # carry their own names. When they are unnamed value rows it is an
        # ordinary spec whose values sit on continuation lines -- treating it
        # as a section gave its bands away to the record above.
        def is_section(idx):
            for nxt in rows[idx + 1: idx + 6]:
                if any(num(cell(nxt, i)) is not None for _k, i in vcols):
                    return bool(cell(nxt, pcol))
            return True

        # An unnamed value row can belong to the record ABOVE or the record
        # BELOW: a merged parameter cell centres its text, so "DC - 2 GHz |
        # 0.34 | 0.53" sometimes precedes its own label rather than following
        # it. Deciding by "most recent name so far" assigned centred labels'
        # leading rows to whatever record happened to be open, which is why
        # 086-11SMR+'s first two insertion-loss bands landed under the
        # unrelated spec above them.
        #
        # Resolved the same way dbg_formats.py resolves it: nearest named row by
        # DISTANCE, ties going to the row below. A run of unnamed value rows is
        # bounded by named rows on each side, and the midpoint is where a
        # centred label's block boundary actually falls.
        named_idx = [i for i, ln in enumerate(rows) if cell(ln, pcol)]

        def owner(idx):
            """Which named row this unnamed value row belongs to.

            A label can sit ABOVE its block (the common case), in the middle of
            a merged cell (centred), or BELOW it -- and below beats nearest-by-
            distance whenever it applies. "Length2 | 11 | DC-2 | 0.34 | 0.53 |
            Insertion Loss | 2-6 | ..." puts the DC-2 row exactly one step from
            each neighbour; distance alone hands it to Length2 (an unrelated
            single-row spec) instead of Insertion Loss (the block it is
            actually part of). What decides it is whether the row immediately
            AFTER the block is a bare label with no value of its own -- that
            is the below-block pattern, and it wins outright when present.
            """
            if not named_idx:
                return None
            before = max((j for j in named_idx if j <= idx), default=None)
            after = min((j for j in named_idx if j > idx), default=None)
            if after is not None and not has_values(rows[after]):
                # 'after' is a bare label (no values of its own): it is this
                # block's name, however far below it sits.
                return after
            if before is None:
                return after
            if after is None:
                return before
            return before if idx - before < after - idx else after

        # ---- pass 1: classify every line -------------------------------
        kinds, band_at, sect_at = [], {}, {}
        section, sect_cond, band_ctx = "", "", ""
        for idx, ln in enumerate(rows):
            name = cell(ln, pcol)
            cond = cell(ln, ccol)
            has_val = any(v is not None for v in values(ln).values())
            joined = " ".join(c for c in ln if c.strip())
            if not has_val and not cond and _BAND_IN_TEXT.search(joined) \
                    and not name.strip().lower().startswith("frequency range"):
                band_ctx = _BAND_IN_TEXT.search(joined).group(0).strip()
                kinds.append("band")
            elif name and not has_val and is_section(idx):
                section, sect_cond = name, cond
                kinds.append("section")
            elif name:
                kinds.append("label")
            elif has_val:
                kinds.append("value")
            else:
                kinds.append("skip")
            band_at[idx] = band_ctx
            sect_at[idx] = (section, sect_cond)

        # ---- pass 2: every value line goes to its NEAREST label ---------
        # Not to the label above. A merged parameter cell CENTRES its text, so
        # a four-band block carries its name on row three and the two lines
        # above it are its own -- attaching them upward gave the previous
        # spec's record two bands that belong to this one. Ties resolve
        # downward, which is where a centred label in an even block sits.
        labels = [i for i, k in enumerate(kinds) if k == "label"]
        # A label whose OWN line already carries values is complete and does not
        # need continuation rows; one with an empty line is waiting for them.
        # Without this, "Length2 | 11 | inches" adopted the first band of the
        # Insertion Loss block below it purely by being one row closer.
        self_complete = {
            i: any(v is not None for v in values(rows[i]).values())
            for i in labels}
        owner = {}
        for idx, k in enumerate(kinds):
            if k not in ("label", "value"):
                continue
            if k == "label":
                owner[idx] = idx
                continue
            best, bd = None, None
            for j in labels:
                if sect_at[j][0] != sect_at[idx][0]:
                    continue        # never across a section boundary
                d = abs(j - idx) + (1 if self_complete.get(j) else 0)
                if bd is None or d < bd or (d == bd and j > best):
                    best, bd = j, d
            if best is not None:
                owner[idx] = best

        by_label = {}
        for idx in sorted(owner):
            root = owner[idx]
            rec = by_label.get(root)
            if rec is None:
                ln0 = rows[root]
                rec = Record(name=cell(ln0, pcol), symbol=cell(ln0, scol),
                             section=sect_at[root][0], rows=[])
                by_label[root] = rec
                out.append(rec)
            ln = rows[idx]
            vals = values(ln)
            if not any(v is not None for v in vals.values()):
                continue
            cond = cell(ln, ccol)
            band = band_ghz(cond) if cond else None
            if band is None:
                for _k, i in vcols:
                    b = band_ghz(cell(ln, i))
                    if b:
                        band = b
                        break
            if band is None and band_at[idx]:
                band = band_ghz(band_at[idx])
            rec["rows"].append({
                **vals,
                "unit": cell(ln, ucol),
                "cond": cond or sect_at[idx][1] or band_at[idx],
                "band_ghz": list(band) if band else None,
            })

    # A placeholder that never got a name takes the next record's name.
    for i, rec in enumerate(out):
        if not rec["name"] and i + 1 < len(out) and out[i + 1]["name"]:
            rec["name"] = out[i + 1]["name"]
    return [r for r in out if r["rows"]]
