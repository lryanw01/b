"""dbg_review.py — check parsed specs against the datasheet, one at a time.

    python dbg_review.py                      (sample across categories)
    python dbg_review.py --vendor MACOM --n 20
    python dbg_review.py --files a.pdf b.pdf
    python dbg_review.py --report              (summarise what you have logged)

For each datasheet it prints what the parser extracted, opens the file in your
PDF/HTML viewer, and waits. You type a verdict and any notes; it appends them to
a CSV and moves on. Ctrl+C stops and keeps everything logged so far.

    [1/20] MASW-011248.pdf  (MACOM / switch)
      freq_min            0.05    table-header
      insertion_loss_db   0.7     table-bands  [3 bands]
      isolation_db        43      table-header
      ...opening the file...

      verdict? [g]ood  [b]ad  [p]artial  [s]kip  [q]uit >

WHY THIS SHAPE
    Everything else in this toolkit tells you WHAT the parser did. Only reading
    the datasheet tells you whether it was RIGHT, and that judgement cannot be
    automated -- so the tool's job is to make the comparison fast and to
    remember the answer. Already-reviewed files are skipped on the next run, so
    the log accumulates instead of being redone.

    The log is the useful output: `--report` groups the failures by vendor,
    category and spec, which is what says where to look next.
"""
from __future__ import annotations

import argparse
import csv
import os
import random
import re
import subprocess
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))


def _opt(name):
    for pkg in ("rfparts", "pythonrfparts"):
        try:
            return __import__(f"{pkg}.{name}", fromlist=[name])
        except Exception:
            continue
    return None


dsmine = _opt("dsmine")
partdb = _opt("partdb")
if dsmine is None:
    sys.exit("Could not import dsmine. Run this from the folder holding "
             "rfparts/.")

LOG = Path(__file__).resolve().parent / "parse_review_log.csv"
FIELDS = ["file", "vendor", "category", "mpn", "verdict", "bad_specs", "notes",
          "n_specs", "specs"]
VERDICTS = {"g": "good", "b": "bad", "p": "partial", "s": "skipped"}


def loose(s):
    return re.sub(r"[^A-Z0-9]", "", str(s or "").upper())


def load_log():
    if not LOG.is_file():
        return {}
    out = {}
    try:
        with open(LOG, newline="", encoding="utf-8") as fh:
            for row in csv.DictReader(fh):
                out[row.get("file", "")] = row
    except Exception:
        pass
    return out


def append_log(row):
    new = not LOG.is_file()
    try:
        with open(LOG, "a", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=FIELDS)
            if new:
                w.writeheader()
            w.writerow({k: row.get(k, "") for k in FIELDS})
        return True
    except OSError as e:
        print(f"  ! could not write the log: {e}")
        return False


def part_table():
    out = {}
    if partdb is None:
        return out
    try:
        for r in partdb.db().execute(
                "SELECT mpn, vendor, category FROM parts"):
            out.setdefault(loose(r["mpn"]),
                           (r["mpn"], r["vendor"] or "?", r["category"] or ""))
    except Exception:
        pass
    return out


def library_files():
    files = []
    for root in dsmine.default_roots():
        try:
            for f in Path(root).rglob("*"):
                if f.is_file() and f.suffix.lower() in (".pdf", ".html",
                                                        ".htm"):
                    files.append(f)
        except OSError:
            continue
    return files


def open_file(path):
    """Hand the datasheet to whatever normally opens it."""
    try:
        if sys.platform.startswith("win"):
            os.startfile(str(path))                      # noqa: S606
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)],
                             stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
        return True
    except Exception as e:
        print(f"  (could not open it: {e} -- the path is above)")
        return False


def parse(path):
    """(specs, provenance) for one datasheet."""
    try:
        text = dsmine.datasheet_text(path)
    except Exception as e:
        return {}, {}, f"read failed: {type(e).__name__}"
    if not text.strip():
        return {}, {}, "no text extracted"
    try:
        mined = dsmine.mine_text(text, path=path, mpn=path.stem)
    except TypeError:
        mined = dsmine.mine_text(text)
    except Exception as e:
        return {}, {}, f"mine failed: {type(e).__name__}: {e}"
    prov = getattr(dsmine.mine_text, "provenance", {}) or {}
    return mined, prov, ""


def show(path, mined, prov, note, i, total, vendor, category):
    print("\n" + "=" * 74)
    print(f"  [{i}/{total}] {path.name}"
          + (f"   ({vendor} / {category})" if vendor else ""))
    print("=" * 74)
    print(f"  {path}")
    if note:
        print(f"  ! {note}")
    scalars = {k: v for k, v in mined.items()
               if not k.endswith("_bands") and k != "space_evidence"}
    if not scalars:
        print("  NOTHING PARSED")
    else:
        print(f"  {len(scalars)} spec(s):")
        for k in sorted(scalars):
            v = scalars[k][0] if isinstance(scalars[k], (tuple, list)) \
                else scalars[k]
            p = prov.get(k) or {}
            extra = ""
            if k + "_bands" in mined:
                extra = "  [piecewise]"
            elif p.get("subs"):
                extra = f"  [{len(p['subs'])} sub-specs]"
            print(f"    {k:<24}{str(v)[:14]:>14}   {p.get('method', '-')}"
                  f"{extra}")
            row = p.get("row")
            if row:
                print(f"      {str(row)[:66]}")


def ask():
    """(verdict, bad specs, notes) from the person, or None to quit."""
    while True:
        try:
            ans = input("\n  verdict? [g]ood [b]ad [p]artial [s]kip [q]uit > ")
        except EOFError:
            return None
        a = (ans or "").strip().lower()[:1]
        if a == "q":
            return None
        if a in VERDICTS:
            bad, notes = "", ""
            if a in ("b", "p"):
                bad = input("  which spec(s) are wrong? (comma separated) > ")
                notes = input("  what should they be / what went wrong? > ")
            elif a == "g":
                notes = input("  notes (enter to skip) > ")
            return VERDICTS[a], bad.strip(), notes.strip()
        print("  (g, b, p, s or q)")


def do_report():
    log = load_log()
    if not log:
        print(f"No log yet at {LOG}")
        return 0
    print(f"{LOG}\n{len(log)} datasheet(s) reviewed\n")
    verdicts = Counter(r.get("verdict", "") for r in log.values())
    for v, n in verdicts.most_common():
        print(f"  {v or '?':<10}{n:>5}")
    by_vendor = defaultdict(Counter)
    bad_specs = Counter()
    for r in log.values():
        by_vendor[r.get("vendor", "?")][r.get("verdict", "?")] += 1
        for s in (r.get("bad_specs") or "").split(","):
            s = s.strip()
            if s:
                bad_specs[s] += 1
    print(f"\n  {'vendor':<20}{'good':>6}{'partial':>9}{'bad':>6}")
    for v, c in sorted(by_vendor.items(),
                       key=lambda kv: -(kv[1]["bad"] + kv[1]["partial"])):
        print(f"  {v[:19]:<20}{c['good']:>6}{c['partial']:>9}{c['bad']:>6}")
    if bad_specs:
        print(f"\n  specs reported wrong most often")
        for s, n in bad_specs.most_common(15):
            print(f"    {n:>4}  {s}")
    notes = [(r.get("file", ""), r.get("notes", "")) for r in log.values()
             if (r.get("notes") or "").strip()]
    if notes:
        print(f"\n  notes ({len(notes)})")
        for f, n in notes[:25]:
            print(f"    {Path(f).name[:28]:<30}{n[:44]}")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--files", nargs="*", default=())
    ap.add_argument("--vendor", default=None)
    ap.add_argument("--category", default=None)
    ap.add_argument("--n", type=int, default=15,
                    help="how many to queue up (default 15)")
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--redo", action="store_true",
                    help="include files already in the log")
    ap.add_argument("--no-open", action="store_true",
                    help="do not launch the viewer")
    ap.add_argument("--report", action="store_true")
    args = ap.parse_args(argv)

    if args.report:
        return do_report()
    if args.seed is not None:
        random.seed(args.seed)

    log = load_log()
    parts = part_table()
    if args.files:
        queue = [Path(f) for f in args.files if Path(f).is_file()]
    else:
        pool = []
        for f in library_files():
            rec = parts.get(loose(f.stem))
            vendor = rec[1] if rec else ""
            cat = rec[2] if rec else ""
            if args.vendor and args.vendor.lower() not in vendor.lower():
                continue
            if args.category and args.category.lower() != cat.lower():
                continue
            if not args.redo and str(f) in log:
                continue
            pool.append(f)
        # Spread across categories so one enormous vendor folder does not fill
        # the queue with twenty of the same kind of part.
        buckets = defaultdict(list)
        for f in pool:
            rec = parts.get(loose(f.stem))
            buckets[rec[2] if rec else ""].append(f)
        queue, keys = [], sorted(buckets)
        while len(queue) < args.n and any(buckets[k] for k in keys):
            for k in keys:
                if buckets[k] and len(queue) < args.n:
                    queue.append(buckets[k].pop(
                        random.randrange(len(buckets[k]))))
    if not queue:
        print("Nothing to review. --redo to revisit logged files.")
        return 0

    print(f"{len(queue)} datasheet(s) queued.  log: {LOG}")
    print("Ctrl+C at any point stops and keeps what you have logged.")
    done = 0
    try:
        for i, path in enumerate(queue, 1):
            rec = parts.get(loose(path.stem))
            mpn, vendor, cat = rec if rec else (path.stem, "", "")
            mined, prov, note = parse(path)
            show(path, mined, prov, note, i, len(queue), vendor, cat)
            if not args.no_open:
                print("\n  ...opening the file...")
                open_file(path)
            ans = ask()
            if ans is None:
                print("\n  stopping.")
                break
            verdict, bad, notes = ans
            scalars = {k: (v[0] if isinstance(v, (tuple, list)) else v)
                       for k, v in mined.items()
                       if not k.endswith("_bands") and k != "space_evidence"}
            append_log({"file": str(path), "vendor": vendor, "category": cat,
                        "mpn": mpn, "verdict": verdict, "bad_specs": bad,
                        "notes": notes, "n_specs": len(scalars),
                        "specs": "; ".join(f"{k}={v}" for k, v in
                                           sorted(scalars.items()))[:600]})
            done += 1
    except KeyboardInterrupt:
        print("\n\n  interrupted.")
    print(f"\n  {done} reviewed this run. Log: {LOG}")
    print("  python dbg_review.py --report   to summarise what it says")
    return 0


if __name__ == "__main__":
    sys.exit(main())
