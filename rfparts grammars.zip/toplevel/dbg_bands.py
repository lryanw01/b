"""dbg_bands.py — how a datasheet's specs vary across frequency.

    python dbg_bands.py                       (the tuning set, if it is nearby)
    python dbg_bands.py FILE [FILE ...]
    python dbg_bands.py --dir "C:\\...\\uploads"
    python dbg_bands.py FILE --rows           (also dump the raw table rows)

Most RF specs are not one number. A cable's insertion loss is 0.34 dB to 2 GHz
and 1.22 dB to 18 GHz; a switch's isolation is 45 dB to 2 GHz and 40 dB to
3.5 GHz. This shows the PIECEWISE reading -- every band, with min/typ/max and
the row it came from -- next to the single headline value the dataset stores.

The headline is the WORST band, not the first: a filter asking for 0.5 dB loss
must not be satisfied by a part that only achieves it at the bottom of its
range.

Read-only. Nothing is written.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))


def _opt(name):
    # The package folder is `rfparts` on this install; `pythonrfparts` on
    # others. Try both rather than assume.
    for pkg in ("rfparts", "pythonrfparts"):
        try:
            return __import__(f"{pkg}.{name}", fromlist=[name])
        except Exception:
            continue
    return None


dsmine = _opt("dsmine")
if dsmine is None:
    sys.exit("Could not import dsmine. Run this from the folder that holds the "
             "package directory (rfparts/).")

TUNING_NAMES = ("086-11SMR", "SXBP-1430", "HMC284A", "ADMV8502", "SMA88",
                "MAAP-011341")


def find_tuning_set(explicit=None):
    roots = [Path(explicit)] if explicit else []
    here = Path(__file__).resolve().parent
    roots += [here, here / "uploads", Path.home() / "Downloads",
              Path("/mnt/user-data/uploads")]
    found = []
    for r in roots:
        if not r.is_dir():
            continue
        for f in r.iterdir():
            if not f.is_file() or f.suffix.lower() not in (".pdf", ".html",
                                                           ".htm"):
                continue
            if any(n.lower() in f.stem.lower() for n in TUNING_NAMES):
                found.append(f)
        if found:
            break
    return sorted(set(found))


def fmt(v):
    return "-" if v is None else f"{v:g}"


def report(path, show_rows=False):
    print("\n" + "=" * 78)
    print(f"  {path.name}")
    print("=" * 78)
    kind = dsmine._sniff(path)
    text = dsmine.datasheet_text(path)
    print(f"  {kind}, {len(text):,} chars")
    if kind == "corrupt" or not text.strip():
        print("  ! nothing readable")
        return
    try:
        rows = dsmine.rows_for(path)
    except Exception as e:
        print(f"  ! rows_for failed: {type(e).__name__}: {e}")
        rows = []
    print(f"  {len(rows)} table row(s)")

    if show_rows:
        print("\n  raw rows carrying numbers:")
        for i, (_p, cells) in enumerate(rows):
            s = " | ".join(str(c)[:18] for c in cells[:8])
            if any(ch.isdigit() for ch in s) and len(cells) >= 3:
                print(f"    [{i:>3}] {s[:104]}")

    segs = {}
    if rows and hasattr(dsmine, "band_segments"):
        try:
            segs = dsmine.band_segments(rows)
        except Exception as e:
            print(f"  ! band_segments failed: {type(e).__name__}: {e}")

    if segs:
        print(f"\n  PIECEWISE -- specs that vary with frequency")
        print(f"    {'spec':<22}{'band (GHz)':<18}{'min':>7}{'typ':>7}"
              f"{'max':>7}  condition")
        print("    " + "-" * 72)
        for key in sorted(segs):
            band_list = segs[key]
            kindw = next((d for a, _b, _c, d in dsmine.SPEC_ROWS if a == key),
                         "max")
            worst = dsmine.worst_of(band_list, kindw)
            for n, s in enumerate(band_list):
                lo, hi = s["band_ghz"]
                label = key if n == 0 else ""
                print(f"    {label:<22}{f'{lo:g} - {hi:g}':<18}"
                      f"{fmt(s['min']):>7}{fmt(s['typ']):>7}{fmt(s['max']):>7}"
                      f"  {(s.get('sub') or '')[:26]}")
            print(f"    {'':<22}{'-> stored (worst ' + kindw + ')':<18}"
                  f"{fmt(worst):>7}")
    else:
        print("\n  no piecewise bands found "
              "(single-value specs only, or the table did not parse)")

    try:
        mined = dsmine.mine_text(text, path=path, mpn=path.stem)
    except TypeError:
        mined = dsmine.mine_text(text)
    prov = getattr(dsmine.mine_text, "provenance", {}) or {}
    scalars = {k: v for k, v in mined.items()
               if not k.endswith("_bands") and k != "space_evidence"}
    print(f"\n  STORED VALUES ({len(scalars)})")
    print(f"    {'spec':<24}{'value':>12}  from")
    print("    " + "-" * 60)
    for k in sorted(scalars):
        v = scalars[k][0]
        method = (prov.get(k) or {}).get("method", "-")
        extra = ""
        if k + "_bands" in mined:
            try:
                extra = f"  [{len(json.loads(mined[k + '_bands'][0]))} bands]"
            except Exception:
                extra = "  [bands]"
        print(f"    {k:<24}{str(v)[:12]:>12}  {method}{extra}")


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("files", nargs="*")
    ap.add_argument("--dir", default=None,
                    help="folder holding the tuning datasheets")
    ap.add_argument("--rows", action="store_true",
                    help="also dump the raw table rows")
    args = ap.parse_args(argv)

    paths = [Path(f) for f in args.files if Path(f).is_file()]
    if not paths:
        paths = find_tuning_set(args.dir)
        if paths:
            print(f"tuning set: {len(paths)} file(s) in {paths[0].parent}")
    if not paths:
        print("Nothing to parse. Pass files, or --dir with the folder holding "
              "them.")
        return 1
    for p in paths:
        report(p, args.rows)

    print("""
  What to look for
    - every band of a piecewise spec present, with the right numbers
    - the stored value equal to the WORST band, not the first
    - a 'condition' that names a port (RF1 & RF2) or a sub-spec (Low-Side IP3)
      is a separate series, not another band of the same one -- if those are
      mixed together the label assignment needs tightening""")
    return 0


if __name__ == "__main__":
    sys.exit(main())
