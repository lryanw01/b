rfparts — parse sample bundle (+ the seven earlier items)
========================================================
12 files: 2 new, 10 modified. Drop into rfparts/.
Run first:  python -m rfparts.selfcheck


THE BUNDLE YOU CAN SEND ME
--------------------------
GUI :  Rebuild dataset…  ->  "Parse sample bundle (for sharing)"  ->  Create
       (also "Export parse bundle…" in the build window while a build is running)
CLI :  python -m rfparts.cli samples --offline
       python -m rfparts.cli samples --vendors qorvo marki --per-vendor 3

Writes ONE zip (default Data/parse_debug/) with a folder per vendor:

    README.txt / environment.txt
    Qorvo/
        01_product-list_ca0021.html          the exact bytes we parsed
        01_..._parsed.txt / .json            the parse report
        parts.json                           the dicts the pipeline emits
    Marki-Microwave/
        01_..._amplifiers_.html              a listing page
        part_ADM-10699PSM.html               one part's own page, where the
        part_ADM-10699PSM_parsed.txt         specs actually live
    Analog-Devices-parametric/
        01_..._Mixers_excerpt.csv            header + units + a few data rows
    everythingRF/
        01_page_001.html + parsed report

Choices that matter, given you want to send this back to me:

  * A couple of part numbers per vendor, not a full walk. --per-vendor changes it.
  * Cached pages are reused and "cached pages only (no network)" is ON by default,
    so a bundle normally costs ZERO requests. Anything that could not be sampled
    is listed in environment.txt WITH THE REASON rather than silently missing.
  * Spreadsheets are excerpted with the part-number column as its RAW FORMULA.
    That column is =HYPERLINK("url","PN"); read with data_only=True it comes back
    blank. That was a real bug on this project, and now you can SEE it in the
    sample rather than having to describe it.
  * The reports name the columns that were IGNORED, put each parsed value beside
    the source cell it came from, label whether a value came from a sheet column
    or the description fallback, and list rejected rows with reasons.
  * Nothing is written to the database — it is a read-and-report pass.

Typical size: ~35 kB with 5 vendor folders. Send it as-is.


ONE THING I CLEANED UP WHILE DOING THIS
---------------------------------------
I had left two implementations of this feature in the tree: an earlier
parse_bundle.py with its own GUI button, and the tested parse_sample.py. gui.py
still imported the first one. Consolidated to parse_sample only, the old button
now points at it, and selfcheck fails if an import of parse_bundle ever reappears.
Also, selfcheck's dangling-name scan caught `sys` being used in gui.py's
"Open containing folder" handler without being imported — the same class of fault
as the part_cb crash, caught before it shipped this time.


ALSO INCLUDED (the seven items from last round)
-----------------------------------------------
 1. everythingRF re-parsing without a reset. The checkpoint name is a hash of the
    source path, so C:\Users\... and c:\users\... — the same folder — hashed
    differently and forced a fresh parse every run. Normalised with
    os.path.normcase; three spellings now collapse to one checkpoint. The resume
    decision is printed too, so a recurrence explains itself in one line.
 2. Parse inspector by vendor: dropdown with counts, sources grouped.
 3. Parse inspector includes local files: everythingRF HTML and both ADI workbook
    types, with mapped-vs-ignored columns for spreadsheets.
 4. ADI parts with no specs: their export has the literal string 'None' in every
    parametric column for ~15% of rows while the description still says
    "1GHz to 22GHz, 15W". Recovered from the description where the sheet gave
    nothing, never overwriting a real value. 158 -> 42 parts without RF specs.
 5. "Current database by vendor" is scrollable; wheel bound only over the panel.
 6. Space classification by source. classify_file() sent EVERY .xlsx to the legacy
    adi adapter, which stamps space_variant on every row — so the whole parametric
    catalogue read as space qualified. Now routed three ways, and
    adi_parametric_ingest refuses to write space keys at all.
    Nine parametric mixers legitimately DO carry space_variant (ADH1015S,
    ADH1048AS … note the S suffix): they appear in both files, taking RF specs
    from the parametric export and qualification from the space portfolio.
 7. Insertion loss counts as NF for passives — for a passive lossy network at
    ambient they are the same number. partdb.PASSIVE_CATEGORIES + effective_nf();
    rank accepts insertion_loss_db for an nf_db requirement; the table shows
    "1.4 (IL)" so it is never mistaken for a measured NF.


NOT TESTED HERE
---------------
No Tk, so the new dialog section, the result window and the scrollable panel are
verified by AST checks and by pack/format logic, not by eye. selfcheck now asserts
RebuildDialog._make_sample_bundle, SampleBundleWindow and
BuildProgressWindow._export_parse_bundle all exist, so the wiring cannot be
quietly removed by a later patch.
