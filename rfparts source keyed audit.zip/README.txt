rfparts — audit grouped by SOURCE, plus the Qorvo and resume fixes
=================================================================
7 files: 1 new (nospec_audit.py), 6 modified. Drop into rfparts/.
Run first:  python -m rfparts.selfcheck


THE AUDIT IS NOW SOURCE-KEYED, NOT VENDOR-KEYED
-----------------------------------------------
    ADI Parametrics
    ADI space qualified product list
    MACOM
    Marki
    EverythingRF
    Qorvo
    Skyworks
    Mini-Circuits

This matters more than it sounds. "Analog Devices" covers two completely
different inputs with different columns and different expectations, so a
per-vendor sample of three could pick three parametric parts and never look at
the space-qualified list at all. On your data the split is:

    ADI Parametrics                      557 parts with gaps
    ADI space qualified product list      171
    Qorvo                                  76
    EverythingRF                           72
    Marki                                  63

The group is derived from what the part was actually read from -- the evidence
signal written at ingest (adi-parametric-export, adi-space-portfolio-*,
erf-space-*), then the walker tag on vendor-catalog rows (qorvo:, macom:, marki:,
skyworks:), then the product URL host as a last resort. Not from the vendor field.

Zip layout follows:
    ADI-Parametrics/AD8131/{source_*.txt, parsed.txt, verdict.txt}
    ADI-space-qualified-product-list/ADH913S/verdict.txt
    EverythingRF/RRM9397800-59A/{source_02_page_002.html, parsed.txt, verdict.txt}
    Marki/adm-0026-5929sm/verdict.txt
    summary.txt   gaps by source, by source+spec+verdict, and per source FILE
    findings.csv  now leads with source_group so you can pivot on it

    GUI :  "Audit missing specs…" in the main window
    CLI :  python -m rfparts.cli audit --per-source 3
           python -m rfparts.cli audit --sources "ADI space" --per-source 5
           python -m rfparts.cli audit --category amplifier --missing nf_db
(--vendors and --per-vendor still work as aliases.)


TWO MORE FALSE-POSITIVE CLASSES REMOVED WHILE DOING THIS
--------------------------------------------------------
Both would have sent you chasing parser bugs that do not exist:

  * Spreadsheet evidence was read from the WHOLE workbook, so AD8131's "missing
    frequency" was evidenced by AD8350's row two lines away. Now scoped to that
    part's own rows.
  * Those rows included the HEADER, so a column named "Frequency Response min"
    made every part look like it stated a frequency even when its own cell said
    'None'. The saved excerpt keeps the header for context; the evidence search
    does not read it.

After both, AD8131 correctly reports NOT IN SOURCE for all nine missing specs --
its row really is empty. Across all six sources: 34 NOT IN SOURCE, 0 PARSER GAP,
6 NO SOURCE.


ALSO IN THIS ZIP (unchanged from the last round, still verified)
---------------------------------------------------------------
QORVO CATEGORIES. Every part was "ic". Section titles are
    <h3 class="pst-header-title">Digital Step Attenuators
        <span class="pst-header-amount">(21)</span></h3>
-- the count is in a nested span, so my [^<] run stopped short and nothing
matched. Now keyed on class="pst-header-title".
    ca0021  was ic x106  ->  attenuator 47, limiter 15, phase_shifter 13
    ca0118  was ic x106  ->  amplifier, filter 18, switch 4, transceiver 6,
                             power 7, + 66 genuine ICs

EVERYTHINGRF RESUME. The per-file signature included st_mtime_ns, so copying or
syncing the Sources tree invalidated every checkpoint despite identical bytes.
Now size + a hash of the first and last 8 kB, with legacy checkpoints migrated on
size match. And a run that was stopped or hit page errors no longer writes
source_complete=True -- that was worse than re-parsing, because it made every
later run skip the remainder for good. Each run ends with:
    RESUME SUMMARY | N file(s) in source, X skipped by resume, Y parsed,
                     source_complete=True/False

EVERYTHINGRF OUTPUT POWER IN WATTS. The audit found this on its first run:
everythingRF quotes "Output Power: 3.16 W", so we stored power_w only -- correct,
but filters, ranking and coverage all speak dBm, so the value was invisible.
psat_dbm is now derived (3.16 W -> 35 dBm, 20 W -> 43 dBm). Re-audited after the
fix: 16 parser gaps -> 0.


NOT TESTED HERE
---------------
No Tk. The main-window button is verified by AST assertion
(App.audit_missing_specs) and by driving build_audit directly, not by eye.
