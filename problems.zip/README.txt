Datasheets flagged by dbg_vendor_matrix.py.

Folders are the problem class:
  NO-SPECS   text extracted, zero specs found
  THIN       almost no text extracted
  FEW-SPECS  fewer specs than expected
  CONFLICT   specs disagree with the catalogue
  CORRUPT    no readable text at all

MANIFEST.csv lists every flagged part, including any whose file was left out
to stay under the size cap.
