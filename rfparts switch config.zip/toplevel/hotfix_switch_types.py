"""hotfix_switch_types.py — backfill absorptive/reflective and throw config.

WHAT IT DOES
    Reads every switch already in the database and fills in two things the
    parsers now capture but earlier runs did not:

      subcategory   absorptive | reflective   (the CONSTRUCTION type)
      throw_config  SPST | SPDT | SP4T | ...  (the throw count)

    It reads only text the vendor already published -- the part's description,
    title, existing subcategory, and any local datasheet -- and never invents a
    value. Nothing is overwritten unless you ask: a part that already has a
    throw_config keeps it, and an existing subcategory is only replaced when it
    is one of the old throw-style values (spdt, sp4t...) that has moved to its own
    field.

WHY A SEPARATE SCRIPT
    A rebuild re-reads the sources; this re-reads the DATABASE. There is no need
    to re-scrape anything to recover facts that are already sitting in the
    description text, and re-scraping six vendors to fix a labelling gap would be
    disproportionate.

USAGE
    python hotfix_switch_types.py                 # dry run, shows what it would do
    python hotfix_switch_types.py --apply         # write the changes
    python hotfix_switch_types.py --apply --all-categories
    python hotfix_switch_types.py --apply --force-subcategory

    Run it from the folder that holds pythonrfparts/ (or anywhere, if
    RFPARTS_HOME points at your Data directory).
"""
from __future__ import annotations

import argparse
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

try:
    from pythonrfparts import partdb, specmatch
    from pythonrfparts.partdb import SpecRow
except Exception as e:                                  # pragma: no cover
    sys.exit(f"Could not import the package: {e}\n"
             "Run this from the folder that contains pythonrfparts/.")

try:
    from pythonrfparts import dsmine
except Exception:
    dsmine = None

# The old subcategory values that were really throw counts. These are the only
# ones this script will replace, because they have moved to throw_config -- a
# subcategory a human deliberately set to something else is left alone.
_LEGACY_THROW_SUBCATS = {
    "spst", "spdt", "sp3t", "sp4t", "sp5t", "sp6t", "sp8t", "sp10t", "sp12t",
    "sp16t", "dpdt", "dp3t", "dp4t", "4p4t", "transfer", "",
}
_VALID_TYPES = ("absorptive", "reflective")


def _switch_rows(conn, all_categories=False):
    if all_categories:
        sql = ("SELECT id, mpn, vendor, category, subcategory, description "
               "FROM parts WHERE lower(category) LIKE '%switch%' "
               "   OR lower(subcategory) LIKE '%switch%' "
               "   OR lower(description) LIKE '%switch%'")
    else:
        sql = ("SELECT id, mpn, vendor, category, subcategory, description "
               "FROM parts WHERE lower(category) = 'switch'")
    return conn.execute(sql).fetchall()


def _existing_specs(conn, pid):
    out = {}
    for r in conn.execute("SELECT key, value_text, value_typ FROM specs "
                          "WHERE part_id=?", (pid,)):
        out[r["key"]] = r["value_text"] if r["value_text"] is not None \
            else r["value_typ"]
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--apply", action="store_true",
                    help="write the changes (default is a dry run)")
    ap.add_argument("--all-categories", action="store_true",
                    help="also consider parts whose category is not exactly "
                         "'switch' but which look like switches")
    ap.add_argument("--force-subcategory", action="store_true",
                    help="replace ANY existing subcategory, not just the old "
                         "throw-style ones")
    ap.add_argument("--datasheets", action="store_true",
                    help="also read each part's local datasheet when the "
                         "description says nothing (slower)")
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args(argv)

    conn = partdb.db()
    rows = _switch_rows(conn, args.all_categories)
    if args.limit:
        rows = rows[: args.limit]
    print(f"{len(rows)} candidate switch part(s) in {partdb.DB_PATH}")
    if not rows:
        print("Nothing to do. Try --all-categories if your switches are filed "
              "under another category.")
        return 0

    index = {}
    if args.datasheets and dsmine is not None:
        index = dsmine.build_index(say=lambda m: print(f"  {m}"))

    stats = Counter()
    type_from = Counter()
    examples = {"absorptive": [], "reflective": [], "config": []}
    plan = []

    for r in rows:
        pid = r["id"]
        text_bits = [r["description"] or "", r["subcategory"] or "",
                     r["mpn"] or ""]
        specs = _existing_specs(conn, pid)
        for k in ("configuration", "subtype", "product_status", "features",
                  "industry_application"):
            v = specs.get(k)
            if isinstance(v, str):
                text_bits.append(v)
        blob = " ".join(text_bits)

        stype = specmatch.parse_switch_type(blob)
        if stype:
            type_from["description/specs"] += 1
        cfg = specmatch.parse_throw_config(blob)

        if (not stype or not cfg) and index:
            mined = dsmine.mine_part(r["mpn"], index) if dsmine else []
            ds_text = ""
            key = dsmine._loose(r["mpn"]) if dsmine else ""
            path = index.get(key)
            if path:
                ds_text = dsmine.datasheet_text(path, max_chars=20000)
            if ds_text:
                if not stype:
                    stype = specmatch.parse_switch_type(ds_text)
                    if stype:
                        type_from["datasheet"] += 1
                if not cfg:
                    cfg = specmatch.parse_throw_config(ds_text)

        cur_sub = (r["subcategory"] or "").strip().lower()
        new_sub = None
        if stype in _VALID_TYPES:
            replaceable = args.force_subcategory or cur_sub in _LEGACY_THROW_SUBCATS
            if cur_sub != stype and replaceable:
                new_sub = stype
            elif cur_sub == stype:
                stats["subcategory already correct"] += 1
            else:
                stats["subcategory kept (not a legacy value)"] += 1
        else:
            stats["no construction type stated"] += 1

        have_cfg = specs.get("throw_config")
        new_cfg = None
        if cfg and not have_cfg:
            new_cfg = cfg
        elif cfg and have_cfg:
            stats["throw_config already set"] += 1
        elif not cfg:
            stats["no throw config stated"] += 1

        if new_sub or new_cfg:
            plan.append((pid, r["mpn"], r["vendor"], cur_sub, new_sub, new_cfg))
            if new_sub:
                stats[f"subcategory -> {new_sub}"] += 1
                if len(examples[new_sub]) < 4:
                    examples[new_sub].append(r["mpn"])
            if new_cfg:
                stats[f"throw_config -> set"] += 1
                if len(examples["config"]) < 6:
                    examples["config"].append(f"{r['mpn']}={new_cfg}")

    print(f"\nwould change {len(plan)} part(s)")
    for k, n in stats.most_common():
        print(f"   {n:>6}  {k}")
    if type_from:
        print("   construction type found in: "
              + ", ".join(f"{k} {v}" for k, v in type_from.most_common()))
    for k in ("absorptive", "reflective"):
        if examples[k]:
            print(f"   e.g. {k}: {', '.join(examples[k])}")
    if examples["config"]:
        print(f"   e.g. config: {', '.join(examples['config'])}")

    if not args.apply:
        print("\nDRY RUN -- nothing written. Re-run with --apply to commit.")
        return 0
    if not plan:
        print("\nNothing to write.")
        return 0

    changed_sub = changed_cfg = 0
    for pid, mpn, vendor, cur_sub, new_sub, new_cfg in plan:
        if new_sub:
            with conn:
                conn.execute("UPDATE parts SET subcategory=? WHERE id=?",
                             (new_sub, pid))
            changed_sub += 1
        if new_cfg:
            # Written at the same low confidence the datasheet miner uses, so a
            # future catalog value that states the configuration outright will
            # take precedence over this inference.
            partdb.put_specs(pid, [SpecRow(
                key="throw_config", value_text=new_cfg, unit="",
                method="hotfix-switch-types", confidence=0.45,
                snippet="inferred from published description text")])
            changed_cfg += 1
    print(f"\nwrote {changed_sub} subcategory change(s) and {changed_cfg} "
          f"throw_config value(s)")
    print("Search Switches in the GUI: Config is the dropdown under Category, "
          "Subcategory is now Absorptive/Reflective.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
