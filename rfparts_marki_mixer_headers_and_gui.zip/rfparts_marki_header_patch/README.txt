Marki mixer table-header patch

Changed files:
  pythonrfparts/specmatch.py
  pythonrfparts/partdb.py
  pythonrfparts/gui.py

Also included unchanged for convenience:
  toplevel/dbg_part_specs.py

What changed:
- Resolves RF/LO Low/High [GHz] before generic label normalization.
- Resolves IF Low/High [GHz] as distinct band edges.
- Uses [dBm] to distinguish LO drive-power Low/High from LO frequency.
- Fans shared RF/LO frequency edges into both rf_freq_ghz and lo_freq_ghz.
- Preserves partial bands without crashing the GUI.
- Freezes the results-table header while vertically scrolling.

After installing, rerun the dataset rebuild or force Marki source reparse so old
stored rows are replaced by the newly distinguished keys.
